<?php
//SITE
$port = 2052;
$root = '/';
$path = $_GET['page'];

$settings = '/var/server' . $root . 'settings.json';

$sitename = 'VGOWitch.com';
$siteabbreviation = 'VGOWitch';
$siteurl = 'https://vgowitch.com';
$sitekeywords = 'jackpot, coinflip, csgo, cs, go, global, offensive, cs:go, vgo, csgocoinflip, csgocoinflip, csgosite, vgocoinflip, vgocoinflip, vgosite, site, vgokingdom, kingdom, bet, gambling, gamble, fair, best, great, csgoempire, csgoatse, csgo500, crypto, btc, eth, roulette, experience';
$siteauthor = 'MrCHICK';
$sitedescription = $sitename . ' - The best crypto place to win money!';
$themecolor = '#9370db';

$mailer = array(
	'host' => 'smtp.gmail.com',
	'port' => 465,
	'secure' => true,
	'email' => '',
	'password' => ''
);

//SOCIAL MEDIA
$link_steam = 'http://steamcommunity.com/groups/VGOWitch';
$link_twitter = 'https://twitter.com/mrchick01';

$names_pages = array(
	'roulette' => 'Roulette', 
	'crash' => 'Crash', 
	'coinflip' => 'Coinflip', 
	'jackpot' => 'Jackpot', 
	'dice' => 'Dice',
	'casebattle' => 'Case Battle',
	'unboxing' => 'Unboxing',
	'upgrader' => 'Upgrader',
	'minesweeper' => 'Minesweeper',
	'tower' => 'Tower',
	'plinko' => 'Plinko',
	'profile' => 'Profile',
	'rewards' => 'Rewards',
	'deposit' => 'Deposit',
	'withdraw' => 'Withdraw',
	'tos' => 'Terms Of Service',
	'support' => 'Support',
	'fair' => 'Provably Fair',
	'faq' => 'Frequently Asked Questions',
	'maintenance' => 'Maintenance',
	'leaderboard' => 'Leaderboard',
	'banned' => 'Banned',
	'reset' => 'Reset Password',
	'home' => 'Home',
	'admin' => 'Admin',
	'dashboard' => 'Dashboard',
	'affiliates' => 'Affiliates',
);

$ranks_name = array('0' => 'member', '1' => 'admin', '2' => 'moderator', '3' => 'helper', '4' => 'veteran', '5' => 'pro', '6' => 'youtuber', '7' => 'streamer', '8' => 'developer', '100' => 'owner');

$banip_excluded = array('owner');
$ban_excluded = array('owner');
$maintenance_excluded = array('owner', 'developer', 'admin', 'moderator', 'helper');
$bonus_allowed = array('owner', 'admin');
$support_allowed = array('owner');
$profile_allowed = array('owner', 'admin');
$refillshop_allowed = array('owner');
$session_extended = array('owner', 'admin', 'moderator');

$settings_json_object = file_get_contents($settings);
$settings_json_decoded = json_decode($settings_json_object, true);

$admin_allowed = $settings_json_decoded['allowed']['admin'];
$dashboard_allowed = $settings_json_decoded['allowed']['dashboard'];

$steam_methods_name = array(
	'csgo' => 'CS:GO',
	'dota2' => 'Dota 2',
	'tf2' => 'Team Fortress 2',
	'rust' => 'Rust',
	'h1z1' => 'H1Z1'
);

$p2p_methods_name = array(
	'csgo' => 'CS:GO',
	'dota2' => 'Dota 2',
	'tf2' => 'Team Fortress 2',
	'rust' => 'Rust',
	'h1z1' => 'H1Z1'
);

$crypto_methods_name = array(
	'eth' => 'Ethereum',
	'btc' => 'Bitcoin',
	'ltc' => 'Litecoin',
	'bch' => 'Bitcoin Cash',
	'usdc' => 'USD Coin',
	'usdt' => 'Tether',
	'doge' => 'Dogecoin',
	'xrp' => 'Ripple'
);

$binds_allowed = array('steam', 'google', 'discord');

$countdown_recover = 10;
$cooldown_verify = 2 * 60;
$cooldown_security_twofa = 2 * 60;
$cooldown_security_login = 2 * 60;

$level_start = 500;
$level_next = 0.235;

$steam = array(
	'apikey' => ''
);

$crypto_coinpayments = array(
	'merchant' => '',
	'secret' => ''
);

$recaptcha = array(
	'sitekey' => ''
);

$google = array(
	'client' => '',
	'secret' => ''
);

$discord = array(
	'client' => '',
	'secret' => ''
);

$rewards_amounts = array(
	'steam' => 0.50,
	'google' => 0.50,
	'discord' => 0.50,
	'facebook' => 0.50,
	'refferal_code' => 1.00,
	'daily_start' => 0.20,
	'daily_step' => 0.02
);

$affiliates_requirements = array(0.00, 200.00, 500.00, 750.00, 1000.00, 2000.00, 3500.00, 5000.00, 7500.00, 10000.00);
$affiliates_commission = array('deposit' => 1, 'bet' => 2);

$sql_maintenance = $db->query('SELECT * FROM `maintenance` WHERE `removed` = 0 ORDER BY `id` DESC LIMIT 1');
$row_maintenance = $sql_maintenance->fetch(PDO::FETCH_ASSOC);

//HAVE SUPPORTS ACTIVE
$sql_support = $db->query('SELECT COUNT(*) AS `total` FROM `support_tickets` INNER JOIN `support_receivers` ON support_tickets.id = support_receivers.supportid WHERE (support_tickets.userid = ' . $db->quote($user['userid']) . ' || support_receivers.userid = ' . $db->quote($user['userid']) . ' || ' . $db->quote($user['rank']) . ' = 100) AND support_tickets.closed = 0 AND support_receivers.removed = 0 AND (SELECT `response` FROM `support_messages` WHERE `supportid` = support_tickets.id ORDER BY `id` DESC LIMIT 1) = 0');
$row_support = $sql_support->fetch(PDO::FETCH_ASSOC);

//CALLBACK
$affiliates['requirements'] = $affiliates_requirements;
$affiliates['commission'] = $affiliates_commission;

$profile['have_supports'] = $row_support['total'] > 0;

$site['root'] = $root;
$site['port'] = $port;
$site['recaptcha'] = $recaptcha;
$site['path'] = $path;
$site['name'] = $sitename;
$site['keywords'] = $sitekeywords;
$site['author'] = $siteauthor;
$site['url'] = $siteurl;
$site['description'] = $sitedescription;
$site['link_steam'] = $link_steam;
$site['link_twitter'] = $link_twitter;
$site['maintenance'] = $sql_maintenance->rowCount() > 0;
$site['theme_color'] = $themecolor;

$site['ranks_name'] = $ranks_name;
$site['permissions'] = array(
	'banip' => $banip_excluded,
	'ban' => $ban_excluded,
	'maintenance' => $maintenance_excluded,
	'bonus' => $bonus_allowed,
	'support' => $support_allowed,
	'profile' => $profile_allowed,
	'refillshop' => $refillshop_allowed
);

$site['access'] = array(
	'admin' => $admin_allowed,
	'dashboard' => $dashboard_allowed,
);

?>