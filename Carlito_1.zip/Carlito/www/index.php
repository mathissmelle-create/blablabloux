<?php
ini_set('display_errors','Off');

/*

if (!(isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||  isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&   $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')){
   $redirect = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
   header('HTTP/1.1 301 Moved Permanently');
   header('location: ' . $redirect);
   exit();
}

*/

/* INCLUDES */

include 'sql.php';

include 'functions/others.php';

include 'functions/check.php';

include 'config/config.php';

include 'functions/support.php';
include 'functions/security.php';
include 'functions/auth.php';
include 'functions/mailer.php';

/* END INCLUDES */

$default_page = 'home';

$parameters = array();
foreach($_GET as $key => $value) if($key != 'page') array_push($parameters,  $key . '=' . $value);

if(sizeof($parameters) > 0) $default_page .= '?' . implode('&', $parameters);

if(!isset($_GET['page'])) {
	header('location: ' . $root . $default_page);
	exit();
}

$paths_all = explode('/', $_GET['page']);
$paths = array();

foreach($paths_all as $key => $path) if(!empty(trim($path))) array_push($paths, trim($path));

if(sizeof($paths) == 0 || empty($paths[0])){
	header('location: ' . $root . $default_page);
	exit();
}

$page = $paths[0];

if(isset($_GET['ref'])){
	$sql_referrals = $db->query('SELECT * FROM `link_referrals` WHERE `referral` = ' . $db->quote($_GET['ref']). ' AND `removed` = 0 AND (`expire` > ' . $db->quote(time()) . ' OR `expire` = -1)');
	
	if($sql_referrals->rowCount() > 0) {
		$row_referrals = $sql_referrals->fetch(PDO::FETCH_ASSOC);
		
		$sql_join_referrals = $db->prepare('INSERT INTO `join_referrals` SET `referral` = ' . $db->quote($row_referrals['referral']) . ', `ip` = ' . $db->quote(getUserIp()) . ', `location` = ' . $db->quote(getUserLocation(getUserIp())) . ', `agent` = ' . $db->quote(getUserAgent()) . ', `time` = ' . $db->quote(time()));
		$row_join_referrals = $sql_join_referrals->execute();
	}
	
	header('location: ' . $root . implode('/', $paths));
	exit();
}

$sql_join_visitors = $db->prepare('INSERT INTO `join_visitors` SET `link` = ' . $db->quote(getSiteLink()) . ', `ip` = ' . $db->quote(getUserIp()) . ', `location` = ' . $db->quote(getUserLocation(getUserIp())) . ', `agent` = ' . $db->quote(getUserAgent()) . ', `time` = ' . $db->quote(time()));
$row_join_visitors = $sql_join_visitors->execute();

$array_page = array('user' => $user, 'security' => $security, 'site' => $site, 'profile' => $profile, 'rewards' => $rewards, 'affiliates' => $affiliates, 'paths' => $paths);

$sql_banip = $db->query('SELECT * FROM `bannedip` WHERE `ip` = ' . $db->quote(getUserIp()) . ' AND `removed` = 0');
if($sql_banip->rowCount() > 0 && !in_array($ranks_name[$user['rank']], $banip_excluded)){
	$page_request = getTemplate('Your IP is banned.', 'empty');
	echo $page_request;
	exit();
}

if($sql_maintenance->rowCount() > 0 && !in_array($ranks_name[$user['rank']], $maintenance_excluded) && !($page == 'auth' && in_array($paths[1], array('login', 'logout', 'register', 'steam', 'google', 'discord', 'facebook', 'recover', 'logout'))) && $page != 'security') {
	$page_request = getTemplate($names_pages['maintenance'], 'maintenance', $array_page, array('response' => array('maintenance' => array('reason' => $row_maintenance['reason'])))); //MAINTENANCE
	echo $page_request;
	exit();
}

$sql_bansite = $db->query('SELECT users_restrictions.reason, users_restrictions.expire, users.name FROM `users_restrictions` INNER JOIN `users` ON users_restrictions.byuserid = users.userid WHERE users_restrictions.restriction = "site" AND users_restrictions.removed = 0 AND (users_restrictions.expire = -1 OR users_restrictions.expire > ' . $db->quote(time()) . ') AND users_restrictions.userid = ' . $db->quote($user['userid']));
if($sql_bansite->rowCount() > 0 && !in_array($ranks_name[$user['rank']], $ban_excluded) && $page != 'support' && $page != 'tos') {
	$row_bansite = $sql_bansite->fetch(PDO::FETCH_ASSOC);
	
	$page_request = getTemplatePage($names_pages['banned'], $page, 'banned', $array_page, array('response' => array('ban' => array('name' => $row_bansite['name'], 'reason' => $row_bansite['reason'], 'expire' => $row_bansite['expire'])))); //BANNED
	echo $page_request;
	exit();
}

switch ($page) {
	case 'admin':
		if(!in_array($user['userid'], $site['access']['admin'])) break;
		
		if(!isset($paths[1])){
			header('location: ' . $root . 'admin/control');
			exit();
		}
		
		$location = $page;
		
		switch($paths[1]){
			case 'control':
				$response = array();
				
				$maintenance = array('status' => $sql_maintenance->rowCount() > 0);
				if($sql_maintenance->rowCount() > 0) $maintenance['reason'] = $row_maintenance['reason'];
				
				$response['settings'] = array_merge($settings_json_decoded, array('maintenance' => $maintenance));
				
				$sql_join_referrals_list = $db->query('SELECT `id`, `userid`, `referral`, `usage` FROM `link_referrals` WHERE `removed` = 0 AND (`expire` > ' . $db->quote(time()) . ' OR `expire` = -1) ORDER BY `id` ASC LIMIT 10');
				$row_join_referrals_list = $sql_join_referrals_list->fetchAll(PDO::FETCH_ASSOC);
				
				$sql_join_referrals_count = $db->query('SELECT COUNT(*) AS `count` FROM `link_referrals` WHERE `removed` = 0 AND (`expire` > ' . $db->quote(time()) . ' OR `expire` = -1)');
				$row_join_referrals_count = $sql_join_referrals_count->fetch(PDO::FETCH_ASSOC);
				
				$join_referrals_count = intval($row_join_referrals_count['count'] / 10) + (($row_join_referrals_count['count'] % 10) > 0 ? 1 : 0);
				if($join_referrals_count <= 0) $join_referrals_count = 1;
				
				$response['join_referrals'] = array('list' => $row_join_referrals_list, 'pages' => $join_referrals_count, 'page' => 1);
				
				$sql_deposit_bonuses_list = $db->query('SELECT `id`, `referral`, `code`, `uses`, `amount` FROM `deposit_codes` WHERE `removed` = 0 ORDER BY `id` ASC LIMIT 10');
				$row_deposit_bonuses_list = $sql_deposit_bonuses_list->fetchAll(PDO::FETCH_ASSOC);
				
				$sql_deposit_bonuses_count = $db->query('SELECT COUNT(*) AS `count` FROM `deposit_codes` WHERE `removed` = 0');
				$row_deposit_bonuses_count = $sql_deposit_bonuses_count->fetch(PDO::FETCH_ASSOC);
				
				$deposit_bonuses_count = intval($row_deposit_bonuses_count['count'] / 10) + (($row_deposit_bonuses_count['count'] % 10) > 0 ? 1 : 0);
				if($deposit_bonuses_count <= 0) $deposit_bonuses_count = 1;
				
				$response['deposit_bonuses'] = array('list' => $row_deposit_bonuses_list, 'pages' => $deposit_bonuses_count, 'page' => 1);
				
				$location .= '_control';
				
				break;
			
			case 'users':
				$response = array();
				
				if(isset($paths[2])){
					$sql_user = $db->query('SELECT * FROM `users` WHERE `bot` = 0 AND `userid` = ' . $db->quote($paths[2]));
					
					if($sql_user->rowCount() <= 0) {
						header('location: ' . $root . 'admin/users');
						exit();
					}
					
					$row_user = $sql_user->fetch(PDO::FETCH_ASSOC);
					
					$response['user'] = array( 'profile' => $row_user );
					
					$sql_security = $db->query('SELECT * FROM `users_twofa` WHERE `userid` = ' . $db->quote($paths[2]) . ' AND `activated` = 1 AND `removed` = 0');
					$response['user']['twofa'] = $sql_security->rowCount() > 0;
					
					$sql_binds = $db->query('SELECT `bind`, `bindid` FROM `users_binds` WHERE `removed` = 0 AND `userid` = ' . $db->quote($paths[2]));
					$row_binds = $sql_binds->fetchAll(PDO::FETCH_ASSOC);
					
					$user_binds = array();
					
					foreach(array_keys($settings_json_decoded['server']['binds']) as $key => $value){
						$user_binds[$value] = array( 'bind' => false );
					}
					
					foreach($row_binds as $key => $value) {
						if(in_array($value['bind'], array_keys(array_filter($settings_json_decoded['server']['binds'], function($value) { return $value === true; })))) $user_binds[$value['bind']] = array( 'bind' => true, 'bindid' => $value['bindid']);
					}
					
					$response['user']['binds'] = $user_binds;
					
					$sql_restrictions = $db->query('SELECT `restriction`, `reason`, `expire` FROM `users_restrictions` WHERE `removed` = 0 AND (`expire` = -1 OR `expire` > ' . $db->quote(time()) . ') AND `userid` = ' . $db->quote($paths[2]));
					$row_restrictions = $sql_restrictions->fetchAll(PDO::FETCH_ASSOC);
					
					$user_restrictions = array(
						'play' => array( 'active' => false ),
						'trade' => array( 'active' => false ),
						'site' => array( 'active' => false ),
						'mute' => array( 'active' => false )
					);
					foreach($row_restrictions as $key => $value) {
						$user_restrictions[$value['restriction']] = array( 'active' => true, 'expire' => $value['expire']);
					}
					
					$response['user']['restrictions'] = $user_restrictions;
					
					$sql_devices = $db->query('SELECT COUNT(*) AS `count` FROM `users_sessions` WHERE `userid` = ' . $db->quote($paths[2]) . ' AND `removed` = 0 AND `expire` > ' . $db->quote(time()));
					$row_devices = $sql_devices->fetch(PDO::FETCH_ASSOC);
					
					$response['user']['devices'] = $row_devices['count'];
					
					$sql_ips = $db->query('SELECT DISTINCT users_logins.ip FROM `users_sessions` INNER JOIN `users_logins` ON users_sessions.userid = users_logins.userid AND users_sessions.id = users_logins.sessionid WHERE users_logins.id = (SELECT users_logins_test.id FROM `users_logins` `users_logins_test` WHERE users_logins.sessionid = users_logins_test.sessionid ORDER BY users_logins_test.time DESC LIMIT 1) AND users_sessions.userid = ' . $db->quote($paths[2]) . ' AND users_sessions.removed = 0 AND users_sessions.expire > ' . $db->quote(time()));
					$row_ips = $sql_ips->fetchAll(PDO::FETCH_ASSOC);
					
					$ips = array();
					foreach($row_ips as $key => $value) {
						array_push($ips, $value['ip']);
					}
					
					$response['user']['ips'] = $ips;
					
					$sql_bannedips = $db->query('SELECT DISTINCT bannedip.ip FROM `bannedip` INNER JOIN `users_logins` ON bannedip.ip = users_logins.ip WHERE users_logins.userid = ' . $db->quote($paths[2]) . ' AND bannedip.removed = 0');
					$row_bannedips = $sql_bannedips->fetchAll(PDO::FETCH_ASSOC);
					
					$bannedips = array();
					foreach($row_bannedips as $key => $value) {
						array_push($bannedips, $value['ip']);
					}
					
					$response['user']['bannedips'] = $bannedips;
				}
				
				$sql_users_list = $db->query('SELECT `userid`, `name`, `avatar`, `xp`,  `balance`, `rank`, `time_create` FROM `users` WHERE `bot` = 0 ORDER BY `id` ASC LIMIT 10');
				$row_users_list = $sql_users_list->fetchAll(PDO::FETCH_ASSOC);
				
				$sql_users_count = $db->query('SELECT COUNT(*) AS `count` FROM `users` WHERE `bot` = 0');
				$row_users_count = $sql_users_count->fetch(PDO::FETCH_ASSOC);
				
				$users_count = intval($row_users_count['count'] / 10) + (($row_users_count['count'] % 10) > 0 ? 1 : 0);
				if($users_count <= 0) $users_count = 1;
				
				$response['users'] = array('list' => $row_users_list, 'pages' => $users_count, 'page' => 1);
				
				$location .= '_users';
				
				break;
				
			case 'trades':
				$response = array();
				
				$maintenance = array('status' => $sql_maintenance->rowCount() > 0);
				if($sql_maintenance->rowCount() > 0) $maintenance['reason'] = $row_maintenance['reason'];
				
				$response['settings'] = $settings_json_decoded;
				
				//STEAM
				$sql_steam_list = $db->query('SELECT `id`, `userid`, `items`, `amount`, `game`, `time` FROM `steam_listings` WHERE `confirmed` = 0 AND `canceled` = 0 ORDER BY `id` ASC LIMIT 10');
				$row_steam_list = $sql_steam_list->fetchAll(PDO::FETCH_ASSOC);
				
				$sql_steam_count = $db->query('SELECT COUNT(*) AS `count` FROM `steam_listings` WHERE `confirmed` = 0 AND `canceled` = 0');
				$row_steam_count = $sql_steam_count->fetch(PDO::FETCH_ASSOC);
				
				$steam_count = intval($row_steam_count['count'] / 10) + (($row_steam_count['count'] % 10) > 0 ? 1 : 0);
				if($steam_count <= 0) $steam_count = 1;
				
				$response['steam'] = array('list' => $row_steam_list, 'pages' => $steam_count, 'page' => 1);
				
				//CRYPTO
				$sql_crypto_list = $db->query('SELECT `id`, `userid`, `amount`, `currency`, `time` FROM `crypto_listings` WHERE `confirmed` = 0 AND `canceled` = 0 ORDER BY `id` ASC LIMIT 10');
				$row_crypto_list = $sql_crypto_list->fetchAll(PDO::FETCH_ASSOC);
				
				$sql_crypto_count = $db->query('SELECT COUNT(*) AS `count` FROM `crypto_listings` WHERE `confirmed` = 0 AND `canceled` = 0');
				$row_crypto_count = $sql_crypto_count->fetch(PDO::FETCH_ASSOC);
				
				$crypto_count = intval($row_crypto_count['count'] / 10) + (($row_crypto_count['count'] % 10) > 0 ? 1 : 0);
				if($crypto_count <= 0) $crypto_count = 1;
				
				$response['crypto'] = array('list' => $row_crypto_list, 'pages' => $crypto_count, 'page' => 1);
				
				$response['methods'] = array(
					'steam' => $settings_json_decoded['trades']['steam']['enable'],
					'p2p' => $settings_json_decoded['trades']['p2p']['enable'],
					'crypto' => $settings_json_decoded['trades']['crypto']['enable']
				);
		
				$response['methods_name'] = array(
					'steam' => $steam_methods_name,
					'p2p' => $p2p_methods_name,
					'crypto' => $crypto_methods_name
				);
				
				$location .= '_trades';
				
				break;
				
			case 'casecreator':
				$response = array();
				
				$allowed_functions = array('create', 'edit');
				
				if(isset($paths[2])){
					if(in_array($paths[2], $allowed_functions)){
						$allowed_creators = array('cases', 'dailycases');
						
						if(isset($paths[3])){
							if(in_array($paths[3], $allowed_creators)){
								if($paths[2] == 'edit'){
									if(isset($paths[4])){
										$table = array( 'cases' => 'cases_cases', 'dailycases' => 'cases_dailycases' )[$paths[3]];
										
										$sql_casecreator_edit = $db->query('SELECT * FROM `' . $table . '` WHERE `caseid` = ' . $db->quote($paths[4]) . ' AND `removed` = 0');
										
										if($sql_casecreator_edit->rowCount() > 0){
											$location .= '_casecreator_' . $paths[2] . '_' . $paths[3];
											
											break;
										}
										
										header('location: ' . $root . 'admin/casecreator/' . $paths[2] . '/cases');
										exit();
									}
									
									$location .= '_casecreator_' . $paths[2];
									
									break;
								}
								
								$location .= '_casecreator_' . $paths[2] . '_' . $paths[3];
								
								break;
							}
						}
						
						header('location: ' . $root . 'admin/casecreator/' . $paths[2] . '/cases');
						exit();
					}
				}
				
				header('location: ' . $root . 'admin/casecreator/create');
				exit();
				
				break;
			
			case 'gamebots':
				$response = array();
				
				$sql_bots_list = $db->query('SELECT `userid`, `name`, `avatar`, `xp`, `balance` FROM `users` WHERE `bot` = 1 ORDER BY `id` ASC LIMIT 10');
				$row_bots_list = $sql_bots_list->fetchAll(PDO::FETCH_ASSOC);
				
				$sql_bots_count = $db->query('SELECT COUNT(*) AS `count` FROM `users` WHERE `bot` = 1');
				$row_bots_count = $sql_bots_count->fetch(PDO::FETCH_ASSOC);
				
				$bots_count = intval($row_bots_count['count'] / 10) + (($row_bots_count['count'] % 10) > 0 ? 1 : 0);
				if($bots_count <= 0) $bots_count = 1;
				
				$response['bots'] = array('list' => $row_bots_list, 'pages' => $bots_count, 'page' => 1);
				
				$response['settings'] = $settings_json_decoded;
				
				$location .= '_bots';
				
				break;
			
			default:
				header('location: ' . $root . 'admin');
				exit();
				
				break;
		}
		
		$page_request = getTemplatePage($names_pages[$page], $page, $location, $array_page, array('response' => $response));
		echo $page_request;
		return;
		
	case 'dashboard':
		if(!in_array($user['userid'], $site['access']['dashboard'])) break;
	
		$page_request = getTemplatePage($names_pages[$page], $page, $page, $array_page);
		echo $page_request;
		return;
	
	case 'home':
		$page_request = getTemplatePage($names_pages[$page], $page, $page, $array_page);
		echo $page_request;
		return;
	
	case 'affiliates':
		$response_affiliates = array();
		
		$sql_referral = $db->query('SELECT * FROM `referral_codes` WHERE `userid` = ' . $db->quote($user['userid']));
		if($sql_referral->rowCount() > 0) {
			$row_referral = $sql_referral->fetch(PDO::FETCH_ASSOC);
			
			$response_affiliates['collected'] = $row_referral['collected'];
			$response_affiliates['available'] = $row_referral['available'];
		}
		
		$response_affiliates['commission_wagered'] = 0;
		$response_affiliates['commission_deposited'] = 0;
		$response_affiliates['deposited'] = 0;
		
		$sql_deposited = $db->query('SELECT COALESCE(SUM(referral_deposited.amount), 0) AS `amount` FROM `referral_uses` INNER JOIN `referral_deposited` ON referral_uses.userid = referral_deposited.userid WHERE referral_deposited.referral = ' . $db->quote($user['userid']));
		if($sql_deposited->rowCount() > 0) {
			$row_deposited = $sql_deposited->fetch(PDO::FETCH_ASSOC);
			
			$response_affiliates['deposited'] = $row_deposited['amount'];
		}
		
		$sql_affiliates_deposited = $db->query('SELECT COALESCE(SUM(referral_deposited.amount), 0) AS `amount`, COALESCE(SUM(referral_deposited.commission), 0) AS `commission`, referral_uses.userid FROM `referral_uses` LEFT JOIN `referral_deposited` ON referral_uses.userid = referral_deposited.userid WHERE referral_uses.referral = ' . $db->quote($user['userid']) . ' AND COALESCE(referral_deposited.referral, ' . $db->quote($user['userid']) . ') = ' . $db->quote($user['userid']) . ' GROUP BY referral_uses.userid ORDER BY `amount` DESC LIMIT 50');
		$sql_affiliates_wagered = $db->query('SELECT COALESCE(SUM(referral_wagered.amount), 0) AS `amount`, COALESCE(SUM(referral_wagered.commission), 0) AS `commission`, referral_uses.userid FROM `referral_uses` LEFT JOIN `referral_wagered` ON referral_uses.userid = referral_wagered.userid WHERE referral_uses.referral = ' . $db->quote($user['userid']) . ' AND COALESCE(referral_wagered.referral, ' . $db->quote($user['userid']) . ') = ' . $db->quote($user['userid']) . ' GROUP BY referral_uses.userid ORDER BY `amount` DESC LIMIT 50');
		$row_affiliates_deposited = $sql_affiliates_deposited->fetchAll(PDO::FETCH_ASSOC);
		$row_affiliates_wagered = $sql_affiliates_wagered->fetchAll(PDO::FETCH_ASSOC);
		
		$response_affiliates['referrals'] = array();
		
		foreach($row_affiliates_deposited as $key => $value){
			$response_affiliates['referrals'][$value['userid']]['userid'] = $value['userid'];
			$response_affiliates['referrals'][$value['userid']]['deposited'] = $value['amount'];
			$response_affiliates['referrals'][$value['userid']]['commission_deposited'] = $value['commission'];
			
			$response_affiliates['commission_deposited'] += $value['commission'];
		}
		
		foreach($row_affiliates_wagered as $key => $value){
			$response_affiliates['referrals'][$value['userid']]['userid'] = $value['userid'];
			$response_affiliates['referrals'][$value['userid']]['wagered'] = $value['amount'];
			$response_affiliates['referrals'][$value['userid']]['commission_wagered'] = $value['commission'];
			
			$response_affiliates['commission_wagered'] += $value['commission'];
		}
		
		usort($response_affiliates['referrals'], function($first, $second){
			return ($first['commission_deposited'] + $first['commission_wagered'] < $second['commission_deposited'] + $second['commission_wagered']);
		});
		
		$response_affiliates['referrals'] = array_slice($response_affiliates['referrals'], 0, 50);
		
		$response['affiliates'] = $response_affiliates;
	
		$page_request = getTemplatePage($names_pages[$page], $page, $page, $array_page, array('response' => $response));
		echo $page_request;
		return;
	
	case 'roulette':
		$page_request = getTemplatePage($names_pages[$page], $page, $page, $array_page);
		echo $page_request;
		return;
	
	case 'crash':
		$page_request = getTemplatePage($names_pages[$page], $page, $page, $array_page);
		echo $page_request;
		return;
		
	case 'jackpot':
		$page_request = getTemplatePage($names_pages[$page], $page, $page, $array_page);
		echo $page_request;
		return;
		
	case 'coinflip':
		$page_request = getTemplatePage($names_pages[$page], $page, $page, $array_page);
		echo $page_request;
		return;
		
	case 'dice':
		$page_request = getTemplatePage($names_pages[$page], $page, $page, $array_page);
		echo $page_request;
		return;
		
	case 'casebattle':
		if(!isset($paths[1])){
			header('location: ' . $root . 'casebattle/list/active');
			exit();
		}
		
		$location = $page;
		$name_page = $names_pages[$page];
		
		switch($paths[1]){
			case 'list':
				if(isset($paths[2])){
					if(!in_array($paths[2], array('active', 'finished', 'my'))){
						header('location: ' . $root . 'casebattle/list/active');
						exit();
					}
				}
				
				$location .= '_lobby';
				
				break;
				
			case 'create':
				$location .= '_create';
				
				break;
			
			default:
				$location .= '_game';
				$name_page .= ' #' . $paths[1];
				
				break;
		}
		
		$page_request = getTemplatePage($name_page, $page, $location, $array_page);
		echo $page_request;
		return;
		
	case 'unboxing':
		$location = $page;
		$name_page = $names_pages[$page];
		
		if(isset($paths[1])) {
			$location .= '_case';
		
			$name_page = ucwords(implode(' ', explode('_', $paths[1])));
		}
	
		$page_request = getTemplatePage($name_page, $page, $location, $array_page);
		echo $page_request;
		return;
		
	case 'upgrader':
		session_start();
		
		if(isset($paths[1])) {
			$_SESSION['upgrader'] = $paths[1];
			
			header('location: ' . $root . 'upgrader');
			exit();
		}
		
		$upgrader_items = array();
		
		if(isset($_SESSION['upgrader'])){
			array_push($upgrader_items, $_SESSION['upgrader']);
			
			unset($_SESSION['upgrader']);
		}
		
		$page_request = getTemplatePage($names_pages[$page], $page, $page, $array_page, array('response' => array('items' => $upgrader_items)));
		echo $page_request;
		return;
		
	case 'minesweeper':
		$page_request = getTemplatePage($names_pages[$page], $page, $page, $array_page);
		echo $page_request;
		return;
		
	case 'tower':
		$page_request = getTemplatePage($names_pages[$page], $page, $page, $array_page);
		echo $page_request;
		return;
		
	case 'plinko':
		$page_request = getTemplatePage($names_pages[$page], $page, $page, $array_page);
		echo $page_request;
		return;
		
	case 'leaderboard':
		$total = 20;
		
		$sql_leaderboard = $db->query('SELECT users.userid, users.name, users.avatar, (SELECT SUM(amount) FROM `users_transactions` WHERE users_transactions.userid = users.userid AND `amount` > 0 GROUP BY users_transactions.userid) AS `winnings`, (SELECT SUM(amount) FROM `users_transactions` WHERE users_transactions.userid = users.userid AND `amount` < 0 GROUP BY users_transactions.userid) AS `bets`, (SELECT COUNT(users_transactions.userid) FROM `users_transactions` WHERE users_transactions.userid = users.userid AND `amount` < 0 GROUP BY users_transactions.userid) AS `games` FROM `users` INNER JOIN `users_transactions` ON users.userid = users_transactions.userid WHERE users.userid IN (SELECT users_transactions.userid FROM (SELECT users_transactions.userid, SUM(amount) AS `profit` FROM `users_transactions` WHERE `amount` < 0 GROUP BY users_transactions.userid ORDER BY `profit` ASC LIMIT ' . $total . ') AS `profit_tabel`) AND users_transactions.amount < 0 GROUP BY users.userid ORDER BY `bets` ASC');
		$row_leaderboard = $sql_leaderboard->fetchAll(PDO::FETCH_ASSOC);
	
		$page_request = getTemplatePage($names_pages[$page], $page, $page, $array_page, array('response' => array('leaderboard' => $row_leaderboard)));
		echo $page_request;
		return;
	
	case 'profile':
		if(!$user && !isset($paths[1])) {
			$page_request = getTemplatePage($names_pages[$page], $page, 'login', $array_page);
			echo $page_request;
			return;
		}
	
		$userid = $user['userid'];
		$user_profile = $user;
		
		if(isset($paths[1])) $userid = $paths[1];
		
		$sql_user = $db->query('SELECT * FROM `users` WHERE `userid` = ' . $db->quote($userid));
		if($sql_user->rowCount() > 0) {
			$user_profile = $sql_user->fetch(PDO::FETCH_ASSOC);
		} else {
			header('location: ' . $root);
			exit();
		}
		
		$response = array();
		$response['looking'] = isset($paths[1]);
		$response['profile'] = $user_profile;
		
		//SECURITY
		$sql_security = $db->query('SELECT * FROM `users_twofa` WHERE `userid` = ' . $db->quote($userid) . ' AND `activated` = 1 AND `removed` = 0');
		$response['twofa'] = $sql_security->rowCount() > 0;
		
		//USER STATS
		if(in_array($ranks_name[$user['rank']], $profile_allowed) || !$response['profile']['private'] || !$response['looking']){
			$sql_winnings = $db->query('SELECT SUM(`amount`) AS `total` FROM `users_transactions` WHERE `userid` = ' . $db->quote($userid) . ' AND `amount` > 0');
			$row_winnings = $sql_winnings->fetch(PDO::FETCH_ASSOC);

			$sql_bets = $db->query('SELECT SUM(`amount`) AS `total` FROM `users_transactions` WHERE `userid` = ' . $db->quote($userid) . ' AND `amount` < 0');
			$row_bets = $sql_bets->fetch(PDO::FETCH_ASSOC);
			
			$user_stats = array( 'win' => abs($row_winnings['total']), 'bet' => abs($row_bets['total']) );
			
			$response['user_stats'] = $user_stats;
		}
		
		//USER SESSIONS
		if(in_array($ranks_name[$user['rank']], $profile_allowed) || !$response['looking']){
			$sql_sessions = $db->query('SELECT users_sessions.id, users_sessions.session, users_logins.ip, users_logins.location, users_logins.agent, users_logins.time FROM `users_sessions` INNER JOIN `users_logins` ON users_sessions.userid = users_logins.userid AND users_sessions.id = users_logins.sessionid WHERE users_logins.id = (SELECT users_logins_test.id FROM `users_logins` `users_logins_test` WHERE users_logins.sessionid = users_logins_test.sessionid ORDER BY users_logins_test.time DESC LIMIT 1) AND users_sessions.userid = ' . $db->quote($userid) . ' AND users_sessions.removed = 0 AND users_sessions.expire > ' . $db->quote(time()));
			$row_sessions = $sql_sessions->fetchAll(PDO::FETCH_ASSOC);

			$response['user_sessions'] = $row_sessions;
		}
		
		//USER TRANSFERS
		if(in_array($ranks_name[$user['rank']], $profile_allowed) || !$response['looking']){
			$sql_user_transfers_list = $db->query('SELECT `id`, `from_userid`, `to_userid`, `amount`, `time` FROM `users_transfers` WHERE `to_userid` = ' . $db->quote($userid) . ' OR `from_userid` = ' . $db->quote($userid) . ' ORDER BY `id` DESC LIMIT 10');
			$row_user_transfers_list = $sql_user_transfers_list->fetchAll(PDO::FETCH_ASSOC);
			
			$sql_user_transfers_count = $db->query('SELECT COUNT(*) AS `count` FROM `users_transfers`  WHERE `to_userid` = ' . $db->quote($userid) . ' OR `from_userid` = ' . $db->quote($userid));
			$row_user_transfers_count = $sql_user_transfers_count->fetch(PDO::FETCH_ASSOC);
			
			$user_transfers_count = intval($row_user_transfers_count['count'] / 10) + (($row_user_transfers_count['count'] % 10) > 0 ? 1 : 0);
			if($user_transfers_count <= 0) $user_transfers_count = 1;
			
			$response['user_transfers'] = array('list' => $row_user_transfers_list, 'pages' => $user_transfers_count, 'page' => 1);
		}
		
		//STEAM TRANSACTIONS
		if(in_array($ranks_name[$user['rank']], $profile_allowed) || !$response['looking']){
			$sql_steam_transactions_list = $db->query('SELECT `id`, `status`, `tradeofferid`, `code`, `amount`, `type`, `game`, `refill`, `time` FROM `steam_transactions` WHERE `userid` = ' . $db->quote($userid) . ' ORDER BY `id` DESC LIMIT 10');
			$row_steam_transactions_list = $sql_steam_transactions_list->fetchAll(PDO::FETCH_ASSOC);
			
			$sql_steam_transactions_count = $db->query('SELECT COUNT(*) AS `count` FROM `steam_transactions` WHERE `userid` = ' . $db->quote($userid));
			$row_steam_transactions_count = $sql_steam_transactions_count->fetch(PDO::FETCH_ASSOC);
			
			$steam_transactions_count = intval($row_steam_transactions_count['count'] / 10) + (($row_steam_transactions_count['count'] % 10) > 0 ? 1 : 0);
			if($steam_transactions_count <= 0) $steam_transactions_count = 1;
			
			$response['steam_transactions'] = array('list' => $row_steam_transactions_list, 'pages' => $steam_transactions_count, 'page' => 1);
		}
		
		//P2P TRANSACTIONS
		if(in_array($ranks_name[$user['rank']], $profile_allowed) || !$response['looking']){
			$sql_p2p_transactions_list = $db->query('SELECT p2p_transactions.*, COALESCE(p2p_buyers.canceled, -1) AS `canceled`, IF(COALESCE(p2p_buyers.userid, 0) = ' . $db->quote($userid) . ', 1, 0) AS `type` FROM `p2p_transactions` LEFT JOIN `p2p_buyers` ON p2p_transactions.id = p2p_buyers.offerid WHERE p2p_buyers.userid = ' . $db->quote($userid) . ' OR p2p_transactions.userid = ' . $db->quote($userid) . ' ORDER BY p2p_transactions.id DESC LIMIT 10');
			$row_p2p_transactions_list = $sql_p2p_transactions_list->fetchAll(PDO::FETCH_ASSOC);
			
			foreach($row_p2p_transactions_list as $key => $value) {
				if(intval($value['type']) == 1) $row_p2p_transactions_list[$key]['type'] = 'withdraw';
				else $row_p2p_transactions_list[$key]['type'] = 'deposit';
				
				if(intval($value['canceled']) == 1 && intval($value['type']) == 1) $row_p2p_transactions_list[$key]['status'] = -1;
			}
			
			$sql_p2p_transactions_count = $db->query('SELECT COUNT(*) AS `count` FROM `p2p_transactions` LEFT JOIN `p2p_buyers` ON p2p_transactions.id = p2p_buyers.offerid WHERE p2p_buyers.userid = ' . $db->quote($userid) . ' OR p2p_transactions.userid = ' . $db->quote($userid));
			$row_p2p_transactions_count = $sql_p2p_transactions_count->fetch(PDO::FETCH_ASSOC);
			
			$p2p_transactions_count = intval($row_p2p_transactions_count['count'] / 10) + (($row_p2p_transactions_count['count'] % 10) > 0 ? 1 : 0);
			if($p2p_transactions_count <= 0) $p2p_transactions_count = 1;
			
			$response['p2p_transactions'] = array('list' => $row_p2p_transactions_list, 'pages' => $p2p_transactions_count, 'page' => 1);
		}
		
		//CRYPTO TRANSACTIONS
		if(in_array($ranks_name[$user['rank']], $profile_allowed) || !$response['looking']){
			$sql_crypto_transactions_list = $db->query('SELECT `id`, `status`, `txnid`, `amount`, `type`, `currency`, `time` FROM `crypto_transactions` WHERE `userid` = ' . $db->quote($userid) . ' ORDER BY `id` DESC LIMIT 10');
			$row_crypto_transactions_list = $sql_crypto_transactions_list->fetchAll(PDO::FETCH_ASSOC);
			
			$sql_crypto_transactions_count = $db->query('SELECT COUNT(*) AS `count` FROM `crypto_transactions` WHERE `userid` = ' . $db->quote($userid));
			$row_crypto_transactions_count = $sql_crypto_transactions_count->fetch(PDO::FETCH_ASSOC);
			
			$crypto_transactions_count = intval($row_crypto_transactions_count['count'] / 10) + (($row_crypto_transactions_count['count'] % 10) > 0 ? 1 : 0);
			if($crypto_transactions_count <= 0) $crypto_transactions_count = 1;
			
			$response['crypto_transactions'] = array('list' => $row_crypto_transactions_list, 'pages' => $crypto_transactions_count, 'page' => 1);
		}
		
		//USER GAMES STATS
		if(in_array($ranks_name[$user['rank']], $profile_allowed) || !$response['profile']['private'] || !$response['looking']){
			$sql_games_stats = $db->query('SELECT SUM(amount) AS `total`, `service` FROM (SELECT `amount`, `service` FROM `users_transactions` WHERE `service` IN ("roulette_bet", "roulette_win", "crash_bet", "crash_win", "coinflip_bet", "coinflip_win", "coinflip_refund", "jackpot_bet", "jackpot_win", "dice_bet", "dice_win", "unboxing_bet", "unboxing_win", "casebattle_bet", "casebattle_win", "casebattle_refund", "upgrader_bet", "upgrader_win", "minesweeper_bet", "minesweeper_win", "tower_bet", "tower_win", "plinko_bet", "plinko_win") AND `userid` = ' . $db->quote($userid) . ' UNION ALL SELECT `amount`, `service` FROM `users_items_transactions` WHERE `service` IN ("unboxing_win", "casebattle_win", "upgrader_bet", "upgrader_win") AND `userid` = ' . $db->quote($userid) . ') AS `table` GROUP BY `service`');
			$row_games_stats = $sql_games_stats->fetchAll(PDO::FETCH_ASSOC);
			
			$games_stats = array();
			foreach($row_games_stats as $key => $value) {
				$service = explode('_', $value['service']);
				
				if(!isset($games_stats[$service[0]])) $games_stats[$service[0]] = array( 'bet' => 0, 'win' => 0, 'refund' => 0 );
				
				$games_stats[$service[0]][$service[1]] = abs($value['total']);
			}
			
			$response['games_stats'] = $games_stats;
		}
		
		//USER OFFERS STATS
		if(!$response['profile']['private'] || !$response['looking']){
			$sql_offers_stats = $db->query('SELECT SUM(amount) AS `total`, COUNT(amount) AS `count`, `type` FROM `users_trades` WHERE `userid` = ' . $db->quote($userid) . ' GROUP BY `type`');
			$row_offers_stats = $sql_offers_stats->fetchAll(PDO::FETCH_ASSOC);
			
			$offers_stats = array(
				'deposit' => array( 'count' => 0, 'total' => 0 ),
				'withdraw' => array( 'count' => 0, 'total' => 0 )
			);
			foreach($row_offers_stats as $key => $value) {
				$offers_stats[$value['type']] = array( 'count' => $value['count'], 'total' => $value['total'] );
			}
			
			$response['offers_stats'] = $offers_stats;
		}
		
		//USER TRANSACTIONS
		if(in_array($ranks_name[$user['rank']], $profile_allowed) || !$response['looking']){
			$sql_user_transactions_list = $db->query('SELECT `id`, `service`, `amount`, `time` FROM `users_transactions` WHERE `userid` = ' . $db->quote($userid) . ' ORDER BY `id` DESC LIMIT 10');
			$row_user_transactions_list = $sql_user_transactions_list->fetchAll(PDO::FETCH_ASSOC);
			
			$balance = 0;
			if($sql_user_transactions_list->rowCount() > 0) {
				if(array_reverse($row_user_transactions_list)[0]['id'] > 0){
					$sql8 = $db->query('SELECT SUM(amount) AS `balance` FROM `users_transactions` WHERE `userid` = ' . $db->quote($userid) . ' AND `id` < ' . array_reverse($row_user_transactions_list)[0]['id']);
					$row8 = $sql8->fetch(PDO::FETCH_ASSOC);
					
					$balance = floatval($row8['balance']);
				}
			}
			
			$user_transactions_list = array();
			foreach(array_reverse($row_user_transactions_list) as $key => $value) {
				array_push($user_transactions_list, array(
					'id' => $value['id'],
					'service' => $value['service'],
					'balance' => $balance,
					'amount' => $value['amount'],
					'time' => $value['time']
				));
				
				$balance += floatval($value['amount']);
			}
			
			$user_transactions_list = array_reverse($user_transactions_list);
			
			$sql_user_transactions_count = $db->query('SELECT COUNT(*) AS `count` FROM `users_transactions` WHERE `userid` = ' . $db->quote($userid));
			$row_user_transactions_count = $sql_user_transactions_count->fetch(PDO::FETCH_ASSOC);
			
			$user_transactions_count = intval($row_user_transactions_count['count'] / 10) + (($row_user_transactions_count['count'] % 10) > 0 ? 1 : 0);
			if($user_transactions_count <= 0) $user_transactions_count = 1;
			
			$response['user_transactions'] = array('list' => $user_transactions_list, 'pages' => $user_transactions_count, 'page' => 1);
		}
		
		//BINDS
		if(in_array($ranks_name[$user['rank']], $profile_allowed) || !$response['looking']){
			$sql_binds = $db->query('SELECT `bind`, `bindid` FROM `users_binds` WHERE `removed` = 0 AND `userid` = ' . $db->quote($userid));
			$row_binds = $sql_binds->fetchAll(PDO::FETCH_ASSOC);
			
			$user_binds = array();
			
			foreach(array_keys($settings_json_decoded['server']['binds']) as $key => $value){
				$user_binds[$value] = array( 'bind' => false );
			}
			
			foreach($row_binds as $key => $value) {
				if(in_array($value['bind'], array_keys(array_filter($settings_json_decoded['server']['binds'], function($value) { return $value === true; })))) $user_binds[$value['bind']] = array( 'bind' => true, 'bindid' => $value['bindid']);
			}
			
			$response['user_binds'] = $user_binds;
		}
		
		$response['binds'] = array_keys(array_filter($settings_json_decoded['server']['binds'], function($value) { return $value === true; }));
		
		$page_request = getTemplatePage($names_pages[$page], $page, $page, $array_page, array('response' => $response));
		echo $page_request;
		return;
	
	case 'rewards':
		if(!$user) {
			$page_request = getTemplatePage($names_pages[$page], $page, 'login', $array_page);
			echo $page_request;
			return;
		}
		
		$response = array();
		$response['rewards'] = array();
		
		$response['rewards']['amounts'] = $rewards_amounts;
		
		$response['rewards']['referral_have'] = 0;
		
		$sql_referral = $db->query('SELECT * FROM `referral_codes` WHERE `userid` = ' . $db->quote($user['userid']));
		if($sql_referral->rowCount() > 0) {
			$row_referral = $sql_referral->fetch(PDO::FETCH_ASSOC);
			
			$response['rewards']['referral_have'] = 1;
			$response['rewards']['referral_code'] = $row_referral['code'];
		}
		
		$sql_code = $db->query('SELECT * FROM `referral_uses` WHERE `userid` = ' . $db->quote($user['userid']));
		$response['rewards']['collected_code'] = 0;
		
		if($sql_code->rowCount() > 0) {
			$row_code = $sql_code->fetch(PDO::FETCH_ASSOC);
			
			$response['rewards']['collected_code'] = 1;
			
			$sql_referral_owner = $db->query('SELECT * FROM `users` WHERE `userid` = ' . $db->quote($row_code['referral']));
			$row_referral_owner = $sql_referral_owner->fetch(PDO::FETCH_ASSOC);
			
			$response['rewards']['referral_owner'] = $row_referral_owner['name'];
		}
		
		$sql_bind_steam = $db->query('SELECT * FROM `users_rewards` WHERE `reward` = ' . $db->quote('steam').' AND `userid` = '.$db->quote($user['userid']));
		$sql_bind_google = $db->query('SELECT * FROM `users_rewards` WHERE `reward` = ' . $db->quote('google').' AND `userid` = '.$db->quote($user['userid']));
		$sql_bind_discord = $db->query('SELECT * FROM `users_rewards` WHERE `reward` = ' . $db->quote('discord').' AND `userid` = '.$db->quote($user['userid']));
		$sql_bind_facebook = $db->query('SELECT * FROM `users_rewards` WHERE `reward` = ' . $db->quote('facebook').' AND `userid` = '.$db->quote($user['userid']));
		
		$sql_name = $db->query('SELECT * FROM `users_rewards` WHERE `reward` = ' . $db->quote('name').' AND `userid` = '.$db->quote($user['userid']));
		$sql_group = $db->query('SELECT * FROM `users_rewards` WHERE `reward` = ' . $db->quote('group').' AND `userid` = '.$db->quote($user['userid']));
		
		$response['rewards']['collected_steam'] = $sql_bind_steam->rowCount();
		$response['rewards']['collected_google'] = $sql_bind_google->rowCount();
		$response['rewards']['collected_discord'] = $sql_bind_discord->rowCount();
		$response['rewards']['collected_facebook'] = $sql_bind_facebook->rowCount();
		
		$response['rewards']['collected_name'] = $sql_name->rowCount();
		$response['rewards']['collected_group'] = $sql_group->rowCount();
		
		//BINDS
		$sql_binds = $db->query('SELECT `bind`, `bindid` FROM `users_binds` WHERE `removed` = 0 AND `userid` = ' . $db->quote($user['userid']));
		$row_binds = $sql_binds->fetchAll(PDO::FETCH_ASSOC);
		
		$user_binds = array();
		
		foreach(array_keys($settings_json_decoded['server']['binds']) as $key => $value){
			$user_binds[$value] = array( 'bind' => false );
		}
		
		foreach($row_binds as $key => $value) {
			if(in_array($value['bind'], array_keys(array_filter($settings_json_decoded['server']['binds'], function($value) { return $value === true; })))) $user_binds[$value['bind']] = array( 'bind' => true, 'bindid' => $value['bindid']);
		}
		
		$response['user_binds'] = $user_binds;
	
		$page_request = getTemplatePage($names_pages[$page], $page, $page, $array_page,  array('response' => $response));
		echo $page_request;
		return;

	case 'deposit':
		$location = $page;
		
		if(isset($paths[1])){
			switch($paths[1]){
				case 'steam':
					if(isset($paths[2])){
						if(in_array($paths[2], array_keys($settings_json_decoded['trades']['steam']['enable']['deposit']))){
							if($settings_json_decoded['trades']['steam']['enable']['deposit'][$paths[2]]){
								$location .= '_steam';
								
								break;
							}
						}
					}
					
					header('location: ' . $root . 'deposit');
					exit();
					
					break;
				
				case 'p2p':
					if(isset($paths[2])){
						if(in_array($paths[2], array_keys($settings_json_decoded['trades']['p2p']['enable']['deposit']))){
							if($settings_json_decoded['trades']['p2p']['enable']['deposit'][$paths[2]]){
								$location .= '_p2p';
								
								break;
							}
						}
					}
					
					header('location: ' . $root . 'deposit');
					exit();
					
					break;
				
				case 'crypto':
					if(isset($paths[2])){
						if(in_array($paths[2], array_keys($settings_json_decoded['trades']['crypto']['enable']['deposit']))){
							if($settings_json_decoded['trades']['crypto']['enable']['deposit'][$paths[2]]){
								$crypto_addresses = array();
								
								foreach(array_keys($settings_json_decoded['trades']['crypto']['enable']['deposit']) as $key => $value){
									$crypto_addresses[$value] = null;
								}
								
								$sql_addresses = $db->query('SELECT * FROM `crypto_addresses` WHERE `userid` = ' . $db->quote($user['userid']) . ' AND `removed` = 0');
								$row_addresses = $sql_addresses->fetchAll(PDO::FETCH_ASSOC);
								
								foreach($row_addresses as $key => $value){
									if(in_array($value['currency'], array_keys($settings_json_decoded['trades']['crypto']['enable']['deposit']))) $crypto_addresses[$value['currency']] = $value['address'];
								}
								
								$array_page['addresses'] = $crypto_addresses;
								
								$location .= '_currency';
								
								break;
							}
						}
					}
					
					header('location: ' . $root . 'deposit');
					exit();
					
					break;
				
				default:
					header('location: ' . $root . 'deposit');
					exit();
					
					break;
			}
		}
		
		$response = array();
		
		$response['deposit_bonus'] = '';
		$sql_deposit_bonus = $db->query('SELECT deposit_codes.code FROM `deposit_uses` INNER JOIN `deposit_codes` ON deposit_uses.bonus = deposit_codes.id WHERE deposit_uses.userid = ' . $db->quote($user['userid']). ' AND deposit_uses.removed = 0');
		if($sql_deposit_bonus->rowCount() > 0) {
			$row_deposit_bonus = $sql_deposit_bonus->fetch(PDO::FETCH_ASSOC);
			
			$response['deposit_bonus'] = $row_deposit_bonus['code'];
		}
		
		$response['methods'] = array(
			'steam' => $settings_json_decoded['trades']['steam']['enable']['deposit'],
			'p2p' => $settings_json_decoded['trades']['p2p']['enable']['deposit'],
			'crypto' => $settings_json_decoded['trades']['crypto']['enable']['deposit']
		);
		
		$response['methods_name'] = array(
			'steam' => $steam_methods_name,
			'p2p' => $p2p_methods_name,
			'crypto' => $crypto_methods_name
		);
		
		$page_request = getTemplatePage($names_pages[$page], $page, $location, $array_page, array('response' => $response));
		echo $page_request;
		return;
		
	case 'withdraw':
		$location = $page;
	
		if(isset($paths[1])){
			switch($paths[1]){
				case 'steam':
					if(isset($paths[2])){
						if(in_array($paths[2], array_keys($settings_json_decoded['trades']['steam']['enable']['withdraw']))){
							if($settings_json_decoded['trades']['steam']['enable']['withdraw'][$paths[2]]){
								$location .= '_steam';
								
								break;
							}
						}
					}
					
					header('location: ' . $root . 'withdraw');
					exit();
					
					break;
				
				case 'p2p':
					if(isset($paths[2])){
						if(in_array($paths[2], array_keys($settings_json_decoded['trades']['p2p']['enable']['withdraw']))){
							if($settings_json_decoded['trades']['p2p']['enable']['withdraw'][$paths[2]]){
								$location .= '_p2p';
								
								break;
							}
						}
					}
					
					header('location: ' . $root . 'withdraw');
					exit();
					
					break;
				
				case 'crypto':
					if(isset($paths[2])){
						if(in_array($paths[2], array_keys($settings_json_decoded['trades']['crypto']['enable']['withdraw']))){
							if($settings_json_decoded['trades']['crypto']['enable']['withdraw'][$paths[2]]){
								$crypto_addresses = array();
								
								foreach(array_keys($settings_json_decoded['trades']['crypto']['enable']['withdraw']) as $key => $value){
									$crypto_addresses[$value] = null;
								}
								
								$sql_addresses = $db->query('SELECT * FROM `crypto_addresses` WHERE `userid` = ' . $db->quote($user['userid']) . ' AND `removed` = 0');
								$row_addresses = $sql_addresses->fetchAll(PDO::FETCH_ASSOC);
								
								foreach($row_addresses as $key => $value){
									if(in_array($value['currency'], array_keys($settings_json_decoded['trades']['crypto']['enable']['withdraw']))) $crypto_addresses[$value['currency']] = $value['address'];
								}
								
								$array_page['addresses'] = $crypto_addresses;
								
								$location .= '_currency';
								
								break;
							}
						}
					}
					
					header('location: ' . $root . 'withdraw');
					exit();
					
					break;
				
				default:
					header('location: ' . $root . 'withdraw');
					exit();
					
					break;
			}
		}
		
		$response = array();
		
		$response['methods'] = array(
			'steam' => $settings_json_decoded['trades']['steam']['enable']['withdraw'],
			'p2p' => $settings_json_decoded['trades']['p2p']['enable']['withdraw'],
			'crypto' => $settings_json_decoded['trades']['crypto']['enable']['withdraw']
		);
		
		$response['methods_name'] = array(
			'steam' => $steam_methods_name,
			'p2p' => $p2p_methods_name,
			'crypto' => $crypto_methods_name
		);
		
		$response['manually_amount'] = $settings_json_decoded['trades']['manually']['amount'];
	
		$page_request = getTemplatePage($names_pages[$page], $page, $location, $array_page, array('response' => $response));
		echo $page_request;
		return;
		
	case 'tos':
		$page_request = getTemplatePage($names_pages[$page], $page, $page, $array_page);
		echo $page_request;
		return;
		
	case 'support':
		$support = array();
		$tickets = array();
		
		if(!$user && (isset($_POST['new']) || isset($_POST['reply']) || isset($_POST['close']) || isset($_POST['redirect']))) exit(json_encode(array('success' => false, 'error' => 'Session expired or you are not logged in. Please refresh the page and try again.')));
		
		if(isset($_POST['new'])){
			$title = htmlspecialchars($_POST['title'], ENT_QUOTES);
			$department = $_POST['department'];
			$message = htmlspecialchars($_POST['message'], ENT_QUOTES);
			
			support_createTicket(array( 'user' => $user, 'title' => $title, 'department' => $department, 'message' => $message ), function($err1){
				if($err1) exit(json_encode(array('success' => false, 'error' => $err1)));
					
				exit(json_encode(array('success' => true, 'message' => 'Successfully created a new ticket!')));
			});
		} else if(isset($_POST['reply'])){
			$id = $_GET['id'];
			$message = htmlspecialchars($_POST['message'], ENT_QUOTES);
			
			support_replyTicket(array( 'user' => $user, 'id' => $id, 'message' => $message ), function($err1){
				if($err1) exit(json_encode(array('success' => false, 'error' => $err1)));
					
				exit(json_encode(array('success' => true, 'message' => 'Successfully replied the ticket!')));
			});
		} else if(isset($_POST['close'])){
			$id = $_GET['id'];
			
			support_closeTicket(array( 'user' => $user, 'id' => $id ), function($err1){
				if($err1) exit(json_encode(array('success' => false, 'error' => $err1)));
					
				exit(json_encode(array('success' => true, 'message' => 'Successfully closed the ticket!')));
			});
		} else if(isset($_POST['redirect'])){
			$id = $_GET['id'];
			$department = intval($_POST['department']);
			
			support_redirectTicket(array( 'user' => $user, 'id' => $id, 'department' => $department ), function($err1){
				if($err1) exit(json_encode(array('success' => false, 'error' => $err1)));
					
				exit(json_encode(array('success' => true, 'message' => 'Successfully redirected the ticket!')));
			});
		}
		
		if($user['rank'] == 100) $sql_support = $db->query('SELECT support_tickets.id, support_tickets.userid AS `sender_userid`, support_tickets.name AS `sender_name`, support_receivers.userid AS `receiver_userid`, support_receivers.name AS `receiver_name`, support_tickets.closed, support_tickets.title, support_tickets.department, support_tickets.time FROM `support_tickets` INNER JOIN `support_receivers` ON support_tickets.id = support_receivers.supportid WHERE support_receivers.removed = 0 ORDER BY support_tickets.id DESC');
		else $sql_support = $db->query('SELECT support_tickets.id, support_tickets.userid AS `sender_userid`, support_tickets.name AS `sender_name`, support_receivers.userid AS `receiver_userid`, support_receivers.name AS `receiver_name`, support_tickets.closed, support_tickets.title, support_tickets.department, support_tickets.time FROM `support_tickets` INNER JOIN `support_receivers` ON support_tickets.id = support_receivers.supportid WHERE (support_tickets.userid = ' . $db->quote($user['userid']) . ' || support_receivers.userid = ' . $db->quote($user['userid']) . ') AND support_receivers.removed = 0 ORDER BY support_tickets.id DESC');
		$row_support = $sql_support->fetchAll(PDO::FETCH_ASSOC);
		$support = $row_support;
		
		if($user['rank'] == 100) $sql_tickets = $db->query('SELECT support_messages.id, support_messages.supportid, support_messages.message, support_messages.userid, support_messages.name, support_messages.avatar, support_messages.xp, support_messages.response, support_messages.time FROM `support_messages` INNER JOIN `support_tickets` ON support_messages.supportid = support_tickets.id INNER JOIN `support_receivers` ON support_tickets.id = support_receivers.supportid WHERE support_receivers.removed = 0');
		else $sql_tickets = $db->query('SELECT support_messages.id, support_messages.supportid, support_messages.message, support_messages.userid, support_messages.name, support_messages.avatar, support_messages.xp, support_messages.response, support_messages.time FROM `support_messages` INNER JOIN `support_tickets` ON support_messages.supportid = support_tickets.id INNER JOIN `support_receivers` ON support_tickets.id = support_receivers.supportid WHERE (support_tickets.userid = ' . $db->quote($user['userid']) . ' || support_receivers.userid = ' . $db->quote($user['userid']) . ') AND support_receivers.removed = 0');
		$row_tickets = $sql_tickets->fetchAll(PDO::FETCH_ASSOC);
		$tickets = $row_tickets;
		
		$page_request = getTemplatePage($names_pages[$page], $page, $page, $array_page, array('response' => array('support' => $support, 'tickets' => $tickets)));
		echo $page_request;
		return;
		
	case 'fair':
		//USER
		$sql_fair_serverseeds = $db->query('SELECT * FROM `users_seeds_server` WHERE `userid` = ' . $db->quote($user['userid']) . ' ORDER BY `id` DESC LIMIT 50');
		$row_sql_fair_serverseeds = $sql_fair_serverseeds->fetchAll(PDO::FETCH_ASSOC);
		
		$fair_serverseeds = array();
		foreach($row_sql_fair_serverseeds as $key => $value){
			$using = intval($value['removed']) == 0;
			
			array_push($fair_serverseeds, array(
				'id' => $value['id'],
				'using' => $using,
				'seed' => ($using) ? hash('sha256', $value['seed']) : $value['seed'],
				'nonce' => $value['nonce'],
				'time' => $value['time']
			));
		}
		
		$sql_fair_clientseed = $db->query('SELECT `seed` FROM `users_seeds_client` WHERE `userid` = ' . $db->quote($user['userid']) . ' AND `removed` = 0 ORDER BY `id` DESC LIMIT 1');
		$row_fair_clientseed = $sql_fair_clientseed->fetch(PDO::FETCH_ASSOC);
		
		//GAMES
		$sql_seeds_roulette = $db->query('SELECT * FROM `roulette_seeds` ORDER BY `id` DESC LIMIT 7');
		$row_seeds_roulette = $sql_seeds_roulette->fetchAll(PDO::FETCH_ASSOC);
		
		$seeds_roulette = array();
		foreach($row_seeds_roulette as $key => $value){
			$sql_games_roulette = $db->query('SELECT `roll`, `color`, `nonce` FROM `roulette_rolls` WHERE `ended` = 1 AND `seedid` = ' . $db->quote($value['id']) . ' ORDER BY `id` ASC');
			$row_games_roulette = $sql_games_roulette->fetchAll(PDO::FETCH_ASSOC);
			
			$using = $value['time'] > time() - (24 * 60 * 60);
			
			array_push($seeds_roulette, array(
				'id' => $value['id'],
				'using' => $using,
				'server_seed' => ($using) ? hash('sha256', $value['server_seed']) : $value['server_seed'],
				'public_seed' => $value['public_seed'],
				'games' => $row_games_roulette,
				'time' => $value['time']
			));
		}
		
		$sql_seeds_crash = $db->query('SELECT * FROM `crash_seeds` ORDER BY `id` DESC LIMIT 7');
		$row_seeds_crash = $sql_seeds_crash->fetchAll(PDO::FETCH_ASSOC);
		
		$seeds_crash = array();
		foreach($row_seeds_crash as $key => $value){
			$sql_games_roulette = $db->query('SELECT `point`, `nonce` FROM `crash_rolls` WHERE `ended` = 1 AND `seedid` = ' . $db->quote($value['id']) . ' ORDER BY `id` ASC');
			$row_games_roulette = $sql_games_roulette->fetchAll(PDO::FETCH_ASSOC);
			
			$using = $value['time'] > time() - (24 * 60 * 60);
			
			array_push($seeds_crash, array(
				'id' => $value['id'],
				'using' => $using,
				'server_seed' => ($using) ? hash('sha256', $value['server_seed']) : $value['server_seed'],
				'public_seed' => $value['public_seed'],
				'games' => $row_games_roulette,
				'time' => $value['time']
			));
		}
		
		$sql_histories_jackpot = $db->query('SELECT jackpot_games.id, jackpot_games.server_seed, jackpot_rolls.public_seed, jackpot_rolls.blockid, jackpot_rolls.roll, jackpot_games.time FROM `jackpot_games` INNER JOIN `jackpot_rolls` ON jackpot_games.id = jackpot_rolls.gameid WHERE jackpot_games.ended = 1 AND jackpot_rolls.removed = 0 ORDER BY jackpot_games.id DESC LIMIT 50');
		$row_histories_jackpot = $sql_histories_jackpot->fetchAll(PDO::FETCH_ASSOC);
		
		$sql_histories_coinflip = $db->query('SELECT coinflip_games.id, coinflip_games.server_seed, coinflip_rolls.public_seed, coinflip_rolls.blockid, coinflip_rolls.roll, coinflip_games.time FROM `coinflip_games` INNER JOIN `coinflip_rolls` ON coinflip_games.id = coinflip_rolls.gameid WHERE coinflip_games.ended = 1 AND coinflip_rolls.removed = 0 ORDER BY coinflip_games.id DESC LIMIT 50');
		$row_histories_coinflip = $sql_histories_coinflip->fetchAll(PDO::FETCH_ASSOC);
		
		$sql_histories_casebattle = $db->query('SELECT casebattle_games.id, casebattle_games.server_seed, casebattle_rolls.public_seed, casebattle_rolls.blockid, casebattle_rolls.roll, casebattle_games.time FROM `casebattle_games` INNER JOIN `casebattle_rolls` ON casebattle_games.id = casebattle_rolls.gameid WHERE casebattle_games.ended = 1 AND casebattle_rolls.removed = 0 ORDER BY casebattle_games.id DESC LIMIT 50');
		$row_histories_casebattle = $sql_histories_casebattle->fetchAll(PDO::FETCH_ASSOC);
		
		$fair_histories = array();
		
		$sql_histories_dice = $db->query('SELECT dice_bets.id, users_seeds_server.removed, users_seeds_server.seed AS `server_seed`, users_seeds_client.seed AS `client_seed`, dice_bets.nonce, dice_bets.roll FROM `dice_bets` INNER JOIN `users_seeds_server` ON dice_bets.server_seedid = users_seeds_server.id INNER JOIN `users_seeds_client` ON dice_bets.client_seedid = users_seeds_client.id WHERE dice_bets.userid = ' . $db->quote($user['userid']) . ' ORDER BY dice_bets.id DESC LIMIT 50');
		$row_histories_dice = $sql_histories_dice->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($row_histories_dice as $key => $value){
			$using = intval($value['removed']) == 0;
			
			if(!isset($fair_histories['dice'])) $fair_histories['dice'] = array();
			
			array_push($fair_histories['dice'], array(
				'id' => $value['id'],
				'using' => $using,
				'server_seed' => ($using) ? hash('sha256', $value['server_seed']) : $value['server_seed'],
				'client_seed' => $value['client_seed'],
				'nonce' => $value['nonce'],
				'roll' => $value['roll']
			));
		}
		
		$sql_histories_unboxing = $db->query('SELECT unboxing_bets.id, users_seeds_server.removed, users_seeds_server.seed AS `server_seed`, users_seeds_client.seed AS `client_seed`, unboxing_bets.nonce, unboxing_bets.tickets, unboxing_bets.roll FROM `unboxing_bets` INNER JOIN `users_seeds_server` ON unboxing_bets.server_seedid = users_seeds_server.id INNER JOIN `users_seeds_client` ON unboxing_bets.client_seedid = users_seeds_client.id WHERE unboxing_bets.userid = ' . $db->quote($user['userid']) . ' ORDER BY unboxing_bets.id DESC LIMIT 50');
		$row_histories_unboxing = $sql_histories_unboxing->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($row_histories_unboxing as $key => $value){
			$using = intval($value['removed']) == 0;
			
			if(!isset($fair_histories['unboxing'])) $fair_histories['unboxing'] = array();
			
			array_push($fair_histories['unboxing'], array(
				'id' => $value['id'],
				'using' => $using,
				'server_seed' => ($using) ? hash('sha256', $value['server_seed']) : $value['server_seed'],
				'client_seed' => $value['client_seed'],
				'nonce' => $value['nonce'],
				'tickets' => $value['tickets'],
				'roll' => $value['roll']
			));
		}
		
		$sql_histories_upgrader = $db->query('SELECT upgrader_bets.id, users_seeds_server.removed, users_seeds_server.seed AS `server_seed`, users_seeds_client.seed AS `client_seed`, upgrader_bets.nonce, upgrader_bets.roll FROM `upgrader_bets` INNER JOIN `users_seeds_server` ON upgrader_bets.server_seedid = users_seeds_server.id INNER JOIN `users_seeds_client` ON upgrader_bets.client_seedid = users_seeds_client.id WHERE upgrader_bets.userid = ' . $db->quote($user['userid']) . ' ORDER BY upgrader_bets.id DESC LIMIT 50');
		$row_histories_upgrader = $sql_histories_upgrader->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($row_histories_upgrader as $key => $value){
			$using = intval($value['removed']) == 0;
			
			if(!isset($fair_histories['upgrader'])) $fair_histories['upgrader'] = array();
			
			array_push($fair_histories['upgrader'], array(
				'id' => $value['id'],
				'using' => $using,
				'server_seed' => ($using) ? hash('sha256', $value['server_seed']) : $value['server_seed'],
				'client_seed' => $value['client_seed'],
				'nonce' => $value['nonce'],
				'roll' => $value['roll']
			));
		}
		
		$sql_histories_minesweeper = $db->query('SELECT minesweeper_bets.id, users_seeds_server.removed, users_seeds_server.seed AS `server_seed`, users_seeds_client.seed AS `client_seed`, minesweeper_bets.nonce, minesweeper_bets.roll FROM `minesweeper_bets` INNER JOIN `users_seeds_server` ON minesweeper_bets.server_seedid = users_seeds_server.id INNER JOIN `users_seeds_client` ON minesweeper_bets.client_seedid = users_seeds_client.id WHERE minesweeper_bets.userid = ' . $db->quote($user['userid']) . ' ORDER BY minesweeper_bets.id DESC LIMIT 50');
		$row_histories_minesweeper = $sql_histories_minesweeper->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($row_histories_minesweeper as $key => $value){
			$using = intval($value['removed']) == 0;
			
			if(!isset($fair_histories['minesweeper'])) $fair_histories['minesweeper'] = array();
			
			array_push($fair_histories['minesweeper'], array(
				'id' => $value['id'],
				'using' => $using,
				'server_seed' => ($using) ? hash('sha256', $value['server_seed']) : $value['server_seed'],
				'client_seed' => $value['client_seed'],
				'nonce' => $value['nonce'],
				'roll' => $value['roll']
			));
		}
		
		$sql_histories_tower = $db->query('SELECT tower_bets.id, users_seeds_server.removed, users_seeds_server.seed AS `server_seed`, users_seeds_client.seed AS `client_seed`, tower_bets.nonce, tower_bets.roll FROM `tower_bets` INNER JOIN `users_seeds_server` ON tower_bets.server_seedid = users_seeds_server.id INNER JOIN `users_seeds_client` ON tower_bets.client_seedid = users_seeds_client.id WHERE tower_bets.userid = ' . $db->quote($user['userid']) . ' ORDER BY tower_bets.id DESC LIMIT 50');
		$row_histories_tower = $sql_histories_tower->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($row_histories_tower as $key => $value){
			$using = intval($value['removed']) == 0;
			
			if(!isset($fair_histories['tower'])) $fair_histories['tower'] = array();
			
			array_push($fair_histories['tower'], array(
				'id' => $value['id'],
				'using' => $using,
				'server_seed' => ($using) ? hash('sha256', $value['server_seed']) : $value['server_seed'],
				'client_seed' => $value['client_seed'],
				'nonce' => $value['nonce'],
				'roll' => $value['roll']
			));
		}
		
		$sql_histories_plinko = $db->query('SELECT plinko_bets.id, users_seeds_server.removed, users_seeds_server.seed AS `server_seed`, users_seeds_client.seed AS `client_seed`, plinko_bets.nonce, plinko_bets.roll FROM `plinko_bets` INNER JOIN `users_seeds_server` ON plinko_bets.server_seedid = users_seeds_server.id INNER JOIN `users_seeds_client` ON plinko_bets.client_seedid = users_seeds_client.id WHERE plinko_bets.userid = ' . $db->quote($user['userid']) . ' ORDER BY plinko_bets.id DESC LIMIT 50');
		$row_histories_plinko = $sql_histories_plinko->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($row_histories_plinko as $key => $value){
			$using = intval($value['removed']) == 0;
			
			if(!isset($fair_histories['plinko'])) $fair_histories['plinko'] = array();
			
			array_push($fair_histories['plinko'], array(
				'id' => $value['id'],
				'using' => $using,
				'server_seed' => ($using) ? hash('sha256', $value['server_seed']) : $value['server_seed'],
				'client_seed' => $value['client_seed'],
				'nonce' => $value['nonce'],
				'roll' => $value['roll']
			));
		}
		
		$page_request = getTemplatePage($names_pages[$page], $page, $page, $array_page, array('response' => array('fair' => array('client_seed' => $row_fair_clientseed['seed'], 'server_seed' => $fair_serverseeds[0]['seed'], 'server_seeds' => $fair_serverseeds, 'roulette' => $seeds_roulette, 'crash' => $seeds_crash, 'jackpot' => $row_histories_jackpot, 'coinflip' => $row_histories_coinflip, 'casebattle' => $row_histories_casebattle, 'histories' => $fair_histories))));
		echo $page_request;
		return;
		
	case 'faq':
		$page_request = getTemplatePage($names_pages[$page], $page, $page, $array_page);
		echo $page_request;
		return;

	case 'auth':
		switch($paths[1]) {
			case 'login':
				if($user) exit(json_encode(array('success' => false, 'error' => 'User logged in')));
			
				$username = $_POST['username'];
				$password = $_POST['password'];
				
				auth_authByLogin(array( 'username' => $username, 'password' => $password ), function($err1, $session){
					if($err1) exit(json_encode(array('success' => false, 'error' => $err1)));
					
					setcookie('session', $session['session'], $session['expire'], $GLOBALS['root']);
					exit(json_encode(array('success' => true, 'reload' => true, 'refresh' => false, 'message' => array('have' => false))));
				});
				
				break;
				
			case 'register':
				if($user) exit(json_encode(array('success' => false, 'error' => 'User logged in')));
				
				$email = $_POST['email'];
				$username = $_POST['username'];
				$password = $_POST['password'];
				
				auth_authByRegister(array( 'email' => $email, 'username' => $username, 'password' => $password ), function($err1, $session){
					if($err1) exit(json_encode(array('success' => false, 'error' => $err1)));
					
					setcookie('session', $session['session'], $session['expire'], $GLOBALS['root']);
					exit(json_encode(array('success' => true, 'reload' => true, 'refresh' => false, 'message' => array('have' => false))));
				});
			
				break;
			
			case 'steam':
				session_start();
			
				$data_parms = array();
				
				foreach($_SESSION as $key => $value){
					unset($_SESSION[$key]);
					
					$data_parms[$key] = $value;
				}
				
				foreach($_GET as $key => $value){
					$_SESSION[$key] = $value;
				}
				
				include 'vendors/steam/openid.php';
				try{
					$openid = new LightOpenID($_SERVER['SERVER_NAME'] . $root);
					
					if (!$openid->mode) {
						if($user && !$_GET['assign']) return header('location: ' . $root . $_GET['return']);
						if(!$user && $_GET['assign']) return header('location: ' . $root . $_GET['return']);
						
						$openid->identity = 'http://steamcommunity.com/openid/';
						
						header('location: '.$openid->authUrl());
					} elseif ($openid->mode == 'cancel') {
						header('location: ' . $root . $data_parms['return']);
					} else {
						if(!$openid->validate()) exit('Invalid Steam Login');
						
						$id = $openid->identity;
						$ptn = '/^https:\/\/steamcommunity\.com\/openid\/id\/(7[0-9]{15,25}+)$/';
						preg_match($ptn, $id, $matches);
						
						$link = 'http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=' . $GLOBALS['steam']['apikey'] . '&steamids=' . $matches[1];
						$json_object = file_get_contents($link);
						$json_decoded = json_decode($json_object, true);
						
						if(!isset($json_decoded['response'])) exit('Invalid Steam Login Response (1)');
						if(!isset($json_decoded['response']['players'])) exit('Invalid Steam Login Response (2)');
						if(sizeof($json_decoded['response']['players']) <= 0) exit('Invalid Steam Login Response (3)');
						
						$steamid = $json_decoded['response']['players'][0]['steamid'];
						$name = htmlspecialchars($json_decoded['response']['players'][0]['personaname'], ENT_QUOTES);
						$avatar = $json_decoded['response']['players'][0]['avatarfull'];
						
						if($data_parms['assign']){
							auth_bindAccount(array( 'user' => $user, 'bind' => 'steam', 'bindid' => $steamid ), function($err1){
								if($err1) exit($err1);
							});
						} else {
							auth_authBySteam(array( 'id' => $steamid, 'name' => $name, 'avatar' => $avatar ), function($err1, $session){
								if($err1) exit($err1);
								
								setcookie('session', $session['session'], $session['expire'], $GLOBALS['root']);
							});
						}
						
						header('location: ' . $root . $data_parms['return']);
					}
				} catch (ErrorException $e) {
					exit($e->getMessage());
				}
			
				break;
				
			case 'google':
				session_start();
			
				$data_parms = array();
				
				foreach($_SESSION as $key => $value){
					unset($_SESSION[$key]);
					
					$data_parms[$key] = $value;
				}
				
				foreach($_GET as $key => $value){
					$_SESSION[$key] = $value;
				}
				
				require_once 'vendors/google_auth/vendor/autoload.php';
				try{
					$openid = new Google_Client();
					$openid->setClientId($google['client']);
					$openid->setClientSecret($google['secret']);
					$openid->setRedirectUri('https://' . $_SERVER['SERVER_NAME'] . $root . 'auth/google');
					$openid->addScope('email');
					$openid->addScope('profile');
					
					if(!isset($_GET['code'])){
						if($user && !$_GET['assign']) return header('location: ' . $root . $_GET['return']);
						if(!$user && $_GET['assign']) return header('location: ' . $root . $_GET['return']);
						
						header('location: ' . $openid->createAuthUrl());
					} else {
						$token = $openid->fetchAccessTokenWithAuthCode($_GET['code']);
						$openid->setAccessToken($token['access_token']);
						
						$google_oauth = new Google_Service_Oauth2($openid);
						
						if(!isset($google_oauth->userinfo)) exit('Invalid Google Login Response (1)');
						
						$google_account_info = $google_oauth->userinfo->get();
						
						$id =  $google_account_info->id;
						$email =  $google_account_info->email;
						$name =  htmlspecialchars($google_account_info->name, ENT_QUOTES);
						$avatar =  $google_account_info->picture;
						
						if($data_parms['assign']){
							auth_bindAccount(array( 'user' => $user, 'bind' => 'google', 'bindid' => $id ), function($err1){
								if($err1) exit($err1);
							});
						} else {
							auth_authByGoogle(array( 'id' => $id, 'email' => $email, 'name' => $name, 'avatar' => $avatar ), function($err1, $session){
								if($err1) exit($err1);
								
								setcookie('session', $session['session'], $session['expire'], $GLOBALS['root']);
							});
						}
						
						header('location: ' . $root . $data_parms['return']);
					}
				} catch (ErrorException $e) {
					exit($e->getMessage());
				}
				
				break;
				
			case 'discord':
				session_start();
			
				$data_parms = array();
				
				foreach($_SESSION as $key => $value){
					unset($_SESSION[$key]);
					
					$data_parms[$key] = $value;
				}
				
				foreach($_GET as $key => $value){
					$_SESSION[$key] = $value;
				}
				
				$redirect_uri = 'https://' . $_SERVER['SERVER_NAME'] . $root . 'auth/discord';
				
				if(!isset($_GET['code'])){
					if($user && !$_GET['assign']) return header('location: ' . $root . $_GET['return']);
					if(!$user && $_GET['assign']) return header('location: ' . $root . $_GET['return']);
					
					header('location: ' . 'https://discord.com/oauth2/authorize?client_id=' . $discord['client'] . '&redirect_uri=' . $redirect_uri . '&response_type=code&scope=email identify');
				} else {
					require_once 'vendors/guzzle_master/vendor/autoload.php';
					try{
						$client = new GuzzleHttp\Client();
						$response = $client->post('https://discord.com/api/oauth2/token', [
							'form_params' => [
								'client_id' => $discord['client'],
								'client_secret' => $discord['secret'],
								'grant_type' => 'authorization_code',
								'code' => $_GET['code'],
								'redirect_uri' => $redirect_uri,
								'scope' => 'identify'
							]
						]);
						
						$response = json_decode($response->getBody(), true);
						$access_token = $response['access_token'];
						
						$response = $client->get('https://discord.com/api/users/@me', [
							'headers' => [
								'Authorization' => 'Bearer ' . $access_token
							]
						]);
						
						$discord_account_info = json_decode($response->getBody(), true);
						
						$id =  $discord_account_info['id'];
						$email =  $discord_account_info['email'];
						$name =  htmlspecialchars($discord_account_info['global_name'], ENT_QUOTES);
						$avatar =  'https://cdn.discordapp.com/avatars/' . $discord_account_info['id'] . '/' . $discord_account_info['avatar'] . '?size=1024';
						
						if($data_parms['assign']){
							auth_bindAccount(array( 'user' => $user, 'bind' => 'discord', 'bindid' => $id ), function($err1){
								if($err1) exit($err1);
							});
						} else {
							auth_authByDiscord(array( 'id' => $id, 'email' => $email, 'name' => $name, 'avatar' => $avatar ), function($err1, $session){
								if($err1) exit($err1);
								
								setcookie('session', $session['session'], $session['expire'], $GLOBALS['root']);
							});
						}
						
						header('location: ' . $root . $data_parms['return']);
					} catch (ErrorException $e) {
						exit($e->getMessage());
					}
				}
				
				break;
				
			case 'facebook':
				session_start();
			
				$data_parms = array();
				
				foreach($_SESSION as $key => $value){
					unset($_SESSION[$key]);
					
					$data_parms[$key] = $value;
				}
				
				foreach($_GET as $key => $value){
					$_SESSION[$key] = $value;
				}
				
				if($user && !$_GET['assign']) return header('location: ' . $root . $_GET['return']);
				if(!$user && $_GET['assign']) return header('location: ' . $root . $_GET['return']);
			
				header('location: ' . $root . $_GET['return']);
			
				break;
			
			case 'logout':
				$return = $_GET['return'];
			
				if(!$user) return header('location: ' . $root . $return);
			
				$session = $_COOKIE['session'];
				$end = intval($_GET['end']);
				
				auth_logout(array( 'session' => $session, 'end' => $end ), function($err1){
					if($err1) return header('location: ' . $GLOBALS['root'] . $return);
					
					setcookie('session', '', time(), $GLOBALS['root']);
				});
				
				header('location: ' . $root . $return);
				
				break;
				
			case 'change_password':
				if(!$user) exit(json_encode(array('success' => false, 'error' => 'User not logged in')));
				
				$current_password = $_POST['current_password'];
				$password = $_POST['password'];
				$confirm_password = $_POST['confirm_password'];
				
				auth_changePassword(array( 'user' => $user, 'current_password' => $current_password, 'password' => $password, 'confirm_password' => $confirm_password ), function($err1){
					if($err1) exit(json_encode(array('success' => false, 'error' => $err1)));
					
					exit(json_encode(array('success' => true, 'reload' => false, 'refresh' => false, 'message' => array('have' => true, 'message' => 'Your password has been changed!'))));
				});
				
				break;
				
			case 'save_settings':
				if(!$user) exit(json_encode(array('success' => false, 'error' => 'User not logged in')));
				
				$email = $_POST['email'];
				$username = $_POST['username'];
				
				auth_userSettings(array( 'user' => $user, 'email' => $email, 'username' => $username ), function($err1){
					if($err1) exit(json_encode(array('success' => false, 'error' => $err1)));
					
					exit(json_encode(array('success' => true, 'reload' => false, 'refresh' => false, 'message' => array('have' => true, 'message' => 'Your settings has been changed!'))));
				});
				
				break;
				
			case 'recover':
				if($user) exit(json_encode(array('success' => false, 'error' => 'User logged in')));
				
				$username = $_POST['username'];
				
				auth_recoverPassword(array( 'username' => $username ), function($err1){
					if($err1) exit(json_encode(array('success' => false, 'error' => $err1)));
					
					exit(json_encode(array('success' => true, 'reload' => false, 'refresh' => false, 'message' => array('have' => true, 'message' => 'A email with reset password link was sent!'))));
				});
				
				header('location: ' . $root);
				
				break;
				
			case 'reset':
				if($user) return header('location: ' . $root);
			
				$key = $_GET['key'];
				
				auth_checkLinkKey(array( 'type' => 'reset_password', 'key' => $key, 'use' => false ), function($err1, $userid) use ($key){
					if($err1) exit($err1);
					
					$sql1 = $GLOBALS['db']->query('SELECT * FROM `users` WHERE `userid` = ' . $GLOBALS['db']->quote($userid));
					
					if($sql1->rowCount() > 0) {
						$page_request = getTemplatePage($GLOBALS['names_pages']['reset'], 'reset', 'reset', $GLOBALS['array_page'], array('key' => $key));
						
						echo $page_request;
						return;
					}
				});
				
				header('location: ' . $root);
				
				break;
				
			case 'reset_confirm':
				if($user) exit(json_encode(array('success' => false, 'error' => 'User logged in')));
			
				$key = $_GET['key'];
				$password = $_POST['password'];
				$confirm_password = $_POST['confirm_password'];
				
				auth_resetPassword(array( 'key' => $key, 'password' => $password, 'confirm_password' => $confirm_password ), function($err1){
					if($err1) exit(json_encode(array('success' => false, 'error' => $err1)));
					
					exit(json_encode(array('success' => true, 'reload' => true, 'refresh' => false, 'message' => array('have' => false))));
				});
				
				break;
			
			case 'resend_verify':
				if(!$user) return header('location: ' . $root);
				
				auth_resendVerifyProfile(array( 'user' => $user ), function($err1){
					if($err1) exit(json_encode(array('success' => false, 'error' => $err1)));
					
					exit(json_encode(array('success' => true, 'reload' => false, 'refresh' => false, 'message' => array('have' => true, 'message' => 'Verification email successfully resent!'))));
				});
				
				header('location: ' . $root);
				
				break;
			
			case 'verify':
				if(!$user) return header('location: ' . $root);
			
				$session = $_COOKIE['session'];
				$key = $_GET['key'];
				
				auth_verifyProfile(array( 'user' => $user, 'key' => $key ), function($err1){
					if($err1) exit($err1);
				});
				
				header('location: ' . $root);
				
				break;
				
			case 'initializing':
				if(!$user) exit(json_encode(array('success' => false, 'error' => 'User not logged in')));
				
				$username = $_POST['username'];
				$email = $_POST['email'];
				$password = $_POST['password'];
				$confirm_password = $_POST['confirm_password'];
				
				auth_accountInitializing(array( 'user' => $user, 'username' => $username, 'email' => $email, 'password' => $password, 'confirm_password' => $confirm_password ), function($err1){
					if($err1) exit(json_encode(array('success' => false, 'error' => $err1)));
						
					exit(json_encode(array('success' => true, 'reload' => false, 'refresh' => false, 'message' => array('have' => true, 'message' => 'Your account has been initialized!'))));
				});
				
				break;
		}
		
		return;
		
	case 'security':
		switch($paths[1]) {
			case 'generate_code_twofa':
				if(!$user) exit(json_encode(array('success' => false, 'error' => 'User not logged in')));
				
				$type = $_POST['type'];
				
				$types_allowed = array('enable_twofa');
				if(!in_array($type, $types_allowed)) exit(json_encode(array('success' => false, 'error' => 'Invalid code type')));
				
				security_generateTwofa(array( 'user' => $user, 'type' => $type ), function($err1){
					if($err1) exit(json_encode(array('success' => false, 'error' => $err1)));
					
					exit(json_encode(array('success' => true, 'action' => 'generate_twofa')));
				});
				
				break;
			
			case 'submit_code_twofa':
				$type = $_POST['type'];
				$code = $_POST['code'];
				
				$types_allowed = array('enable_twofa', 'login');
				if(!in_array($type, $types_allowed)) exit(json_encode(array('success' => false, 'error' => 'Invalid code type')));
				
				if($type == 'enable_twofa'){
					if(!$user) exit(json_encode(array('success' => false, 'error' => 'User not logged in')));
					
					security_enableTwofa(array( 'user' => $user, 'code' => $code ), function($err1, $twofa){
						if($err1) exit(json_encode(array('success' => false, 'error' => $err1)));
						
						exit(json_encode(array('success' => true, 'action' => 'enable_twofa', 'twofa' => $twofa)));
					});
				} else if($type == 'login') {
					$session = $_COOKIE['session'];
					
					security_submitCodeLogin(array( 'session' => $session, 'code' => $code ), function($err1){
						if($err1) exit(json_encode(array('success' => false, 'error' => $err1)));
						
						exit(json_encode(array('success' => true, 'action' => 'login')));
					});
				}
			
				break;
			
			case 'resend_code_twofa':
				$type = $_POST['type'];
				
				$types_allowed = array('enable_twofa', 'login');
				if(!in_array($type, $types_allowed)) exit(json_encode(array('success' => false, 'error' => 'Invalid code type')));
				
				if($type == 'enable_twofa' && !$user) exit(json_encode(array('success' => false, 'error' => 'User not logged in')));
				
				$session = $_COOKIE['session'];
				
				security_resendCode(array( 'session' => $session, 'type' => $type ), function($err1){
					if($err1) exit(json_encode(array('success' => false, 'error' => $err1)));
					
					exit(json_encode(array('success' => true, 'message' => 'Security code successfully resent!')));
				});
			
				break;
			
			case 'submit_security_twofa':
				$type = $_POST['type'];
				$security = $_POST['security'];
				
				$types_allowed = array('disable_twofa', 'login');
				if(!in_array($type, $types_allowed)) exit(json_encode(array('success' => false, 'error' => 'Invalid security type')));
				
				if($type == 'disable_twofa'){
					if(!$user) exit(json_encode(array('success' => false, 'error' => 'User not logged in')));
					
					security_disableTwofa(array( 'user' => $user, 'security' => $security ), function($err1){
						if($err1) exit(json_encode(array('success' => false, 'error' => $err1)));
						
						exit(json_encode(array('success' => true, 'action' => 'disable_twofa', 'message' => 'Your security with 2FA has beed disabled!')));
					});
				} else if($type == 'login') {
					$session = $_COOKIE['session'];
					
					security_submitSecurityLogin(array( 'session' => $session, 'security' => $security ), function($err1){
						if($err1) exit(json_encode(array('success' => false, 'error' => $err1)));
						
						exit(json_encode(array('success' => true, 'action' => 'login')));
					});
				}
			
				break;
			
			case 'activate_twofa':
				if(!$user) exit(json_encode(array('success' => false, 'error' => 'User not logged in')));
			
				$security = $_POST['security'];
				
				security_activateTwofa(array( 'user' => $user, 'security' => $security ), function($err1){
					if($err1) exit(json_encode(array('success' => false, 'error' => $err1)));
					
					exit(json_encode(array('success' => true, 'action' => 'activate_twofa', 'message' => 'Your account has been secured with 2FA!')));
				});
				
				break;
			
			case 'recover_twofa':
				$recover = $_POST['recover'];
				
				security_recoverTwofa(array( 'recover' => $recover ), function($err1){
					if($err1) exit(json_encode(array('success' => false, 'error' => $err1)));
					
					exit(json_encode(array('success' => true, 'action' => 'recover_twofa', 'message' => 'Your security with 2FA has beed disabled!')));
				});
				
				break;
		}
		
		return;
}

$page_request = getTemplate('Page not Found (404)', 'empty');
echo $page_request;
exit();

function getTemplate($name, $page, $in1 = null, $in2 = null) {
	if($in1 != null) extract($in1);
	if($in2 != null) extract($in2);
	
	ob_start();
	include 'template/' . $page . '.tpl';
	$text = ob_get_clean();
	return $text;
}

function getTemplatePage($name, $page, $name_page, $in1 = null, $in2 = null) {
	if($in1 != null) extract($in1);
	if($in2 != null) extract($in2);
	
	ob_start();
	include 'template/page.tpl';
	$text = ob_get_clean();
	return $text;
}