<div class="flex responsive justify-center mt-2">
	<div class="width-8 responsive">
		<div class="bg-light-transparent rounded-1 b-d2 mb-2 p-2">
			<div class="dice-grid responsive">
				<div style="grid-column-start: 1; grid-column-end: 3;">
					<div class="input_field bet_input_field transition-5" data-border="#de4c41">
						<div class="field_container">
							<div class="field_content">
								<input type="text" class="betamount field_element_input" id="betamount_dice" data-game="dice" data-amount="dice" value="0.01">
								
								<div class="field_label transition-5"><div class="input_coins coins mr-1"></div>Bet Amount</div>
							</div>
							
							<div class="field_extra">
								<button class="site-button betshort_action" data-game="dice" data-action="half">1/2</button>
								<button class="site-button betshort_action" data-game="dice" data-action="double">x2</button>
								<button class="site-button betshort_action" data-game="dice" data-action="max">Max</button>
							</div>
						</div>
						
						<div class="field_bottom">
							<div class="field_error" data-error="required">This field is required</div>
							<div class="field_error" data-error="number">This field must be a number</div>
							<div class="field_error" data-error="greater">You must enter a greater value</div>
							<div class="field_error" data-error="lesser">You must enter a lesser value</div>
						</div>
					</div>
				</div>
				
				<div style="grid-column-start: 3; grid-column-end: 4;">
					<div class="input_field bet_input_field transition-5" data-border="#de4c41">
						<div class="field_container">
							<div class="field_content">
								<input type="text" class="field_element_input" id="dice_winnings" disabled="" value="0.02">
								
								<div class="field_label transition-5"><div class="input_coins coins mr-1"></div>Winnings</div>
							</div>
							
							<div class="field_extra">
							</div>
						</div>
						
						<div class="field_bottom"></div>
					</div>
				</div>
				
				<div style="grid-column-start: 1; grid-column-end: 2;">
					<div class="input_field bet_input_field transition-5" data-border="#de4c41">
						<div class="field_container">	
							<div class="field_content">
								<input type="text" class="field_element_input" id="dice_roll" disabled="" value="47.50">
								
								<div class="field_label transition-5">Roll <span class="text-successful" id="dice_type">UNDER</span></div>
							</div>
							
							<div class="field_extra">
								<img class="icon-medium pointer" src="<?php echo $site['root'];?>template/img/switch.svg" id="dice_switch">
							</div>
						</div>
						
						<div class="field_bottom"></div>
					</div>
				</div>
				
				<div style="grid-column-start: 2; grid-column-end: 3;">
					<div class="input_field bet_input_field transition-5" data-border="#de4c41">
						<div class="field_container">
							<div class="field_content">
								<input type="text" class="field_element_input" id="dice_multiplier" disabled="" value="2.00">
								
								<div class="field_label transition-5">Multiplier</div>
							</div>
							
							<div class="field_extra">
							</div>
						</div>
						
						<div class="field_bottom"></div>
					</div>
				</div>
				
				<div style="grid-column-start: 3; grid-column-end: 4;">
					<div class="input_field bet_input_field transition-5" data-border="#de4c41">
						<div class="field_container">
							<div class="field_content">
								<input type="text" class="field_element_input" id="dice_chanceinput" value="47.50">
								
								<div class="field_label transition-5">Win Chance</div>
							</div>
							
							<div class="field_extra"></div>
						</div>
						
						<div class="field_bottom">
							<div class="field_error" data-error="required">This field is required</div>
							<div class="field_error" data-error="number">This field must be a number</div>
							<div class="field_error" data-error="greater">You must enter a greater value</div>
						</div>
					</div>
				</div>
				
				<div style="grid-column-start: 1; grid-column-end: 2;">
					<div class="switch_field transition-5">
						<div class="field_container">
							<div class="field_content">
								<input type="checkbox" class="field_element_input" id="slow_dice_type" data-type="slow">
								
								<div class="field_switch">
									<div class="field_switch_bar"></div>
								</div>
								
								<div class="field_label active transition-5">SLOW ROLL</div>
							</div>
							
							<div class="field_extra"></div>
						</div>
						
						<div class="field_bottom"></div>
					</div>
				</div>
				
				<div style="grid-column-start: 2; grid-column-end: 4;">
					<div class="relative hidden" id="dice_pointer">
						<div class="dice-result">
							<div class="dice-result-bar flex justify-center transition-5" style="width: 0%;">
								<div class="hover-message flex justify-center items-center">
									<div class="pointer">100.00%</div>
								</div>
							</div>
						</div>
					</div>
				
					<div class="slider_field transition-5">
						<div class="field_container">
							<div class="field_content">
								<input type="range" class="field_element_input" id="dice_chanceslider" min="0.01" max="100" step="0.01" value="47.5">
								
								<div class="field_label active transition-5">Chance</div>
							</div>
							
							<div class="field_extra"></div>
						</div>
						
						<div class="field_bottom">
							<div class="flex justify-between">
								<div>0</div>
								<div>100</div>
							</div>
						</div>
					</div>
				</div>
				
				<div class="hidden" id="type_slow" style="grid-column-start: 1; grid-column-end: 4;">
					<div class="dice-slots mt-2 mb-2" id="dice-slots">
						<?php for($i = 0; $i < 4; $i++){ ?>
						<div class="dice-slots-column" id="dice-slots-spinner" data-id="<?php echo $i; ?>">
							<?php for($j = 0; $j < 4; $j++){ ?>
							<div class="">
								<div class="dice-slots-row flex justify-center items-center">0</div>
								<div class="dice-slots-row flex justify-center items-center">1</div>
								<div class="dice-slots-row flex justify-center items-center">2</div>
								<div class="dice-slots-row flex justify-center items-center">3</div>
								<div class="dice-slots-row flex justify-center items-center">4</div>
								<div class="dice-slots-row flex justify-center items-center">5</div>
								<div class="dice-slots-row flex justify-center items-center">6</div>
								<div class="dice-slots-row flex justify-center items-center">7</div>
								<div class="dice-slots-row flex justify-center items-center">8</div>
								<div class="dice-slots-row flex justify-center items-center">9</div>
							</div>
							<?php } ?>	
						</div>
						<?php } ?>			
					</div>
				</div>
				
				<div style="grid-column-start: 1; grid-column-end: 4;">
					<button class="site-button purple width-full" id="dice_bet">ROLL!</button>
				</div>
			</div>
		</div>
		
		<div class="table-container">
			<div class="table-header">
				<div class="table-row">
					<div class="table-column text-left">Betid</div>
					<div class="table-column text-left">User</div>
					<div class="table-column text-left">Bet</div>
					<div class="table-column text-left">Multiplier</div>
					<div class="table-column text-left">Game</div>
					<div class="table-column text-left">Roll</div>
					<div class="table-column text-left">Profit</div>
				</div>
			</div>
			
			<div class="table-body" id="dice_history">
				<div class="table-row history_message"><div class="table-column">No data found</div></div>
			</div>
		</div>
	</div>
</div>