<div class="flex column width-full">
	<div class="wrapper-page flex row">
		<div class="flex column height-full width-full overflow-a p-2 gap-4 text-left">
			<div>
				<div class="offers-options-name">Withdraw with Steam</div>
				
				<div class="offers-options mt-2">
					<?php foreach($response['methods']['steam'] as $key => $value){ ?>
						<a class="<?php if(!$value){ ?>disabled<?php } ?>" href="<?php echo $site['root'];?>withdraw/steam/<?php echo $key; ?>">
							<div class="offers-option p-2 rounded-2">
								<div class="offers-option-image-content flex items-center justify-center rounded-1">
									<?php if(!$value){ ?><div class="offers-option-info font-5 pl-2 pr-2 pt-1 pb-1 rounded-1">Disabled</div><?php } ?>
									
									<img class="offers-option-image" src="<?php echo $site['root'];?>template/img/methods/<?php echo $key; ?>_shop.png?v=<?php echo time();?>">
								</div>
								
								<div class="offers-option-name flex justify-center items-center"><?php echo $response['methods_name']['steam'][$key]; ?> (<?php echo strtoupper($key); ?>)</div>
							</div>
						</a>
					<?php } ?>
				</div>
			</div>
			
			<div>
				<div class="offers-options-name">Withdraw with P2P</div>
				
				<div class="offers-options mt-2">
					<?php foreach($response['methods']['p2p'] as $key => $value){ ?>
						<a class="<?php if(!$value){ ?>disabled<?php } ?>" href="<?php echo $site['root'];?>withdraw/p2p/<?php echo $key; ?>">
							<div class="offers-option p-2 rounded-2">
								<div class="offers-option-image-content flex items-center justify-center rounded-1">
									<?php if(!$value){ ?><div class="offers-option-info font-5 pl-2 pr-2 pt-1 pb-1 rounded-1">Disabled</div><?php } ?>
									
									<img class="offers-option-image" src="<?php echo $site['root'];?>template/img/methods/<?php echo $key; ?>_shop.png?v=<?php echo time();?>">
								</div>
								
								<div class="offers-option-name flex justify-center items-center"><?php echo $response['methods_name']['p2p'][$key]; ?> (<?php echo strtoupper($key); ?>)</div>
							</div>
						</a>
					<?php } ?>
				</div>
			</div>
			
			<div>
				<div class="offers-options-name">Withdraw with Cryptocurrency</div>
				
				<div class="offers-options mt-2">
					<?php foreach($response['methods']['crypto'] as $key => $value){ ?>
						<a class="<?php if(!$value){ ?>disabled<?php } ?>" href="<?php echo $site['root'];?>withdraw/crypto/<?php echo $key; ?>">
							<div class="offers-option p-2 rounded-2">
								<div class="offers-option-image-content flex items-center justify-center rounded-1">
									<?php if(!$value){ ?><div class="offers-option-info font-5 pl-2 pr-2 pt-1 pb-1 rounded-1">Disabled</div><?php } ?>
									
									<img class="offers-option-image" src="<?php echo $site['root'];?>template/img/methods/<?php echo $key; ?>_shop.png?v=<?php echo time();?>">
								</div>
								
								<div class="offers-option-name flex justify-center items-center"><?php echo $response['methods_name']['crypto'][$key]; ?> (<?php echo strtoupper($key); ?>)</div>
							</div>
						</a>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>
</div>