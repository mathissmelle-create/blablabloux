<div class="p-2">
	<div class="grid split-column-3 gap-4 responsive">
		<div class="flex nowarp column gap-2">
			<div class="faq-panel p-4">
				<div class="mt-2 mb-4 font-10 text-bold">General</div>
				
				<div class="flex nowarp column gap-2">
					<div class="faq-item flex nowarp column gap-2 pb-2">
						<div class="flex nowarp row justify-between items-center gap-2">
							<div>What is <?php echo $site['name'];?>?</div>
							
							<div class="faq-open pointer transition-2 font-7">
								<i class="fa fa-angle-down" aria-hidden="true"></i>
							</div>
						</div>
						
						<div class="description transition-2">
							<div><?php echo $site['name'];?> is a brand new way to gamble CS:GO and more games skins. We are NOT a jackpot site – instead players deposit skins for credits and these points are then transferred to our site, bet those credits on our inspired games: roulette, crash, coinflip, jackpot, dice, unboxing, minesweeper, tower, plinko.</div>
							<div>It doesn't matter how big your inventory is, or how much you bet, your odds are always the same.</div>
							<div>Bets occur in real time, across the entire site, meaning you bet, win, and lose along with other players.</div>
							<div>All rolls are generated using a provably fair system – ensuring a fair roll each and every time.</div>
						</div>
					</div>
					
					<div class="faq-item flex nowarp column gap-2 pb-2">
						<div class="flex nowarp row justify-between items-center gap-2">
							<div>How use the chat?</div>
						
							<div class="faq-open pointer transition-2 font-7">
								<i class="fa fa-angle-down" aria-hidden="true"></i>
							</div>
						</div>
						
						<div class="description transition-2">
							<ol type="1">
								<li>To send coins you need have level 1.</li>
								<li>Don't beg for coins.</li>
								<li>Don't post your affiliates codes in chat.</li>
								<li>Don't advertise other websites.</li>
								<li>Technical problems are not solved on chat but through support page</li>
								<li>Do not ask about support tickets in chat. You can expect a response within 48 hours of sending your ticket.</li>
								<li>Do not lie about transactions on support tickets, as this can result in a ban.</li>
								<li>Respect our staff. Any rude remarks or attempts to belittle them will result in a mute.</li>
							</ol>
						</div>
					</div>
				</div>
			</div>
			
			<div class="faq-panel p-4">
				<div class="mt-2 mb-4 font-10 text-bold">Contact Support</div>
				
				<div class="flex nowarp column gap-2">
					<div class="faq-item flex nowarp column gap-2 pb-2">
						<div class="flex nowarp row justify-between items-center gap-2">
							<div>I doesn't find a correct answer</div>
							
							<div class="faq-open pointer transition-2 font-7">
								<i class="fa fa-angle-down" aria-hidden="true"></i>
							</div>
						</div>
						
						<div class="description transition-2">
							<div>Feel free to contact us every time, if you need help or have some question's about the website and our service.</div>
							<div>Our Support team is normally 24/7 online for you. You can contact us <a href="<?php echo $site['soot']; ?>support" target="_blank" class="text-color">here</a>.</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="faq-panel p-4">
				<div class="mt-2 mb-4 font-10 text-bold">Promotion</div>
				
				<div class="flex nowarp column gap-2">
					<div class="faq-item flex nowarp column gap-2 pb-2">
						<div class="flex nowarp row justify-between items-center gap-2">
							<div>Partnership / Sponsorchip - Would you like to sponsor me?</div>
							
							<div class="faq-open pointer transition-2 font-7">
								<i class="fa fa-angle-down" aria-hidden="true"></i>
							</div>
						</div>
						
						<div class="description transition-2">
							<div>We do not sponsor youtube channels with under 10 000 subscribers.</div>
							<div>If you do have more than 10 000 but without an active fan base, there is only a slim chance of getting us to sponsor you.</div>
							<div>We do not sponsor CSGO teams at the moment, if we ever will do it, we will be contacting them.</div>
							<div>For business related questions, we advice you to contact <?php echo $site['name'];?> team .</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="faq-panel p-4">
				<div class="mt-2 mb-4 font-10 text-bold">Responsible Gambling</div>
				
				<div class="flex nowarp column gap-2">
					<div class="faq-item flex nowarp column gap-2 pb-2">
						<div class="flex nowarp row justify-between items-center gap-2">
							<div>How to play responsibly</div>
							
							<div class="faq-open pointer transition-2 font-7">
								<i class="fa fa-angle-down" aria-hidden="true"></i>
							</div>
						</div>
						
						<div class="description transition-2">
							<div>Responsible Gaming is a set of social responsibility initiatives by the industry to ensure the integrity and fairness of their operations and to promote awareness of harms associated with it.</div>
							<div>Tips on how to play responsibly:</div>
							<ol type="1">
								<li>Don't treat playing on <?php echo $site['name'];?> as a way to make money</li>
								<li>Only play with money you're willing to lose - play with your disposable income</li>
								<li>Never chase your losses, there is no guarantee you will come out ahead</li>
								<li>Don't play while under the influence of alcohol, drugs or other controlled substances</li>
								<li>Never play when you're being depressed or upset</li>
								<div>If you'd like to take a forced break from playing, you can go to your profile and lock yourself.</div>
								<div>We will not remove this restriction for any reason.</div>
							</ol>
						</div>
					</div>
				</div>
			</div>
			
			<div class="faq-panel p-4">
				<div class="mt-2 mb-4 font-10 text-bold">Self Help</div>
				
				<div class="flex nowarp column gap-2">
					<div class="faq-item flex nowarp column gap-2 pb-2">
						<div class="flex nowarp row justify-between items-center gap-2">
							<div>What if I can't stop?</div>
							
							<div class="faq-open pointer transition-2 font-7">
								<i class="fa fa-angle-down" aria-hidden="true"></i>
							</div>
						</div>
						
						<div class="description transition-2">
							<div>Like all forms of gambling, online gambling can become an addiction that can have serious negative effects on your life.</div>
							<div>If you lose more than you planned to or can't safely afford and find yourself struggling to control time and/or money spent gambling, please check these sites for information that could help you:</div>
							<div>HELP: <a href="http://www.psychguides.com/" target="_blank" class="text-color">http://www.psychguides.com/</a></div>
							<div>Self Help: <a href="http://www.gamblersanonymous.org/ga/" target="_blank" class="text-color">http://www.gamblersanonymous.org/ga/</a></div>
						</div>
					</div>
					
					<div class="faq-item flex nowarp column gap-2 pb-2">
						<div class="flex nowarp row justify-between items-center gap-2">
							<div>Can I self-request a ban?</div>
							
							<div class="faq-open pointer transition-2 font-7">
								<i class="fa fa-angle-down" aria-hidden="true"></i>
							</div>
						</div>
						
						<div class="description transition-2">
							<div>Yes. If you feel like you can't control your gambling habits, you can use self exclusion.</div>
							<div>If you enable it, you won't be able to bet, claim rewards, send BUX or deposit anything until the restriction expires.</div>
							<div>Withdraws and chat privileges will remain active. Use it if you'd like to take a break from playing for an extended period. For custom restrictions, you can always contact us.</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="flex nowarp column gap-2">
			<div class="faq-panel p-4">
				<div class="mt-2 mb-4 font-10 text-bold">Coins</div>
				
				<div class="flex nowarp column gap-2">
					<div class="faq-item flex nowarp column gap-2 pb-2">
						<div class="flex nowarp row justify-between items-center gap-2">
							<div>What are coins?</div>
							
							<div class="faq-open pointer transition-2 font-7">
								<i class="fa fa-angle-down" aria-hidden="true"></i>
							</div>
						</div>
						
						<div class="description transition-2">
							<div>1 Dollar = 1000 coins</div>
							<div>Coins have no real currency value, but are used to withdraw skins from the withdraw on our website.</div>
						</div>
					</div>
					
					<div class="faq-item flex nowarp column gap-2 pb-2">
						<div class="flex nowarp row justify-between items-center gap-2">
							<div>Can I send my coins to other players?</div>
							
							<div class="faq-open pointer transition-2 font-7">
								<i class="fa fa-angle-down" aria-hidden="true"></i>
							</div>
						</div>
						
						<div class="description transition-2">
							<div>For send coins you must have level 1. You can send coins to other players by clicking on their username in the chat and then on gift icon".</div>
						</div>
					</div>
					
					<div class="faq-item flex nowarp column gap-2 pb-2">
						<div class="flex nowarp row justify-between items-center gap-2">
							<div>I logged into my account and all my coins are gone?</div>
							
							<div class="faq-open pointer transition-2 font-7">
								<i class="fa fa-angle-down" aria-hidden="true"></i>
							</div>
						</div>
						
						<div class="description transition-2">
							<div>When this happens there are a ton of possible reasons that might have caused it, but one thing that is for sure, is that it has nothing to do with errors from our site.</div>
							<div>Reason 1: Just by entering the site you will be automatically logged in most of the time, someone around you can have used the coins to play on your account.</div>
							<div>Reason 2: Virus / Exploits / Harmful browser extensions. <?php echo $site['name'];?> does not advice any of their users to use any kind of extensions in their browser when playing on <?php echo $site['name'];?>.</div>
							<div>There are alot of more things that can cause problems, here are only 2 mentioned above. Lastly, we do NOT refund these types of incidents. We only refund what we can see and prove in our logs/DataBase.</div>
							<div><?php echo $site['name'];?> Admins/Bots/Moderators will NEVER add you on Steam and they will never request any of your items. Be wary of giveaway and impersonation scams.</div>
						</div>
					</div>
					
					<div class="faq-item flex nowarp column gap-2 pb-2">
						<div class="flex nowarp row justify-between items-center gap-2">
							<div>How can I get free coins?</div>
							
							<div class="faq-open pointer transition-2 font-7">
								<i class="fa fa-angle-down" aria-hidden="true"></i>
							</div>
						</div>
						
						<div class="description transition-2">
							<div>Head over to your profile tab and make sure your account is verified.</div>
							<div>There is a couple of ways you can earn free coins on <?php echo $site['name'];?>:</div>
							<ol type="1">
								<li>
									Daily reward:
									<div>You can earn up to <?php echo getFormatAmountString($rewards['amounts']['daily_start'] + 100 * $rewards['amounts']['daily_step']); ?> coins daily by claiming your Daily Reward.</div>
									<div><i>Don't forget that you'll receive more coins as you level up!</i></div>
								</li>
								<li>Coin rain</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			
			<div class="faq-panel p-4">
				<div class="mt-2 mb-4 font-10 text-bold">Affiliates</div>
				
				<div class="flex nowarp column gap-2">
					<div class="faq-item flex nowarp column gap-2 pb-2">
						<div class="flex nowarp row justify-between items-center gap-2">
							<div>How can I earn extra coins by referring new users?</div>
							
							<div class="faq-open pointer transition-2 font-7">
								<i class="fa fa-angle-down" aria-hidden="true"></i>
							</div>
						</div>
						
						<div class="description transition-2">
							<div>Create your unique code in the affiliate tab and receive <?php echo number_format(roundedToFixed($affiliates['commission']['bet'] * sizeof($affiliates['requirements']), 2), 2, '.', ''); ?>% bet commission and <?php echo number_format(roundedToFixed($affiliates['commission']['deposit'] * sizeof($affiliates['requirements']), 2), 2, '.', ''); ?>% deposit commission from every user who used your code.</div>
							<div>The code will also generate <?php echo getFormatAmountString($rewards['amounts']['refferal_code']); ?> coins for the person who uses the code.</div>
							<div class="text-italic">Note: The code should not be misleading or violate any trademarks.</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="flex nowarp column gap-2">
			<div class="faq-panel p-4">
				<div class="mt-2 mb-4 font-10 text-bold">Games</div>
				
				<div class="flex nowarp column gap-2">
					<div class="faq-item flex nowarp column gap-2 pb-2">
						<div class="flex nowarp row justify-between items-center gap-2">
							<div>Is there a maximum and minimum bet?</div>
							
							<div class="faq-open pointer transition-2 font-7">
								<i class="fa fa-angle-down" aria-hidden="true"></i>
							</div>
						</div>
						
						<div class="description transition-2">
							<div>The minimum for any game is 1.00 coins</div>
							<div>The maximum for any game is 500.00 coins</div>
						</div>
					</div>
					
					<div class="faq-item flex nowarp column gap-2 pb-2">
						<div class="flex nowarp row justify-between items-center gap-2">
							<div>Is there a maximum profit on crash?</div>
							
							<div class="faq-open pointer transition-2 font-7">
								<i class="fa fa-angle-down" aria-hidden="true"></i>
							</div>
						</div>
						
						<div class="description transition-2">
							<div>You'll be automatically cashed out if you profit more than 5.000.00 coins.</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="faq-panel p-4">
				<div class="mt-2 mb-4 font-10 text-bold">Faireness</div>
				
				<div class="flex nowarp column gap-2">
					<div class="faq-item flex nowarp column gap-2 pb-2">
						<div class="flex nowarp row justify-between items-center gap-2">
							<div>Are the games fair?</div>
							
							<div class="faq-open pointer transition-2 font-7">
								<i class="fa fa-angle-down" aria-hidden="true"></i>
							</div>
						</div>
						
						<div class="description transition-2">
							<div>Absolutely! And we can prove it. Please see our <a href="<?php echo $site['root'];?>fair" target="_blank" class="text-color">provably fair</a> page for technical details.</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>