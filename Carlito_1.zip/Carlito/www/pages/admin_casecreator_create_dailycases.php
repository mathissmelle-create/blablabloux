<div class="p-2">
	<div class="grid split-column-full responsive gap-1 mb-2">
		<a href="<?php echo $site['root']; ?>admin/control"><button class="site-button black width-full">Control</button></a>
		<a href="<?php echo $site['root']; ?>admin/users"><button class="site-button black width-full">Users</button></a>
		<a href="<?php echo $site['root']; ?>admin/trades"><button class="site-button black width-full">Trades</button></a>
		<a href="<?php echo $site['root']; ?>admin/casecreator"><button class="site-button black active width-full">Case Creator</button></a>
		<a href="<?php echo $site['root']; ?>admin/gamebots"><button class="site-button black width-full">Game Bots</button></a>
	</div>
	
	<div class="flex column gap-1">
		<div class="flex column gap-2 bg-dark-transparent bb-d2 p-2">
			<div class="flex justify-between responsive gap-2 bb-l2 pb-2">
				<div class="flex row gap-2">
					<a href="<?php echo $site['root']; ?>admin/casecreator/create/cases"><button class="site-button black <?php if(sizeof($paths) > 2) if($paths[3] == 'cases') echo 'active' ?>">Cases</button></a>
					<a href="<?php echo $site['root']; ?>admin/casecreator/create/dailycases"><button class="site-button black <?php if(sizeof($paths) > 2) if($paths[3] == 'dailycases') echo 'active' ?>">Daily Cases</button></a>
				</div>
				
				<a href="<?php echo $site['root']; ?>admin/casecreator/edit"><button class="site-button purple">Edit Cases</button></a>
			</div>
		</div>
	
		<div class="flex column items-center gap-2 mt-4 overflow-a">
			<div class="width-8 responsive text-left">
				<div class="font-10 text-bold">Create Case</div>
			</div>
			
			<div class="bg-light-transparent text-left rounded-1 b-d2 p-4 width-8 responsive">
				<div class="flex items-start column gap-2">
					<div class="input_field transition-5" data-border="#de4c41">
						<div class="field_container">
							<div class="field_content">
								<input type="text" class="field_element_input" id="casecreator_case_name" value="">
								
								<div class="field_label transition-5">Case name</div>
							</div>
							
							<div class="field_extra">
							</div>
						</div>
						
						<div class="field_bottom">
							<div class="field_error" data-error="required">This field is required</div>
						</div>
					</div>
					
					<div class="file_field transition-5" data-border="#de4c41">
						<div class="field_container">
							<div class="field_content">
								<input type="file" class="field_element_input" id="casecreator_case_image" accept="image/*" value="">
								<div class="field_file">
									<div class="field_file_source"><img src=""></div>
								</div>
								
								<div class="field_label active transition-5">Case image</div>
							</div>
							
							<div class="field_extra">
								<button class="field_element_file site-button purple width-full">Choose File</button>
							</div>
						</div>
						
						<div class="field_bottom"></div>
					</div>
					
					<div class="input_field transition-5" data-border="#de4c41">
						<div class="field_container">
							<div class="field_content">
								<input type="text" class="field_element_input" id="casecreator_case_level" value="0">
								
								<div class="field_label transition-5">Level</div>
							</div>
							
							<div class="field_extra">
							</div>
						</div>
						
						<div class="field_bottom">
							<div class="field_error" data-error="required">This field is required</div>
						</div>
					</div>
					
					<div class="flex column gap-1 width-full">
						<div class="flex row responsive gap-2">
							<div class="input_field bet_input_field transition-5" data-border="#de4c41">
								<div class="field_container">
									<div class="field_content">
										<input type="text" class="field_element_input" id="casecreator_items_search" value="">
										
										<div class="field_label transition-5">Search Item</div>
									</div>
									
									<div class="field_extra">
									</div>
								</div>
								
								<div class="field_bottom"></div>
							</div>
							
							<div class="dropdown_field transition-5">
								<div class="field_container">
									<div class="field_content">
										<input type="text" class="field_element_input" id="casecreator_items_order" value="0">
										<div class="field_dropdown"></div>
									
										<div class="field_element_dropdowns">
											<div class="field_element_dropdown" value="0" data-index="0">Name A-Z</div>
											<div class="field_element_dropdown" value="1" data-index="1">Name Z-A</div>
											<div class="field_element_dropdown" value="2" data-index="2">Price acending</div>
											<div class="field_element_dropdown" value="3" data-index="3">Price descending</div>
										</div>
									
										<div class="field_label active transition-5">Order by</div>
									</div>
									
									<div class="field_extra">
										<div class="field_caret">
											<i class="fa fa-caret-down"></i>
										</div>
									</div>
								</div>
								
								<div class="field_bottom"></div>
							</div>
						</div>
						
						<div id="casecreator_items">
							<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No cases found</div>
						</div>
						
						<div class="flex items-center justify-center bg-dark p-2 rounded-0">
							<div class="pagination-content flex row gap-2 width-full" id="pagination_casecreator_items">
								<div class="flex row gap-2 justify-between items-center width-full">
									<div class="pagination-item flex items-center justify-center" data-page="1">«</div>
									
									<div class="bg-light rounded-1 b-l2 pl-2 pr-2 flex row items-center justify-center height-full">1/1</div>
									
									<div class="pagination-item flex items-center justify-center" data-page="1">»</div>
								</div>
							</div>
						</div>
						
						<div class="table-container">
							<div class="table-body" id="casecreator_case_items">
								<div class="in-grid bg-light flex justify-center items-center font-8 p-4 history_message">No items selected</div>
							</div>
						</div>
						
						<div class="flex row justify-between items-center gap-2">
							<div class="flex row justify-center items-center gap-2">
								<div class="bg-dark p-2 rounded-0">Total Odds: <span id="casecreator_chance">0.00</span>%</div>
								<div class="bg-dark p-2 rounded-0">Case Price: <span id="casecreator_price">N/A</span></div>
							</div>
							
							<button class="site-button purple disabled" id="casecreator_case_create">Create Case</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>