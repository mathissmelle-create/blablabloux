<div class="grid split-column-2 gap-2 responsive p-2">
	<div class="flex column gap-2">
		<div class="flex justify-between items-center responsive bg-dark rounded-0 p-2">
			<div class="text-bold text-left font-10 mb-2">Ticket</div>
			
			<?php 
			$tickets_opened = 0;
			$tickers_closed = 0;
			
			foreach($response['support'] as $key => $value_support){
				$tickets_opened += ($value_support['closed'] + 1) % 2;
				$tickers_closed += $value_support['closed'];
			} ?>
			
			<div class="flex row gap-2">
				<button class="site-button black support-open active" data-status="all">All <div class="inline-block bg-main-transparent rounded-0 pl-1 pr-1 ml-2"><?php echo $tickets_opened + $tickers_closed; ?></div></button>
				<button class="site-button black support-open" data-status="opened">Opened <div class="inline-block bg-main-transparent rounded-0 pl-1 pr-1 ml-2"><?php echo $tickets_opened; ?></div></button>
				<button class="site-button black support-open" data-status="closed">Closed <div class="inline-block bg-main-transparent rounded-0 pl-1 pr-1 ml-2"><?php echo $tickers_closed; ?></div></button>
			</div>
		</div>
		
		<div class="support-content flex column rounded-0 overflow-h">
			<?php if(sizeof($response['support']) == 0) { ?>
			<div class="text-center p-4 font-8 history_message">You haven't any tickets yet.</div>
			<?php } ?>
			
			<?php foreach($response['support'] as $key => $value_support){
				
			$tickets_support = array();
			
			foreach($response['tickets'] as $key => $value_ticket){
				if($value_ticket['supportid'] == $value_support['id']){
					array_push($tickets_support, $value_ticket);
				}
			}
			
			?>
			
			<div class="support-ticket flex column bg-dark transition-2 pointer" data-status="<?php echo $value_support['closed'] ? 'closed' : 'opened'; ?>">
				<div class="title flex justify-between items-center gap-2 responsive p-4 width-full">
					<div class="flex row items-center gap-4">
						<div class="text-gray text-bold">#<?php echo $value_support['id']; ?></div>
						<div class="font-8"><?php echo $value_support['title']; ?></div>
					</div>
					
					<div class="flex row items-center gap-2">
						<div class="text-gray"><?php echo makeDate($value_support['time']); ?></div>
						<div class="<?php echo $value_support['closed'] ? 'text-danger' : ($tickets_support[sizeof($tickets_support) - 1]['response'] ? 'text-success' : 'text-warning'); ?>"><?php echo $value_support['closed'] ? 'Closed' : ($tickets_support[sizeof($tickets_support) - 1]['response'] ? 'Answered' : 'Opened'); ?></div>
					</div>
				</div>
				
				<div class="description transition-2 overflow-h pr-4 pl-4">
					<form class="form_support" method="POST" action="<?php echo $site['root']; ?>support?id=<?php echo $value_support['id']; ?>">
						<div class="flex column gap-2 mb-4">
							<div class="bg-light p-2 rounded-0 flex justify-between items-center gap-2">
								<div class="flex column items-start gap-2">
									<?php $departments = array(
										'0'=>'General / Others',
										'1'=>'Bug report',
										'2'=>'Trade offer issue',
										'3'=>'Improvements / Ideas',
										'4'=>'Marketing / Partnership',
										'5'=>'Ranking up'
									); ?>
								
									<div>Department: <span class="text-danger"><?php echo $departments[$value_support['department']]; ?></span></div>
									
									<?php if($value_support['receiver_userid'] == $user['userid']){?>
									<div>Creator name: <span class="text-danger"><?php echo $value_support['sender_name']; ?></span></div>
									<?php } else { ?>
									<div>Staff name: <span class="text-danger"><?php echo $value_support['receiver_name']; ?></span></div>
									<?php } ?>
								</div>
								
								<?php if(!$value_support['closed']){ ?>
								<button class="site-button purple" type="submit" name="close">CLOSE TICKET</button>
								<?php } ?>
							</div>
							
							<div class="messages flex column gap-2 pr-2">
								<?php foreach($tickets_support as $key => $value_ticket){ ?>
									<?php if($value_ticket['response']){ ?>
									
									<div class="flex column gap-2">
										<div class="flex justify-between items-center gap-2 pl-2 pr-2">
											<div class="flex row gap-1">
												<?php echo createAvatarField(array('userid' => $value_ticket['userid'], 'name' => $value_ticket['name'], 'avatar' => $value_ticket['avatar'], 'level' => calculateLevel($value_ticket['xp'])['level']), 'medium', ''); ?>
												
												<div class="flex column text-left">
													<div class="font-8"><?php echo $value_ticket['name']; ?></div>
													<div class="text-success font-6">Support Staff</div>
												</div>
											</div>
											
											<div class="text-gray font-6"><?php echo makeDate($value_ticket['time']); ?></div>
										</div>
										
										<div class="message response p-4 text-left ml-6">
											<div class="flex column gap-4 text-left mt-2">
												<div class="text-gray">Greetings <?php echo $value_support['sender_name']; ?>,</div>
												<div><?php echo $value_ticket['message']; ?></div>
												<div class="text-gray">
													<div>All the best,</div>
													<div><?php echo $value_ticket['name']; ?></div>
												</div>
											</div>
										</div>
									</div>
									
									<?php } else { ?>
									
									<div class="flex column gap-2">
										<div class="flex justify-between items-center gap-2 pl-2 pr-2">
											<div class="flex row gap-1">
												<?php echo createAvatarField(array('userid' => $value_ticket['userid'], 'name' => $value_ticket['name'], 'avatar' => $value_ticket['avatar'], 'level' => calculateLevel($value_ticket['xp'])['level']), 'medium', ''); ?>
												
												<div class="flex column text-left">
													<div class="font-8"><?php echo $value_ticket['name']; ?></div>
													<?php if(($value_support['receiver_userid'] == $user['userid'] || in_array($site['ranks_name'][$user['rank']], $site['permissions']['support'])) && $value_support['sender_userid'] != $user['userid']){ ?>
													<div class="text-danger font-6">He</div>
													<?php } else { ?>
													<div class="text-danger font-6">You</div>
													<?php } ?>
												</div>
											</div>
											
											<div class="text-gray font-6"><?php echo makeDate($value_ticket['time']); ?></div>
										</div>
										
										<div class="message p-4 text-left ml-6"><?php echo $value_ticket['message']; ?></div>
									</div>
									
									<?php } ?>
								<?php } ?>
							</div>
							
							<?php if(!$value_support['closed']){ ?>
							<div class="flex row items-center gap-2 responsive">
								<div class="input_field transition-5" data-border="#de4c41">
									<div class="field_container">
										<div class="field_content">
											<textarea type="text" class="field_element_input" name="message"></textarea>
											
											<div class="field_label transition-5">Ticket Message</div>
										</div>
										
										<div class="field_extra">
										</div>
									</div>
									
									<div class="field_bottom">
										<div class="field_error" data-error="required">This field is required</div>
									</div>
								</div>
								
								<button class="site-button purple" type="submit" name="reply">REPLY</button>
							</div>
							
							<?php if($value_support['receiver_userid'] == $user['userid'] || in_array($site['ranks_name'][$user['rank']], $site['permissions']['support'])){ ?>
							<div class="flex row items-center gap-2 responsive">
								<div class="dropdown_field transition-5 width-full">
									<div class="field_container">
										<div class="field_content">
											<input type="text" class="field_element_input" name="department" value="0">
											<div class="field_dropdown"></div>
										
											<div class="field_element_dropdowns">
												<div class="field_element_dropdown" value="0" data-index="0">General / Others</div>
												<div class="field_element_dropdown" value="1" data-index="1">Bug report</div>
												<div class="field_element_dropdown" value="2" data-index="2">Trade offer issue</div>
												<div class="field_element_dropdown" value="3" data-index="3">Improvements / Ideas</div>
												<div class="field_element_dropdown" value="4" data-index="4">Marketing / Partnership</div>
												<div class="field_element_dropdown" value="5" data-index="5">Ranking up</div>
											</div>
										
											<div class="field_label active">Department</div>
										</div>
										
										<div class="field_extra">
											<div class="field_caret">
												<i class="fa fa-caret-down"></i>
											</div>
										</div>
									</div>
									
									<div class="field_bottom"></div>
								</div>
								
								<button class="site-button purple" type="submit" name="redirect">REDIRECT</button>
							</div>
							<?php } ?>
							<?php } ?>
						</div>
					</form>
				</div>
			</div>
			
			<?php } ?>
		</div>
	</div>
	
	<div>
		<div class="bg-dark rounded-0 p-2">
			<div class="text-bold text-left font-10 mb-2">New ticket</div>
		
			<form class="form_support flex column gap-2" method="POST" action="<?php echo $site['root']; ?>support">
				<div class="input_field transition-5" data-border="#de4c41">
					<div class="field_container">
						<div class="field_content">
							<input type="text" class="field_element_input" name="title">
							
							<div class="field_label">Ticket Title</div>
						</div>
						
						<div class="field_extra">
						</div>
					</div>
					
					<div class="field_bottom">
						<div class="field_error" data-error="required">This field is required</div>
					</div>
				</div>
				
				<div class="dropdown_field transition-5 width-full">
					<div class="field_container">
						<div class="field_content">
							<input type="text" class="field_element_input" name="department" value="0">
							<div class="field_dropdown"></div>
						
							<div class="field_element_dropdowns">
								<div class="field_element_dropdown" value="0" data-index="0">General / Others</div>
								<div class="field_element_dropdown" value="1" data-index="1">Bug report</div>
								<div class="field_element_dropdown" value="2" data-index="2">Trade offer issue</div>
								<div class="field_element_dropdown" value="3" data-index="3">Improvements / Ideas</div>
								<div class="field_element_dropdown" value="4" data-index="4">Marketing / Partnership</div>
								<div class="field_element_dropdown" value="5" data-index="5">Ranking up</div>
							</div>
						
							<div class="field_label active">Department</div>
						</div>
						
						<div class="field_extra">
							<div class="field_caret">
								<i class="fa fa-caret-down"></i>
							</div>
						</div>
					</div>
					
					<div class="field_bottom"></div>
				</div>
				
				<div class="input_field transition-5" data-border="#de4c41">
					<div class="field_container">
						<div class="field_content">
							<textarea type="text" class="field_element_input" name="message"></textarea>
							
							<div class="field_label transition-5">Ticket Message</div>
						</div>
						
						<div class="field_extra">
						</div>
					</div>
					
					<div class="field_bottom">
						<div class="field_error" data-error="required">This field is required</div>
						<div class="field_error" data-error="minimum_10_characters">This field must be a text with minimum 10 characters</div>
					</div>
				</div>
				
				<button class="site-button purple width-full" type="submit" name="new">SEND TICKET</button>
			</form>
		</div>
	</div>
</div>