<div class="p-2">
	<div class="grid split-column-full responsive gap-1 mb-2">
		<a href="<?php echo $site['root']; ?>admin/control"><button class="site-button black active width-full">Control</button></a>
		<a href="<?php echo $site['root']; ?>admin/users"><button class="site-button black width-full">Users</button></a>
		<a href="<?php echo $site['root']; ?>admin/trades"><button class="site-button black width-full">Trades</button></a>
		<a href="<?php echo $site['root']; ?>admin/casecreator"><button class="site-button black width-full">Case Creator</button></a>
		<a href="<?php echo $site['root']; ?>admin/gamebots"><button class="site-button black width-full">Game Bots</button></a>
	</div>
	
	<div class="width-12 flex row responsive gap-2">
		<div class="flex column gap-2 width-5 responsive height-full">
			<div class="flex column gap-4 bg-light-transparent rounded-1 b-l2 p-2">
				<div class="flex column gap-2 text-left">
					<div class="font-8">
						<span>Status Server - <span>
						<span class="status-server">
							<span class="text-warning" data-status="connecting">Connecting</span>
							<span class="text-success hidden" data-status="running">Running</span>
							<span class="text-danger hidden" data-status="connection_lost">Connection lost</span>
						</span>
					</div>
					<div class="font-8">Maintenance - <?php if($response['settings']['maintenance']['status']){ ?><span class="text-success">Active - Reason: <?php echo $response['settings']['maintenance']['reason']; ?></span><?php } else { ?><span class="text-danger">Inactive</span><?php } ?></div>
					<div class="font-8">Status Games - <?php if($response['settings']['games']['status']){ ?><span class="text-success">Active</span><?php } else { ?><span class="text-danger">Inactive</span><?php } ?></div>
					<div class="font-8">Status Trades - <?php if($response['settings']['trades']['status']){ ?><span class="text-success">Active</span><?php } else { ?><span class="text-danger">Inactive</span><?php } ?></div>
				</div>
				
				<div class="flex column gap-2 text-left">
					<div class="font-8">Roulette - <?php if($response['settings']['games']['enable']['roulette']){ ?><span class="text-success">Active</span><?php } else { ?><span class="text-danger">Inactive</span><?php } ?></div>
					<div class="font-8">Crash - <?php if($response['settings']['games']['enable']['crash']){ ?><span class="text-success">Active</span><?php } else { ?><span class="text-danger">Inactive</span><?php } ?></div>
					<div class="font-8">Jackpot - <?php if($response['settings']['games']['enable']['jackpot']){ ?><span class="text-success">Active</span><?php } else { ?><span class="text-danger">Inactive</span><?php } ?></div>
					<div class="font-8">Coinflip - <?php if($response['settings']['games']['enable']['coinflip']){ ?><span class="text-success">Active</span><?php } else { ?><span class="text-danger">Inactive</span><?php } ?></div>
					<div class="font-8">Dice - <?php if($response['settings']['games']['enable']['dice']){ ?><span class="text-success">Active</span><?php } else { ?><span class="text-danger">Inactive</span><?php } ?></div>
					<div class="font-8">Unboxing - <?php if($response['settings']['games']['enable']['unboxing']){ ?><span class="text-success">Active</span><?php } else { ?><span class="text-danger">Inactive</span><?php } ?></div>
					<div class="font-8">Case Battle - <?php if($response['settings']['games']['enable']['casebattle']){ ?><span class="text-success">Active</span><?php } else { ?><span class="text-danger">Inactive</span><?php } ?></div>
					<div class="font-8">Upgrader - <?php if($response['settings']['games']['enable']['upgrader']){ ?><span class="text-success">Active</span><?php } else { ?><span class="text-danger">Inactive</span><?php } ?></div>
					<div class="font-8">Minesweeper - <?php if($response['settings']['games']['enable']['minesweeper']){ ?><span class="text-success">Active</span><?php } else { ?><span class="text-danger">Inactive</span><?php } ?></div>
					<div class="font-8">Tower - <?php if($response['settings']['games']['enable']['tower']){ ?><span class="text-success">Active</span><?php } else { ?><span class="text-danger">Inactive</span><?php } ?></div>
					<div class="font-8">Plinko - <?php if($response['settings']['games']['enable']['plinko']){ ?><span class="text-success">Active</span><?php } else { ?><span class="text-danger">Inactive</span><?php } ?></div>
				</div>
			</div>
			
			<div class="flex column gap-2 bg-light-transparent rounded-1 b-l2 p-2">
				<div class="flex column items-start gap-2">
					<div class="text-left font-8">Deposit Bonuses</div>
					
					<div class="flex column width-full">
						<div class="flex row responsive gap-2 width-full">
							<div class="input_field transition" data-border="#de4c41">
								<div class="field_container">
									<div class="field_content">
										<input type="text" class="field_element_input" id="admin_deposit_bonus_referral" value="">
										
										<div class="field_label transition">Referral</div>
									</div>
									
									<div class="field_extra">
									</div>
								</div>
								
								<div class="field_bottom">
									<div class="field_error" data-error="required">This field is required</div>
								</div>
							</div>
							
							<div class="input_field transition" data-border="#de4c41">
								<div class="field_container">
									<div class="field_content">
										<input type="text" class="field_element_input" id="admin_deposit_bonus_code" value="">
										
										<div class="field_label transition">Code</div>
									</div>
									
									<div class="field_extra">
										<button class="site-button purple" id="admin_deposit_bonus_create">Create</button>
									</div>
								</div>
								
								<div class="field_bottom">
									<div class="field_error" data-error="required">This field is required</div>
								</div>
							</div>
						</div>
						
						<div class="flex column gap-1">
							<div class="input_field bet_input_field transition-5" data-border="#de4c41">
								<div class="field_container">
									<div class="field_content">
										<input type="text" class="field_element_input" id="admin_deposit_bonuses_search" value="">
										
										<div class="field_label transition-5">Search Deposit Bonus</div>
									</div>
									
									<div class="field_extra">
									</div>
								</div>
								
								<div class="field_bottom"></div>
							</div>
							
							<div class="table-container">
								<div class="table-header">
									<div class="table-row">
										<div class="table-column text-left">Code</div>
										<div class="table-column text-left">Referral</div>
										<div class="table-column text-left">Uses</div>
										<div class="table-column text-left">Amount</div>
										<div class="table-column text-right">Action</div>
									</div>
								</div>
								
								<div class="table-body" id="admin_deposit_bonuses">
									<?php if(sizeof($response['deposit_bonuses']['list']) > 0){?>
									<?php foreach($response['deposit_bonuses']['list'] as $key => $value){ ?>
									
									<div class="table-row">
										<div class="table-column text-left pointer" data-copy="text" data-text="<?php echo strtoupper($value['code']); ?>"><?php echo strtoupper($value['code']); ?></div>
										<div class="table-column text-left pointer" data-copy="text" data-text="<?php echo $value['referral']; ?>"><?php echo $value['referral']; ?></div>
										<div class="table-column text-left"><?php echo $value['uses']; ?></div>
										<div class="table-column text-left"><?php echo number_format(roundedToFixed($value['amount'], 5), 5, '.', ''); ?></div>
										
										<div class="table-column full text-right">
											<button class="site-button purple admin_deposit_bonus_remove" data-id="<?php echo $value['id']; ?>">Remove</button>
										</div>
									</div>
									
									<?php } ?>
									<?php } else { ?>
									<div class="table-row table_message">
										<div class="table-column">No data found</div>
									</div>
									<?php } ?>
								</div>
								
								<div class="table-footer">
									<div class="flex items-center justify-center bg-dark p-2">
										<div class="pagination-content flex row gap-2" id="pagination_admin_deposit_bonuses">
											<div class="pagination-item flex items-center justify-center" data-page="1">«</div>
											
											<div class="flex row gap-1">
												<?php $imin_page = $response['deposit_bonuses']['page'] - 3; ?>
												<?php $imax_page = $response['deposit_bonuses']['page'] + 3; ?>
												
												<?php $min_page = max(1, ($imin_page - (($imax_page > $response['deposit_bonuses']['pages']) ? $imax_page - $response['deposit_bonuses']['pages'] : 0))); ?>
												<?php $max_page = min($response['deposit_bonuses']['pages'], ($imax_page + (($imin_page < 1) ? 1 - $imin_page : 0))); ?>
											
												<?php for($i = $min_page; $i <= $max_page; $i++){ ?>
												<div class="pagination-item flex items-center justify-center <?php if($response['deposit_bonuses']['page'] == $i) { ?>active<?php } ?>" data-page="<?php echo $i; ?>"><?php echo $i; ?></div>
												<?php } ?>
											</div>
											
											<div class="pagination-item flex items-center justify-center" data-page="<?php echo $response['deposit_bonuses']['pages']; ?>">»</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="flex column gap-2 bg-light-transparent rounded-1 b-l2 p-2">
				<div class="flex column items-start gap-2">
					<div class="text-left font-8">Alerts</div>
					
					<div class="flex column gap-1 width-full">
						<div class="input_field bet_input_field transition-5" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" id="admin_alert_alert" value="">
									
									<div class="field_label transition-5">Alert</div>
								</div>
								
								<div class="field_extra">
									<button class="site-button purple" id="admin_alert_set">Set</button>
								</div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
						
						<div class="flex column gap-2">
							<?php foreach($response['settings']['server']['alerts'] as $key => $value){ ?>
								<div class="flex row gap-1 items-center justify-between bg-light rounded-1 b-d2 p-2">
									<div class="text-left"><?php echo $value; ?></div>
									
									<button class="site-button purple admin_alert_unset" data-id="<?php echo $key; ?>">Remove</button>
								</div>
							<?php } ?>
						</div>
					</div>
				</div>
			</div>
			
			<div class="flex column gap-2 bg-light-transparent rounded-1 b-l2 p-2">
				<div class="flex column items-start gap-2">
					<div class="text-left font-8">Notifies</div>
					
					<div class="flex column gap-1 width-full">
						<div class="input_field bet_input_field transition-5" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" id="admin_notify_notify" value="">
									
									<div class="field_label transition-5">Notify</div>
								</div>
								
								<div class="field_extra">
									<button class="site-button purple" id="admin_notify_set">Set</button>
								</div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
						
						<div class="flex column gap-2">
							<?php foreach($response['settings']['server']['notifies'] as $key => $value){ ?>
								<div class="flex row gap-1 items-center justify-between bg-light rounded-1 b-d2 p-2">
									<div class="text-left"><?php echo $value; ?></div>
									
									<button class="site-button purple admin_notify_unset" data-id="<?php echo $key; ?>">Remove</button>
								</div>
							<?php } ?>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="flex column gap-2 width-7 responsive height-full">
			<div class="flex column gap-2 bg-light-transparent rounded-1 b-l2 p-2">
				<div class="flex column items-start gap-2">
					<div class="text-left font-8">Maintenance</div>
					
					<div class="flex row responsive gap-2 width-full">
						<div class="dropdown_field transition-5">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" id="admin_maintenance_status" value="1">
									<div class="field_dropdown"></div>
								
									<div class="field_element_dropdowns">
										<div class="field_element_dropdown" value="1" data-index="0">Enable</div>
										<div class="field_element_dropdown" value="0" data-index="1">Disable</div>
									</div>
								
									<div class="field_label active transition-5">Status</div>
								</div>
								
								<div class="field_extra">
									<div class="field_caret">
										<i class="fa fa-caret-down"></i>
									</div>
								</div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
						
						<div class="input_field transition" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" id="admin_maintenance_reason" value="">
									
									<div class="field_label transition">Reason</div>
								</div>
								
								<div class="field_extra">
									<button class="site-button purple" id="admin_maintenance_set">Set</button>
								</div>
							</div>
							
							<div class="field_bottom">
								<div class="field_error" data-error="required">This field is required</div>
							</div>
						</div>
					</div>
				</div>
				
				<div class="flex column items-start gap-2">
					<div class="text-left font-8">Games</div>
					
					<div class="flex row responsive items-center gap-2">
						<div class="dropdown_field transition-5">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input admin_control_settings" data-settings="games_status" value="<?php echo $response['settings']['games']['status'] ? '1' : '0'; ?>">
									<div class="field_dropdown"></div>
								
									<div class="field_element_dropdowns">
										<div class="field_element_dropdown" value="1" data-index="0">Enable</div>
										<div class="field_element_dropdown" value="0" data-index="1">Disable</div>
									</div>
								
									<div class="field_label active transition-5">Status</div>
								</div>
								
								<div class="field_extra">
									<div class="field_caret">
										<i class="fa fa-caret-down"></i>
									</div>
								</div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
						
						<button class="site-button purple admin_dropdown_settings" data-settings="games_status">Set</button>
					</div>
				</div>
				
				<div class="flex column items-start gap-2">
					<div class="text-left font-8">Trades</div>
					
					<div class="flex row responsive items-center gap-2">
						<div class="dropdown_field transition-5">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input admin_control_settings" data-settings="trades_status" value="<?php echo $response['settings']['trades']['status'] ? '1' : '0'; ?>">
									<div class="field_dropdown"></div>
								
									<div class="field_element_dropdowns">
										<div class="field_element_dropdown" value="1" data-index="0">Enable</div>
										<div class="field_element_dropdown" value="0" data-index="1">Disable</div>
									</div>
								
									<div class="field_label active transition-5">Status</div>
								</div>
								
								<div class="field_extra">
									<div class="field_caret">
										<i class="fa fa-caret-down"></i>
									</div>
								</div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
						
						<button class="site-button purple admin_dropdown_settings" data-settings="trades_status">Set</button>
					</div>
				</div>
				
				<div class="flex column items-start gap-2">
					<div class="text-left font-8">Games</div>
					
					<div class="inline-block text-left width-full">
						<div class="switch_field height-full transition-5">
							<div class="field_container">
								<div class="field_content">
									<input type="checkbox" class="field_element_input admin_switch_settings" data-settings="games_enable_roulette" <?php if($response['settings']['games']['enable']['roulette']){ ?>checked<?php } ?>>
									
									<div class="field_switch">
										<div class="field_switch_bar"></div>
									</div>
									
									<div class="field_label active transition-5">Roulette</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
						
						<div class="switch_field height-full transition-5">
							<div class="field_container">
								<div class="field_content">
									<input type="checkbox" class="field_element_input admin_switch_settings" data-settings="games_enable_crash" <?php if($response['settings']['games']['enable']['crash']){ ?>checked<?php } ?>>
									
									<div class="field_switch">
										<div class="field_switch_bar"></div>
									</div>
									
									<div class="field_label active transition-5">Crash</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
						
						<div class="switch_field height-full transition-5">
							<div class="field_container">
								<div class="field_content">
									<input type="checkbox" class="field_element_input admin_switch_settings" data-settings="games_enable_jackpot" <?php if($response['settings']['games']['enable']['jackpot']){ ?>checked<?php } ?>>
									
									<div class="field_switch">
										<div class="field_switch_bar"></div>
									</div>
									
									<div class="field_label active transition-5">Jackpot</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
						
						<div class="switch_field height-full transition-5">
							<div class="field_container">
								<div class="field_content">
									<input type="checkbox" class="field_element_input admin_switch_settings" data-settings="games_enable_coinflip" <?php if($response['settings']['games']['enable']['coinflip']){ ?>checked<?php } ?>>
									
									<div class="field_switch">
										<div class="field_switch_bar"></div>
									</div>
									
									<div class="field_label active transition-5">Coinflip</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
						
						<div class="switch_field height-full transition-5">
							<div class="field_container">
								<div class="field_content">
									<input type="checkbox" class="field_element_input admin_switch_settings" data-settings="games_enable_dice" <?php if($response['settings']['games']['enable']['dice']){ ?>checked<?php } ?>>
									
									<div class="field_switch">
										<div class="field_switch_bar"></div>
									</div>
									
									<div class="field_label active transition-5">Dice</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
						
						<div class="switch_field height-full transition-5">
							<div class="field_container">
								<div class="field_content">
									<input type="checkbox" class="field_element_input admin_switch_settings" data-settings="games_enable_unboxing" <?php if($response['settings']['games']['enable']['unboxing']){ ?>checked<?php } ?>>
									
									<div class="field_switch">
										<div class="field_switch_bar"></div>
									</div>
									
									<div class="field_label active transition-5">Unboxing</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
						
						<div class="switch_field height-full transition-5">
							<div class="field_container">
								<div class="field_content">
									<input type="checkbox" class="field_element_input admin_switch_settings" data-settings="games_enable_casebattle" <?php if($response['settings']['games']['enable']['casebattle']){ ?>checked<?php } ?>>
									
									<div class="field_switch">
										<div class="field_switch_bar"></div>
									</div>
									
									<div class="field_label active transition-5">Case Battle</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
						
						<div class="switch_field height-full transition-5">
							<div class="field_container">
								<div class="field_content">
									<input type="checkbox" class="field_element_input admin_switch_settings" data-settings="games_enable_upgrader" <?php if($response['settings']['games']['enable']['upgrader']){ ?>checked<?php } ?>>
									
									<div class="field_switch">
										<div class="field_switch_bar"></div>
									</div>
									
									<div class="field_label active transition-5">Upgrader</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
						
						<div class="switch_field height-full transition-5">
							<div class="field_container">
								<div class="field_content">
									<input type="checkbox" class="field_element_input admin_switch_settings" data-settings="games_enable_minesweeper" <?php if($response['settings']['games']['enable']['minesweeper']){ ?>checked<?php } ?>>
									
									<div class="field_switch">
										<div class="field_switch_bar"></div>
									</div>
									
									<div class="field_label active transition-5">Minesweeper</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
						
						<div class="switch_field height-full transition-5">
							<div class="field_container">
								<div class="field_content">
									<input type="checkbox" class="field_element_input admin_switch_settings" data-settings="games_enable_tower" <?php if($response['settings']['games']['enable']['tower']){ ?>checked<?php } ?>>
									
									<div class="field_switch">
										<div class="field_switch_bar"></div>
									</div>
									
									<div class="field_label active transition-5">Tower</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
						
						<div class="switch_field height-full transition-5">
							<div class="field_container">
								<div class="field_content">
									<input type="checkbox" class="field_element_input admin_switch_settings" data-settings="games_enable_plinko" <?php if($response['settings']['games']['enable']['plinko']){ ?>checked<?php } ?>>
									
									<div class="field_switch">
										<div class="field_switch_bar"></div>
									</div>
									
									<div class="field_label active transition-5">Plinko</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="flex column gap-2 bg-light-transparent rounded-1 b-l2 p-2">
				<div class="flex column items-start gap-2">
					<div class="text-left font-8">Admin Access - <span class="text-success"><?php echo implode(', ', $response['settings']['allowed']['admin']); ?></span></div>
					
					<div class="input_field transition" data-border="#de4c41">
						<div class="field_container">
							<div class="field_content">
								<input type="text" class="field_element_input" id="admin_admin_access_userid" value="">
								
								<div class="field_label transition">User Id</div>
							</div>
							
							<div class="field_extra">
								<button class="site-button purple" id="admin_admin_access_set">Set</button>
								<button class="site-button purple" id="admin_admin_access_unset">Unset</button>
							</div>
						</div>
						
						<div class="field_bottom">
							<div class="field_error" data-error="required">This field is required</div>
						</div>
					</div>
				</div>
				
				<div class="flex column items-start gap-2">
					<div class="text-left font-8">Dashboard Access - <span class="text-success"><?php echo implode(', ', $response['settings']['allowed']['dashboard']); ?></span></div>
					
					<div class="input_field transition" data-border="#de4c41">
						<div class="field_container">
							<div class="field_content">
								<input type="text" class="field_element_input" id="admin_dashboard_access_userid" value="">
								
								<div class="field_label transition">User Id</div>
							</div>
							
							<div class="field_extra">
								<button class="site-button purple" id="admin_dashboard_access_set">Set</button>
								<button class="site-button purple" id="admin_dashboard_access_unset">Unset</button>
							</div>
						</div>
						
						<div class="field_bottom">
							<div class="field_error" data-error="required">This field is required</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="flex column gap-2 bg-light-transparent rounded-1 b-l2 p-2">			
				<div class="flex column items-start gap-2">
					<div class="text-left font-8">Join Referrals</div>
					
					<div class="flex column width-full">
						<div class="flex row responsive gap-2 width-full">
							<div class="dropdown_field transition-5">
								<div class="field_container">
									<div class="field_content">
										<input type="text" class="field_element_input" id="admin_join_referrals_expire" value="permanent">
										<div class="field_dropdown"></div>
									
										<div class="field_element_dropdowns">
											<div class="field_element_dropdown" value="permanent" data-index="0">Never</div>
											<div class="field_element_dropdown" value="1days" data-index="1">One day</div>
											<div class="field_element_dropdown" value="7days" data-index="2">One week</div>
											<div class="field_element_dropdown" value="1months" data-index="3">One month</div>
										</div>
									
										<div class="field_label active transition-5">Expire</div>
									</div>
									
									<div class="field_extra">
										<div class="field_caret">
											<i class="fa fa-caret-down"></i>
										</div>
									</div>
								</div>
								
								<div class="field_bottom"></div>
							</div>
							
							<div class="input_field transition" data-border="#de4c41">
								<div class="field_container">
									<div class="field_content">
										<input type="text" class="field_element_input" id="admin_join_referrals_usage" value="">
										
										<div class="field_label transition">Usage</div>
									</div>
									
									<div class="field_extra">
										<button class="site-button purple" id="admin_join_referrals_create">Create</button>
									</div>
								</div>
								
								<div class="field_bottom">
									<div class="field_error" data-error="required">This field is required</div>
								</div>
							</div>
						</div>
						
						<div class="flex column gap-1">
							<div class="input_field bet_input_field transition-5" data-border="#de4c41">
								<div class="field_container">
									<div class="field_content">
										<input type="text" class="field_element_input" id="admin_join_referrals_search" value="">
										
										<div class="field_label transition-5">Search Join Referral</div>
									</div>
									
									<div class="field_extra">
									</div>
								</div>
								
								<div class="field_bottom"></div>
							</div>
							
							<div class="table-container">
								<div class="table-header">
									<div class="table-row">
										<div class="table-column text-left">Raferral</div>
										<div class="table-column text-left">User Id</div>
										<div class="table-column text-left">Usage</div>
										<div class="table-column text-right">Action</div>
									</div>
								</div>
								
								<div class="table-body" id="admin_join_referrals">
									<?php if(sizeof($response['join_referrals']['list']) > 0){?>
									<?php foreach($response['join_referrals']['list'] as $key => $value){ ?>
									
									<div class="table-row">
										<div class="table-column text-left pointer" data-copy="text" data-text="<?php echo $value['referral']; ?>"><?php echo $value['referral']; ?></div>
										<div class="table-column text-left pointer" data-copy="text" data-text="<?php echo $value['userid']; ?>"><?php echo $value['userid']; ?></div>
										<div class="table-column text-left"><?php echo $value['usage']; ?></div>
										
										<div class="table-column full text-right">
											<div class="flex responsive row justify-end gap-1">
												<!--<button class="site-button purple admin_join_referrals_remove" data-id="<?php echo $value['id']; ?>">Remove</button>-->
												<button class="site-button purple admin_join_referral_dashboard" data-id="<?php echo $value['id']; ?>">Dashboard</button>
												<button class="site-button red" data-copy="text" data-text="<?php echo $site['url']; ?><?php echo substr($site['root'], 0, -1); ?>?ref=<?php echo $value['referral']; ?>">Copy link</button>
											</div>
										</div>
									</div>
									
									<?php } ?>
									<?php } else { ?>
									<div class="table-row table_message">
										<div class="table-column">No data found</div>
									</div>
									<?php } ?>
								</div>
								
								<div class="table-footer">
									<div class="flex items-center justify-center bg-dark p-2">
										<div class="pagination-content flex row gap-2" id="pagination_admin_join_referrals">
											<div class="pagination-item flex items-center justify-center" data-page="1">«</div>
											
											<div class="flex row gap-1">
												<?php $imin_page = $response['join_referrals']['page'] - 3; ?>
												<?php $imax_page = $response['join_referrals']['page'] + 3; ?>
												
												<?php $min_page = max(1, ($imin_page - (($imax_page > $response['join_referrals']['pages']) ? $imax_page - $response['join_referrals']['pages'] : 0))); ?>
												<?php $max_page = min($response['join_referrals']['pages'], ($imax_page + (($imin_page < 1) ? 1 - $imin_page : 0))); ?>
											
												<?php for($i = $min_page; $i <= $max_page; $i++){ ?>
												<div class="pagination-item flex items-center justify-center <?php if($response['join_referrals']['page'] == $i) { ?>active<?php } ?>" data-page="<?php echo $i; ?>"><?php echo $i; ?></div>
												<?php } ?>
											</div>
											
											<div class="pagination-item flex items-center justify-center" data-page="<?php echo $response['join_referrals']['pages']; ?>">»</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>