<div class="flex column height-full width-full">
	<div class="wrapper-page flex row">
		<div class="flex column height-full width-full content-spliter p-2">
			<div class="flex justify-between">
				<a href="<?php echo $site['root'];?>deposit"><button class="site-button black"><i class="fa fa-arrow-left mr-1"></i> Back to Options</button></a>
				
				<button class="site-button purple" id="refresh_inventory">Refresh</button>
			</div>
		
			<div class="flex gap-1">
				<div class="input_field bet_input_field transition-5" data-border="#de4c41">
					<div class="field_container">
						<div class="field_content">
							<input type="text" class="field_element_input" id="items_search" value="">
							
							<div class="field_label transition-5">Search Item</div>
						</div>
						
						<div class="field_extra"></div>
					</div>
					
					<div class="field_bottom"></div>
				</div>
				
				<div class="dropdown_field transition-5">
					<div class="field_container">
						<div class="field_content">
							<input type="text" class="field_element_input" id="items_order" value="0">
							<div class="field_dropdown"></div>
							
							<div class="field_element_dropdowns">
								<div class="field_element_dropdown" value="0" data-index="0">Price descending</div>
								<div class="field_element_dropdown" value="1" data-index="1">Price acending</div>
								<div class="field_element_dropdown" value="2" data-index="2">Name A-Z</div>
								<div class="field_element_dropdown" value="3" data-index="3">Name Z-A</div>
							</div>
						
							<div class="field_label active transition-5">Order by</div>
						</div>
						
						<div class="field_extra">
							<div class="field_caret">
								<i class="fa fa-caret-down"></i>
							</div>
						</div>
					</div>
					
					<div class="field_bottom"></div>
				</div>
			</div>
			
			<div class="height-full" id="list_items"></div>
		</div>
	</div>
</div>