<div class="p-2">
	<div class="grid split-column-full responsive gap-1 mb-2">
		<a href="<?php echo $site['root']; ?>admin/control"><button class="site-button black width-full">Control</button></a>
		<a href="<?php echo $site['root']; ?>admin/users"><button class="site-button black width-full">Users</button></a>
		<a href="<?php echo $site['root']; ?>admin/trades"><button class="site-button black width-full">Trades</button></a>
		<a href="<?php echo $site['root']; ?>admin/casecreator"><button class="site-button black width-full">Case Creator</button></a>
		<a href="<?php echo $site['root']; ?>admin/gamebots"><button class="site-button black active width-full">Game Bots</button></a>
	</div>
	
	<div class="width-12 flex row responsive gap-2">
		<div class="width-4 responsive flex column gap-2 text-left height-full bg-light-transparent rounded-1 b-l2 p-2">
			<div class="flex column items-start gap-2">
				<div class="text-left font-8">Game Bots</div>
				
				<div class="flex column gap-2">
					<div class="flex row gap-2">
						<div class="switch_field height-full transition-5">
							<div class="field_container">
								<div class="field_content">
									<input type="checkbox" class="field_element_input admin_switch_settings" data-settings="games_bots_enable_coinflip" <?php if($response['settings']['games']['bots']['enable']['coinflip']){ ?>checked<?php } ?>>
									
									<div class="field_switch">
										<div class="field_switch_bar"></div>
									</div>
									
									<div class="field_label active transition-5">Coinflip Game Bots</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
						
						<div class="text-left mt-2">If this is enabled, all users can call bots on Coinflip Game.</div>
					</div>
					
					<div class="flex row gap-2">
						<div class="switch_field height-full transition-5">
							<div class="field_container">
								<div class="field_content">
									<input type="checkbox" class="field_element_input admin_switch_settings" data-settings="games_bots_enable_casebattle" <?php if($response['settings']['games']['bots']['enable']['casebattle']){ ?>checked<?php } ?>>
									
									<div class="field_switch">
										<div class="field_switch_bar"></div>
									</div>
									
									<div class="field_label active transition-5">Casebattle Game Bots</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
						
						<div class="text-left mt-2">If this is enabled, all users can call bots on Case Battle Game.</div>
					</div>
					
					<div class="input_field transition" data-border="#de4c41">
						<div class="field_container">
							<div class="field_content">
								<input type="text" class="field_element_input" id="admin_gamebots_name" value="">
								
								<div class="field_label transition">Bot Name</div>
							</div>
							
							<div class="field_extra">
								<button class="site-button purple" id="admin_gamebots_create">Create</button>
							</div>
						</div>
						
						<div class="field_bottom">
							<div class="field_error" data-error="required">This field is required</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="width-8 responsive flex column gap-2 height-full">
			<div class="bg-light-transparent rounded-1 b-l2 p-2">
				<div class="flex column gap-1">
					<div class="flex gap-1">
						<div class="input_field transition-5" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" id="admin_gamebots_search" value="">
									
									<div class="field_label transition-5">Search Bot (userid, username, name)</div>
								</div>
								
								<div class="field_extra">
								</div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
						
						<div class="dropdown_field transition-5">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" id="admin_gamebots_order" value="0">
									<div class="field_dropdown"></div>
								
									<div class="field_element_dropdowns">
										<div class="field_element_dropdown" value="0" data-index="0">Creation date</div>
										<div class="field_element_dropdown" value="1" data-index="1">Name A-Z</div>
										<div class="field_element_dropdown" value="2" data-index="2">Name Z-A</div>
										<div class="field_element_dropdown" value="3" data-index="3">Balance acending</div>
										<div class="field_element_dropdown" value="4" data-index="4">Balance descending</div>
									</div>
									
									<div class="field_label active transition-5">Order by</div>
								</div>
								
								<div class="field_extra">
									<div class="field_caret">
										<i class="fa fa-caret-down"></i>
									</div>
								</div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
					</div>
					
					<div class="table-container">
						<div class="table-header">
							<div class="table-row">
								<div class="table-column text-left">User</div>
								<div class="table-column text-left">User Id</div>
								<div class="table-column text-left">Balance</div>
								<div class="table-column text-right">Action</div>
							</div>
						</div>
						<div class="table-body" id="admin_gamebots_list">
							<?php if(sizeof($response['bots']['list']) > 0){?>
							<?php foreach($response['bots']['list'] as $key => $value){ ?>
							
							<?php
							
							$level = calculateLevel($value['xp']);
							
							$level_class = array('tier-steel', 'tier-bronze', 'tier-silver', 'tier-gold', 'tier-diamond')[intval($level['level'] / 25)];
							$rank_name = $site['ranks_name'][$value['rank']];
							
							?>
							
							<div class="table-row">
								<div class="table-column text-left">
									<div class="flex items-center gap-1">
										<div class="avatar-field <?php echo $level_class; ?> relative">
											<img class="avatar icon-small rounded-full" src="<?php echo $value['avatar']; ?>">
											<div class="level sup-small-left flex justify-center items-center b-d2 bg-dark rounded-full"><?php echo $level['level']; ?></div>
										</div>
										
										<div class="text-left width-full ellipsis"><?php echo $value['name']; ?></div>
									</div>
								</div>
								
								<div class="table-column text-left pointer" data-copy="text" data-text="<?php echo $value['userid']; ?>"><?php echo $value['userid']; ?></div>
								<div class="table-column text-left"><?php echo getFormatAmountString($value['balance']); ?>$</div>
								
								<div class="table-column text-right"><button class="site-button purple admin_gamebot_moderate" data-userid="<?php echo $value['userid']; ?>">Moderate</button></div>
							</div>
							<?php } ?>
							<?php } else { ?>
							<div class="table-row table_message">
								<div class="table-column">No data found</div>
							</div>
							<?php } ?>
						</div>
						<div class="table-footer">
							<div class="flex items-center justify-center bg-dark p-2">
								<div class="pagination-content flex row gap-2" id="pagination_admin_gamebots">
									<div class="pagination-item flex items-center justify-center" data-page="1">«</div>
									
									<div class="flex row gap-1">
										<?php $imin_page = $response['bots']['page'] - 3; ?>
										<?php $imax_page = $response['bots']['page'] + 3; ?>
										
										<?php $min_page = max(1, ($imin_page - (($imax_page > $response['bots']['pages']) ? $imax_page - $response['bots']['pages'] : 0))); ?>
										<?php $max_page = min($response['bots']['pages'], ($imax_page + (($imin_page < 1) ? 1 - $imin_page : 0))); ?>
									
										<?php for($i = $min_page; $i <= $max_page; $i++){ ?>
										<div class="pagination-item flex items-center justify-center <?php if($response['bots']['page'] == $i) { ?>active<?php } ?>" data-page="<?php echo $i; ?>"><?php echo $i; ?></div>
										<?php } ?>
									</div>
									
									<div class="pagination-item flex items-center justify-center" data-page="<?php echo $response['bots']['pages']; ?>">»</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>