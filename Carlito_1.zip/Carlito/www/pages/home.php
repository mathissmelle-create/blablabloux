<div class="m-2">
	<div class="flex column justify-center gap-2">
		<div class="carousel large rounded-1">
			<div class="carousel-content flex row justify-between items-center">
				<div class="carousel-button flex justify-center items-center" data-type="left">
					<i class="fa fa-angle-left" aria-hidden="true"></i>
				</div>
				
				<div class="carousel-pages">
					<div class="carousel-page active" data-page="crypto" data-index="0">
						<div class="carousel-panel flex column items-start justify-between text-left">
							<div class="flex column items-start gap-2">
								<div class="title text-bold font-20 text-blue">TRUE CRYPTO CASINO</div>
								<div class="description">Enjoy <span class="text-blue">blazing fast</span> transactions with <span class="text-blue">most popular</span> cryptocurrencies exclusive on <?php echo $site['name'];?></div>
							</div>
							
							<a href="<?php echo $site['root']; ?>deposit"><button class="site-button large blue">Start Playing</button></a>
						</div>
					</div>
					
					<div class="carousel-page" data-page="affiliates" data-index="1">
						<div class="carousel-panel flex column items-start justify-between text-left">
							<div class="flex column items-start gap-2">
								<div class="title text-bold font-20 text-orange">BIG AFFILIATES REWARDS</div>
								<div class="description">We give up to <span class="text-orange"><?php echo number_format(roundedToFixed($affiliates['commission']['bet'] * sizeof($affiliates['requirements']), 2), 2, '.', ''); ?>% commission</span> of your friends bets and up to <span class="text-orange"><?php echo number_format(roundedToFixed($affiliates['commission']['deposit'] * sizeof($affiliates['requirements']), 2), 2, '.', ''); ?>% commission</span> of your friends deposits!</div>
							</div>
							
							<a href="<?php echo $site['root']; ?>deposit"><button class="site-button large orange">Start Playing</button></a>
						</div>
					</div>
				</div>
				
				<div class="carousel-button flex justify-center items-center" data-type="right">
					<i class="fa fa-angle-right" aria-hidden="true"></i>
				</div>
			</div>
		</div>
		
		<div class="flex column height-full width-full overflow-a p-2 gap-4 text-left">
			<div>
				<div class="home-options-name">Casino</div>
				<div class="home-options-description text-gray">Enjoy casino games at the comforts of your home!</div>
				
				<div class="home-options medium mt-2">
					<a class="disabled" href="<?php echo $site['root'];?>slots">
						<div class="home-option p-2 rounded-2">
							<div class="home-option-image-content slots rounded-1"></div>
							
							<div class="home-option-name flex justify-center items-center">Slots</div>
							<div class="home-option-description flex justify-center items-center">Play on slots</div>
							
							<div class="home-option-info font-5 pl-2 pr-2 pt-1 pb-1 rounded-1">Coming soon</div>
						</div>
					</a>
					
					<a class="disabled" href="<?php echo $site['root'];?>match_betting">
						<div class="home-option p-2 rounded-2">
							<div class="home-option-image-content match_betting rounded-1"></div>
							
							<div class="home-option-name flex justify-center items-center">Match betting</div>
							<div class="home-option-description flex justify-center items-center">Play on match betting</div>
							
							<div class="home-option-info font-5 pl-2 pr-2 pt-1 pb-1 rounded-1">Coming soon</div>
						</div>
					</a>
				</div>
			</div>
			
			<div>
				<div class="home-options-name1">Originals</div>
				<div class="home-options-description text-gray">Play one of our classic games!</div>
				
				<div class="home-options small mt-2">
					<a href="<?php echo $site['root'];?>roulette">
						<div class="home-option p-2 rounded-2">
							<div class="home-option-image-content roulette rounded-1"></div>
							
							<div class="home-option-name flex justify-center items-center">Roulette</div>
							<div class="home-option-description flex justify-center items-center">Spin the wheel</div>
						</div>
					</a>
					
					<a href="<?php echo $site['root'];?>crash">
						<div class="home-option p-2 rounded-2">
							<div class="home-option-image-content crash rounded-1"></div>
							
							<div class="home-option-name flex justify-center items-center">Crash</div>
							<div class="home-option-description flex justify-center items-center">Reach the sky</div>
						</div>
					</a>
					
					<a href="<?php echo $site['root'];?>jackpot">
						<div class="home-option p-2 rounded-2">
							<div class="home-option-image-content jackpot rounded-1"></div>
							
							<div class="home-option-name flex justify-center items-center">Jackpot</div>
							<div class="home-option-description flex justify-center items-center">The chosen one</div>
						</div>
					</a>
					
					<a href="<?php echo $site['root'];?>coinflip">
						<div class="home-option p-2 rounded-2">
							<div class="home-option-image-content coinflip rounded-1"></div>
							
							<div class="home-option-name flex justify-center items-center">Coinflip</div>
							<div class="home-option-description flex justify-center items-center">Fate on a toss</div>
						</div>
					</a>
					
					<a href="<?php echo $site['root'];?>dice">
						<div class="home-option p-2 rounded-2">
							<div class="home-option-image-content dice rounded-1"></div>
							
							<div class="home-option-name flex justify-center items-center">Dice</div>
							<div class="home-option-description flex justify-center items-center">Roll you luck</div>
						</div>
					</a>
					
					<a href="<?php echo $site['root'];?>unboxing">
						<div class="home-option p-2 rounded-2">
							<div class="home-option-image-content unboxing rounded-1"></div>
							
							<div class="home-option-name flex justify-center items-center">Unboxing</div>
							<div class="home-option-description flex justify-center items-center">Unveil the mystery</div>
						</div>
					</a>
					
					<a href="<?php echo $site['root'];?>casebattle">
						<div class="home-option p-2 rounded-2">
							<div class="home-option-image-content casebattle rounded-1"></div>
							
							<div class="home-option-name flex justify-center items-center">Case Battle</div>
							<div class="home-option-description flex justify-center items-center">Unveil the mystery</div>
						</div>
					</a>
					
					<a href="<?php echo $site['root'];?>upgrader">
						<div class="home-option p-2 rounded-2">
							<div class="home-option-image-content upgrader rounded-1"></div>
							
							<div class="home-option-name flex justify-center items-center">Upgrader</div>
							<div class="home-option-description flex justify-center items-center">Unveil the mystery</div>
						</div>
					</a>
					
					<a href="<?php echo $site['root'];?>minesweeper">
						<div class="home-option p-2 rounded-2">
							<div class="home-option-image-content minesweeper rounded-1"></div>
							
							<div class="home-option-name flex justify-center items-center">Minesweeper</div>
							<div class="home-option-description flex justify-center items-center">Hit or miss</div>
						</div>
					</a>
					
					<a href="<?php echo $site['root'];?>tower">
						<div class="home-option p-2 rounded-2">
							<div class="home-option-image-content tower rounded-1"></div>
							
							<div class="home-option-name flex justify-center items-center">Tower</div>
							<div class="home-option-description flex justify-center items-center">Climp the top</div>
						</div>
					</a>
					
					<a href="<?php echo $site['root'];?>plinko">
						<div class="home-option p-2 rounded-2">
							<div class="home-option-image-content plinko rounded-1"></div>
							
							<div class="home-option-name flex justify-center items-center">Plinko</div>
							<div class="home-option-description flex justify-center items-center">Bounce to win</div>
						</div>
					</a>
				</div>
			</div>
		</div>
	</div>
</div>