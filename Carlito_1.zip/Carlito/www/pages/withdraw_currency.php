<div class="flex column height-full width-full">
	<div class="wrapper-page flex row">
		<div class="flex column height-full width-full p-2">
			<div class="flex justify-start">
				<a href="<?php echo $site['root'];?>withdraw"><button class="site-button black"><i class="fa fa-arrow-left mr-1"></i> Back to Options</button></a>
			</div>
			
			<div class="flex column items-center gap-2 mt-4 overflow-a">
				<div class="width-6 responsive text-left">
					<div class="font-10 text-bold mb-2">Withdraw with <?php echo $response['methods_name']['crypto'][$paths[2]]; ?></div>
					
					<div class="font-6 text-gray">All <?php echo $response['methods_name']['crypto'][$paths[2]]; ?> withdrawals are sent instantly.</div>
				</div>
				
				<div class="bg-light-transparent text-left rounded-1 b-d2 p-4 width-6 responsive currency-panel">
					<div class="font-8 text-bold mb-2"><?php echo $response['methods_name']['crypto'][$paths[2]]; ?> wallet address</div>
					
					<div class="font-6 text-gray">Please enter the <?php echo $response['methods_name']['crypto'][$paths[2]]; ?> wallet address you want the withdrawal to be sent to.</div>
					<div class="font-6 text-gray">All withdraws more than <?php echo getFormatAmountString($response['manually_amount']); ?> coins, require manually confirmations and checks.</div>
					
					<div class="input_field bet_input_field transition-5" data-border="#de4c41">
						<div class="field_container">
							<div class="field_content">
								<input type="text" class="field_element_input" id="currency_withdraw_address" value="">
								
								<div class="field_label transition-5">Your personal <?php echo strtoupper($paths[2]); ?> withdraw address</div>
							</div>
							
							<div class="field_extra"></div>
						</div>
						
						<div class="field_bottom">
							<div class="field_error" data-error="required">This field is required</div>
						</div>
					</div>
					
					<div class="flex responsive mt-2">
						<div class="input_field bet_input_field transition-5" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" id="currency_coin_from" data-currency="<?php echo $paths[2]; ?>" value="100">
									
									<div class="field_label transition-5"><div class="input_coins coins mr-1"></div>Amount Coins</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom">
								<div class="field_error" data-error="required">This field is required</div>
								<div class="field_error" data-error="number">This field must be a number</div>
								<div class="field_error" data-error="greater">You must enter a greater value</div>
								<div class="field_error" data-error="lesser">You must enter a lesser value</div>
							</div>
						</div>
						
						<div class="flex justify-center items-center pr-2 pl-2 font-10">=</div>
						
						<div class="input_field bet_input_field transition-5" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" id="currency_coin_to" data-currency="<?php echo $paths[2]; ?>" value="">
									
									<div class="field_label transition-5"><div class="input_coins <?php echo $paths[2]; ?>-coins mr-1"></div>Amount <?php echo $response['methods_name']['crypto'][$paths[2]]; ?></div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom">
								<div class="field_error" data-error="number">This field must be a number</div>
							</div>
						</div>
					</div>
					
					<div class="flex justify-center mt-2">
						<button type="button" class="site-button purple" id="crypto_withdraw" data-currency="<?php echo $paths[2]; ?>">WITHDRAW</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
