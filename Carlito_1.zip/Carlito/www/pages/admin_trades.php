<div class="p-2">
	<div class="grid split-column-full responsive gap-1 mb-2">
		<a href="<?php echo $site['root']; ?>admin/control"><button class="site-button black width-full">Control</button></a>
		<a href="<?php echo $site['root']; ?>admin/users"><button class="site-button black width-full">Users</button></a>
		<a href="<?php echo $site['root']; ?>admin/trades"><button class="site-button black active width-full">Trades</button></a>
		<a href="<?php echo $site['root']; ?>admin/casecreator"><button class="site-button black width-full">Case Creator</button></a>
		<a href="<?php echo $site['root']; ?>admin/gamebots"><button class="site-button black width-full">Game Bots</button></a>
	</div>
	
	<div class="width-12 flex row responsive gap-2">
		<div class="width-4 responsive flex column gap-2 text-left height-full bg-light-transparent rounded-1 b-l2 p-2">
			<div class="flex column items-start gap-2">
				<div class="text-left font-8">Manually Confirmations</div>
				
				<div class="flex column gap-2">
					<div class="input_field transition" data-border="#de4c41">
						<div class="field_container">
							<div class="field_content">
								<input type="text" class="field_element_input" id="admin_trades_manually_amount_value" value="<?php echo getFormatAmountString($response['settings']['trades']['manually']['amount']); ?>">
								
								<div class="field_label transition">Confirmations Amount</div>
							</div>
							
							<div class="field_extra">
								<button class="site-button purple" id="admin_trades_manually_amount_set">Set</button>
							</div>
						</div>
						
						<div class="field_bottom">
							<div class="field_error" data-error="required">This field is required</div>
							<div class="field_error" data-error="number">This field must be a number</div>
							<div class="field_error" data-error="greater">You must enter a greater value</div>
						</div>
					</div>
					
					<div class="flex row gap-2">
						<div class="switch_field height-full transition-5">
							<div class="field_container">
								<div class="field_content">
									<input type="checkbox" class="field_element_input admin_switch_settings" data-settings="trades_manually_enable_crypto" <?php if($response['settings']['trades']['manually']['enable']['crypto']){ ?>checked<?php } ?>>
									
									<div class="field_switch">
										<div class="field_switch_bar"></div>
									</div>
									
									<div class="field_label active transition-5">Crypto Confirmations</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
						
						<div class="text-left mt-2">If this is enabled, an admin must to confirm manually the Crypto transactions.</div>
					</div>
					
					<div class="flex row gap-2">
						<div class="switch_field height-full transition-5">
							<div class="field_container">
								<div class="field_content">
									<input type="checkbox" class="field_element_input admin_switch_settings" data-settings="trades_manually_enable_steam" <?php if($response['settings']['trades']['manually']['enable']['steam']){ ?>checked<?php } ?>>
									
									<div class="field_switch">
										<div class="field_switch_bar"></div>
									</div>
									
									<div class="field_label active transition-5">Steam Confirmations</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
						
						<div class="text-left mt-2">If this is enabled, an admin must to confirm manually the Steam transactions.</div>
					</div>
				</div>
			</div>
			
			<div class="flex column items-start gap-2">
				<div class="text-left font-8">Steam Deposit</div>
				
				<div class="inline-block width-full">
					<?php foreach($response['methods']['steam']['deposit'] as $key => $value){ ?>
					
					<div class="switch_field height-full transition-5">
						<div class="field_container">
							<div class="field_content">
								<input type="checkbox" class="field_element_input admin_switch_settings" data-settings="trades_steam_enable_deposit_<?php echo $key; ?>" <?php if($value){ ?>checked<?php } ?>>
								
								<div class="field_switch">
									<div class="field_switch_bar"></div>
								</div>
								
								<div class="field_label active transition-5"><?php echo $response['methods_name']['steam'][$key]; ?></div>
							</div>
							
							<div class="field_extra"></div>
						</div>
						
						<div class="field_bottom"></div>
					</div>
					
					<?php } ?>
				</div>
			</div>
			
			<div class="flex column items-start gap-2">
				<div class="text-left font-8">Steam Withdraw</div>
				
				<div class="inline-block width-full">
					<?php foreach($response['methods']['steam']['withdraw'] as $key => $value){ ?>
					
					<div class="switch_field height-full transition-5">
						<div class="field_container">
							<div class="field_content">
								<input type="checkbox" class="field_element_input admin_switch_settings" data-settings="trades_steam_enable_withdraw_<?php echo $key; ?>" <?php if($value){ ?>checked<?php } ?>>
								
								<div class="field_switch">
									<div class="field_switch_bar"></div>
								</div>
								
								<div class="field_label active transition-5"><?php echo $response['methods_name']['steam'][$key]; ?></div>
							</div>
							
							<div class="field_extra"></div>
						</div>
						
						<div class="field_bottom"></div>
					</div>
					
					<?php } ?>
				</div>
			</div>
			
			<div class="flex column items-start gap-2">
				<div class="text-left font-8">P2P Deposit</div>
				
				<div class="inline-block width-full">
					<?php foreach($response['methods']['p2p']['deposit'] as $key => $value){ ?>
					
					<div class="switch_field height-full transition-5">
						<div class="field_container">
							<div class="field_content">
								<input type="checkbox" class="field_element_input admin_switch_settings" data-settings="trades_p2p_enable_deposit_<?php echo $key; ?>" <?php if($value){ ?>checked<?php } ?>>
								
								<div class="field_switch">
									<div class="field_switch_bar"></div>
								</div>
								
								<div class="field_label active transition-5"><?php echo $response['methods_name']['p2p'][$key]; ?></div>
							</div>
							
							<div class="field_extra"></div>
						</div>
						
						<div class="field_bottom"></div>
					</div>
					
					<?php } ?>
				</div>
			</div>
			
			<div class="flex column items-start gap-2">
				<div class="text-left font-8">P2P Withdraw</div>
				
				<div class="inline-block width-full">
					<?php foreach($response['methods']['p2p']['withdraw'] as $key => $value){ ?>
					
					<div class="switch_field height-full transition-5">
						<div class="field_container">
							<div class="field_content">
								<input type="checkbox" class="field_element_input admin_switch_settings" data-settings="trades_p2p_enable_withdraw_<?php echo $key; ?>" <?php if($value){ ?>checked<?php } ?>>
								
								<div class="field_switch">
									<div class="field_switch_bar"></div>
								</div>
								
								<div class="field_label active transition-5"><?php echo $response['methods_name']['p2p'][$key]; ?></div>
							</div>
							
							<div class="field_extra"></div>
						</div>
						
						<div class="field_bottom"></div>
					</div>
					
					<?php } ?>
				</div>
			</div>
			
			<div class="flex column items-start gap-2">
				<div class="text-left font-8">Crypto Currency Withdraw</div>
				
				<div class="inline-block width-full">
					<?php foreach($response['methods']['crypto']['withdraw'] as $key => $value){ ?>
					
					<div class="switch_field height-full transition-5">
						<div class="field_container">
							<div class="field_content">
								<input type="checkbox" class="field_element_input admin_switch_settings" data-settings="trades_crypto_enable_withdraw_<?php echo $key; ?>" <?php if($value){ ?>checked<?php } ?>>
								
								<div class="field_switch">
									<div class="field_switch_bar"></div>
								</div>
								
								<div class="field_label active transition-5"><?php echo $response['methods_name']['crypto'][$key]; ?></div>
							</div>
							
							<div class="field_extra"></div>
						</div>
						
						<div class="field_bottom"></div>
					</div>
					
					<?php } ?>
				</div>
			</div>
		</div>
	
		<div class="width-8 responsive flex column gap-2 height-full">
			<div class="bg-light-transparent rounded-1 b-l2 p-2">
				<div class="grid split-column-full responsive gap-1 mb-2">
					<button class="site-button black dashboard-load switch_panel active" data-id="confirmation" data-panel="crypto">Crypto</button>
					<button class="site-button black dashboard-load switch_panel" data-id="confirmation" data-panel="steam">Steam</button>
				</div>
				
				<div class="switch_content" data-id="confirmation" data-panel="crypto">
					<div class="table-container">
						<div class="table-header">
							<div class="table-row">
								<div class="table-column text-left">Id</div>
								<div class="table-column text-left">User Id</div>
								<div class="table-column text-left">Amount</div>
								<div class="table-column text-left">Currency</div>
								<div class="table-column text-left">Date</div>
								<div class="table-column text-right">Action</div>
							</div>
						</div>
						
						<div class="table-body" id="admin_crypto_confirmations">
							<?php if(sizeof($response['crypto']['list']) > 0){?>
							<?php foreach($response['crypto']['list'] as $key => $value){ ?>
							
							<div class="table-row">
								<div class="table-column text-left">#<?php echo $value['id']; ?></div>
								<div class="table-column text-left pointer" data-copy="text" data-text="<?php echo $value['userid']; ?>"><?php echo $value['userid']; ?></div>
								<div class="table-column text-left"><?php echo getFormatAmountString($value['amount']); ?></div>
								<div class="table-column text-left"><?php echo $value['currency']; ?></div>
								<div class="table-column text-left"><?php echo makeDate($value['time']); ?></div>
								
								<div class="table-column full text-right">
									<div class="flex responsive row justify-end gap-1">
										<button class="site-button purple admin_trades_confirm" data-method="crypto" data-trade="<?php echo $value['id']; ?>">Confirm</button>
										<button class="site-button purple admin_trades_cancel" data-method="crypto" data-trade="<?php echo $value['id']; ?>">Cancel</button>
									</div>
								</div>
							</div>
							
							<?php } ?>
							<?php } else { ?>
							<div class="table-row table_message">
								<div class="table-column">No data found</div>
							</div>
							<?php } ?>
						</div>
						
						<div class="table-footer">
							<div class="flex items-center justify-center bg-dark p-2">
								<div class="pagination-content flex row gap-2" id="pagination_admin_crypto_confirmations">
									<div class="pagination-item flex items-center justify-center" data-page="1">«</div>
									
									<div class="flex row gap-1">
										<?php $imin_page = $response['crypto']['page'] - 3; ?>
										<?php $imax_page = $response['crypto']['page'] + 3; ?>
										
										<?php $min_page = max(1, ($imin_page - (($imax_page > $response['crypto']['pages']) ? $imax_page - $response['crypto']['pages'] : 0))); ?>
										<?php $max_page = min($response['crypto']['pages'], ($imax_page + (($imin_page < 1) ? 1 - $imin_page : 0))); ?>
									
										<?php for($i = $min_page; $i <= $max_page; $i++){ ?>
										<div class="pagination-item flex items-center justify-center <?php if($response['crypto']['page'] == $i) { ?>active<?php } ?>" data-page="<?php echo $i; ?>"><?php echo $i; ?></div>
										<?php } ?>
									</div>
									
									<div class="pagination-item flex items-center justify-center" data-page="<?php echo $response['crypto']['pages']; ?>">»</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
				<div class="switch_content hidden" data-id="confirmation" data-panel="steam">
					<div class="table-container">
						<div class="table-header">
							<div class="table-row">
								<div class="table-column text-left">Id</div>
								<div class="table-column text-left">User Id</div>
								<div class="table-column text-left">Amount</div>
								<div class="table-column text-left">Items</div>
								<div class="table-column text-left">Game</div>
								<div class="table-column text-left">Date</div>
								<div class="table-column text-right">Action</div>
							</div>
						</div>
						
						<div class="table-body" id="admin_steam_confirmations">
							<?php if(sizeof($response['steam']['list']) > 0){?>
							<?php foreach($response['steam']['list'] as $key => $value){ ?>
							
							<div class="table-row">
								<div class="table-column text-left">#<?php echo $value['id']; ?></div>
								<div class="table-column text-left pointer" data-copy="text" data-text="<?php echo $value['userid']; ?>"><?php echo $value['userid']; ?></div>
								<div class="table-column text-left"><?php echo getFormatAmountString($value['amount']); ?></div>
								<div class="table-column text-left text-color pointer admin_trades_items" data-items='<?php echo str_replace('\'', '', $value['items']); ?>'>View Items</div>
								<div class="table-column text-left"><?php echo strtoupper($value['game']); ?></div>
								<div class="table-column text-left"><?php echo makeDate($value['time']); ?></div>
								<div class="table-column full text-right flex responsive row gap-2">
									<button class="site-button purple admin_trades_confirm" data-method="steam" data-trade="<?php echo $value['id']; ?>">Confirm</button>
										<button class="site-button purple admin_trades_cancel" data-method="steam" data-trade="<?php echo $value['id']; ?>">Cancel</button>
								</div>
							</div>
							
							<?php } ?>
							<?php } else { ?>
							<div class="table-row table_message">
								<div class="table-column">No data found</div>
							</div>
							<?php } ?>
						</div>
						
						<div class="table-footer">
							<div class="flex items-center justify-center bg-dark p-2">
								<div class="pagination-content flex row gap-2" id="pagination_admin_steam_confirmations">
									<div class="pagination-item flex items-center justify-center" data-page="1">«</div>
									
									<div class="flex row gap-1">
										<?php $imin_page = $response['steam']['page'] - 3; ?>
										<?php $imax_page = $response['steam']['page'] + 3; ?>
										
										<?php $min_page = max(1, ($imin_page - (($imax_page > $response['steam']['pages']) ? $imax_page - $response['steam']['pages'] : 0))); ?>
										<?php $max_page = min($response['steam']['pages'], ($imax_page + (($imin_page < 1) ? 1 - $imin_page : 0))); ?>
									
										<?php for($i = $min_page; $i <= $max_page; $i++){ ?>
										<div class="pagination-item flex items-center justify-center <?php if($response['steam']['page'] == $i) { ?>active<?php } ?>" data-page="<?php echo $i; ?>"><?php echo $i; ?></div>
										<?php } ?>
									</div>
									
									<div class="pagination-item flex items-center justify-center" data-page="<?php echo $response['steam']['pages']; ?>">»</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>