<div class="flex responsive justify-center mt-2">
	<div class="width-8 responsive">
		<div class="width-12 flex responsive row items-center mb-2 gap-2">
			<div class="width-6 responsive flex justify-end">
				<div class="minesweeper-grid justify-center" id="minesweeper_bombs">
					<?php for($i = 0; $i < 25; $i++){ ?>
					<div class="bomb flex justify-center items-center rounded-0 disabled" data-bomb="<?php echo $i; ?>"></div>
					<?php } ?>
				</div>
			</div>
				
			<div class="width-6 responsive">
				<div class="input_field bet_input_field transition-5" data-border="#de4c41">
					<div class="field_container">
						<div class="field_content">
							<input type="text" class="betamount field_element_input" id="betamount_minesweeper" data-game="minesweeper" data-amount="minesweeper" value="0.01">
							
							<div class="field_label transition-5"><div class="input_coins coins mr-1"></div>Bet Amount</div>
						</div>
						
						<div class="field_extra">
							<button class="site-button betshort_action" data-game="minesweeper" data-action="0.01">+0.01</button>
							<button class="site-button betshort_action" data-game="minesweeper" data-action="0.10">+0.10</button>
							<button class="site-button betshort_action" data-game="minesweeper" data-action="1.00">+1.00</button>
							<button class="site-button betshort_action" data-game="minesweeper" data-action="10.00">+10.00</button>
						</div>
					</div>
					
					<div class="field_bottom">
						<div class="field_error" data-error="required">This field is required</div>
						<div class="field_error" data-error="number">This field must be a number</div>
						<div class="field_error" data-error="greater">You must enter a greater value</div>
						<div class="field_error" data-error="lesser">You must enter a lesser value</div>
					</div>
				</div>
				
				<div class="input_field bet_input_field transition-5" data-border="#de4c41">
					<div class="field_container">
						<div class="field_content">
							<input type="text" class="field_element_input" id="bombsamount_minesweeper" value="5">
							
							<div class="field_label transition-5">Bombs Amount</div>
						</div>
						
						<div class="field_extra">
							<button class="site-button changeshort_action" data-id="#bombsamount_minesweeper" data-fixed="0" data-action="-1">-1</button>
							<button class="site-button changeshort_action" data-id="#bombsamount_minesweeper" data-fixed="0" data-action="1">+1</button>
						</div>
					</div>
					
					<div class="field_bottom">
						<div class="field_error" data-error="required">This field is required</div>
						<div class="field_error" data-error="number">This field must be a number</div>
					</div>
				</div>
				
				<div class="mt-2">
					<button class="site-button purple width-full" id="minesweeper_bet">PLACE BET</button>
					<button class="site-button pink hidden width-full" id="minesweeper_cashout">CASHOUT</button>
				</div>
			</div>
		</div>
		
		<div class="table-container">
			<div class="table-header">
				<div class="table-row">
					<div class="table-column text-left">User</div>
					<div class="table-column text-left">Bet</div>
					<div class="table-column text-left">Bombs</div>
					<div class="table-column text-left">Roll</div>
					<div class="table-column text-left">Profit</div>
				</div>
			</div>
			
			<div class="table-body" id="minesweeper_history">
				<div class="table-row history_message"><div class="table-column">No data found</div></div>
			</div>
		</div>
	</div>
</div>