<div class="flex responsive justify-center mt-2">
	<div class="width-8 responsive">
		<div class="width-12 flex responsive column items-center mb-2 gap-2">
			<div class="plinko-grid width-full relative" id="plinko-case">
				<div class="absolute height-full width-full flex items-center justify-center">
					<div class="absolute flex justify-center" id="plinko-arena"></div>
				</div>
				
				<div class="stage flex justify-center"></div>
				
				<?php for($i = 2; $i < 16; $i++){ ?>
					<div class="stage flex justify-center">
					<?php for($j = 0; $j <= $i; $j++){ ?>
						<div class="hole height-full flex justify-center items-center"></div>
					<?php } ?>
					</div>
				<?php } ?>
			</div>
			
			<div class="width-full">
				<div class="plinko-winnings low width-full flex justify-center items-center">
					<div>x7.1</div>
					<div>x4</div>
					<div>x1.9</div>
					<div>x1.4</div>
					<div>x1.3</div>
					<div>x1.1</div>
					<div>x1</div>
					<div>x0.5</div>
					<div>x1</div>
					<div>x1.1</div>
					<div>x1.3</div>
					<div>x1.4</div>
					<div>x1.9</div>
					<div>x4</div>
					<div>x7.1</div>
				</div>
				
				<div class="plinko-winnings medium width-full flex justify-center items-center">
					<div>x58</div>
					<div>x15</div>
					<div>x7</div>
					<div>x4</div>
					<div>x1.9</div>
					<div>x1</div>
					<div>x0.5</div>
					<div>x0.2</div>
					<div>x0.5</div>
					<div>x1</div>
					<div>x1.9</div>
					<div>x4</div>
					<div>x7</div>
					<div>x15</div>
					<div>x58</div>
				</div>
				
				<div class="plinko-winnings high width-full flex justify-center items-center">
					<div>x420</div>
					<div>x56</div>
					<div>x18</div>
					<div>x5</div>
					<div>x1.9</div>
					<div>x0.3</div>
					<div>x0.2</div>
					<div>x0.2</div>
					<div>x0.2</div>
					<div>x0.3</div>
					<div>x1.9</div>
					<div>x5</div>
					<div>x18</div>
					<div>x56</div>
					<div>x420</div>
				</div>
			</div>
				
			<div class="input_field bet_input_field transition-5" data-border="#de4c41">
				<div class="field_container">
					<div class="field_content">
						<input type="text" class="betamount field_element_input" id="betamount_plinko" data-game="plinko" data-amount="plinko" value="0.01">
						
						<div class="field_label transition-5"><div class="input_coins coins mr-1"></div>Bet Amount</div>
					</div>
					
					<div class="field_extra">
						<button class="site-button betshort_action" data-game="plinko" data-action="0.01">+0.01</button>
						<button class="site-button betshort_action" data-game="plinko" data-action="0.10">+0.10</button>
						<button class="site-button betshort_action" data-game="plinko" data-action="1.00">+1.00</button>
						<button class="site-button betshort_action" data-game="plinko" data-action="10.00">+10.00</button>
					</div>
				</div>
				
				<div class="field_bottom">
					<div class="field_error" data-error="required">This field is required</div>
					<div class="field_error" data-error="number">This field must be a number</div>
					<div class="field_error" data-error="greater">You must enter a greater value</div>
					<div class="field_error" data-error="lesser">You must enter a lesser value</div>
				</div>
			</div>
			
			<div class="grid split-column-3 width-full gap-1">
				<button class="site-button low width-full plinko_bet" data-game="low">LOW RISK</button>
				<button class="site-button medium width-full plinko_bet" data-game="medium">MEDIUM RISK</button>
				<button class="site-button high width-full plinko_bet" data-game="high">HIGH RISK</button>
			</div>
		</div>
		
		<div class="table-container">
			<div class="table-header">
				<div class="table-row">
					<div class="table-column text-left">User</div>
					<div class="table-column text-left">Bet</div>
					<div class="table-column text-left">Multiplier</div>
					<div class="table-column text-left">Game</div>
					<div class="table-column text-left">Roll</div>
					<div class="table-column text-left">Profit</div>
				</div>
			</div>
			
			<div class="table-body" id="plinko_history">
				<div class="table-row history_message"><div class="table-column">No data found</div></div>
			</div>
		</div>
	</div>
</div>