<div class="flex column gap-2 bg-dark-transparent bb-d2 p-2">
	<div class="flex justify-end responsive gap-2 bb-l2 pb-2">
		<div class="flex row gap-2">
			<a href="<?php echo $site['root']; ?>casebattle/list/active"><button class="site-button black <?php if(sizeof($paths) > 2) if($paths[2] == 'active') echo 'active' ?>">Active battles</button></a>
			<a href="<?php echo $site['root']; ?>casebattle/list/finished"><button class="site-button black <?php if(sizeof($paths) > 2) if($paths[2] == 'finished') echo 'active' ?>">Finished battles</button></a>
			<a href="<?php echo $site['root']; ?>casebattle/list/my"><button class="site-button black <?php if(sizeof($paths) > 2) if($paths[2] == 'my') echo 'active' ?>">My battles</button></a>
		</div>
	</div>
	
	<div class="flex row justify-between items-center responsive gap-2 pr-2 pl-2">
		<div class="flex row gap-4">
			<div class="flex row gap-2 justify-center items-center">
				<img style="height: 40px;" src="<?php echo $site['root']; ?>template/img/swords1.png">
				
				<div class="flex column items-start gap-1">
					<div class="font-10 text-bold text-color"><span id="casebattle_stats_active">0</span></div>
					<div class="font-6">Active</div>
				</div>
			</div>
			
			<div class="flex row gap-2 justify-center items-center">
				<img style="height: 40px;" src="<?php echo $site['root']; ?>template/img/swords2.png">
				
				<div class="flex column items-start gap-1">
					<div class="font-10 text-bold text-color"><span id="casebattle_stats_total">0</span></div>
					<div class="font-6">Total Battles</div>
				</div>
			</div>
		</div>
		
		<div class="flex row responsive gap-2">
			<a href="<?php echo $site['root']; ?>casebattle/create"><button class="site-button purple">Create battle</button></a>
		</div>
	</div>

	<div class="flex row responsive items-center gap-1">
		<div class="input_field transition-5" data-border="#de4c41">
			<div class="field_container">
				<div class="field_content">
					<input type="text" class="field_element_input" id="casebattle_search" value="">
					
					<div class="field_label transition-5">Search Case</div>
				</div>
				
				<div class="field_extra">
				</div>
			</div>
			
			<div class="field_bottom"></div>
		</div>
		
		<div class="dropdown_field transition-5">
			<div class="field_container">
				<div class="field_content">
					<input type="text" class="field_element_input" id="casebattle_players" value="0">
					<div class="field_dropdown"></div>
				
					<div class="field_element_dropdowns">
						<div class="field_element_dropdown" value="0" data-index="0">All</div>
						<div class="field_element_dropdown" value="2" data-index="1">2</div>
						<div class="field_element_dropdown" value="3" data-index="2">3</div>
						<div class="field_element_dropdown" value="4" data-index="3">4</div>
					</div>
				
					<div class="field_label active transition-5">Players</div>
				</div>
				
				<div class="field_extra">
					<div class="field_caret">
						<i class="fa fa-caret-down"></i>
					</div>
				</div>
			</div>
			
			<div class="field_bottom"></div>
		</div>
		
		<div class="dropdown_field transition-5">
			<div class="field_container">
				<div class="field_content">
					<input type="text" class="field_element_input" id="casebattle_order" value="0">
					<div class="field_dropdown"></div>
				
					<div class="field_element_dropdowns">
						<div class="field_element_dropdown" value="0" data-index="0">Latest</div>
						<div class="field_element_dropdown" value="1" data-index="1">Amount acending</div>
						<div class="field_element_dropdown" value="2" data-index="2">Amount descending</div>
					</div>
				
					<div class="field_label active transition-5">Order by</div>
				</div>
				
				<div class="field_extra">
					<div class="field_caret">
						<i class="fa fa-caret-down"></i>
					</div>
				</div>
			</div>
			
			<div class="field_bottom"></div>
		</div>
	</div>
</div>

<div class="flex column gap-2 m-2">
	<div class="flex column gap-2" id="casebattle_betlist">
		<div class="in-grid bg-light flex justify-center items-center font-8 p-4 history_message">No active case battles</div>
	</div>
</div>