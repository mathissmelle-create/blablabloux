<div class="p-2">
	<div class="grid split-column-full responsive gap-1 mb-2">
		<a href="<?php echo $site['root']; ?>admin/control"><button class="site-button black width-full">Control</button></a>
		<a href="<?php echo $site['root']; ?>admin/users"><button class="site-button black width-full">Users</button></a>
		<a href="<?php echo $site['root']; ?>admin/trades"><button class="site-button black width-full">Trades</button></a>
		<a href="<?php echo $site['root']; ?>admin/casecreator"><button class="site-button black active width-full">Case Creator</button></a>
		<a href="<?php echo $site['root']; ?>admin/gamebots"><button class="site-button black width-full">Game Bots</button></a>
	</div>
	
	<div class="flex column gap-1">
		<div class="flex column gap-2 bg-dark-transparent bb-d2 p-2">
			<div class="flex justify-between responsive gap-2 bb-l2 pb-2">
				<div class="flex row gap-2">
					<a href="<?php echo $site['root']; ?>admin/casecreator/edit/cases"><button class="site-button black <?php if(sizeof($paths) > 2) if($paths[3] == 'cases') echo 'active' ?>">Cases</button></a>
					<a href="<?php echo $site['root']; ?>admin/casecreator/edit/dailycases"><button class="site-button black <?php if(sizeof($paths) > 2) if($paths[3] == 'dailycases') echo 'active' ?>">Daily Cases</button></a>
				</div>
				
				<a href="<?php echo $site['root']; ?>admin/casecreator/create"><button class="site-button purple">Create Cases</button></a>
			</div>
		</div>
	
		<div class="flex column items-center gap-2 mt-4 overflow-a">
			<div class="width-8 responsive text-left">
				<div class="font-10 text-bold">Edit Case</div>
			</div>
			
			<div class="bg-light-transparent text-left rounded-1 b-d2 p-4 width-8 responsive">
				<div id="casecreator_cases">
					<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No cases found</div>
				</div>
			</div>
		</div>
	</div>
</div>