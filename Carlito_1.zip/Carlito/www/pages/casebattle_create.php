<div class="flex column gap-2 bg-dark-transparent bb-d2 p-2">
	<div class="flex justify-between responsive gap-2 bb-l2 pb-2">
		<a href="<?php echo $site['root']; ?>casebattle"><button class="site-button black"><i class="fa fa-arrow-left mr-1"></i> Back to battles</button></a>
		
		<div class="flex row gap-2">
			<a href="<?php echo $site['root']; ?>casebattle/list/active"><button class="site-button black <?php if(sizeof($paths) > 2) if($paths[2] == 'active') echo 'active' ?>">Active battles</button></a>
			<a href="<?php echo $site['root']; ?>casebattle/list/finished"><button class="site-button black <?php if(sizeof($paths) > 2) if($paths[2] == 'finished') echo 'active' ?>">Finished battles</button></a>
			<a href="<?php echo $site['root']; ?>casebattle/list/my"><button class="site-button black <?php if(sizeof($paths) > 2) if($paths[2] == 'my') echo 'active' ?>">My battles</button></a>
		</div>
	</div>
	
	<div class="flex row justify-between items-center responsive gap-2 pr-2 pl-2">
		<div class="flex row gap-4">
			<div class="flex row gap-2 justify-center items-center">
				<img style="height: 40px;" src="<?php echo $site['root']; ?>template/img/swords1.png">
				
				<div class="flex column items-start gap-1">
					<div class="font-10 text-bold text-color"><span id="casebattle_stats_active">0</span></div>
					<div class="font-6">Active</div>
				</div>
			</div>
			
			<div class="flex row gap-2 justify-center items-center">
				<img style="height: 40px;" src="<?php echo $site['root']; ?>template/img/swords2.png">
				
				<div class="flex column items-start gap-1">
					<div class="font-10 text-bold text-color"><span id="casebattle_stats_total">0</span></div>
					<div class="font-6">Total Battles</div>
				</div>
			</div>
		</div>
		
		<div class="flex row gap-4">
			<div class="flex column justify-between gap-2">
				<div class="text-color text-bold">CASHBACK</div>
				
				<div class="text-bold font-8"><div class="coins mr-1"></div><span id="casebattle_create_cashback">0.00</span></div>
			</div>
			
			<div class="flex row gap-4">
				<div class="flex column justify-between gap-2">
					<div class="text-color text-bold">TOTAL COST</div>
					
					<div class="text-bold font-8"><div class="coins mr-1"></div><span id="casebattle_create_total">0.00</span></div>
				</div>
				
				<button class="site-button purple" id="casebattle_create_confirm">Create Battle</button>
			</div>
		</div>
	</div>
</div>

<div class="flex column gap-2 m-2">
	<div class="width-full pb-2 bb-l2" id="casebattle_create_list">
		<div class="case-item flex column gap-1">
			<div class="case-slot rounded-0">
				<div class="flex justify-center items-center height-full width-full">
					<button class="site-button purple casebattle-add">Add Cases</button>
				</div>
			</div>
		</div>
	</div>
	
	<div class="flex row responsive justify-between items-center gap-2 width-full p-2 mt-2 bg-light b-d2 rounded-1">
		<div class="flex row gap-4">
			<div class="flex column items-start gap-4">
				<div class="text-color text-bold">STANDARD BATTLE</div>
				
				<div class="flex row gap-2">
					<button class="site-button black casebattle_set_mode active" data-mode="0">1v1</button>
					<button class="site-button black casebattle_set_mode" data-mode="1">1v1v1</button>
					<button class="site-button black casebattle_set_mode" data-mode="2">1v1v1v1</button>
				</div>
			</div>
			
			<div class="flex column items-start gap-4">
				<div class="text-color text-bold">TEAM BATTLE</div>
				
				<div class="flex row gap-2">
					<button class="site-button black casebattle_set_mode" data-mode="3">2v2</button>
				</div>
			</div>
		</div>
		
		<div class="flex row items-center gap-6">
			<div class="flex column justify-between items-start gap-2">
				<div class="flex column items-start">
					<div class="text-color text-bold">PRIVACY</div>
					<div class="text-left text-gray font-6">Game privacy settings</div>
				</div>
				
				<div class="switch_field transition-5 mb-0">
					<div class="field_container">
						<div class="field_content">
							<input type="checkbox" class="field_element_input" id="casebattle_set_privacy">
							
							<div class="field_switch">
								<div class="field_switch_bar"></div>
							</div>
							
							<div class="field_label active transition-5">Privacy</div>
						</div>
						
						<div class="field_extra"></div>
					</div>
					
					<div class="field_bottom"></div>
				</div>
			</div>
			
			<div class="flex column justify-between items-start gap-2">
				<div class="flex column items-start">
					<div class="text-color text-bold">FREE ENTRY</div>
					<div class="text-left text-gray font-6">The others players can join for free</div>
				</div>
				
				<div class="switch_field transition-5 mb-0">
					<div class="field_container">
						<div class="field_content">
							<input type="checkbox" class="field_element_input" id="casebattle_set_free">
							
							<div class="field_switch">
								<div class="field_switch_bar"></div>
							</div>
							
							<div class="field_label active transition-5">Free Entry</div>
						</div>
						
						<div class="field_extra"></div>
					</div>
					
					<div class="field_bottom"></div>
				</div>
			</div>
		</div>
	</div>
</div>