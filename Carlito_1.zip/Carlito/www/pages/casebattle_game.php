<div class="flex column gap-2 bg-dark-transparent bb-d2 p-2">
	<div class="flex justify-between responsive gap-2 bb-l2 pb-2">
		<a href="<?php echo $site['root']; ?>casebattle"><button class="site-button black"><i class="fa fa-arrow-left mr-1"></i> Back to battles</button></a>
		
		<div class="flex row gap-2">
			<a href="<?php echo $site['root']; ?>casebattle/list/active"><button class="site-button black <?php if(sizeof($paths) > 2) if($paths[2] == 'active') echo 'active' ?>">Active battles</button></a>
			<a href="<?php echo $site['root']; ?>casebattle/list/finished"><button class="site-button black <?php if(sizeof($paths) > 2) if($paths[2] == 'finished') echo 'active' ?>">Finished battles</button></a>
			<a href="<?php echo $site['root']; ?>casebattle/list/my"><button class="site-button black <?php if(sizeof($paths) > 2) if($paths[2] == 'my') echo 'active' ?>">My battles</button></a>
		</div>
	</div>
	
	<div class="flex row justify-between items-center responsive gap-2 pr-2 pl-2">
		<div class="flex row gap-4">
			<div class="flex row gap-2 justify-center items-center">
				<img style="height: 40px;" src="<?php echo $site['root']; ?>template/img/swords1.png">
				
				<div class="flex column items-start gap-1">
					<div class="font-10 text-bold text-color"><span id="casebattle_stats_active">0</span></div>
					<div class="font-6">Active</div>
				</div>
			</div>
			
			<div class="flex row gap-2 justify-center items-center">
				<img style="height: 40px;" src="<?php echo $site['root']; ?>template/img/swords2.png">
				
				<div class="flex column items-start gap-1">
					<div class="font-10 text-bold text-color"><span id="casebattle_stats_total">0</span></div>
					<div class="font-6">Total Battles</div>
				</div>
			</div>
		</div>
		
		<div class="flex row items-center responsive gap-2 pointer">
			<div class="flex row gap-1 text-gray hidden" id="casebattle_link" data-copy="text" data-text="">
				<i class="fa fa-copy" aria-hidden="true"></i>
				
				<span class="link"></span>
			</div>
			
			<button class="site-button green fair-results" id="casebattle_fair" data-fair="{}">Provably fair</button>
			<button class="site-button purple" id="casebattle_create_same" data-battle='{"cases":[],"players":"0","privacy":"0"}'>Create same battle $<span id="casebattle_stats_amount">0.00</span></button>
			<a href="<?php echo $site['root']; ?>casebattle/create"><button class="site-button purple">Create battle</button></a>
		</div>
	</div>
</div>

<div class="flex column items-center gap-2 m-2">
	<div class="casebattle-game bg-dark width-full flex row gap-2 items-center relative">
		<div class="casebattle-round casebattle_game_round rounded-full flex justify-center items-center text-bold active">1</div>
		
		<div class="flex column justify-center items-start gap-2" style="min-width: 100px;">
			<div class="font-6 text-bold">BATTLE ROUNDS</div>
			<div class="font-4"><span class="casebattle_game_round">1</span> OF <span class="casebattle_game_rounds">1</span></div>
		</div>
		
		<div class="width-full overflow-h">
			<div class="width-full flex row gap-1 p-1 transition-2" id="casebattle_roundslist"></div>
		</div>
	</div>
	
	<div class="flex row justify-center gap-2 responsive" id="casebattle_roundlist"></div>
	
	<div class="flex row justify-center gap-2 responsive" id="casebattle_itemslist"></div>
</div>