<div class="flex column width-full">
	<div class="wrapper-page flex row">
		<div class="flex column height-full width-full overflow-a p-2 gap-2">
			<div class="width-3 responsive">
				<div class="input_field transition" data-border="#de4c41">
					<div class="field_container">
						<div class="field_content">
							<input type="text" class="field_element_input" id="deposit_bonus_code" value="<?php echo strtoupper($response['deposit_bonus']); ?>">
							
							<div class="field_label transition">5% Deposit Bonus</div>
						</div>
						
						<div class="field_extra">
							<button class="site-button purple" id="deposit_bonus_apply">Apply</button>
						</div>
					</div>
					
					<div class="field_bottom">
					</div>
				</div>
			</div>
			
			<div class="flex column gap-4 text-left">
				<div>
					<div class="offers-options-name">Deposit with Steam</div>
					
					<div class="offers-options mt-2">
						<?php foreach($response['methods']['steam'] as $key => $value){ ?>
							<a class="<?php if(!$value){ ?>disabled<?php } ?>" href="<?php echo $site['root'];?>deposit/steam/<?php echo $key; ?>">
								<div class="offers-option p-2 rounded-2">
									<div class="offers-option-image-content flex items-center justify-center rounded-1">
										<?php if(!$value){ ?><div class="offers-option-info font-5 pl-2 pr-2 pt-1 pb-1 rounded-1">Disabled</div><?php } ?>
										
										<img class="offers-option-image" src="<?php echo $site['root'];?>template/img/methods/<?php echo $key; ?>_shop.png?v=<?php echo time();?>">
									</div>
									
									<div class="offers-option-name flex justify-center items-center"><?php echo $response['methods_name']['steam'][$key]; ?> (<?php echo strtoupper($key); ?>)</div>
								</div>
							</a>
						<?php } ?>
					</div>
				</div>
				
				<div>
					<div class="offers-options-name">Deposit with P2P</div>
					
					<div class="offers-options mt-2">
						<?php foreach($response['methods']['p2p'] as $key => $value){ ?>
							<a class="<?php if(!$value){ ?>disabled<?php } ?>" href="<?php echo $site['root'];?>deposit/p2p/<?php echo $key; ?>">
								<div class="offers-option p-2 rounded-2">
									<div class="offers-option-image-content flex items-center justify-center rounded-1">
										<?php if(!$value){ ?><div class="offers-option-info font-5 pl-2 pr-2 pt-1 pb-1 rounded-1">Disabled</div><?php } ?>
										
										<img class="offers-option-image" src="<?php echo $site['root'];?>template/img/methods/<?php echo $key; ?>_shop.png?v=<?php echo time();?>">
									</div>
									
									<div class="offers-option-name flex justify-center items-center"><?php echo $response['methods_name']['p2p'][$key]; ?> (<?php echo strtoupper($key); ?>)</div>
								</div>
							</a>
						<?php } ?>
					</div>
				</div>
				
				<div>
					<div class="offers-options-name">Deposit with Cryptocurrency</div>
					
					<div class="offers-options mt-2">
						<?php foreach($response['methods']['crypto'] as $key => $value){ ?>
							<a class="<?php if(!$value){ ?>disabled<?php } ?>" href="<?php echo $site['root'];?>deposit/crypto/<?php echo $key; ?>">
								<div class="offers-option p-2 rounded-2">
									<div class="offers-option-image-content flex items-center justify-center rounded-1">
										<?php if(!$value){ ?><div class="offers-option-info font-5 pl-2 pr-2 pt-1 pb-1 rounded-1">Disabled</div><?php } ?>
										
										<img class="offers-option-image" src="<?php echo $site['root'];?>template/img/methods/<?php echo $key; ?>_shop.png?v=<?php echo time();?>">
									</div>
									
									<div class="offers-option-name flex justify-center items-center"><?php echo $response['methods_name']['crypto'][$key]; ?> (<?php echo strtoupper($key); ?>)</div>
								</div>
							</a>
						<?php } ?>
					</div>
				</div>
				
				<div>
					<div class="offers-options-name">Deposit with Real Money</div>
					
					<div class="offers-options mt-2">
						<a class="disabled" href="<?php echo $site['root'];?>deposit/cards">
							<div class="offers-option p-2 rounded-2">
								<div class="offers-option-image-content flex items-center justify-center rounded-1">
									<div class="offers-option-info font-5 pl-2 pr-2 pt-1 pb-1 rounded-1">Coming soon</div>
									
									<img class="offers-option-image" src="<?php echo $site['root'];?>template/img/methods/cards_shop.png?v=<?php echo time();?>">
								</div>
								
								<div class="offers-option-name flex justify-center items-center">Credit Cards</div>
							</div>
						</a>
						
						<a class="disabled" href="<?php echo $site['root'];?>deposit/paypal">
							<div class="offers-option p-2 rounded-2">
								<div class="offers-option-image-content flex items-center justify-center rounded-1">
									<div class="offers-option-info font-5 pl-2 pr-2 pt-1 pb-1 rounded-1">Coming soon</div>
									
									<img class="offers-option-image" src="<?php echo $site['root'];?>template/img/methods/paypal_shop.png?v=<?php echo time();?>">
								</div>
								
								<div class="offers-option-name flex justify-center items-center">Paypal</div>
							</div>
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>