<div class="p-2">
	<div class="flex gap-2 responsive">
		<div class="width-3 responsive">
			<div class="flex column gap-2">
				<div class="table-container">
					<div class="table-header">
						<div class="table-row">
							<div class="table-column text-left">Tier</div>
							<div class="table-column text-left">Requirements</div>
							<div class="table-column text-left">Deposit</div>
							<div class="table-column text-left">Bet</div>
						</div>
					</div>
					
					<div class="table-body">
						<?php foreach($affiliates['requirements'] as $key => $value){ ?>
						<div class="table-row">
							<div class="table-column text-left"><?php echo $key + 1;?></div>
							<div class="table-column text-left"><?php echo getFormatAmountString($value);?></div>
							<div class="table-column text-left"><?php echo number_format(roundedToFixed($affiliates['commission']['deposit'] * ($key + 1), 2), 2, '.', ''); ?>%</div>
							<div class="table-column text-left"><?php echo number_format(roundedToFixed($affiliates['commission']['bet'] * ($key + 1), 2), 2, '.', ''); ?>%</div>
						</div>
						<?php } ?>
					</div>
				</div>
				
				<div class="flex column gap-1 bg-light-transparent b-d2 p-2 rounded-1">
					<?php
					
					$tier = 0;
					for($tier = 0; $tier < sizeof($affiliates['requirements']); $tier++) {
						if($response['affiliates']['deposited'] < $affiliates['requirements'][$tier]) break;
					}
						
					?>
				
					<div class="flex justify-between font-6">
						<div class="text-upper text-bold text-gray">Progress</div>
						<div><?php echo getFormatAmountString($response['affiliates']['deposited']);?> / <?php echo getFormatAmountString($affiliates['requirements'][$tier]); ?></div>
					</div>
				
					<div class="progress-container small width-full rounded-0" title="Progress: <?php echo number_format(roundedToFixed($response['affiliates']['deposited'] / $affiliates['requirements'][$tier] * 100, 2), 2, '.', ''); ?>%">
						<div class="progress-bar rounded-0" style="width: <?php echo roundedToFixed($response['affiliates']['deposited'] / $affiliates['requirements'][$tier] * 100, 2); ?>%"></div>
						<div class="progress-content pl-2 flex justify-start items-center">Tier <?php echo $tier;?></div>
					</div>
				</div>
			</div>
		</div>

		<div class="width-9 responsive">
			<div class="flex column gap-2">
				<div class="bg-dark-transparent b-d2 p-2 rounded-1 grid split-column-2 gap-2">
					<div class="flex column items-center justify-center">
						<div class="text-upper font-9"><?php echo number_format(roundedToFixed($affiliates['commission']['bet'] * sizeof($affiliates['requirements']), 2), 2, '.', ''); ?>% bet commission!</div>
						<div class="text-color font-7">We give commission of your friends bets!</div>
					</div>
					
					<div class="flex column items-center justify-center">
						<div class="text-upper font-9"><?php echo number_format(roundedToFixed($affiliates['commission']['deposit'] * sizeof($affiliates['requirements']), 2), 2, '.', ''); ?>% deposit commission!</div>
						<div class="text-color font-7">Get coins when friends deposit!</div>
					</div>
				</div>
				
				<?php if(!$response['looking']){ ?>
				<div class="grid split-column-4 gap-2 responsive">
					<div class="flex justify-between bg-light b-d2 p-2 rounded-1">
						<div class="flex column gap-1 text-left">
							<div class="text-upper text-bold text-gray font-6">Bet commission</div>
							<div class="font-8"><div class="coins mr-1"></div><?php echo number_format(roundedToFixed($response['affiliates']['commission_wagered'], 5), 5, '.', ''); ?></div>
						</div>
					</div>
					<div class="flex justify-between bg-light b-d2 p-2 rounded-1">
						<div class="flex column gap-1 text-left">
							<div class="text-upper text-bold text-gray font-6">Deposit commission</div>
							<div class="font-8"><div class="coins mr-1"></div><?php echo number_format(roundedToFixed($response['affiliates']['commission_deposited'], 5), 5, '.', ''); ?></div>
						</div>
					</div>
					<div class="flex justify-between bg-light b-d2 p-2 rounded-1">
						<div class="flex column gap-1 text-left">
							<div class="text-upper text-bold text-gray font-6">Collected</div>
							<div class="font-8"><div class="coins mr-1"></div><?php echo getFormatAmountString($response['affiliates']['collected']);?></div>
						</div>
					</div>
					<div class="flex justify-between bg-light b-d2 p-2 rounded-1">
						<div class="flex column gap-1 text-left">
							<div class="text-upper text-bold text-gray font-6">Available</div>
							<div class="font-8"><div class="coins mr-1"></div><?php echo number_format(roundedToFixed($response['affiliates']['available'], 5), 5, '.', '');?></div>
						</div>
						
						<button class="site-button purple" id="collect_affiliates_referral_available">Collect</button>
					</div>
				</div>
				<?php } else { ?>
				<div class="grid split-column-3 gap-2 responsive">
					<div class="flex justify-between bg-light b-d2 p-2 rounded-1">
						<div class="flex column gap-1 text-left">
							<div class="text-upper text-bold text-gray font-6">Bet commission</div>
							<div class="font-8"><div class="coins mr-1"></div><?php echo number_format(roundedToFixed($response['affiliates']['commission_wagered'], 5), 5, '.', ''); ?></div>
						</div>
					</div>
					<div class="flex justify-between bg-light b-d2 p-2 rounded-1">
						<div class="flex column gap-1 text-left">
							<div class="text-upper text-bold text-gray font-6">Deposit commission</div>
							<div class="font-8"><div class="coins mr-1"></div><?php echo number_format(roundedToFixed($response['affiliates']['commission_deposited'], 5), 5, '.', ''); ?></div>
						</div>
					</div>
					<div class="flex justify-between bg-light b-d2 p-2 rounded-1">
						<div class="flex column gap-1 text-left">
							<div class="text-upper text-bold text-gray font-6">Collected</div>
							<div class="font-8"><div class="coins mr-1"></div><?php echo getFormatAmountString($response['affiliates']['collected']);?></div>
						</div>
					</div>
				</div>
				<?php } ?>
			
				<div class="table-container">
					<div class="table-header">
						<div class="table-row">
							<div class="table-column text-left">User Id</div>
							<div class="table-column text-left">Wagered</div>
							<div class="table-column text-left">Deposited</div>
							<div class="table-column text-left">Commission wagered</div>
							<div class="table-column text-left">Commission deposited</div>
							<div class="table-column text-left">Total</div>
						</div>
					</div>
					
					<div class="table-body">
						<?php if(sizeof($response['affiliates']['referrals']) > 0){?>
						<?php foreach($response['affiliates']['referrals'] as $key => $value){ ?>
						<div class="table-row">
							<div class="table-column text-left"><?php echo $value['userid']; ?></div>
							<div class="table-column text-left"><?php echo getFormatAmountString($value['wagered']); ?></div>
							<div class="table-column text-left"><?php echo getFormatAmountString($value['deposited']);?></div>
							<div class="table-column text-left"><?php echo number_format(roundedToFixed($value['commission_wagered'], 5), 5, '.', ''); ?></div>
							<div class="table-column text-left"><?php echo number_format(roundedToFixed($value['commission_deposited'], 5), 5, '.', ''); ?></div>
							<div class="table-column text-left"><?php echo number_format(roundedToFixed($value['commission_deposited'] + $value['commission_wagered'], 5), 5, '.', ''); ?></div>
						</div>
						<?php } ?>
						<?php } else { ?>
						<div class="table-row">
							<div class="table-column">No data found</div>
						</div>
						<?php } ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>