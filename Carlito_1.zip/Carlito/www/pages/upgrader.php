<script>
	$(document).ready(function() {
		<?php foreach($response['items'] as $key => $value){ ?>
		upgraderGame_items.push(<?php echo $value; ?>);
		<?php } ?>
	});
</script>

<div class="flex column items-center m-2">
	<div class="flex row width-full" style="max-width: 1200px;">
		<div class="flex column gap-2 width-full">
			<div class="flex row items-center justify-between height-full width-full responsive">
				<div class="upgrader-side flex column justify-between gap-2 height-full pt-4 pb-1" id="upgrader_myside">
					<div class="flex column gap-2 p-2 bg-dark" style="width: 400px; height: 330px; border-radius: 0.5rem 0 0 0.5rem">
						<div class="relative overflow-h height-full">
							<div class="flex column items-center justify-between gap-2 height-full relative">
								<div class="flex column items-center justify-center height-full width-full">
									<div class="upgrader-items items-center width-full" id="upgrader_myitems_selected"></div>
								</div>
								
								<div class="flex row justify-between items-center bg-light rounded-0 gap-2 width-full p-2">
									<div class="flex column gap-1 text-left">
										<div class="upgrader-brand ellipsis">Choose your item</div>
										<div class="upgrader-name ellipsis">Item, that you want to upgrade</div>
									</div>
									
									<div class="flex column gap-2 text-right">
										<div><div class="coins mr-1"></div><span class="upgrader-price">0.00</span></div>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					<div class="flex row justify-center items-center gap-2 pr-2 pl-2">
						<button class="site-button black width-full upgrader-multiplier active" data-multiplier="0">1.5x</button>
						<button class="site-button black width-full upgrader-multiplier" data-multiplier="1">2x</button>
						<button class="site-button black width-full upgrader-multiplier" data-multiplier="2">5x</button>
						<button class="site-button black width-full upgrader-multiplier" data-multiplier="3">10x</button>
					</div>
					
					<div class="flex row justify-center items-center gap-2 pr-2 pl-2">
						<button class="site-button purple width-full" id="upgrader_mode">Triangle Mode</button>
						<button class="site-button purple width-full" id="upgrader_roll">Roll Under</button>
					</div>
				</div>
				
				<div class="flex column justify-between items-center bg-light width-full height-full rounded-1 pt-4 b-d2" style="max-width: 400px;">
					<div class="flex column items-center justify-center height-full width-full">
						<div class="upgrader-spinner-content flex justify-center items-center relative" id="upgrader_spinner">
							<div class="upgrader-pointer flex justify-center items-start absolute top-0 bottom-0 left-0 right-0" id="upgrader_spinner_1"></div>
							
							<div class="upgrader-spinner flex justify-center items-center">
								<div class="upgrader-info flex column gap-1 justify-center items-center">
									<div class="flex column gap-1 justify-center items-center">
										<div class="upgrader-brand ellipsis"><span id="upgrader_chance">0.00</span>%</div>
										<div class="upgrader-name ellipsis">Upgrader chance</div>
									</div>
									
									<div class="flex column gap-1 justify-center items-center">
										<div class="upgrader-brand text-success ellipsis">YOU WON</div>
									</div>
									
									<div class="flex column gap-1 justify-center items-center">
										<div class="upgrader-brand text-danger ellipsis">YOU LOST</div>
									</div>
								</div>
								
								<div class="width-full height-full" id="upgrader_spinner_2">
									<div class="upgrader-progress flex justify-center items-center width-full height-full transition-5" id="upgrader_progress" style="--upgrader-progress-start: 0%; --upgrader-progress-end: 0%; --upgrader-rotate: 0deg;"></div>
								</div>
							</div>
						</div>
					</div>
					
					<div class="bg-dark-transparent width-full p-4">
						<div class="slider_field transition-5">
							<div class="field_container">
								<div class="field_content">
									<input type="range" class="field_element_input" id="upgrader_betamount" min="0" max="<?php echo getFormatAmountString(min($user['balance'], 1000)); ?>" step="0.01" value="0">
									
									<div class="field_cursor_content">
										<div class="field_cursor" data-fixed="2">
											<div class="field_cursor_text">0</div>
										</div>
									</div>
									
									<div class="field_label active transition-5">Amount</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom">
								<div class="flex justify-between">
									<div>0.00</div>
									<div><?php echo getFormatAmountString(min($user['balance'], 1000)); ?></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
				<div class="upgrader-side flex column justify-between gap-2 height-full pt-4 pb-1" id="upgrader_siteside">
					<div class="flex column gap-2 p-2 bg-dark" style="width: 400px; height: 330px; border-radius: 0.5rem 0 0 0.5rem">
						<div class="rounded-0 relative overflow-h height-full">
							<div class="flex column items-center justify-between gap-2 height-full relative">
								<div class="flex column items-center justify-center height-full width-full">
									<div class="upgrader-items items-center width-full" id="upgrader_siteitems_selected"></div>
								</div>
								
								<div class="flex row justify-between items-center bg-light rounded-0 gap-2 width-full p-2">
									<div class="flex column gap-2 text-left">
										<div><div class="coins mr-1"></div><span class="upgrader-price">0.00</span></div>
									</div>
									<div class="flex column gap-1 text-right">
										<div class="upgrader-brand ellipsis">Choose item</div>
										<div class="upgrader-name ellipsis">Item, that you want to receive</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					<div class="flex row justify-center items-center gap-2 pr-2 pl-2">
						<button class="site-button purple width-full" id="upgrader_bet">Upgrade</button>
					</div>
				</div>
			</div>
			
			<div class="flex row gap-1 width-full responsive">
				<div class="upgrader-inventory flex column gap-1 bg-dark width-full rounded-1 p-2">
					<div class="flex row items-center justify-between gap-2 pl-2 pr-2 bb-l2">
						<div class="text-bold font-8">Your Items</div>
						
						<div class="flex row responsive gap-1">
							<div class="dropdown_field transition-5" style="max-width: 200px">
								<div class="field_container">
									<div class="field_content">
										<input type="text" class="field_element_input" id="upgrader_myitems_order" value="0">
										<div class="field_dropdown"></div>
									
										<div class="field_element_dropdowns">
											<div class="field_element_dropdown" value="0" data-index="0">Latest</div>
											<div class="field_element_dropdown" value="1" data-index="1">Name A-Z</div>
											<div class="field_element_dropdown" value="2" data-index="2">Name Z-A</div>
											<div class="field_element_dropdown" value="3" data-index="3">Price acending</div>
											<div class="field_element_dropdown" value="4" data-index="4">Price descending</div>
										</div>
									
										<div class="field_label active transition-5">Order by</div>
									</div>
									
									<div class="field_extra">
										<div class="field_caret">
											<i class="fa fa-caret-down"></i>
										</div>
									</div>
								</div>
								
								<div class="field_bottom"></div>
							</div>
						</div>
					</div>
					
					<div id="upgrader_myitems_list">
						<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No items found</div>
					</div>
					
					<div class="flex items-center justify-center bg-dark p-2 bt-l2">
						<div class="pagination-content flex row gap-2 width-full" id="pagination_upgrader_myitems">
							<div class="flex row gap-2 justify-between items-center width-full">
								<div class="pagination-item flex items-center justify-center" data-page="1">«</div>
								
								<div class="bg-light rounded-1 b-l2 pl-2 pr-2 flex row items-center justify-center height-full">1/1</div>
								
								<div class="pagination-item flex items-center justify-center" data-page="1">»</div>
							</div>
						</div>
					</div>
				</div>
				
				<div class="upgrader-inventory flex column gap-1 bg-dark width-full rounded-1 p-2">
					<div class="flex row items-center justify-between gap-2 pl-2 pr-2 bb-l2">
						<div class="text-bold font-8">Upgrade</div>
						
						<div class="flex row responsive gap-1">
							<div class="input_field bet_input_field transition-5" style="max-width: 200px" data-border="#de4c41">
								<div class="field_container">
									<div class="field_content">
										<input type="text" class="field_element_input" id="upgrader_siteitems_search" value="">
										
										<div class="field_label transition-5">Search Item</div>
									</div>
									
									<div class="field_extra"></div>
								</div>
								
								<div class="field_bottom"></div>
							</div>
							
							<div class="dropdown_field transition-5" style="max-width: 200px">
								<div class="field_container">
									<div class="field_content">
										<input type="text" class="field_element_input" id="upgrader_siteitems_order" value="2">
										<div class="field_dropdown"></div>
									
										<div class="field_element_dropdowns">
											<div class="field_element_dropdown" value="0" data-index="0">Name A-Z</div>
											<div class="field_element_dropdown" value="1" data-index="1">Name Z-A</div>
											<div class="field_element_dropdown" value="2" data-index="2">Price acending</div>
											<div class="field_element_dropdown" value="3" data-index="3">Price descending</div>
										</div>
									
										<div class="field_label active transition-5">Order by</div>
									</div>
									
									<div class="field_extra">
										<div class="field_caret">
											<i class="fa fa-caret-down"></i>
										</div>
									</div>
								</div>
								
								<div class="field_bottom"></div>
							</div>
						</div>
					</div>
					
					<div id="upgrader_siteitems_list">
						<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No items found</div>
					</div>
					
					<div class="flex items-center justify-center bg-dark p-2 bt-l2">
						<div class="pagination-content flex row gap-2 width-full" id="pagination_upgrader_siteitems">
							<div class="flex row gap-2 justify-between items-center width-full">
								<div class="pagination-item flex items-center justify-center" data-page="1">«</div>
								
								<div class="bg-light rounded-1 b-l2 pl-2 pr-2 flex row items-center justify-center height-full">1/1</div>
								
								<div class="pagination-item flex items-center justify-center" data-page="1">»</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>