<div class="width-12 mb-2 inline-table">
	<div class="width-full inline-grid">
		<div class="panel-histories medium flex gap-1 p-2" id="unboxing_history">
			<div class="history_message flex justify-center items-center width-full height-full">No unboxes</div>
		</div>
	</div>
</div>

<div class="flex justify-between pr-2 pl-2 font-9">
	<div id="unboxing_name"></div>
	
	<div class="flex">
		<div class="coins mr-1"></div>
		<div id="unboxing_price">0.00</div>
	</div>
</div>

<div class="flex column gap-1" id="unboxing_case_spinner">
</div>

<div class="flex row responsive gap-1 mt-2 justify-center items-center">
	<div class="dropdown_field transition-5">
		<div class="field_container">
			<div class="field_content">
				<input type="text" class="field_element_input" id="unboxing_amount" value="1">
				<div class="field_dropdown"></div>
			
				<div class="field_element_dropdowns">
					<div class="field_element_dropdown" value="1" data-index="0">1</div>
					<div class="field_element_dropdown" value="2" data-index="1">2</div>
					<div class="field_element_dropdown" value="3" data-index="1">3</div>
					<div class="field_element_dropdown" value="4" data-index="1">4</div>
					<div class="field_element_dropdown" value="5" data-index="1">5</div>
				</div>
			
				<div class="field_label active transition-5">Amount</div>
			</div>
			
			<div class="field_extra">
				<div class="field_caret">
					<i class="fa fa-caret-down"></i>
				</div>
			</div>
		</div>
		
		<div class="field_bottom"></div>
	</div>
	
	<div class="flex row gap-1 justify-center items-center">
		<button class="site-button pink" id="unboxing_demo">DEMO</button>
		<button class="site-button purple" id="unboxing_open">OPEN CASE</button>
	</div>
</div>

<div class="flex column gap-2 mt-2 p-2">
	<div class="text-left font-9">This case contains:</div>

	<div class="unboxing-list" id="unboxing_list"></div>
</div>