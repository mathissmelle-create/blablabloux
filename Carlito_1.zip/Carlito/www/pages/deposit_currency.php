<div class="flex column height-full width-full">
	<div class="wrapper-page flex row">
		<div class="flex column height-full width-full p-2">
			<div class="flex justify-start">
				<a href="<?php echo $site['root'];?>deposit"><button class="site-button black"><i class="fa fa-arrow-left mr-1"></i> Back to Options</button></a>
			</div>
			
			<script>
				$(document).ready(function() {	
					$(".qrcode-crypto").empty();
							
					var qrcode = new QRCode($(".qrcode-crypto")[0], {
						text: "<?php echo $addresses[$paths[2]]; ?>",
						width: 150,
						height: 150,
					});
				});
			</script>
			
			<div class="flex column items-center gap-2 mt-4 overflow-a">
				<div class="width-6 responsive text-left">
					<div class="font-10 text-bold mb-2">Deposit with <?php echo $response['methods_name']['crypto'][$paths[2]]; ?></div>
					
					<div class="font-6 text-gray">You will receive coins automatically after sending <?php echo strtoupper($paths[2]); ?> to the address displayed below.</div>
				</div>
				
				<div class="bg-light-transparent text-left rounded-1 b-d2 p-4 width-6 responsive currency-panel">
					<div class="font-8 text-bold mb-2"><?php echo $response['methods_name']['crypto'][$paths[2]]; ?> wallet address</div>
					
					<div class="flex column gap-2 <?php if($addresses[$paths[2]] == null) echo "hidden";?>" id="panel_currency_top">
						<div class="qrcode m-a qrcode-crypto qrcode-<?php echo $paths[2];?>"></div>
						
						<div class="input_field bet_input_field transition-5" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" id="<?php echo $paths[2]; ?>_address" value="<?php echo $addresses[$paths[2]];?>" readonly="">
									
									<div class="field_label transition-5">Your personal <?php echo strtoupper($paths[2]); ?> deposit address</div>
								</div>
								
								<div class="field_extra">
									<button type="button" class="site-button purple" data-copy="input" data-input="#<?php echo $paths[2]; ?>_address">Copy Address</button>
								</div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
					</div>
					
					<div class="flex column items-center gap-2 <?php if($addresses[$paths[2]] != null) echo "hidden";?>" id="panel_currency_bottom">
						<button type="button" class="site-button purple" id="generate_address" data-currency="<?php echo $paths[2]; ?>">GENERATE MY DEPOSIT ADDRESS</button>
					</div>
				</div>	
				
				<div class="bg-light-transparent text-left rounded-1 b-d2 p-4 width-6 responsive currency-panel">
					<div class="font-8 text-bold mb-2"><?php echo $response['methods_name']['crypto'][$paths[2]]; ?> coin rate calculator</div>
					
					<div class="flex responsive">
						<div class="input_field bet_input_field transition-5" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" id="currency_coin_from" data-currency="<?php echo $paths[2]; ?>" value="100">
									
									<div class="field_label transition-5"><div class="input_coins coins mr-1"></div>Amount Coins</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom">
								<div class="field_error" data-error="number">This field must be a number</div>
								<div class="field_error" data-error="greater">You must enter a greater value</div>
							</div>
						</div>
						
						<div class="flex justify-center items-center pr-2 pl-2 font-10">=</div>
						
						<div class="input_field bet_input_field transition-5" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" id="currency_coin_to" data-currency="<?php echo $paths[2]; ?>" value="">
									
									<div class="field_label transition-5"><div class="input_coins <?php echo $paths[2]; ?>-coins mr-1"></div>Amount <?php echo $response['methods_name']['crypto'][$paths[2]]; ?></div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom">
								<div class="field_error" data-error="number">This field must be a number</div>
							</div>
						</div>
					</div>
					
					<div class="font-6 text-gray">The exchange rate shown above is an estimate. The final rate is determined by the time of the transaction.</div>
				</div>
			</div>
		</div>
	</div>
</div>
