<div class="header-max">
	<div class="header layout flex">
		<div class="header-logo flex justify-center items-center">
			<a class="flex justify-center items-center" href="<?php echo $site['root']; ?>">
				<img src="<?php echo $site['root']; ?>template/img/logo.png?v=<?php echo time(); ?>">
			</a>
		</div>
		
		<div class="header-menu-top flex items-center justify-between">
			<div class="inline-block">
				<div class="inline-block">
					<div class="header-menu-button inline-block mr-2"><a href="<?php echo $site['root']; ?>fair" class="<?php if($paths[0] == 'fair') echo 'active'; ?>">Provably Fair</a></div>
					<div class="header-menu-button inline-block mr-2"><a href="<?php echo $site['root']; ?>faq" class="<?php if($paths[0] == 'faq') echo 'active'; ?>">FAQ</a></div>
					<div class="header-menu-button inline-block mr-2"><a href="<?php echo $site['root']; ?>tos" class="<?php if($paths[0] == 'tos') echo 'active'; ?>">Terms Of Service</a></div>
					<div class="header-menu-button inline-block mr-2"><a href="<?php echo $site['root']; ?>support" class="<?php if($paths[0] == 'support') echo 'active'; ?> <?php if($profile['have_supports']) { ?>text-success<?php } ?>">Support</a></div>
					<div class="header-menu-button inline-block mr-2"><a href="<?php echo $site['root']; ?>leaderboard" class="<?php if($paths[0] == 'leaderboard') echo 'active'; ?>">Leaderboard</a></div>
					<div class="header-menu-button inline-block mr-2"><a href="<?php echo $site['root']; ?>rewards" class="<?php if($paths[0] == 'rewards') echo 'active'; ?>">Rewards</a></div>
					<div class="header-menu-button inline-block mr-2"><a href="<?php echo $site['root']; ?>affiliates" class="<?php if($paths[0] == 'rewards') echo 'active'; ?>">Affiliates</a></div>
					
					<?php if(in_array($user['userid'], $site['access']['admin'])){ ?><div class="header-menu-button inline-block mr-2"><a href="<?php echo $site['root']; ?>admin" class="text-success <?php if($paths[0] == 'admin') echo 'active'; ?>">Admin</a></div><?php } ?>
					<?php if(in_array($user['userid'], $site['access']['dashboard'])){ ?><div class="header-menu-button inline-block mr-2"><a href="<?php echo $site['root']; ?>dashboard" class="text-success <?php if($paths[0] == 'dashboard') echo 'active'; ?>">Dashboard</a></div><?php } ?>
				</div>
				
				<div class="inline-block ml-2">
					<div class="inline-block mr-1"><a href="<?php echo $site['link_twitter']; ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></div>
					<div class="inline-block mr-1"><a href="<?php echo $site['link_steam']; ?>" target="_blank"><i class="fa fa-steam" aria-hidden="true"></i></a></div>
				</div>
			</div>
			
			<div class="flex items-center gap-2 height-full pr-2">
				<?php if($user){ ?>
				<div class="level-bar flex items-center gap-1">
					<div class="text-bold">Lvl. <span id="level_count">0</span></div>
					
					<div class="progress-container rounded-0">
						<div class="progress-bar transition-2 linear rounded-0" id="level_bar" style="width: 0%;"></div>
						<div class="progress-content flex justify-center items_center text-bold"><span id="level_have">0</span> / <span id="level_next">100</span></div>
					</div>
				</div>
				
				<div class="pointer" data-modal="show" data-id="#modal_auth_settings"><i class="fa fa-cog" aria-hidden="true"></i></div>
				
				<div class="pointer" data-modal="show" data-id="#modal_auth_logout"><i class="fa fa-sign-out" aria-hidden="true"></i></div>
				<?php } ?>
			</div>
		</div>
		
		<div class="header-menu-bottom flex items-center justify-between">
			<div class="flex items-center gap-4 height-full" id="favorite_game">
				<div class="main-game header-menu-button hidden" data-game="roulette">
					<a href="<?php echo $site['root']; ?>roulette">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'roulette') echo 'active'; ?>">
							<img src="<?php echo $site['root']; ?>template/img/menu/roulette.png?v=<?php echo time(); ?>">
							<div class="ml-1">Roulette</div>
						</div>
					</a>
				</div>
				<div class="main-game header-menu-button hidden" data-game="crash">
					<a href="<?php echo $site['root']; ?>crash">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'crash') echo 'active'; ?>">
							<img src="<?php echo $site['root']; ?>template/img/menu/crash.png?v=<?php echo time(); ?>">
							<div class="ml-1">Crash</div>
						</div>
					</a>
				</div>
				<div class="main-game header-menu-button hidden" data-game="jackpot">
					<a href="<?php echo $site['root']; ?>jackpot">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'jackpot') echo 'active'; ?>">
							<img src="<?php echo $site['root']; ?>template/img/menu/jackpot.png?v=<?php echo time(); ?>">
							<div class="ml-1">Jackpot</div>
						</div>
					</a>
				</div>
				<div class="main-game header-menu-button hidden" data-game="coinflip">
					<a href="<?php echo $site['root']; ?>coinflip">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'coinflip') echo 'active'; ?>">
							<img src="<?php echo $site['root']; ?>template/img/menu/coinflip.png?v=<?php echo time(); ?>">
							<div class="ml-1">Coinflip</div>
						</div>
					</a>
				</div>
				<div class="main-game header-menu-button hidden" data-game="dice">
					<a href="<?php echo $site['root']; ?>dice">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'dice') echo 'active'; ?>">
							<img src="<?php echo $site['root']; ?>template/img/menu/dice.png?v=<?php echo time(); ?>">
							<div class="ml-1">Dice</div>
						</div>
					</a>
				</div>
				<div class="main-game header-menu-button hidden" data-game="unboxing">
					<a href="<?php echo $site['root']; ?>unboxing">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'unboxing') echo 'active'; ?>">
							<img src="<?php echo $site['root']; ?>template/img/menu/unboxing.png?v=<?php echo time(); ?>">
							<div class="ml-1">Unboxing</div>
						</div>
					</a>
				</div>
				<div class="main-game header-menu-button hidden" data-game="casebattle">
					<a href="<?php echo $site['root']; ?>casebattle">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'casebattle') echo 'active'; ?>">
							<img src="<?php echo $site['root']; ?>template/img/menu/casebattle.png?v=<?php echo time(); ?>">
							<div class="ml-1">Case Battle</div>
						</div>
					</a>
				</div>
				<div class="main-game header-menu-button hidden" data-game="upgrader">
					<a href="<?php echo $site['root']; ?>upgrader">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'upgrader') echo 'active'; ?>">
							<img src="<?php echo $site['root']; ?>template/img/menu/upgrader.png?v=<?php echo time(); ?>">
							<div class="ml-1">Upgrader</div>
						</div>
					</a>
				</div>
				<div class="main-game header-menu-button hidden" data-game="minesweeper">
					<a href="<?php echo $site['root']; ?>minesweeper">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'minesweeper') echo 'active'; ?>">
							<img src="<?php echo $site['root']; ?>template/img/menu/minesweeper.png?v=<?php echo time(); ?>">
							<div class="ml-1">Minesweeper</div>
						</div>
					</a>
				</div>
				<div class="main-game header-menu-button hidden" data-game="tower">
					<a href="<?php echo $site['root']; ?>tower">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'tower') echo 'active'; ?>">
							<img src="<?php echo $site['root']; ?>template/img/menu/tower.png?v=<?php echo time(); ?>">
							<div class="ml-1">Tower</div>
						</div>
					</a>
				</div>
				<div class="main-game header-menu-button hidden" data-game="plinko">
					<a href="<?php echo $site['root']; ?>plinko">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'plinko') echo 'active'; ?>">
							<img src="<?php echo $site['root']; ?>template/img/menu/plinko.png?v=<?php echo time(); ?>">
							<div class="ml-1">Plinko</div>
						</div>
					</a>
				</div>
				
				<div class="header-menu-button">
					<div class="header-button-games flex items-center">
						<div class="mr-1">All games</div>
						<i class="fa fa-caret-down" aria-hidden="true"></i>
						
						<div class="header-games">
							<div class="header-list-games bg-dark items-center justify-center p-2">
								<a href="<?php echo $site['root']; ?>roulette">
									<div class="header-list-game flex items-center justify-center rounded-1 transition-2">
										<img src="<?php echo $site['root']; ?>template/img/menu/roulette.png?v=<?php echo time(); ?>">
										<div class="ml-1">Roulette</div>
									</div>
								</a>
								<a href="<?php echo $site['root']; ?>crash">
									<div class="header-list-game flex items-center justify-center rounded-1 transition-2">
										<img src="<?php echo $site['root']; ?>template/img/menu/crash.png?v=<?php echo time(); ?>">
										<div class="ml-1">Crash</div>
									</div>
								</a>
								<a href="<?php echo $site['root']; ?>jackpot">
									<div class="header-list-game flex items-center justify-center rounded-1 transition-2">
										<img src="<?php echo $site['root']; ?>template/img/menu/jackpot.png?v=<?php echo time(); ?>">
										<div class="ml-1">Jackpot</div>
									</div>
								</a>
								<a href="<?php echo $site['root']; ?>coinflip">
									<div class="header-list-game flex items-center justify-center rounded-1 transition-2">
										<img src="<?php echo $site['root']; ?>template/img/menu/coinflip.png?v=<?php echo time(); ?>">
										<div class="ml-1">Coinflip</div>
									</div>
								</a>
								<a href="<?php echo $site['root']; ?>dice">
									<div class="header-list-game flex items-center justify-center rounded-1 transition-2">
										<img src="<?php echo $site['root']; ?>template/img/menu/dice.png?v=<?php echo time(); ?>">
										<div class="ml-1">Dice</div>
									</div>
								</a>
								<a href="<?php echo $site['root']; ?>unboxing">
									<div class="header-list-game flex items-center justify-center rounded-1 transition-2">
										<img src="<?php echo $site['root']; ?>template/img/menu/unboxing.png?v=<?php echo time(); ?>">
										<div class="ml-1">Unboxing</div>
									</div>
								</a>
								<a href="<?php echo $site['root']; ?>casebattle">
									<div class="header-list-game flex items-center justify-center rounded-1 transition-2">
										<img src="<?php echo $site['root']; ?>template/img/menu/casebattle.png?v=<?php echo time(); ?>">
										<div class="ml-1">Case Battle</div>
									</div>
								</a>
								<a href="<?php echo $site['root']; ?>upgrader">
									<div class="header-list-game flex items-center justify-center rounded-1 transition-2">
										<img src="<?php echo $site['root']; ?>template/img/menu/upgrader.png?v=<?php echo time(); ?>">
										<div class="ml-1">Upgrader</div>
									</div>
								</a>
								<a href="<?php echo $site['root']; ?>minesweeper">
									<div class="header-list-game flex items-center justify-center rounded-1 transition-2">
										<img src="<?php echo $site['root']; ?>template/img/menu/minesweeper.png?v=<?php echo time(); ?>">
										<div class="ml-1">Minesweeper</div>
									</div>
								</a>
								<a href="<?php echo $site['root']; ?>tower">
									<div class="header-list-game flex items-center justify-center rounded-1 transition-2">
										<img src="<?php echo $site['root']; ?>template/img/menu/tower.png?v=<?php echo time(); ?>">
										<div class="ml-1">Tower</div>
									</div>
								</a>
								<a href="<?php echo $site['root']; ?>plinko">
									<div class="header-list-game flex items-center justify-center rounded-1 transition-2">
										<img src="<?php echo $site['root']; ?>template/img/menu/plinko.png?v=<?php echo time(); ?>">
										<div class="ml-1">Plinko</div>
									</div>
								</a>
							</div>
						</div>
					</div>
				</div>
				
				<div class="header-menu-button">
					<a href="<?php echo $site['root']; ?>deposit">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'deposit') echo 'active'; ?>">
							<div class="ml-1">Deposit</div>
						</div>
					</a>
				</div>
				
				<div class="header-menu-button">
					<a href="<?php echo $site['root']; ?>withdraw">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'withdraw') echo 'active'; ?>">
							<div class="ml-1">Withdraw</div>
						</div>
					</a>
				</div>
				
				<div class="header-menu-button" data-modal="show" data-id="#modal_dailycases_cases">
					<div class="header-side-button flex items-center">
						<div class="ml-1 text-success">Daily Cases</div>
					</div>
				</div>
			</div>
			
			<div class="flex items-center gap-2 height-full pr-2">
				<?php if($user){ ?>
				
				<div class="header-panel bg-light rounded-1 b-l2 p-1 flex items-center justify-center pointer" data-modal="show" data-id="#modal_user_inventory">
					<img style="height: 20px;" src="<?php echo $site['root']; ?>template/img/backpack.png">
				</div>
				
				<a class="header-panel" href="<?php echo $site['root']; ?>deposit">
					<div class="balances bg-light rounded-1 b-l2 pl-2 pr-2 flex row items-center justify-center height-full relative">
						<div class="balance flex row items-center justify-center gap-1" data-balance="total">
							<div class="coins"></div>
							<span class="amount">0.00</span>
						</div>
						
						<!--<div class="balances-panel b-m2 bg-light rounded-1 p-2 flex column items-start justify-center gap-1 hidden">
							<div class="balance flex row items-center justify-center gap-1" data-balance="balance">
								<span>Balance:</span>
								<span class="amount">0.00</span>
							</div>
						</div>-->
					</div>
				</a>
			
				<a class="header-panel" href="<?php echo $site['root']; ?>profile">
					<div class="bg-main-transparent rounded-1 b-l2 pl-2 pr-2 flex items-center justify-center height-full">
						<img class="rounded-full" src="<?php echo $user['avatar']; ?>">
						
						<div class="ml-2"><?php echo $user['name']; ?></div>
					</div>
				</a>
				<?php }else{ ?>
				<div class="header-panel bg-light rounded-1 b-l2 flex items-center justify-center">
					<button class="site-button black height-full flex justify-center items-center pt-0 pb-0" data-modal="show" data-id="#modal_auth">LOGIN</button>
				</div>
				<?php } ?>
			</div>
		</div>
	</div>
</div>

<div class="header-min">
	<div class="header layout flex">
		<div class="header-logo justify-center">
			<a class="justify-center flex" href="<?php echo $site['root']; ?>">
				<img src="<?php echo $site['root']; ?>template/img/logo.png?v=<?php echo time(); ?>">
			</a>
		</div>
		
		<div class="flex items-center justify-end gap-2 height-full pr-2">
			<?php if($user){ ?>
			<div class="header-panel bg-light rounded-1 b-l2 p-1 flex items-center justify-center pointer" data-modal="show" data-id="#modal_user_inventory">
				<img style="height: 20px;" src="<?php echo $site['root']; ?>template/img/backpack.png">
			</div>
			
			<a href="<?php echo $site['root']; ?>deposit">
				<div class="balances bg-light rounded-1 b-l2 pl-2 pr-2 flex row items-center justify-center height-full relative">
					<div class="balance flex row items-center justify-center gap-1" data-balance="total">
						<div class="coins"></div>
						<span class="amount">0.00</span>
					</div>
					
					<!--<div class="balances-panel b-m2 bg-light rounded-1 p-2 flex column items-start justify-center gap-1 hidden">
						<div class="balance flex row items-center justify-center gap-1" data-balance="balance">
							<span>Balance:</span>
							<span class="amount">0.00</span>
						</div>
					</div>-->
				</div>
			</a>
			<?php }else{ ?>
			<div class="header-panel bg-light rounded-1 b-l2 flex items-center justify-center">
				<button class="site-button black height-full flex justify-center items-center pt-0 pb-0" data-modal="show" data-id="#modal_auth">LOGIN</button>
			</div>
			<?php } ?>
		
			<button class="site-button pullout_view" data-pullout="menu"><i class="fa fa-bars" aria-hidden="true"></i></button>
		</div>
	</div>
</div>