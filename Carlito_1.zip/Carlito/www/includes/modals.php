<div class="modal medium" id="modal_gamebots_list">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Choose a bot</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body text-left">
				<div class="flex column gap-2 height-full overflow-h">
					<div id="gamebots_list">
						<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No active bots found</div>
					</div>
					
					<button class="site-button purple" id="gamebots_confirm" data-game="" data-data="">Play with this Bot</button>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal medium" id="modal_gamebots_moderate">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Moderate bot</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body text-left">
				<div class="flex column gap-2 text-left">
					<div class="flex column items-start gap-2">
						<div class="text-left font-8">Edit Balance</div>
						
						<div class="input_field transition" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" id="admin_gamebots_balance_amount" value="0.00">
									
									<div class="field_label transition">Amount</div>
								</div>
								
								<div class="field_extra">
									<button class="site-button purple" id="admin_gamebots_balance_edit" data-userid="">Confirm</button>
								</div>
							</div>
							
							<div class="field_bottom">
								<div class="field_error" data-error="required">This field is required</div>
								<div class="field_error" data-error="number">This field must be a number</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal large" id="modal_user_inventory">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Inventory</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body text-left">
				<div class="flex column gap-2 height-full overflow-h">
					<div class="flex row justify-between items-center gap-2 pt-2 pb-2 bb-l2">
						<div class="bg-light p-2 rounded-0">Inventory value: <span id="inventory_value">0.00</span>$</div>
						
						<button class="site-button purple" id="inventory_sell_all">Sell All</button>
					</div>
					
					<div id="inventory_list">
						<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No items found</div>
					</div>
					
					<div class="flex items-center justify-center bg-dark p-2 bt-l2">
						<div class="pagination-content flex row gap-2 width-full" id="pagination_inventory_items">
							<div class="flex row gap-2 justify-between items-center width-full">
								<div class="pagination-item flex items-center justify-center" data-page="1">«</div>
								
								<div class="bg-light rounded-1 b-l2 pl-2 pr-2 flex row items-center justify-center height-full">1/1</div>
								
								<div class="pagination-item flex items-center justify-center" data-page="1">»</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal small" id="modal_offers_pending">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Offer Pending Status</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body text-left">
				<div class="offers_pending_method hidden" data-method="p2p">
					<div class="offers_pending_type hidden" data-type="deposit">
						<div class="offers_pending_status hidden" data-status="-1">
							<div class="bundle_items_pending">
							</div>
							
							<div class="mt-2 font-8">
								<div>This trade has expired or canceled. If you sent the trade offer to buyer, please cancel it now.</div>
								<div>If the trade was already completed and you have received your coins after an hour, contact support.</div>
							</div>
							
							<div class="flex justify-center gap-1 mt-2">
								<button type="button" class="site-button purple" data-modal="hide">Close</button>
							</div>
						</div>
						
						<div class="offers_pending_status hidden" data-status="0">
							<div class="bundle_items_pending">
							</div>
							
							<div class="bg-main-transparent rounded-1 b-l2 flex items-center justify-center mt-2 text-center font-9 width-full inline-block">
								<div class="counter_content m-1">Waiting for <span class="counter">00:00</span></div>
							</div>
							
							<div class="mt-2 font-8">Your deposit has been listed on the withdraw page. Please wait for another user to withdraw yout items. It could happen at any time so be ready!</div>
							
							<div class="flex justify-center gap-1 mt-2">
								<button type="button" class="site-button black" id="cancel_p2p_listing" data-listing="0" data-modal="hide">Cancel Trade</button>
								<button type="button" class="site-button purple" data-modal="hide">Close</button>
							</div>
						</div>
						
						<div class="offers_pending_status hidden" data-status="1">
							<div class="bundle_items_pending">
							</div>
							
							<div class="bg-main-transparent rounded-1 b-l2 flex items-center justify-center mt-2 text-center font-9 width-full inline-block">
								<div class="counter_content m-1">Expire in <span class="counter">00:00</span></div>
							</div>
							
							<div class="bg-light rounded-1 b-l2 flex items-center justify-center mt-2 text-center p-1 font-9 width-full inline-block">
								<div class="flex column gap-2">
									<a class="offer_buyer_profile flex gap-2 justify-center items-center" href="" target="_blank">
										<div class="avatar-field relative">
											<img class="avatar icon-medium rounded-full" src="https://steamcdn-a.akamaihd.net/steamcommunity/public/images/avatars/fe/fef49e7fa7e1997310d705b2a6158ff8dc1cdfeb_full.jpg">
										</div>
										<div>None</div>
									</a>
								</div>
							</div>
							
							<div class="mt-2 font-8">
								<div>A buyer has been found and you must to confirm to start the tracking. You will see the buyer's informations after your confirmation.</div>
								<div>Are you ready to start the trade?</div>
							</div>
							
							<div class="flex justify-center gap-1 mt-1">
								<button type="button" class="site-button purple" id="confirm_p2p_listing" data-listing="0" data-modal="hide">Yes, I'm Ready</button>
							</div>
						</div>
					
						<div class="offers_pending_status hidden" data-status="2">
							<div class="bundle_items_pending">
							</div>
							
							<div class="bg-main-transparent rounded-1 b-l2 flex items-center justify-center mt-2 text-center font-9 width-full inline-block">
								<div class="counter_content m-1">Expire in <span class="counter">00:00</span></div>
							</div>
							
							<div class="bg-light rounded-1 b-l2 flex items-center justify-center mt-2 text-center p-1 font-9 width-full inline-block">
								<div class="flex column gap-2">
									<a class="offer_buyer_profile flex gap-2 justify-center items-center" href="" target="_blank">
										<div class="avatar-field relative">
											<img class="avatar icon-medium rounded-full" src="https://steamcdn-a.akamaihd.net/steamcommunity/public/images/avatars/fe/fef49e7fa7e1997310d705b2a6158ff8dc1cdfeb_full.jpg">
										</div>
										<div>None</div>
									</a>
									
									<a class="trade_link_offer" href="" target="_blank"><button type="button" class="site-button purple">Trade Link</button></a>
								</div>
							</div>
							
							<div class="mt-2 font-8">
								<div>A buyer has been found. Please send the items to buyer.</div>
							</div>
							
							<div class="flex justify-center gap-1 mt-2">
								<button type="button" class="site-button purple" data-modal="hide">Close</button>
							</div>
						</div>
						
						<div class="offers_pending_status hidden" data-status="3">
							<div class="bundle_items_pending">
							</div>
							
							<div class="bg-main-transparent rounded-1 b-l2 flex items-center justify-center mt-2 text-center font-9 width-full inline-block">
								<div class="counter_content m-1">Expire in <span class="counter">00:00</span></div>
							</div>
							
							<div class="bg-light rounded-1 b-l2 flex items-center justify-center mt-2 text-center p-1 font-9 width-full inline-block">
								<div class="flex column gap-2">
									<a class="offer_buyer_profile flex gap-2 justify-center items-center" href="" target="_blank">
										<div class="avatar-field relative">
											<img class="avatar icon-medium rounded-full" src="https://steamcdn-a.akamaihd.net/steamcommunity/public/images/avatars/fe/fef49e7fa7e1997310d705b2a6158ff8dc1cdfeb_full.jpg">
										</div>
										<div>None</div>
									</a>
									
									<a class="trade_link_offer" href="" target="_blank"><button type="button" class="site-button purple">Trade Link</button></a>
								</div>
							</div>
							
							<div class="mt-2 font-8">
								<div>Trade offer successfully sent. To complete the withdraw please wait until the buyer accept the offer.</div>
							</div>
							
							<div class="flex justify-center gap-1 mt-2">
								<button type="button" class="site-button purple" data-modal="hide">Close</button>
							</div>
						</div>
						
						<div class="offers_pending_status hidden" data-status="4">
							<div class="bundle_items_pending">
							</div>
							
							<div class="mt-2 font-8">
								<div>Trade offer successfully completed. You delivered the items to buyer.</div>
							</div>
							
							<div class="flex justify-center gap-1 mt-2">
								<button type="button" class="site-button purple" data-modal="hide">Close</button>
							</div>
						</div>
					</div>
					
					<div class="offers_pending_type hidden" data-type="withdraw">
						<div class="offers_pending_status hidden" data-status="-1">
							<div class="bundle_items_pending">
							</div>
							
							<div class="mt-2 font-8">
								<div>This trade has canceled. Your coins was refunded.</div>
							</div>
							
							<div class="flex justify-center gap-1 mt-2">
								<button type="button" class="site-button purple" data-modal="hide">Close</button>
							</div>
						</div>
						
						<div class="offers_pending_status hidden" data-status="0">
							<div class="bundle_items_pending">
							</div>
							
							<div class="mt-2 font-8">
								<div>This trade has expired. Your coins was refunded.</div>
							</div>
							
							<div class="flex justify-center gap-1 mt-2">
								<button type="button" class="site-button purple" data-modal="hide">Close</button>
							</div>
						</div>
						
						<div class="offers_pending_status hidden" data-status="1">
							<div class="bundle_items_pending">
							</div>
							
							<div class="bg-main-transparent rounded-1 b-l2 flex items-center justify-center mt-2 text-center font-9 width-full inline-block">
								<div class="counter_content m-1">Expire in <span class="counter">00:00</span></div>
							</div>
							
							<div class="mt-2 font-8">
								<div>Your withdrawl request has bees sent to seller.</div>
								<div>The seller must to confirm the request!</div>
							</div>
							
							<div class="flex justify-center gap-1 mt-2">
								<button type="button" class="site-button purple" data-modal="hide">Close</button>
							</div>
						</div>
					
						<div class="offers_pending_status hidden" data-status="2">
							<div class="bundle_items_pending">
							</div>
							
							<div class=" bg-main-transparent rounded-1 b-l2 flex items-center justify-center mt-2 text-center font-9 width-full inline-block">
								<div class="counter_content m-1">Expire in <span class="counter">00:00</span></div>
							</div>
							
							<div class="mt-2 font-8">
								<div>Wait for a trade offer, always check the Steam offers to see if you received new offers from seller and check if the offer contain the correct items.</div>
							</div>
							
							<div class="flex justify-center gap-1 mt-2">
								<button type="button" class="site-button purple" data-modal="hide">Close</button>
							</div>
						</div>
						
						<div class="offers_pending_status hidden" data-status="3">
							<div class="bundle_items_pending">
							</div>
							
							<div class="bg-main-transparent rounded-1 b-l2 flex items-center justify-center mt-2 text-center font-9 width-full inline-block">
								<div class="counter_content m-1">Expire in <span class="counter">00:00</span></div>
							</div>
							
							<div class="mt-2 font-8">
								<div>The seller successfully sent a trade offer with your items. To complete the withdraw please accept the offer.</div>
							</div>
							
							<div class="flex justify-center gap-1 mt-2">
								<a class="trade_link_offer" href="" target="_blank"><button type="button" class="site-button black">Trade Offer</button></a>
								<button type="button" class="site-button purple" data-modal="hide">Close</button>
							</div>
						</div>
						
						<div class="offers_pending_status hidden" data-status="4">
							<div class="bundle_items_pending">
							</div>
							
							<div class="mt-2 font-8">
								<div>Trade offer successfully completed. You received the items.</div>
							</div>
							
							<div class="flex justify-center gap-1 mt-2">
								<button type="button" class="site-button purple" data-modal="hide">Close</button>
							</div>
						</div>
					</div>
				</div>
			
				<div class="offers_pending_method hidden" data-method="steam">
					<div class="offers_pending_type hidden" data-type="deposit">
						<div class="offers_pending_status hidden" data-status="-1">
							<div class="bundle_items_pending">
							</div>
							
							<div class="mt-2 font-8">
								<div>Your deposit trade offer with id <span class="text-color">#<span class="offer_id"></span></span> was declined/canceled.</div>
							</div>
							
							<div class="flex justify-center gap-1 mt-2">
								<button type="button" class="site-button purple" data-modal="hide">OK</button>
							</div>
						</div>
					
						<div class="offers_pending_status hidden" data-status="1">
							<div class="bundle_items_pending">
							</div>
							
							<div class="bg-main-transparent rounded-1 b-l2 flex items-center justify-center mt-2 text-center font-9 width-full inline-block">
								<div class="counter_content m-1">Expire in <span class="counter">00:00</span></div>
							</div>
							
							<div class="mt-2 font-8">
								<div>Your deposit trade offer with id <span class="text-color">#<span class="offer_id"></span></span> and with security code <span class="text-color offer_code"></span> was sent. Please accept the trade offer until the time expires.</div>
							</div>
							
							<div class="flex justify-center gap-1 mt-2">
								<a class="offer_trade" href="" target="_blank"><button type="button" class="site-button black">Trade Offer</button></a>
								<button type="button" class="site-button purple" data-modal="hide">Close</button>
							</div>
						</div>
						
						<div class="offers_pending_status hidden" data-status="2">
							<div class="bundle_items_pending">
							</div>
							
							<div class="mt-2 font-8">
								<div>Your deposit trade offer with id <span class="text-color">#<span class="offer_id"></span></span> was successfully accepted. <span class="offer_got_coins">You received <span class="offer_coins"></span> coins.</span></div>
							</div>
							
							<div class="flex justify-center gap-1 mt-2">
								<button type="button" class="site-button purple" data-modal="hide">OK</button>
							</div>
						</div>
					</div>
					
					<div class="offers_pending_type hidden" data-type="withdraw">
						<div class="offers_pending_status hidden" data-status="-1">
							<div class="bundle_items_pending">
							</div>
							
							<div class="mt-2 font-8">
								<div>Your withdraw trade offer with id <span class="text-color">#<span class="offer_id"></span></span> was declined/canceled. You received <span class="offer_coins"></span> coins refund.</div>
							</div>
							
							<div class="flex justify-center gap-1 mt-2">
								<button type="button" class="site-button purple" data-modal="hide">OK</button>
							</div>
						</div>
						
						<div class="offers_pending_status hidden" data-status="0">
							<div class="bundle_items_pending">
							</div>
							
							<div class="mt-2 font-8">
								<div>Your withdraw trade offer with id <span class="text-color">#<span class="offer_id"></span></span> and with security code <span class="text-color offer_code"></span> was created and must Steam Guard confirmation. Please wait for bot Steam Guard confirmation.</div>
							</div>
							
							<div class="flex justify-center gap-1 mt-2">
								<button type="button" class="site-button purple" data-modal="hide">Close</button>
							</div>
						</div>
					
						<div class="offers_pending_status hidden" data-status="1">
							<div class="bundle_items_pending">
							</div>
							
							<div class="bg-main-transparent rounded-1 b-l2 flex items-center justify-center mt-2 text-center font-9 width-full inline-block">
								<div class="counter_content m-1">Expire in <span class="counter">00:00</span></div>
							</div>
							
							<div class="mt-2 font-8">
								<div>Your withdraw trade offer with id <span class="text-color">#<span class="offer_id"></span></span> and with security code <span class="text-color offer_code"></span> was sent. Please accept the trade offer until the time expires.</div>
							</div>
							
							<div class="flex justify-center gap-1 mt-2">
								<a class="offer_trade" href="" target="_blank"><button type="button" class="site-button black">Trade Offer</button></a>
								<button type="button" class="site-button purple" data-modal="hide">Close</button>
							</div>
						</div>
						
						<div class="offers_pending_status hidden" data-status="2">
							<div class="bundle_items_pending">
							</div>
							
							<div class="mt-2 font-8">
								<div>Your withdraw trade offer with id <span class="text-color">#<span class="offer_id"></span></span> was successfully accepted.</div>
							</div>
							
							<div class="flex justify-center gap-1 mt-2">
								<button type="button" class="site-button purple" data-modal="hide">OK</button>
							</div>
						</div>
					</div>
				</div>
				
				<div class="offers_pending_method hidden" data-method="currency">
					
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal medium" id="modal_select_bundle">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Select Bundle</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body text-left">
				<div class="bundle-items">
					
				</div>
			</div>
			<div class="modal-footer text-center">
				<div class="bg-light rounded-1 flex items-center justify-center mt-2 text-center inline-block">
					<div class="m-1">Bundle Total <div class='coins mr-1'></div><span id="bundle_total_amount">0</span> coins</div>
				</div>
				<button type="button" class="site-button purple" id="select_bundle" data-bundle="0" data-modal="hide">SELECT</button>
			</div>
		</div>
	</div>
</div>

<div class="modal medium" id="modal_view_bundle">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">View Bundle</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body text-left">
				<div class="bundle-items">
					
				</div>
			</div>
			<div class="modal-footer text-center">
				<button type="button" class="site-button purple" data-modal="hide">CLOSE</button>
			</div>
		</div>
	</div>
</div>




<div class="modal medium" id="modal_auth">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper"></div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			
			<div class="modal-body text-left">
				<div class="grid split-column-2 gap-1 mb-2">
					<button class="site-button black switch_panel active" data-id="auth" data-panel="login">LOGIN</button>
					<button class="site-button black switch_panel" data-id="auth" data-panel="register">REGISTER</button>
				</div>
				
				<div class="switch_content" data-id="auth" data-panel="login">
					<div class="grid split-column-4 gap-2 mr-2 ml-2">
						<a href="<?php echo $site['root'];?>auth/steam?assign=0&return=<?php echo $site['path'];?>">
							<div class="social-login steam rounded-1 flex justify-center items-center width-full"></div>
						</a>
						
						<a href="<?php echo $site['root'];?>auth/google?assign=0&return=<?php echo $site['path'];?>">
							<div class="social-login google rounded-1 flex justify-center items-center width-full"></div>
						</a>
						
						<a href="<?php echo $site['root'];?>auth/discord?assign=0&return=<?php echo $site['path'];?>">
							<div class="social-login discord rounded-1 flex justify-center items-center width-full"></div>
						</a>
						
						<div class="social-login facebook rounded-1 flex justify-center items-center width-full disabled"></div>
					</div>
					
					<div class="title-text width-full flex items-center justify-center mt-1 mb-1">or</div>
				
					<form class="form_auth" autocomplete="login" method="POST" action="<?php echo $site['root'];?>auth/login?return=<?php echo $site['path'];?>">
						<div class="flex column items-center gap-2">
							<div class="input_field bet_input_field transition-5" data-border="#de4c41">
								<div class="field_container">
									<div class="field_content">
										<input type="text" class="field_element_input" name="username" value="" autocomplete="email">
										
										<div class="field_label">Username / E-mail</div>
									</div>
									
									<div class="field_extra"></div>
								</div>
								
								<div class="field_bottom">
									<div class="field_error" data-error="required">This field is required</div>
									<div class="field_error" data-error="username_email">This field must be a username or a email</div>
								</div>
							</div>
							
							<div class="input_field bet_input_field transition-5" data-border="#de4c41">
								<div class="field_container">
									<div class="field_content">
										<input type="password" class="field_element_input" name="password" value="" autocomplete="password">
										
										<div class="field_label">Password</div>
									</div>
									
									<div class="field_extra"></div>
								</div>
								
								<div class="field_bottom">
									<div class="field_error" data-error="required">This field is required</div>
									<div class="field_error" data-error="password">At least 8 characters, one uppercase, one lowercase, one number and one symbol</div>
								</div>
							</div>
							
							<div class="flex justify-start width-full mt-2">
								<div class="text-gray pointer font-6" data-modal="show" data-id="#modal_auth_recover">Recover password</div>
							</div>
							
							<button type="submit" class="site-button purple mt-1">Sumbit</button>
						</div>
					</form>
				</div>
				
				<div class="switch_content hidden" data-id="auth" data-panel="register">
					<form class="form_auth" autocomplete="register" method="POST" action="<?php echo $site['root'];?>auth/register?return=<?php echo $site['path'];?>">
						<div class="flex column items-center gap-2">
							<div class="input_field bet_input_field transition-5" data-border="#de4c41">
								<div class="field_container">
									<div class="field_content">
										<input type="text" class="field_element_input" name="email" value="" autocomplete="email">
										
										<div class="field_label">E-mail</div>
									</div>
									
									<div class="field_extra"></div>
								</div>
								
								<div class="field_bottom">
									<div class="field_error" data-error="required">This field is required</div>
									<div class="field_error" data-error="email">This field must be a email</div>
								</div>
							</div>
							
							<div class="input_field bet_input_field transition-5" data-border="#de4c41">
								<div class="field_container">
									<div class="field_content">
										<input type="text" class="field_element_input" name="username" value="" autocomplete="username">
										
										<div class="field_label">Username</div>
									</div>
									
									<div class="field_extra"></div>
								</div>
								
								<div class="field_bottom">
									<div class="field_error" data-error="required">This field is required</div>
									<div class="field_error" data-error="username">At least 6 characters, only lowercase, numbers and underscore are allowed</div>
								</div>
							</div>
							
							<div class="input_field bet_input_field transition-5" data-border="#de4c41">
								<div class="field_container">
									<div class="field_content">
										<input type="password" class="field_element_input" name="password" value="" autocomplete="password">
										
										<div class="field_label">Password</div>
									</div>
									
									<div class="field_extra"></div>
								</div>
								
								<div class="field_bottom">
									<div class="field_error" data-error="required">This field is required</div>
									<div class="field_error" data-error="password">At least 8 characters, one uppercase, one lowercase, one number and one symbol</div>
								</div>
							</div>
							
							<button type="submit" class="site-button purple mt-1">Sumbit</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal medium" id="modal_auth_initializing">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Initialize Account</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			
			<div class="modal-body text-left">
				<form class="form_auth" autocomplete="initializing" method="POST" action="<?php echo $site['root'];?>auth/initializing?return=<?php echo $site['path'];?>">
					<div class="flex column items-center gap-2">
						<div class="input_field bet_input_field transition-5" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" name="username" value="<?php echo $user['username']; ?>">
									
									<div class="field_label">Username</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom">
								<div class="field_error" data-error="required">This field is required</div>
								<div class="field_error" data-error="username">At least 6 characters, only lowercase, numbers and underscore are allowed</div>
							</div>
						</div>
						
						<div class="input_field bet_input_field transition-5" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" name="email" value="<?php echo $user['email']; ?>">
									
									<div class="field_label">E-mail</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom">
								<div class="field_error" data-error="required">This field is required</div>
								<div class="field_error" data-error="email">This field must be a email</div>
							</div>
						</div>
						
						<div class="input_field bet_input_field transition-5" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="password" class="field_element_input" name="password" value="">
									
									<div class="field_label">Password</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom">
								<div class="field_error" data-error="required">This field is required</div>
								<div class="field_error" data-error="password">At least 8 characters, one uppercase, one lowercase, one number and one symbol</div>
							</div>
						</div>
						
						<div class="input_field bet_input_field transition-5" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="password" class="field_element_input" name="confirm_password" value="">
									
									<div class="field_label">Confirm Password</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom">
								<div class="field_error" data-error="required">This field is required</div>
								<div class="field_error" data-error="password">At least 8 characters, one uppercase, one lowercase, one number and one symbol</div>
							</div>
						</div>
						
						<button type="submit" class="site-button purple mt-1">Sumbit</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="modal medium" id="modal_auth_settings">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Account Settings</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			
			<div class="modal-body text-left">
				<form class="form_auth" autocomplete="settings" method="POST" action="<?php echo $site['root'];?>auth/save_settings">
					<div class="flex column items-center gap-2">
						<div class="input_field bet_input_field transition-5" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" name="username" value="<?php echo $user['username']; ?>">
									
									<div class="field_label">Username</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom">
								<div class="field_error" data-error="required">This field is required</div>
								<div class="field_error" data-error="username">At least 6 characters, only lowercase, numbers and underscore are allowed</div>
							</div>
						</div>
						
						<div class="input_field bet_input_field transition-5" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" name="email" value="<?php echo $user['email']; ?>">
									
									<div class="field_label">E-mail</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom">
								<div class="field_error" data-error="required">This field is required</div>
								<div class="field_error" data-error="email">By changing your email, you need to verify your profile again</div>
							</div>
						</div>
						
						<div class="flex column items-start width-full">
							<button type="button" class="site-button black" data-modal="show" data-id="#modal_auth_change_password">Change password</button>
						</div>
						
						<button type="submit" class="site-button purple mt-1">Sumbit</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="modal medium" id="modal_auth_change_password">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Change Password</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			
			<div class="modal-body text-left">
				<form class="form_auth" autocomplete="change_password" method="POST" action="<?php echo $site['root'];?>auth/change_password">
					<div class="flex column items-center gap-2">
						<div class="input_field bet_input_field transition-5" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="password" class="field_element_input" name="current_password" value="">
									
									<div class="field_label">Current password</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom">
								<div class="field_error" data-error="required">This field is required</div>
								<div class="field_error" data-error="password">This field must be a password</div>
							</div>
						</div>
						
						<div class="input_field bet_input_field transition-5" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="password" class="field_element_input" name="password" value="">
									
									<div class="field_label">New password</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom">
								<div class="field_error" data-error="required">This field is required</div>
								<div class="field_error" data-error="password">At least 8 characters, one uppercase, one lowercase, one number and one symbol</div>
							</div>
						</div>
						
						<div class="input_field bet_input_field transition-5" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="password" class="field_element_input" name="confirm_password" value="">
									
									<div class="field_label">Confirm new password</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom">
								<div class="field_error" data-error="required">This field is required</div>
								<div class="field_error" data-error="password">At least 8 characters, one uppercase, one lowercase, one number and one symbol</div>
							</div>
						</div>
						
						<button type="submit" class="site-button purple mt-1">Sumbit</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="modal" id="modal_auth_recover">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Recover password</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body text-left font-8">
				<form class="form_auth" autocomplete="recover" method="POST" action="<?php echo $site['root'];?>auth/recover">
					<div class="flex column items-center">
						<div class="input_field bet_input_field transition-5" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" name="username" value="" autocomplete="username">
									
									<div class="field_label">Username / E-mail</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom">
								<div class="field_error" data-error="required">This field is required</div>
								<div class="field_error" data-error="username_email">This field must be a username or a email</div>
							</div>
						</div>
						
						<button type="submit" class="site-button purple mt-1">Sumbit</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="modal small" id="modal_auth_logout">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">LOGOUT</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			
			<div class="modal-body text-left">
				<div class="text-center mb-2">Do you wish to log out?</div>
			
				<div class="grid split-column-2 gap-1 mb-2">
					<button class="site-button black" data-modal="hide">CANCEL</button>
					
					<a href="<?php echo $site['root'];?>auth/logout?end=0&return=<?php echo $site['path'];?>">
						<button class="site-button purple width-full">LOGOUT</button>
					</a>
				</div>
				
				<a class="width-full" href="<?php echo $site['root'];?>auth/logout?end=1&return=<?php echo $site['path'];?>">
					<button class="site-button purple width-full">END THIS SESSION</button>
				</a>
			</div>
		</div>
	</div>
</div>

<div class="modal large" id="modal_fair_games">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Game Results</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body text-left">
				<div class="fair-games">
				
				</div>
			</div>
			<div class="modal-footer text-center">
				<button type="button" class="site-button purple" data-modal="hide">CLOSE</button>
			</div>
		</div>
	</div>
</div>

<div class="modal medium" id="modal_fair_round">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Round Results</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body text-left">
				<div class="flex justify-center items-center column gap-2">
					<div class="font-6 width-full ellipsis"><span class="text-gray mr-1">Server Seed (hashed):</span><span class="pointer" id="fair_server_seed_hashed" data-copy="text" data-text="">-</span></div>
					<div class="font-6 width-full ellipsis"><span class="text-gray mr-1">Server Seed:</span><span class="pointer" id="fair_server_seed" data-copy="text" data-text="">-</span></div>
					<div class="font-6 width-full ellipsis"><span class="text-gray mr-1">Public Seed:</span><span class="pointer" id="fair_public_seed" data-copy="text" data-text="">-</span></div>
					<div class="font-6 width-full ellipsis"><span class="text-gray mr-1">Nonce:</span><span class="pointer" id="fair_nonce" data-copy="text" data-text="">-</span></div>
					<div class="font-6 width-full ellipsis"><span class="text-gray mr-1">EOS block:</span><a id="fair_block_link" href="" target="_black"><span id="fair_block">-</span></a></div>
				</div>
			</div>
			<div class="modal-footer text-center">
				<button type="button" class="site-button purple" data-modal="hide">CLOSE</button>
			</div>
		</div>
	</div>
</div>

<div class="modal medium" id="modal_fair_casebattle_results">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Case Battle Results</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body text-left">
				<div class="fair-results flex justify-center items-center column gap-2">
				</div>
			</div>
			<div class="modal-footer text-center">
				<button type="button" class="site-button purple" data-modal="hide">CLOSE</button>
			</div>
		</div>
	</div>
</div>

<div class="modal large" id="modal_dailycases_cases">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Daily Cases</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body text-left">
				<div id="dailycases_cases">
					<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No daily cases found</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal large" id="modal_dailycases_case">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Daily Cases - <span id="dailycases_case_name">none</span></div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body text-left">
				<div class="dailycases-case relative mt-2 transition-5" id="dailycases_case">
					<div class="group-reel flex" id="dailycases_spinner">
						<div class="flex" id="dailycases_field"></div>
					</div>
					
					<div class="shadow shadow-left"></div>
					<div class="shadow shadow-right"></div>
					
					<div class="absolute top-0 bottom-0 left-0 right-0 flex justify-center">
						<div class="pointer flex items-center"></div>
					</div>
				</div>

				<div class="mt-2 text-center">
					<button class="site-button pink" id="dailycases_open" data-id="">OPEN CASE (LVL. <span id="dailycases_case_level">0</span>)</button>
				</div>

				<div class="mt-2 p-2">
					<div class="text-left font-9">This case contains:</div>
					
					<div class="dailycases-list" id="dailycases_list"></div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal" id="modal_send_coins">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Send Coins</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body text-left">
				<div class="input_field bet_input_field transition" data-border="#de4c41">
					<div class="field_container">
						<div class="field_content">
							<input type="text" class="field_element_input" id="send_coins_amount" data-amount="send_coins" value="0.01">
							
							<div class="field_label transition">Send Amount</div>
						</div>
						
						<div class="field_extra">
						</div>
					</div>
					
					<div class="field_bottom">
						<div class="field_error" data-error="required">This field is required</div>
						<div class="field_error" data-error="number">This field must be a number</div>
						<div class="field_error" data-error="greater">You must enter a greater value</div>
						<div class="field_error" data-error="lesser">You must enter a lesser value</div>
					</div>
				</div>
			</div>
			<div class="modal-footer text-center">
				<button type="button" class="site-button purple" data-modal="hide" id="send_coins_to_user" data-user="0">SEND</button>
				<button type="button" class="site-button purple" data-modal="hide">CLOSE</button>
			</div>
		</div>
	</div>
</div>

<div class="modal large" id="modal_casebattle_add">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Select Cases</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body">
				<div class="flex column gap-2 overflow-h">
					<div class="flex row responsive justify-between gap-2 bg-light p-2">
						<div class="flex column justify-between gap-2">
							<div class="text-color text-bold">TOTAL COST</div>
							
							<div class="text-bold font-8"><div class="coins mr-1"></div><span id="casebattle_add_total">0.00</span></div>
						</div>
						
						<button class="site-button purple" id="casebattle_add_confirm">Confirm</button>
					</div>
					
					<div class="flex row responsive gap-2">
						<div class="input_field bet_input_field transition-5" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" id="casebattle_add_search" value="">
									
									<div class="field_label transition-5">Search Case</div>
								</div>
								
								<div class="field_extra"></div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
						
						<div class="dropdown_field transition-5">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" id="casebattle_add_order" value="2">
									<div class="field_dropdown"></div>
								
									<div class="field_element_dropdowns">
										<div class="field_element_dropdown" value="0" data-index="0">Name A-Z</div>
										<div class="field_element_dropdown" value="1" data-index="1">Name Z-A</div>
										<div class="field_element_dropdown" value="2" data-index="2">Price acending</div>
										<div class="field_element_dropdown" value="3" data-index="3">Price descending</div>
									</div>
								
									<div class="field_label active transition-5">Order by</div>
								</div>
								
								<div class="field_extra">
									<div class="field_caret">
										<i class="fa fa-caret-down"></i>
									</div>
								</div>
							</div>
							
							<div class="field_bottom"></div>
						</div>
					</div>
					
					<div id="casebattle_add_list">
						<div class="in-grid flex justify-center items-center font-8 p-4 history_message">No cases found</div></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal medium" id="join_referral_dashboard">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Dashboard Join Referrals</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body">
				<div class="dashboard-chart flex column items-start gap-2" data-graph="join_referral" data-graph="0">
					<div class="width-full relative">
						<div class="dashboard-loader hidden bg-light-transparent flex justify-center items-center">
							<div class="loader">
								<div class="loader-part loader-part-1">
									<div class="loader-dot loader-dot-1"></div>
									<div class="loader-dot loader-dot-2"></div>
								</div>
								
								<div class="loader-part loader-part-2">
									<div class="loader-dot loader-dot-1"></div>
									<div class="loader-dot loader-dot-2"></div>
								</div>
							</div>
						</div>
					
						<div class="width-full">
							<canvas id="dashboard_chart_join_referral"></canvas>
						</div>
					</div>
					
					<div class="dashboard-select grid split-column-full width-full responsive gap-1">
						<button class="site-button black dashboard-graph switch_panel active" data-date="day" data-id="chart_join_referral" data-panel="day">This Day</button>
						<button class="site-button black dashboard-graph switch_panel" data-date="week" data-id="chart_join_referral" data-panel="week">This Week</button>
						<button class="site-button black dashboard-graph switch_panel" data-date="month" data-id="chart_join_referral" data-panel="month">This Month</button>
						<button class="site-button black dashboard-graph switch_panel" data-date="year" data-id="chart_join_referral" data-panel="year">This Year</button>
					</div>
				</div>
			</div>
			<div class="modal-footer text-center">
				<button type="button" class="site-button purple" data-modal="hide">CLOSE</button>
				<button type="button" class="site-button red admin_join_referrals_remove" data-id="0">Remove</button>
			</div>
		</div>
	</div>
</div>

<div class="modal small" id="modal_confirm_action">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Confirmation</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body text-left">
				<div class="text-center mb-2">Do you confirm your next action?</div>
			
				<div class="grid split-column-2 gap-1">
					<button class="site-button black" id="confirm_action_no" data-modal="hide">CANCEL</button>
					<button class="site-button purple" id="confirm_action_yes" data-modal="hide">YES</button>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal small" id="modal_confirm_identity">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Confirmation</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body text-left">
				<div class="text-center mb-2">Confirm your identity by providing a secret code!</div>
				
				<div class="input_field transition" data-border="#de4c41">
					<div class="field_container">
						<div class="field_content">
							<input type="password" class="field_element_input" id="confirm_identity_secret" value="">
							
							<div class="field_label transition">Secret</div>
						</div>
						
						<div class="field_extra">
						</div>
					</div>
					
					<div class="field_bottom">
						<div class="field_error" data-error="required">This field is required</div>
					</div>
				</div>
			
				<div class="grid split-column-2 gap-1 mt-2">
					<button class="site-button black" id="confirm_identity_no" data-modal="hide">CANCEL</button>
					<button class="site-button purple" id="confirm_identity_yes" data-modal="hide">YES</button>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal small" id="modal_insufficient_balance">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Oops, your balance is too low</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body text-left">
				<div class="text-left mb-2">You need <span class="amount">0.00</span> coins more to continue your action.</div>
				
				<div class="flex justify-center items-center">
					<a href="<?php echo $site['root']; ?>deposit"><button class="site-button purple">DEPOSIT</button></a>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal medium" id="modal_online_list">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Online list</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body text-left">
				<div id="online_list">
					<div class="in-grid font-8 history_message">No players online</div>
				</div>
			</div>
			<div class="modal-footer text-center">
				<button type="button" class="site-button purple" data-modal="hide">CLOSE</button>
			</div>
		</div>
	</div>
</div>

<div class="modal small" id="modal_twofa_code">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Security code</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body text-left">
				<div class="text-left mb-2">You have received a email with a security code. Please enter the code.</div>
				
				<form class="form_security submit-code-twofa" autocomplete="code" method="POST" action="<?php echo $site['root'];?>security/submit_code_twofa" data-type="">
					<div class="flex column items-center gap-2">
						<div class="input_field bet_input_field transition" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" name="code" value="" autocomplete="code">
									
									<div class="field_label transition">Security Code</div>
								</div>
								
								<div class="field_extra">
								</div>
							</div>
							
							<div class="field_bottom">
								<div class="field_error" data-error="required">This field is required</div>
							</div>
						</div>
						
						<div class="flex justify-start width-full mt-2">
							<a class="form_security submit-code-twofa text-gray pointer font-6" href="<?php echo $site['root'];?>security/resend_code_twofa" data-type="">I did not receive the security code</a>
						</div>
						
						<button type="submit" class="site-button purple mt-1">Sumbit</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="modal small" id="modal_twofa_enable">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Enable 2FA Security</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body text-left">
				<div class="text-left mb-2">Recover Code: <span id="twofa_auth_recover">none</span></div>
				<div class="text-left mb-2">Secret: <span id="twofa_auth_secret">none</span></div>
				
				<div class="width-full flex row justify-center">
					<div class="qrcode" id="twofa_qrcode"></div>
				</div>
				
				<form class="form_security" autocomplete="activation" method="POST" action="<?php echo $site['root'];?>security/activate_twofa">
					<div class="flex column items-center gap-2">
						<div class="input_field bet_input_field transition" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" name="security" value="" autocomplete="activation">
									
									<div class="field_label transition">Authentication Code</div>
								</div>
								
								<div class="field_extra">
								</div>
							</div>
							
							<div class="field_bottom">
								<div class="field_error" data-error="required">This field is required</div>
							</div>
						</div>
						
						<button type="submit" class="site-button purple mt-1">Activate</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="modal small" id="modal_twofa_security">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Require 2FA Code</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body text-left">
				<form class="form_security submit-security-twofa" autocomplete="security" method="POST" action="<?php echo $site['root'];?>security/submit_security_twofa" data-type="">
					<div class="flex column items-center gap-2">
						<div class="input_field bet_input_field transition" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" name="security" value="" autocomplete="security">
									
									<div class="field_label transition">Authentication Code</div>
								</div>
								
								<div class="field_extra">
								</div>
							</div>
							
							<div class="field_bottom">
								<div class="field_error" data-error="required">This field is required</div>
							</div>
						</div>
						
						<div class="flex justify-start width-full mt-2">
							<div class="text-gray pointer font-6" data-modal="show" data-id="#modal_twofa_recover">I lost 2FA Authentication</div>
						</div>
						
						<button type="submit" class="site-button purple mt-1">Submit</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="modal small" id="modal_twofa_recover">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Recover 2FA Code</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body text-left">
				<form class="form_security" autocomplete="recover" method="POST" action="<?php echo $site['root'];?>security/recover_twofa">
					<div class="flex column items-center gap-2">
						<div class="input_field bet_input_field transition" data-border="#de4c41">
							<div class="field_container">
								<div class="field_content">
									<input type="text" class="field_element_input" name="recover" value="" autocomplete="recover">
									
									<div class="field_label transition">Recover Code</div>
								</div>
								
								<div class="field_extra">
								</div>
							</div>
							
							<div class="field_bottom">
								<div class="field_error" data-error="required">This field is required</div>
							</div>
						</div>
						
						<button type="submit" class="site-button purple mt-1">Submit</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="modal small" id="modal_recaptcha">
	<div class="modal-dialog flex justify-center items-center">
		<div class="modal-content rounded-1">
			<div class="modal-header flex items-center justify-between">
				<div class="modal-title text-upper">Verify Recaptcha</div>
				<div class="modal-close flex justify-center items-center rounded-0" data-modal="hide"><i aria-hidden="true" class="fa fa-times"></i></div>
			</div>
			<div class="modal-body font-8">
				<div class="flex justify-center" id="g-recaptcha"></div>
			</div>
		</div>
	</div>
</div>