<div class="footer">
	<div class="flex column gap-6">
		<div class="footer-top flex row justify-between gap-6 responsive">
			<div class="footer-logo flex column gap-4">
				<div class="justify-center">
					<a class="justify-center flex" href="<?php echo $site['root']; ?>">
						<img src="<?php echo $site['root']; ?>template/img/logo.png?v=<?php echo time(); ?>">
					</a>
				</div>
				
				<div>Your favorite place to trade & win skins!</div>
			</div>
			
			<div class="footer-grid flex row gap-2">
				<div class="column flex column items-start gap-4">
					<div class="title font-9 text-bold">Support</div>
					
					<div class="flex column text-left gap-2">
						<a class="text-gray" href="<?php echo $site['root']; ?>rewards">Rewards</a>
						<a class="text-gray" href="<?php echo $site['root']; ?>faq">FAQ</a>
						<a class="text-gray" href="<?php echo $site['root']; ?>tos">Terms of Service</a>
						<a class="text-gray" href="<?php echo $site['root']; ?>support">Support</a>
					</div>
				</div>
				
				<div class="column flex column items-start gap-4">
					<div class="title font-9 text-bold">Games</div>
					
					<div class="flex column text-left gap-2">
						<a class="text-gray" href="<?php echo $site['root']; ?>roulette">Roulette</a>
						<a class="text-gray" href="<?php echo $site['root']; ?>crash">Crash</a>
						<a class="text-gray" href="<?php echo $site['root']; ?>jackpot">Jackpot</a>
						<a class="text-gray" href="<?php echo $site['root']; ?>coinflip">Coinflip</a>
						<a class="text-gray" href="<?php echo $site['root']; ?>dice">Dice</a>
						<a class="text-gray" href="<?php echo $site['root']; ?>unboxing">Unboxing</a>
						<a class="text-gray" href="<?php echo $site['root']; ?>casebattle">Case Battle</a>
						<a class="text-gray" href="<?php echo $site['root']; ?>upgrader">Upgrader</a>
						<a class="text-gray" href="<?php echo $site['root']; ?>minesweeper">Minesweeper</a>
						<a class="text-gray" href="<?php echo $site['root']; ?>tower">Tower</a>
						<a class="text-gray" href="<?php echo $site['root']; ?>plinko">Plinko</a>
					</div>
				</div>
				
				<div class="column flex column items-start gap-4">
					<div class="title font-9 text-bold">Social Medias</div>
					
					<div class="flex column text-left gap-2">
						<a class="text-gray" href="<?php echo $site['link_twitter']; ?>" target="_blank"><i class="fa fa-twitter mr-2" aria-hidden="true"></i> Twitter</a>
						<a class="text-gray" href="<?php echo $site['link_steam']; ?>" target="_blank"><i class="fa fa-steam mr-2" aria-hidden="true"></i> Steam</a>
					</div>
				</div>
			</div>
		</div>
		
		<div class="footer-bottom flex justify-between items-center responsive gap-2 pt-2 bt-l2">
			<div class="flex row items-center gap-4">
				<div class="bg-main-transparent pt-1 pb-1 pr-2 pl-2 rounded-0 text-bold">+18</div>
				<div class="text-gray">© 2021 <?php echo $site['name']; ?>. All rights reserved.</div>
			</div>
			
			<img src="<?php echo $site['root']; ?>template/img/fair.png">
		</div>
	</div>
</div>