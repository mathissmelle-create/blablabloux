<div class="slider slider-right text-right slider-top flex justify-content transition-5 p-2 pullout_view" data-pullout="cart">
	<i class="fa fa-shopping-cart" aria-hidden="true"></i>
</div>

<div class="pullout pullout-right flex column transition-5" data-pullout="cart">
	<div class="m-2">
		<div class="flex justify-between items-center mb-2 font-7">
			<div class="pullout_view pointer" data-pullout="cart"><i class="fa fa-times" aria-hidden="true"></i></div>
		</div>
		
		<?php if(($paths[0] == 'deposit' || $paths[0] == 'withdraw') && sizeof($paths) > 0){?>
		<div class="grid split-column-2 gap-1">
			<button class="site-button black switch_panel active" data-id="offers" data-panel="cart">CART</button>
			<button class="site-button black relative switch_panel" data-id="offers" data-panel="pending">PENDING<div class="sop-medium-right bg-danger rounded-full flex justify-center items-center hidden" id="pending_count">0</div></button>
		</div>
		<?php } else { ?>
		<button class="site-button black relative switch_panel width-full active" data-id="offers" data-panel="pending">PENDING<div class="sop-medium-right bg-danger rounded-full flex justify-center items-center hidden" id="pending_count">0</div></button>
		<?php } ?>
	</div>

	<div class="wrapper-page flex column height-full width-full">
		<div class="wrapper-page switch_content flex column pr-1 pl-1 <?php if(($paths[0] != 'deposit' && $paths[0] != 'withdraw') || sizeof($paths) <= 0) echo 'hidden'; ?>" data-id="offers" data-panel="cart">
			<div class="flex column gap-1">
				<button class="confirm-offer site-button purple width-full" data-confirm="order">Confirm</button>
				<?php if($paths[0] == 'deposit' && $paths[1] == 'steam' && in_array($site['ranks_name'][$user['rank']], $site['permissions']['refillshop'])){ ?>
				<button class="confirm-offer site-button purple width-full" data-confirm="refill">Refill Shop</button>
				<?php } ?>
			</div>
			
			<?php if($paths[0] == 'deposit' && $paths[1] == 'p2p'){ ?>
			<div class="mt-2">
				<div class="slider_field transition-5">
					<div class="field_container">
						<div class="field_content">
							<input type="range" class="field_element_input" id="bundle_offset" min="-10" max="10" step="1" value="0">
							
							<div class="field_cursor_content">
								<div class="field_cursor" data-fixed="0">
									<div class="field_cursor_text">0</div>
								</div>
							</div>
							
							<div class="field_label active transition-5">Offset Price</div>
						</div>
						
						<div class="field_extra"></div>
					</div>
					
					<div class="field_bottom">
						<div class="flex justify-between">
							<div>-10</div>
							<div>10</div>
						</div>
					</div>
				</div>
			</div>
			<?php } ?>
			
			<div class="header-items">
				<div class="text-left">Skins: <span id="cart_items_count">0</span></div>
				<div class="text-right">Coins: <span id="cart_items_total">0.00</span></div>
			</div>
			
			<div class="flex gap-1 column width-full p-1 pt-2 pb-2 overflow-a" id="cart-items">

			</div>
		</div>
		
		<div class="wrapper-page switch_content flex column pr-1 pl-1 <?php if(($paths[0] == 'deposit' || $paths[0] == 'withdraw') && sizeof($paths) > 0) echo 'hidden'; ?>" data-id="offers" data-panel="pending">
			<div class="header-items">
				<div class="text-left">Skins: <span id="padding_items_count">0</span></div>
				<div class="text-right">Coins: <span id="padding_items_total">0.00</span></div>
			</div>
			
			<div class="grid gap-2 width-full p-1 pt-2 pb-2 overflow-a" id="pending-offers">
				
			</div>
		</div>
	</div>
</div>

<div class="slider slider-left text-left slider-top flex justify-content transition-5 show_chat p-2 pullout_view" data-pullout="chat">
	<i class="fa fa-comments" aria-hidden="true"></i>
</div>

<div class="pullout pullout-left flex column transition-5" data-pullout="chat">
	<div class="m-2">
		<div class="flex justify-between items-center mb-2 font-7">
			<div>
				<i class="fa fa-user text-color" aria-hidden="true"></i>
				<span id="isonline">0</span> Online
			</div>
			
			<div class="pullout_view pointer" data-pullout="chat"><i class="fa fa-times" aria-hidden="true"></i></div>
		</div>
		
		<div class="grid split-column-full gap-1">
			<div class="flag rounded-1 flex items-center justify-center relative active" data-channel="en" data-name="English"><img class="rounded-full" src="<?php echo $site['root'];?>template/img/lang/en.png?v=<?php echo time(); ?>"><div class="sop-medium-right bg-danger rounded-full flex justify-center items-center new-messages hidden">0</div></div>
			<div class="flag rounded-1 flex items-center justify-center relative" data-channel="ro" data-name="Română"><img class="rounded-full" src="<?php echo $site['root'];?>template/img/lang/ro.png?v=<?php echo time(); ?>"><div class="sop-medium-right bg-danger rounded-full flex justify-center items-center new-messages hidden">0</div></div>
			<div class="flag rounded-1 flex items-center justify-center relative" data-channel="fr" data-name="Français"><img class="rounded-full" src="<?php echo $site['root'];?>template/img/lang/fr.png?v=<?php echo time(); ?>"><div class="sop-medium-right bg-danger rounded-full flex justify-center items-center new-messages hidden">0</div></div>
			<div class="flag rounded-1 flex items-center justify-center relative" data-channel="ru" data-name="Pусский"><img class="rounded-full" src="<?php echo $site['root'];?>template/img/lang/ru.png?v=<?php echo time(); ?>"><div class="sop-medium-right bg-danger rounded-full flex justify-center items-center new-messages hidden">0</div></div>
			<div class="flag rounded-1 flex items-center justify-center relative" data-channel="de" data-name="German"><img class="rounded-full" src="<?php echo $site['root'];?>template/img/lang/de.png?v=<?php echo time(); ?>"><div class="sop-medium-right bg-danger rounded-full flex justify-center items-center new-messages hidden">0</div></div>
		</div>
	</div>
	
	<div class="rain_panel p-3 hidden">
		<div class="title-page flex items-center justify-center text-center">IT'S RAINING</div>
		
		<div class="rainJoin hidden">
			<div class="text-center font-8">Join to claim some free coins!</div>
			
			<div class="text-center">
				<button type="button" class="site-button purple" id="join_rain">JOIN</button>
			</div>
		</div>
		
		<div class="rainJoined hidden">
			<div class="text-center font-8">You have successfully joined the rain! You will receive your coins as soon as the rain is over.</div>
		</div>
		
		<div class="rainWait hidden">
			<div class="text-center font-8">The time to enter to rain has elapsed. You can enter the next rain.</div>
		</div>
	</div>
	
	<div class="chat-group flex column">
		<div id="chat-area"></div>
			
		<div class="emojis-panel text-center" style="display: none;">
			<?php
			$emojis = array('smile', 'smiley', 'grin', 'pensive', 'weary', 'astonished', 'rolling_eyes', 'relaxed', 'wink', 'woozy_face', 'zany_face', 'hugging', 'joy', 'sob', 'grimacing', 'rofl', 'face_monocle', 'thinking', 'pleading_face', 'sleeping', 'sunglasses', 'heart_eyes', 'smiling_hearts', 'kissing_heart', 'star_struck', 'nerd', 'innocent', 'face_vomiting', 'money_mouth', 'cold_sweat', 'partying_face', 'exploding_head', 'rage', 'hot_face', 'cold_face', 'smiling_imp', 'alien', 'clown', 'scream_cat', 'smiley_cat', 'robot', 'ghost', 'skull', 'poop', 'jack_o_lantern', '100', 'bell', 'birthday', 'gift', 'first_place', 'trophy', 'tada', 'crown', 'fire', 'heart', 'broken_heart', 'wave', 'clap', 'raised_hands', 'thumbsup', 'peace', 'ok_hand', 'muscle', 'punch', 'moneybag');
			
			if(sizeof($emojis) > 0){
				echo '<div class="emojis-content m-2">';
				echo '<div class="title-panel text-left rounded-0 p-1 mb-1">Emojis</div>';
				
				foreach($emojis as $emoji){
					echo '<img id="chat_place_emoji" title=":' . $emoji . ':" data-emoji=":' . $emoji . ':" src="' . $site['root'] . 'template/img/emojis/' . $emoji . '.png">';
				}
				echo '</div>';
			}
			?>
			
			<?php
			$pepe = array('crypepe', 'firinpepe', 'happepe', 'monkachrist', 'okpepe', 'sadpepe');
			
			if(sizeof($pepe) > 0){
				echo '<div class="emojis-content m-2">';
				echo '<div class="title-panel text-left rounded-0 p-1 mb-1">Pepe</div>';
				
				foreach($pepe as $emoji){
					echo '<img id="chat_place_emoji" title=":' . $emoji . ':" data-emoji=":' . $emoji . ':" src="' . $site['root'] . 'template/img/emojis/' . $emoji . '.png">';
				}
				echo '</div>';
			}
			?>
			
			<?php
			$faces = array('gaben', 'kappa', 'kappapride', 'kim', 'pogchamp', 'shaq');
			
			if(sizeof($faces) > 0){
				echo '<div class="emojis-content m-2">';
				echo '<div class="title-panel text-left rounded-0 p-1 mb-1">Faces</div>';
				
				foreach($faces as $emoji){
					echo '<img id="chat_place_emoji" title=":' . $emoji . ':" data-emoji=":' . $emoji . ':" src="' . $site['root'] . 'template/img/emojis/' . $emoji . '.png">';
				}
				echo '</div>';
			}
			?>
			
			<?php
			$gifs = array('alert', 'awp', 'bananadance', 'carlton', 'fortdance', 'grenade', 'lolizard', 'partyblob', 'saxguy', 'squidab', 'turtle', 'zombie');
			
			if(sizeof($gifs) > 0){
				echo '<div class="emojis-content m-2">';
				echo '<div class="title-panel text-left rounded-0 p-1 mb-1">Gifs</div>';
				
				foreach($gifs as $emoji){
					echo '<img id="chat_place_emoji" title=":' . $emoji . ':" data-emoji=":' . $emoji . ':" src="' . $site['root'] . 'template/img/emojis/' . $emoji . '.gif">';
				}
				echo '</div>';
			}
			?>
			
			<?php
			$messages = array('bet', 'cant', 'cashout', 'doit', 'dont', 'feelsbad', 'feelsgood', 'gg', 'gl', 'highroller', 'joinme', 'letsgo', 'win', 'lose', 'nice', 'sniped', 'midtick', 'lowtick');
			
			if(sizeof($messages) > 0){
				echo '<div class="emojis-content m-2">';
				echo '<div class="title-panel text-left rounded-0 p-1 mb-1">Messages</div>';
				
				foreach($messages as $emoji){
					echo '<img id="chat_place_emoji" title=":' . $emoji . ':" data-emoji=":' . $emoji . ':" src="' . $site['root'] . 'template/img/emojis/' . $emoji . '.png">';
				}
				echo '</div>';
			}
			?>
		</div>
			
		<div class="chat-input">
			<div style="position: relative;">
				<div class="emojis-smile-icon flex" data-type="show"><i class="fa fa-smile-o" aria-hidden="true"></i></div>
				<div class="emojis-smile-icon flex hidden" data-type="hide"><i class="fa fa-times" aria-hidden="true"></i></div>
			
				<form id="chat-input-form"><input type="text" class="chat-input-field" placeholder="Say something" id="chat_message" maxlength="200" autocomplete="off"></form>
				<div class="chat-input-scroll flex items-center justify-center hidden">Scroll to recent messages</div>
			</div>
		</div>
	</div>
</div>

<div class="pullout pullout-left flex column transition-5" data-pullout="menu">
	<div class="header-menu-center wrapper-page flex column height-full width-full">
		<div class="flex column gap-4 pr-4 pl-4 pb-4" style="overflow: hidden; overflow-y: auto;">
			<div class="flex column gap-4">
				<div class="header-menu-button">
					<a href="<?php echo $site['root'];?>roulette">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'roulette') echo 'active';?>">
							<img src="<?php echo $site['root'];?>template/img/menu/roulette.png?v=<?php echo time(); ?>">
							<div class="ml-1">Roulette</div>
						</div>
					</a>
				</div>
				<div class="header-menu-button">
					<a href="<?php echo $site['root'];?>crash">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'crash') echo 'active';?>">
							<img src="<?php echo $site['root'];?>template/img/menu/crash.png?v=<?php echo time(); ?>">
							<div class="ml-1">Crash</div>
						</div>
					</a>
				</div>
				<div class="header-menu-button">
					<a href="<?php echo $site['root'];?>jackpot">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'jackpot') echo 'active';?>">
							<img src="<?php echo $site['root'];?>template/img/menu/jackpot.png?v=<?php echo time(); ?>">
							<div class="ml-1">Jackpot</div>
						</div>
					</a>
				</div>
				<div class="header-menu-button">
					<a href="<?php echo $site['root'];?>coinflip">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'coinflip') echo 'active';?>">
							<img src="<?php echo $site['root'];?>template/img/menu/coinflip.png?v=<?php echo time(); ?>">
							<div class="ml-1">Coinflip</div>
						</div>
					</a>
				</div>
				<div class="header-menu-button">
					<a href="<?php echo $site['root'];?>dice">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'dice') echo 'active';?>">
							<img src="<?php echo $site['root'];?>template/img/menu/dice.png?v=<?php echo time(); ?>">
							<div class="ml-1">Dice</div>
						</div>
					</a>
				</div>
				<div class="header-menu-button">
					<a href="<?php echo $site['root'];?>unboxing">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'unboxing') echo 'active';?>">
							<img src="<?php echo $site['root'];?>template/img/menu/unboxing.png?v=<?php echo time(); ?>">
							<div class="ml-1">Unboxing</div>
						</div>
					</a>
				</div>
				<div class="header-menu-button">
					<a href="<?php echo $site['root'];?>casebattle">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'casebattle') echo 'active';?>">
							<img src="<?php echo $site['root'];?>template/img/menu/casebattle.png?v=<?php echo time(); ?>">
							<div class="ml-1">Case Battle</div>
						</div>
					</a>
				</div>
				<div class="header-menu-button">
					<a href="<?php echo $site['root'];?>upgrader">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'upgrader') echo 'active';?>">
							<img src="<?php echo $site['root'];?>template/img/menu/upgrader.png?v=<?php echo time(); ?>">
							<div class="ml-1">Upgrader</div>
						</div>
					</a>
				</div>
				<div class="header-menu-button">
					<a href="<?php echo $site['root'];?>minesweeper">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'minesweeper') echo 'active';?>">
							<img src="<?php echo $site['root'];?>template/img/menu/minesweeper.png?v=<?php echo time(); ?>">
							<div class="ml-1">Minesweeper</div>
						</div>
					</a>
				</div>
				<div class="header-menu-button">
					<a href="<?php echo $site['root'];?>tower">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'tower') echo 'active';?>">
							<img src="<?php echo $site['root'];?>template/img/menu/tower.png?v=<?php echo time(); ?>">
							<div class="ml-1">Tower</div>
						</div>
					</a>
				</div>
				<div class="header-menu-button">
					<a href="<?php echo $site['root'];?>plinko">
						<div class="header-side-button flex items-center <?php if($paths[0] == 'plinko') echo 'active';?>">
							<img src="<?php echo $site['root'];?>template/img/menu/plinko.png?v=<?php echo time(); ?>">
							<div class="ml-1">Plinko</div>
						</div>
					</a>
				</div>
			</div>
			
			<div class="flex column gap-2">
				<div class="header-menu-button"><a href="<?php echo $site['root'];?>deposit" class="<?php if($paths[0] == 'deposit') echo 'active';?>">Deposit</a></div>
				<div class="header-menu-button"><a href="<?php echo $site['root'];?>withdraw" class="<?php if($paths[0] == 'withdraw') echo 'active';?>">Withdraw</a></div>
				<div class="header-menu-button"><a href="<?php echo $site['root'];?>fair" class="<?php if($paths[0] == 'fair') echo 'active';?>">Provably Fair</a></div>
				<div class="header-menu-button"><a href="<?php echo $site['root'];?>faq" class="<?php if($paths[0] == 'faq') echo 'active';?>">FAQ</a></div>
				<div class="header-menu-button"><a href="<?php echo $site['root'];?>tos" class="<?php if($paths[0] == 'tos') echo 'active';?>">Terms Of Service</a></div>
				<div class="header-menu-button"><a href="<?php echo $site['root'];?>support" class="<?php if($paths[0] == 'support') echo 'active';?>">Support</a></div>
				<div class="header-menu-button"><a href="<?php echo $site['root'];?>leaderboard" class="<?php if($paths[0] == 'leaderboard') echo 'active';?>">Leaderboard</a></div>
				<div class="header-menu-button"><a href="<?php echo $site['root'];?>rewards" class="<?php if($paths[0] == 'rewards') echo 'active';?>">Rewards</a></div>
				<div class="header-menu-button"><a href="<?php echo $site['root']; ?>affiliates" class="<?php if($paths[0] == 'rewards') echo 'active'; ?>">Affiliates</a></div>
				<div class="header-menu-button"><a href="<?php echo $site['root'];?>profile" class="text-success <?php if($paths[0] == 'history') echo 'active';?>">Profile</a></div>
				
				<div class="header-menu-button"><div class="text-success pointer" data-modal="show" data-id="#modal_dailycases_cases">Daily Cases</div></div>
				
				<?php if(in_array($user['userid'], $site['access']['admin'])){ ?><div class="header-menu-button"><a href="<?php echo $site['root']; ?>admin" class="text-success <?php if($paths[0] == 'admin') echo 'active'; ?>">Admin</a></div><?php } ?>
				<?php if(in_array($user['userid'], $site['access']['dashboard'])){ ?><div class="header-menu-button"><a href="<?php echo $site['root']; ?>dashboard" class="text-success <?php if($paths[0] == 'dashboard') echo 'active'; ?>">Dashboard</a></div><?php } ?>
				
				<div class="header-menu-button"><div class="text-danger pointer" data-modal="show" data-id="#modal_auth_logout">Logout</div></div>
				
				<div class="flex gap-1 mt-2 font-10">
					<a href="<?php echo $site['link_twitter'];?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a>
					<a href="<?php echo $site['link_steam'];?>" target="_blank"><i class="fa fa-steam" aria-hidden="true"></i></a>
				</div>
			</div>
		</div>
	</div>
</div>