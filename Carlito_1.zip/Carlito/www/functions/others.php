<?php

function createAvatarField($user, $type, $more){
	if($user['level'] >= 100) $level_class = 'tier-diamond';
	else if($user['level'] >= 75) $level_class = 'tier-gold';
	else if($user['level'] >= 50) $level_class = 'tier-silver';
	else if($user['level'] >= 25) $level_class = 'tier-bronze';
	else if($user['level'] >= 0) $level_class = 'tier-steel';
	
	$DIV = '<div class="avatar-field ' . $level_class . ' relative">';
		$DIV .= '<img class="avatar icon-' . $type . ' rounded-full" src="' . $user['avatar'] . '">';
		$DIV .= '<div class="level sup-' . $type . '-left flex justify-center items-center b-d2 bg-dark rounded-full">' . $user['level'] . '</div>';
		$DIV .= $more;
	$DIV .= '</div>';
	
	return $DIV;
}

function roundedToFixed($number, $decimals) {
	if(!is_numeric($number)) return 0;
	
	$number = round($number, 5);
	
	$number_string = strval($number);
	$decimals_string = 0;
	
	if(isset(explode('.', $number_string)[1])) $decimals_string = strlen(explode('.', $number_string)[1]);
	
	while($decimals_string - $decimals > 0) {
		$number_string = substr($number_string, 0, -1);
		
		$decimals_string--;
	}
	
	return (float)$number_string;
}

function getFormatAmount($amount) {
	return roundedToFixed((float)$amount, 2);
}

function getFormatAmountString($amount) {
	return number_format(getFormatAmount($amount), 2, '.', ''); 
}

function makeDate($date){
	$months = array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
	
	$type_time = (date('G', $date) < 12) ? 'AM' : 'PM';
	
	return substr('0' . date('d', $date), -2) . ' ' . $months[(int)date('m', $date) - 1] . ' ' . date('Y', $date) . ', ' . substr('0' . (date('g', $date) % 12), -2) . ':' . substr('0' . date('i', $date), -2) . ' ' . $type_time;
}

function calculateLevel($xp){
	global $level_start, $level_next;
	
	$start = 0;
	$next = $level_start;
	
	$level = 0;
	
	for($i = 1; $next <= $xp && $level < 100; $i++){
		$start = $next;
		$next += intval($next * $level_next * (1.00 - 0.0095 * $level));
		
		$level++;
	}
	
	return array(
		'level' => $level,
		'start' => 0,
		'next' => $next - $start,
		'have' => (($xp > $next) ? $next : $xp) - $start
	);
}

function generateHexCode($length) {
    $text = '';
    $possible = 'abcdef0123456789';

    for($i = 0; $i < $length; $i++) $text .= $possible[rand(0, strlen($possible) - 1)];

    return $text;
}

function getUserIp(){
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    if(filter_var($client, FILTER_VALIDATE_IP)){
        $ip = $client;
    } elseif(filter_var($forward, FILTER_VALIDATE_IP)) {
        $ip = $forward;
    } else {
        $ip = $remote;
    }
	
    return $ip;
}

function getUserAgent(){
    $device  = $_SERVER['HTTP_USER_AGENT'];
	
    return $device;
}

function getUserDevice($user_agent){
    $browser = array('name' => '', 'version' => '');
	$platform = 'Unknown';
	$os = array('name' => '', 'version' => '');
	$device = 'Unknown';
	
	// Is Mobile
	$mobile = preg_match('/Mobile/i', $user_agent);
	
	// Browser
    if(preg_match('/MSIE/i', $user_agent) && !preg_match('/Opera/i', $user_agent)) {
        $browser['name'] = 'Internet Explorer';
		
        if(preg_match('/MSIE (\d+(\.\d+)?)/i', $user_agent, $matches)) $browser['version'] = trim($matches[1]);
    } else if(preg_match('/Firefox/i', $user_agent)) {
        $browser['name'] = 'Mozilla Firefox';
		
        if(preg_match('/Firefox\/(\d+(\.\d+)?)/i', $user_agent, $matches)) $browser['version'] = trim($matches[1]);
    } else if(preg_match('/Chrome/i', $user_agent)) {
		if(strpos($user_agent, 'Brave') !== false) $browser['name'] = 'Brave Browser';
		else if(strpos($user_agent, 'HuaweiBrowser') !== false) $browser['name'] = 'Huawei Browser';
		else if(strpos($user_agent, 'Edg') !== false) $browser['name'] = 'Microsoft Edge';
		else if(strpos($user_agent, 'YaBrowser') !== false) $browser['name'] = 'Yandex Browser';
		else if(strpos($user_agent, 'UCBrowser') !== false) $browser['name'] = 'UC Browser';
		else if(strpos($user_agent, 'SamsungBrowser') !== false) $browser['name'] = 'Samsung Browser';
		else if(strpos($user_agent, 'OPR') !== false || strpos($user_agent, 'Opera') !== false) $browser['name'] = 'Opera';
		else $browser['name'] = 'Google Chrome';
		
        if(preg_match('/Chrome\/(\d+(\.\d+)?)/i', $user_agent, $matches)) $browser['version'] = trim($matches[1]);
    } else if(preg_match('/Safari/i', $user_agent)) {
        $browser['name'] = 'Apple Safari';
		
        if(preg_match('/Version\/(\d+(\.\d+)?)/i', $user_agent, $matches)) $browser['version'] = trim($matches[1]);
    } else if(preg_match('/Opera/i', $user_agent)) {
        $browser['name'] = 'Opera';
		
        if(preg_match('/Opera\/(\d+(\.\d+)?)/i', $user_agent, $matches)) $browser['version'] = trim($matches[1]);
    }
	
	// Platform & OS
	if(preg_match('/Windows/i', $user_agent)) {
        $platform = 'Windows';
		$os['name'] = 'Windows';
		
		if(preg_match('/Phone (OS )?([\d\.]+)(;\s+([^\)]+)\))?/i', $user_agent, $matches)) {
			$os['name'] = 'Windows Phone';
			
			if(isset($matches[2])) $os['version'] = trim($matches[2]);
			if(isset($matches[4])){ $device_parts = explode(';', $matches[4]); if(isset($device_parts[0])) $device = trim($device_parts[0]); }
		} else if(preg_match('/NT ([\d\.]+)(;\s+([^\)]+)\))?/i', $user_agent, $matches)) {
			$array_versions = array(
				'10.0' => '10',
				'6.3' => '8.1',
				'6.2' => '8',
				'6.1' => '7',
				'6.0' => 'Vista',
				'5.1' => 'XP',
				'5.0' => '2000'
			);
			
			if(isset($matches[1])) if(in_array(trim($matches[1]), $array_versions)) $os['version'] = $array_versions[trim($matches[1])];
			if(isset($matches[3])){ $device_parts = explode(';', $matches[3]); if(isset($device_parts[0])) $device = trim($device_parts[0]); }
		}
    } else if (preg_match('/iPhone/i', $user_agent)) {
        $platform = 'iOS';
        $os['name'] = 'iPhone';
		
        if(preg_match('/iPhone OS ([\d\.]+)(;\s+([^\)]+)\))?/i', $user_agent, $matches)){
			if(isset($matches[1])) $os['version'] = trim($matches[1]);
			if(isset($matches[3])){ $device_parts = explode(';', $matches[3]); if(isset($device_parts[0])) $device = trim($device_parts[0]); }
		}
    } else if(preg_match('/iPad/i', $user_agent)) {
        $platform = 'iOS';
        $os['name'] = 'iPad';
		
        if(preg_match('/CPU OS ([\d\.]+)(;\s+([^\)]+)\))?/i', $user_agent, $matches)){
			if(isset($matches[1])) $os['version'] = trim($matches[1]);
			if(isset($matches[3])){ $device_parts = explode(';', $matches[3]); if(isset($device_parts[0])) $device = trim($device_parts[0]); }
		}
    } else if(preg_match('/Macintosh/i', $user_agent)) {
        $platform = 'Mac OS X';
        $os['name'] = 'Macintosh';
		
        if(preg_match('/Mac OS X ([\d\.]+)(;\s+([^\)]+)\))?/i', $user_agent, $matches)){
			if(isset($matches[1])) $os['version'] = trim($matches[1]);
			if(isset($matches[3])){ $device_parts = explode(';', $matches[3]); if(isset($device_parts[0])) $device = trim($device_parts[0]); }
		}
    } else if(preg_match('/Android/i', $user_agent)) {
        $platform = 'Android';
		
        if(preg_match('/Mobile/i', $user_agent)) $os['name'] = 'Android Phone';
        else $os['name'] = 'Android Tablet';
		
        if(preg_match('/Android ([\d\.]+)(;\s+([^\)]+)\))?/i', $user_agent, $matches)) {
			if(isset($matches[1])) $os['version'] = trim($matches[1]);
			if(isset($matches[3])){ $device_parts = explode(';', $matches[3]); if(isset($device_parts[0])) $device = trim($device_parts[0]); }
		}
    } else if(preg_match('/Linux/i', $user_agent)) {
        $platform = 'Linux';
        
		if(preg_match('/Ubuntu/i', $user_agent)) {
            $os['name'] = 'Ubuntu';
			
			if(preg_match('/Ubuntu\/([\d\.]+)(;\s+([^\)]+)\))?/i', $user_agent, $matches)){
				if(isset($matches[1])) $os['version'] = trim($matches[1]);
				if(isset($matches[3])){ $device_parts = explode(';', $matches[3]); if(isset($device_parts[0])) $device = trim($device_parts[0]); }
			}
        }
    }
	
	return array(
        'browser' => $browser,
        'platform' => $platform,
        'os' => $os,
        'device' => $device,
        'mobile' => $mobile
    );
}

/*function getUserFootprint($user_agent){
	$device = getUserDevice($user_agent);
	
	$footprint = ($device['mobile'] ? 'mobile' : 'computer') . '/' . $device['browser']['name'] . '_' . $device['browser']['version'] . '/' . $device['os']['name'] . '_' . $device['os']['version'] . '/' . $device['device'];
	$footprint = strtolower(str_replace(' ', '_', $footprint));
	
	return hash('sha256', $footprint);
}*/

function getUserLocation($ip){
    $json = file_get_contents('http://ipinfo.io/' . $ip . '/geo');
	$json = json_decode($json, true);
	$country = $json['country'];
	$region = $json['region'];
	$city = $json['city'];
	
    return $city . ', ' . $region . ', ' . $country;
}

function getSiteUrl(){
	return (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . '/';
}

function getSiteLink(){
	return (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
}

?>