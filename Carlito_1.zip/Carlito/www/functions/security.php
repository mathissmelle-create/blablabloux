<?php

function security_resendCode($data, $callback){
	$sql1 = $GLOBALS['db']->query('SELECT users.*, users_sessions.session, users_sessions.activated FROM `users` INNER JOIN `users_sessions` ON users.userid = users_sessions.userid WHERE users_sessions.session = ' . $GLOBALS['db']->quote($data['session']) . ' AND users_sessions.removed = 0 AND users_sessions.expire > ' . $GLOBALS['db']->quote(time()));
	if($sql1->rowCount() <= 0) return $callback('User resend security code unsuccessfully (1)'); //ERROR
	
	$row1 = $sql1->fetch(PDO::FETCH_ASSOC);
	
	if(!intval($row1['initialized'])) return $callback('Your account is not initialized'); //ERROR
	if(!intval($row1['verified'])) return $callback('Your account is not verified'); //ERROR
	
	$sql2 = $GLOBALS['db']->query('SELECT * FROM `users_twofa` WHERE `userid` = ' . $GLOBALS['db']->quote($row1['userid']) . ' AND `removed` = 0 AND `activated` = 1');
	if($sql2->rowCount() > 0) return $callback('You have already enabled 2FA authentication'); //ERROR
	
	$sql3 = $GLOBALS['db']->query('SELECT * FROM `security_codes` WHERE `type` = ' . $GLOBALS['db']->quote($data['type']) . ' AND `userid` = ' . $GLOBALS['db']->quote($row1['userid']) . ' AND `used` = 0 AND `removed` = 0 AND (`expire` > ' . $GLOBALS['db']->quote(time()) . ' OR `expire` = -1)');
	if($sql3->rowCount() > 0) return $callback('Please wait until you can resend a new security code'); //ERROR
	
	$security_code = generateHexCode(6);
	
	$sql4 = $GLOBALS['db']->prepare('INSERT INTO `security_codes` SET `type` = ' . $GLOBALS['db']->quote($data['type']) . ', `userid` = ' . $GLOBALS['db']->quote($row1['userid']) . ', `code` = ' . $GLOBALS['db']->quote($security_code) . ', `expire` = ' . $GLOBALS['db']->quote(time() + $GLOBALS['cooldown_security_login']) . ', `created` = ' . $GLOBALS['db']->quote(time()));
	$row4 = $sql4->execute();
	
	if(!$row4) return $callback('User resend security code unsuccessfully (2)'); //ERROR
	if($sql4->rowCount() <= 0) return $callback('User resend security code unsuccessfully (3)'); //ERROR
	
	$mail_subject = 'Security Code';
	$mail_message = 'Security Code: ' . $security_code;
	
	mailer_sendMail($row1['email'], $mail_subject, $mail_message, function($err1) use ($callback, $row1, $mail_subject, $mail_message){
		if($err1) return $callback('User resend security code unsuccessfully (4)'); //ERROR
		
		$sql5 = $GLOBALS['db']->prepare('INSERT INTO `mailer_sent` SET `userid` = ' . $GLOBALS['db']->quote($row1['userid']) . ', `email` = ' . $GLOBALS['db']->quote($row1['email']) . ', `subject` = ' . $GLOBALS['db']->quote($mail_subject) . ', `message` = ' . $GLOBALS['db']->quote($mail_message) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row5 = $sql5->execute();
		
		if(!$row5) return $callback('User resend security code unsuccessfully (5)'); //ERROR
		if($sql5->rowCount() <= 0) return $callback('User resend security code unsuccessfully (6)'); //ERROR
		
		return $callback(null);
	});
}

function security_generateTwofa($data, $callback){
	if(!intval($data['user']['initialized'])) return $callback('Your account is not initialized'); //ERROR
	if(!intval($data['user']['verified'])) return $callback('Your account is not verified'); //ERROR
	
	$sql1 = $GLOBALS['db']->query('SELECT * FROM `users_twofa` WHERE `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ' AND `removed` = 0 AND `activated` = 1');
	if($sql1->rowCount() > 0) return $callback('You have already enabled 2FA authentication'); //ERROR
	
	$sql2 = $GLOBALS['db']->query('SELECT * FROM `security_codes` WHERE `type` = ' . $GLOBALS['db']->quote($data['type']) . ' AND `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ' AND `used` = 0 AND `removed` = 0 AND (`expire` > ' . $GLOBALS['db']->quote(time()) . ' OR `expire` = -1)');
	if($sql2->rowCount() > 0) return $callback(null);
	
	$security_code = generateHexCode(6);
	
	$sql3 = $GLOBALS['db']->prepare('INSERT INTO `security_codes` SET `type` = ' . $GLOBALS['db']->quote($data['type']) . ', `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ', `code` = ' . $GLOBALS['db']->quote($security_code) . ', `expire` = ' . $GLOBALS['db']->quote(time() + $GLOBALS['cooldown_security_twofa']) . ', `created` = ' . $GLOBALS['db']->quote(time()));
	$row3 = $sql3->execute();
	
	if(!$row3) return $callback('User generate 2FA security unsuccessfully (1)'); //ERROR
	if($sql3->rowCount() <= 0) return $callback('User generate 2FA security unsuccessfully (2)'); //ERROR
	
	$mail_subject = 'Security Code';
	$mail_message = 'Security Code: ' . $security_code;
	
	mailer_sendMail($data['user']['email'], $mail_subject, $mail_message, function($err1) use ($callback, $data, $mail_subject, $mail_message){
		if($err1) return $callback('User generate 2FA security unsuccessfully (3)'); //ERROR
		
		$sql4 = $GLOBALS['db']->prepare('INSERT INTO `mailer_sent` SET `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ', `email` = ' . $GLOBALS['db']->quote($data['user']['email']) . ', `subject` = ' . $GLOBALS['db']->quote($mail_subject) . ', `message` = ' . $GLOBALS['db']->quote($mail_message) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row4 = $sql4->execute();
		
		if(!$row4) return $callback('User generate 2FA security unsuccessfully (4)'); //ERROR
		if($sql4->rowCount() <= 0) return $callback('User generate 2FA security unsuccessfully (5)'); //ERROR
		
		return $callback(null);
	});
}

function security_enableTwofa($data, $callback){
	if(!intval($data['user']['initialized'])) return $callback('Your account is not initialized'); //ERROR
	if(!intval($data['user']['verified'])) return $callback('Your account is not verified'); //ERROR
	
	$sql1 = $GLOBALS['db']->query('SELECT * FROM `users_twofa` WHERE `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ' AND `removed` = 0 AND `activated` = 1');
	if($sql1->rowCount() > 0) return $callback('You have already enabled 2FA authentication', null); //ERROR
	
	$sql2 = $GLOBALS['db']->query('SELECT * FROM `security_codes` WHERE `type` = ' . $GLOBALS['db']->quote("enable_twofa") . ' AND `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ' AND `code` = ' . $GLOBALS['db']->quote($data['code']) . ' AND `used` = 0 AND `removed` = 0 AND (`expire` > ' . $GLOBALS['db']->quote(time()) . ' OR `expire` = -1)');
	if($sql2->rowCount() <= 0) return $callback('Please enter a valid security code', null); //ERROR
	
	$sql3 = $GLOBALS['db']->prepare('UPDATE `security_codes` SET `used` = 1 WHERE `type` = ' . $GLOBALS['db']->quote("enable_twofa") . ' AND `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ' AND `code` = ' . $GLOBALS['db']->quote($data['code']) . ' AND `used` = 0 AND `removed` = 0 AND (`expire` > ' . $GLOBALS['db']->quote(time()) . ' OR `expire` = -1)');
	$row3 = $sql3->execute();
	
	if(!$row3) return $callback('User enable 2FA security unsuccessfully (1)', null); //ERROR
	if($sql3->rowCount() <= 0) return $callback('User enable 2FA security unsuccessfully (2)', null); //ERROR
	
	$sql4 = $GLOBALS['db']->prepare('UPDATE `security_codes` SET `removed` = 1 WHERE `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ' AND `used` = 0 AND `removed` = 0 AND (`expire` > ' . $GLOBALS['db']->quote(time()) . ' OR `expire` = -1)');
	$row4 = $sql4->execute();
	
	if(!$row4) return $callback('User enable 2FA security unsuccessfully (3)', null); //ERROR
	
	$sql5 = $GLOBALS['db']->prepare('UPDATE `users_twofa` SET `removed` = 1 WHERE `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ' AND `removed` = 0 AND `activated` = 0');
	$row5 = $sql5->execute();
	
	if(!$row5) return $callback('User enable 2FA security unsuccessfully (4)', null); //ERROR
	
	$secret = generate2FACode(16);
	$recover_code = generateHexCode(24);
	
	$sql6 = $GLOBALS['db']->prepare('INSERT INTO `users_twofa` SET `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ', `secret` = ' . $GLOBALS['db']->quote($secret) . ', `recover` = ' . $GLOBALS['db']->quote($recover_code) . ', `time` = ' . $GLOBALS['db']->quote(time()));
	$row6 = $sql6->execute();
	
	if(!$row6) return $callback('User enable 2FA security unsuccessfully (5)', null); //ERROR
	if($sql6->rowCount() <= 0) return $callback('User enable 2FA security unsuccessfully (6)', null); //ERROR
	
	return $callback(null, array( 'userid' => $data['user']['userid'], 'secret' => $secret, 'recover' => $recover_code, 'issuer' => $GLOBALS['siteabbreviation']));
}

function security_activateTwofa($data, $callback){
	if(!intval($data['user']['initialized'])) return $callback('Your account is not initialized'); //ERROR
	if(!intval($data['user']['verified'])) return $callback('Your account is not verified'); //ERROR
	
	include 'vendors/google_twofa/twofa.php';
	$twofa = new GoogleAuthenticator();
	
	$sql1 = $GLOBALS['db']->query('SELECT * FROM `users_twofa` WHERE `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ' AND `removed` = 0 AND `activated` = 0');
	$row1 = $sql1->fetch(PDO::FETCH_ASSOC);
	
	if($sql1->rowCount() <= 0) return $callback('You have no activation 2FA authentication request'); //ERROR
	if($sql1->rowCount() > 0) if(intval($row1['activated'])) return $callback('You have already activated 2FA authentication'); //ERROR
	
	if(!$twofa->verifyCode($row1['secret'], $data['security'])) return $callback('Please enter a valid security code'); //ERROR
	
	$sql2 = $GLOBALS['db']->prepare('UPDATE `users_twofa` SET `activated` = 1 WHERE `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ' AND `removed` = 0 AND `activated` = 0');
	$row2 = $sql2->execute();
	
	if(!$row2) return $callback('User activate 2FA security unsuccessfully (1)'); //ERROR
	if($sql2->rowCount() <= 0) return $callback('User activate 2FA security unsuccessfully (2)'); //ERROR
	
	return $callback(null);
}

function security_disableTwofa($data, $callback){
	include 'vendors/google_twofa/twofa.php';
	$twofa = new GoogleAuthenticator();
	
	$sql1 = $GLOBALS['db']->query('SELECT * FROM `users_twofa` WHERE `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ' AND `removed` = 0 AND `activated` = 1');
	if($sql1->rowCount() <= 0) return $callback('You have no enabled 2FA authentication'); //ERROR
	
	$row1 = $sql1->fetch(PDO::FETCH_ASSOC);
	
	if(!$twofa->verifyCode($row1['secret'], $data['security'])) return $callback('Please enter a valid security code'); //ERROR
	
	$sql2 = $GLOBALS['db']->prepare('UPDATE `users_twofa` SET `removed` = 1 WHERE `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ' AND `removed` = 0 AND `activated` = 1');
	$row2 = $sql2->execute();
	
	if(!$row2) return $callback('User disable 2FA security unsuccessfully (1)'); //ERROR
	if($sql2->rowCount() <= 0) return $callback('User disable 2FA security unsuccessfully (2)'); //ERROR
	
	return $callback(null);
}

function security_recoverTwofa($data, $callback){
	$sql1 = $GLOBALS['db']->query('SELECT * FROM `users_twofa` WHERE `recover` = ' . $GLOBALS['db']->quote($data['recover']) . ' AND `removed` = 0 AND `activated` = 1');
	if($sql1->rowCount() <= 0) return $callback('Unable to recover your 2FA authentication'); //ERROR
	
	$row1 = $sql1->fetch(PDO::FETCH_ASSOC);
	
	$sql2 = $GLOBALS['db']->prepare('UPDATE `users_twofa` SET `removed` = 1 WHERE `userid` = ' . $GLOBALS['db']->quote($row1['userid']) . ' AND `removed` = 0 AND `activated` = 1');
	$row2 = $sql2->execute();
	
	if(!$row2) return $callback('User recover 2FA security unsuccessfully (1)'); //ERROR
	if($sql2->rowCount() <= 0) return $callback('User recover 2FA security unsuccessfully (2)'); //ERROR
	
	return $callback(null);
}

function security_submitCodeLogin($data, $callback){
	$sql1 = $GLOBALS['db']->query('SELECT users.*, users_sessions.session, users_sessions.activated FROM `users` INNER JOIN `users_sessions` ON users.userid = users_sessions.userid WHERE users_sessions.session = ' . $GLOBALS['db']->quote($data['session']) . ' AND users_sessions.removed = 0 AND users_sessions.expire > ' . $GLOBALS['db']->quote(time()));
	if($sql1->rowCount() <= 0) return $callback('User activate session unsuccessfully (1)'); //ERROR
	
	$row1 = $sql1->fetch(PDO::FETCH_ASSOC);
	
	if(intval($row1['activated']) == 1) return $callback('User session already activated'); //ERROR
	
	if(!intval($row1['initialized'])) return $callback('Your account is not initialized'); //ERROR
	if(!intval($row1['verified'])) return $callback('Your account is not verified'); //ERROR
	
	$userid = $row1['userid'];
	
	$sql2 = $GLOBALS['db']->query('SELECT * FROM `users` WHERE `userid` = ' . $GLOBALS['db']->quote($userid) . ' AND `initialized` = 1 AND `verified` = 1');
	if($sql2->rowCount() <= 0) return $callback('User activate session unsuccessfully (2)'); //ERROR
	
	$sql3 = $GLOBALS['db']->query('SELECT * FROM `users_twofa` WHERE `userid` = ' . $GLOBALS['db']->quote($userid) . ' AND `removed` = 0 AND `activated` = 1');
	if($sql3->rowCount() > 0) return $callback('User activate session unsuccessfully (3)'); //ERROR
	
	$sql4 = $GLOBALS['db']->query('SELECT * FROM `security_codes` WHERE `type` = ' . $GLOBALS['db']->quote("login") . ' AND `userid` = ' . $GLOBALS['db']->quote($userid) . ' AND `code` = ' . $GLOBALS['db']->quote($data['code']) . ' AND `used` = 0 AND `removed` = 0 AND (`expire` > ' . $GLOBALS['db']->quote(time()) . ' OR `expire` = -1)');
	if($sql4->rowCount() <= 0) return $callback('Please enter a valid security code'); //ERROR
	
	$sql5 = $GLOBALS['db']->prepare('UPDATE `security_codes` SET `used` = 1 WHERE `type` = ' . $GLOBALS['db']->quote("login") . ' AND `userid` = ' . $GLOBALS['db']->quote($userid) . ' AND `code` = ' . $GLOBALS['db']->quote($data['code']) . ' AND `used` = 0 AND `removed` = 0 AND (`expire` > ' . $GLOBALS['db']->quote(time()) . ' OR `expire` = -1)');
	$row5 = $sql5->execute();
	
	if(!$row5) return $callback('User activate session unsuccessfully (4)'); //ERROR
	if($sql5->rowCount() <= 0) return $callback('User activate session unsuccessfully (5)'); //ERROR
	
	$sql6 = $GLOBALS['db']->prepare('UPDATE `security_codes` SET `removed` = 1 WHERE `userid` = ' . $GLOBALS['db']->quote($userid) . ' AND `used` = 0 AND `removed` = 0 AND (`expire` > ' . $GLOBALS['db']->quote(time()) . ' OR `expire` = -1)');
	$row6 = $sql6->execute();
	
	if(!$row6) return $callback('User activate session unsuccessfully (6)'); //ERROR
	
	$sql7 = $GLOBALS['db']->prepare('UPDATE `users_sessions` SET `activated` = 1 WHERE `session` = ' . $GLOBALS['db']->quote($data['session']) . ' AND `removed` = 0 AND `activated` = 0 AND `expire` > ' . $GLOBALS['db']->quote(time()));
	$row7 = $sql7->execute();
	
	if(!$row7) return $callback('User activate session unsuccessfully (7)'); //ERROR
	if($sql7->rowCount() <= 0) return $callback('User activate session unsuccessfully (8)'); //ERROR
	
	return $callback(null);
}

function security_submitSecurityLogin($data, $callback){
	include 'vendors/google_twofa/twofa.php';
	$twofa = new GoogleAuthenticator();
	
	$sql1 = $GLOBALS['db']->query('SELECT * FROM `users_sessions` WHERE `session` = ' . $GLOBALS['db']->quote($data['session']) . ' AND `removed` = 0 AND `expire` > ' . $GLOBALS['db']->quote(time()));
	if($sql1->rowCount() <= 0) return $callback('Unable to find user session'); //ERROR
	
	$row1 = $sql1->fetch(PDO::FETCH_ASSOC);
	if(intval($row1['activated'])) return $callback('User session already activated'); //ERROR
	
	$userid = $row1['userid'];
	
	$sql2 = $GLOBALS['db']->query('SELECT * FROM `users_twofa` WHERE `userid` = ' . $GLOBALS['db']->quote($userid) . ' AND `removed` = 0 AND `activated` = 1');
	if($sql2->rowCount() <= 0) return $callback('User activate session unsuccessfully (1)'); //ERROR
	
	$row2 = $sql2->fetch(PDO::FETCH_ASSOC);
	
	if(!$twofa->verifyCode($row2['secret'], $data['security'])) return $callback('Please enter a valid security code'); //ERROR
	
	$sql3 = $GLOBALS['db']->prepare('UPDATE `users_sessions` SET `activated` = 1 WHERE `session` = ' . $GLOBALS['db']->quote($data['session']) . ' AND `removed` = 0 AND `activated` = 0 AND `expire` > ' . $GLOBALS['db']->quote(time()));
	$row3 = $sql3->execute();
	
	if(!$row3) return $callback('User activate session unsuccessfully (2)'); //ERROR
	if($sql3->rowCount() <= 0) return $callback('User activate session unsuccessfully (3)'); //ERROR
	
	return $callback(null);
}

function generate2FACode($length) {
    $text = '';
    $possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

    for($i = 0; $i < $length; $i++) $text .= $possible[rand(0, strlen($possible) - 1)];

    return $text;
}

?>