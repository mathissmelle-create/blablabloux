<?php

$user = null;
$security = array( 'email' => false, 'twofa' => false );

if (isset($_COOKIE['session'])) {
	$sql1 = $db->query('SELECT users.*, users_sessions.session, users_sessions.activated FROM `users` INNER JOIN `users_sessions` ON users.userid = users_sessions.userid WHERE users_sessions.session = ' . $db->quote($_COOKIE['session']) . ' AND users_sessions.removed = 0 AND users_sessions.expire > ' . $db->quote(time()));
	if ($sql1->rowCount() != 0) {
		$row1 = $sql1->fetch(PDO::FETCH_ASSOC);
		
		if($_COOKIE['session'] == $row1['session']) {
			if(intval($row1['activated']) == 1) $user = $row1;
			
			$sql2 = $GLOBALS['db']->query('SELECT * FROM `users` WHERE `userid` = ' . $GLOBALS['db']->quote($row1['userid']) . ' AND `initialized` = 1 AND `verified` = 1');
			if($sql2->rowCount() > 0) $security['email'] = true;
			
			$sql3 = $GLOBALS['db']->query('SELECT * FROM `users_twofa` WHERE `userid` = ' . $GLOBALS['db']->quote($row1['userid']) . ' AND `removed` = 0 AND `activated` = 1');
			if($sql3->rowCount() > 0) $security['twofa'] = true;
		}
	}
}

?>