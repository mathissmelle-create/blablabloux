<?php

function auth_authByLogin($data, $callback){
	$crypted_password = hash('sha256', $data['password']);
	
	$sql1 = $GLOBALS['db']->query('SELECT * FROM `users` WHERE (`email` = ' . $GLOBALS['db']->quote($data['username']) . ' OR `username` = ' . $GLOBALS['db']->quote($data['username']) . ') AND `password` = ' . $GLOBALS['db']->quote($crypted_password));
	if($sql1->rowCount() <= 0) return $callback('Invalid username/email or password', null); //ERROR
	
	$row1 = $sql1->fetch(PDO::FETCH_ASSOC);
	
	return auth_checkSession(array('userid' => $row1['userid'], 'type' => 'auth_login'), $callback);
}

function auth_authByRegister($data, $callback){
	$pattern_email = '/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*\.\w+$/';
	$pattern_username = '/^[a-z0-9_]{6,}$/';
	$pattern_password = '/^((?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*\W).{8,})$/';
	
	if(!preg_match($pattern_email, $data['email'])) return $callback('Invalid e-mail. Invalid format e-mail', null); //ERROR
	if(!preg_match($pattern_username, $data['username'])) return $callback('Invalid username. At least 6 characters, only lowercase, numbers and underscore are allowed', null); //ERROR
	if(!preg_match($pattern_password, $data['password'])) return $callback('Invalid password. At least 8 characters, one uppercase, one lowercase, one number and one symbol', null); //ERROR
	
	$sql1 = $GLOBALS['db']->query('SELECT * FROM `users` WHERE `email` = ' . $GLOBALS['db']->quote($data['email']));
	if($sql1->rowCount() > 0) return $callback('E-mail already taken', null); //ERROR
	
	$sql2 = $GLOBALS['db']->query('SELECT * FROM `users` WHERE `username` = ' . $GLOBALS['db']->quote($data['username']));
	if($sql2->rowCount() > 0) return $callback('Username already taken', null); //ERROR
	
	$userid = generateHexCode(24);
	$crypted_password = hash('sha256', $data['password']);
	
	$name = $data['username'];
	$avatar = $GLOBALS['siteurl'] . $GLOBALS['root'] . 'template/img/avatar.jpg';
	
	$sql3 = $GLOBALS['db']->prepare('INSERT INTO `users` SET `initialized` = 1, `userid` = ' . $GLOBALS['db']->quote($userid) . ', `username` = ' . $GLOBALS['db']->quote($data['username']) . ', `email` = ' . $GLOBALS['db']->quote($data['email']) . ', `password` = ' . $GLOBALS['db']->quote($crypted_password) . ', `name` = ' . $GLOBALS['db']->quote($name) . ', `avatar` = ' . $GLOBALS['db']->quote($avatar) . ', `time_create` = ' . $GLOBALS['db']->quote(time()));
	$row3 = $sql3->execute();
	
	if(!$row3) return $callback('User registered with Auth unsuccessfully (1)', null); //ERROR
	if($sql3->rowCount() <= 0) return $callback('User registered with Auth unsuccessfully (2)', null); //ERROR
	
	$sql4 = $GLOBALS['db']->prepare('INSERT INTO `users_logins` SET `type` = ' . $GLOBALS['db']->quote('auth_register') . ', `userid` = ' . $GLOBALS['db']->quote($userid) . ', `ip` = ' . $GLOBALS['db']->quote(getUserIp()) . ', `agent` = ' . $GLOBALS['db']->quote(getUserAgent()) . ', `location` = ' . $GLOBALS['db']->quote(getUserLocation(getUserIp())) . ', `time` = ' . $GLOBALS['db']->quote(time()));
	$row4 = $sql4->execute();
	
	if(!$row4) return $callback('User registered with Auth unsuccessfully (3)', null); //ERROR
	if($sql4->rowCount() <= 0) return $callback('User registered with Auth unsuccessfully (4)', null); //ERROR
	
	/**/
	
	$sql5 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `change` = ' . $GLOBALS['db']->quote('email') . ', `value` = ' . $GLOBALS['db']->quote($data['email']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
	$row5 = $sql5->execute();
	
	if(!$row5) return $callback('User registered with Auth unsuccessfully (5)', null); //ERROR
	if($sql5->rowCount() <= 0) return $callback('User registered with Auth unsuccessfully (6)', null); //ERROR
	
	$sql6 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `change` = ' . $GLOBALS['db']->quote('username') . ', `value` = ' . $GLOBALS['db']->quote($data['username']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
	$row6 = $sql6->execute();
	
	if(!$row6) return $callback('User registered with Auth unsuccessfully (7)', null); //ERROR
	if($sql6->rowCount() <= 0) return $callback('User registered with Auth unsuccessfully (8)', null); //ERROR
	
	$sql7 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `change` = ' . $GLOBALS['db']->quote('password') . ', `value` = ' . $GLOBALS['db']->quote($crypted_password) . ', `time` = ' . $GLOBALS['db']->quote(time()));
	$row7 = $sql7->execute();
	
	if(!$row7) return $callback('User registered with Auth unsuccessfully (9)', null); //ERROR
	if($sql7->rowCount() <= 0) return $callback('User registered with Auth unsuccessfully (10)', null); //ERROR
	
	$sql8 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `change` = ' . $GLOBALS['db']->quote('name') . ', `value` = ' . $GLOBALS['db']->quote($name) . ', `time` = ' . $GLOBALS['db']->quote(time()));
	$row8 = $sql8->execute();
	
	if(!$row8) return $callback('User registered with Auth unsuccessfully (11)', null); //ERROR
	if($sql8->rowCount() <= 0) return $callback('User registered with Auth unsuccessfully (12)', null); //ERROR
	
	$sql9 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `change` = ' . $GLOBALS['db']->quote('avatar') . ', `value` = ' . $GLOBALS['db']->quote($avatar) . ', `time` = ' . $GLOBALS['db']->quote(time()));
	$row9 = $sql9->execute();
	
	if(!$row9) return $callback('User registered with Auth unsuccessfully (13)', null); //ERROR
	if($sql9->rowCount() <= 0) return $callback('User registered with Auth unsuccessfully (14)', null); //ERROR
	
	/**/
	
	$client_seed = generateHexCode(32);
	$server_seed = generateHexCode(64);
	
	$sql10 = $GLOBALS['db']->prepare('INSERT INTO `users_seeds_client` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `seed` = ' . $GLOBALS['db']->quote($client_seed) . ', `time` = ' . $GLOBALS['db']->quote(time()));
	$row10 = $sql10->execute();
	
	if(!$row10) return $callback('User registered with Auth unsuccessfully (15)', null); //ERROR
	if($sql10->rowCount() <= 0) return $callback('User registered with Auth unsuccessfully (16)', null); //ERROR
	
	$sql11 = $GLOBALS['db']->prepare('INSERT INTO `users_seeds_server` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `seed` = ' . $GLOBALS['db']->quote($server_seed) . ', `time` = ' . $GLOBALS['db']->quote(time()));
	$row11 = $sql11->execute();
	
	if(!$row11) return $callback('User registered with Auth unsuccessfully (17)', null); //ERROR
	if($sql11->rowCount() <= 0) return $callback('User registered with Auth unsuccessfully (18)', null); //ERROR
	
	$sql12 = $GLOBALS['db']->prepare('UPDATE `link_keys` SET `removed` = 1 WHERE `type` = ' . $GLOBALS['db']->quote("verify_profile") . ' AND `userid` = ' . $GLOBALS['db']->quote($userid) . ' AND `used` = 0 AND `removed` = 0 AND (`expire` > ' . $GLOBALS['db']->quote(time()) . ' OR `expire` = -1)');
	$row12 = $sql12->execute();
	
	if(!$row12) return $callback('User registered with Auth unsuccessfully (19)'); //ERROR
	
	$verify_key = generateHexCode(32);
	
	$sql13 = $GLOBALS['db']->prepare('INSERT INTO `link_keys` SET `type` = ' . $GLOBALS['db']->quote("verify_profile") . ', `userid` = ' . $GLOBALS['db']->quote($userid) . ', `key` = ' . $GLOBALS['db']->quote($verify_key) . ', `expire` = -1, `created` = ' . $GLOBALS['db']->quote(time()));
	$row13 = $sql13->execute();
	
	if(!$row13) return $callback('User registered with Auth unsuccessfully (20)', null); //ERROR
	if($sql13->rowCount() <= 0) return $callback('User registered with Auth unsuccessfully (21)', null); //ERROR
	
	$mail_subject = 'Verify Profile';
	$mail_message = 'Verify Profile Link: ' . $GLOBALS['siteurl'] . $GLOBALS['root'] . 'auth/verify?key=' . $verify_key;
	
	mailer_sendMail($data['email'], $mail_subject, $mail_message, function($err1) use ($callback, $data, $userid, $mail_subject, $mail_message){
		if($err1) return $callback('User registered with Auth unsuccessfully (22)', null); //ERROR
		
		$sql14 = $GLOBALS['db']->prepare('INSERT INTO `mailer_sent` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `email` = ' . $GLOBALS['db']->quote($data['email']) . ', `subject` = ' . $GLOBALS['db']->quote($mail_subject) . ', `message` = ' . $GLOBALS['db']->quote($mail_message) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row14 = $sql14->execute();
		
		if(!$row14) return $callback('User registered with Auth unsuccessfully (23)', null); //ERROR
		if($sql14->rowCount() <= 0) return $callback('User registered with Auth unsuccessfully (24)', null); //ERROR
		
		return auth_checkSession(array('userid' => $userid, 'type' => 'auth_register'), $callback);
	});
}

function auth_authBySteam($data, $callback){
	$sql1 = $GLOBALS['db']->query('SELECT `userid` FROM `users_binds` WHERE `bind` = ' . $GLOBALS['db']->quote('steam') . ' AND `bindid` = ' . $GLOBALS['db']->quote($data['id']) . ' AND `removed` = 0');
	if($sql1->rowCount() > 0) {
		/* LOGIN */
		
		$row1 = $sql1->fetch(PDO::FETCH_ASSOC);
		
		$sql2 = $GLOBALS['db']->prepare('UPDATE `users` SET `name` = ' . $GLOBALS['db']->quote($data['name']) . ', `avatar` = ' . $GLOBALS['db']->quote($data['avatar']) . ' WHERE `userid` = ' . $GLOBALS['db']->quote($row1['userid']));
		$row2 = $sql2->execute();
		
		$sql3 = $GLOBALS['db']->prepare('INSERT INTO `users_logins` SET `type` = ' . $GLOBALS['db']->quote('steam_login') . ', `userid` = ' . $GLOBALS['db']->quote($row1['userid']) . ', `ip` = ' . $GLOBALS['db']->quote(getUserIp()) . ', `agent` = ' . $GLOBALS['db']->quote(getUserAgent()) . ', `location` = ' . $GLOBALS['db']->quote(getUserLocation(getUserIp())) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row3 = $sql3->execute();
		
		if(!$row3) return $callback('User logged in with Steam unsuccessfully (1)', null); //ERROR
		if($sql3->rowCount() <= 0) return $callback('User logged in with Steam unsuccessfully (2)', null); //ERROR
		
		/**/
		
		$sql4 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($row1['userid']) . ', `change` = ' . $GLOBALS['db']->quote('name') . ', `value` = ' . $GLOBALS['db']->quote($data['name']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row4 = $sql4->execute();
		
		if(!$row4) return $callback('User logged in with Steam unsuccessfully (3)', null); //ERROR
		if($sql4->rowCount() <= 0) return $callback('User logged in with Steam unsuccessfully (4)', null); //ERROR
		
		$sql5 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($row1['userid']) . ', `change` = ' . $GLOBALS['db']->quote('avatar') . ', `value` = ' . $GLOBALS['db']->quote($data['avatar']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row5 = $sql5->execute();
		
		if(!$row5) return $callback('User logged in with Steam unsuccessfully (5)', null); //ERROR
		if($sql5->rowCount() <= 0) return $callback('User logged in with Steam unsuccessfully (6)', null); //ERROR
		
		/**/
		
		return auth_checkSession(array('userid' => $row1['userid'], 'type' => 'steam_login'), $callback);
	} else {
		/* REGISTER */
		
		$userid = generateHexCode(24);
		$username = 'user_' . generateHexCode(8);
		
		$sql2 = $GLOBALS['db']->prepare('INSERT INTO `users` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `username` = ' . $GLOBALS['db']->quote($username) . ', `name` = ' . $GLOBALS['db']->quote($data['name']) . ', `avatar` = ' . $GLOBALS['db']->quote($data['avatar']) . ', `time_create` = ' . $GLOBALS['db']->quote(time()));
		$row2 = $sql2->execute();
		
		if(!$row2) return $callback('User registered with Steam unsuccessfully (1)', null); //ERROR
		if($sql2->rowCount() <= 0) return $callback('User registered with Steam unsuccessfully (2)', null); //ERROR
			
		$sql3 = $GLOBALS['db']->prepare('INSERT INTO `users_binds` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `bind` = ' . $GLOBALS['db']->quote('steam') . ', `bindid` = ' . $GLOBALS['db']->quote($data['id']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row3 = $sql3->execute();
		
		if(!$row3) return $callback('User registered with Steam unsuccessfully (3)', null); //ERROR
		if($sql3->rowCount() <= 0) return $callback('User registered with Steam unsuccessfully (4)', null); //ERROR
		
		$sql4 = $GLOBALS['db']->prepare('INSERT INTO `users_logins` SET `type` = ' . $GLOBALS['db']->quote('steam_register') . ', `userid` = ' . $GLOBALS['db']->quote($userid) . ', `ip` = ' . $GLOBALS['db']->quote(getUserIp()) . ', `agent` = ' . $GLOBALS['db']->quote(getUserAgent()) . ', `location` = ' . $GLOBALS['db']->quote(getUserLocation(getUserIp())) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row4 = $sql4->execute();
		
		if(!$row4) return $callback('User registered with Steam unsuccessfully (5)', null); //ERROR
		if($sql4->rowCount() <= 0) return $callback('User registered with Steam unsuccessfully (6)', null); //ERROR
		
		/**/
		
		$sql5 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `change` = ' . $GLOBALS['db']->quote('username') . ', `value` = ' . $GLOBALS['db']->quote($username) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row5 = $sql5->execute();
		
		if(!$row5) return $callback('User registered with Steam unsuccessfully (7)', null); //ERROR
		if($sql5->rowCount() <= 0) return $callback('User registered with Steam unsuccessfully (8)', null); //ERROR
		
		$sql6 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `change` = ' . $GLOBALS['db']->quote('name') . ', `value` = ' . $GLOBALS['db']->quote($data['name']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row6 = $sql6->execute();
		
		if(!$row6) return $callback('User registered with Steam unsuccessfully (9)', null); //ERROR
		if($sql6->rowCount() <= 0) return $callback('User registered with Steam unsuccessfully (10)', null); //ERROR
		
		$sql7 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `change` = ' . $GLOBALS['db']->quote('avatar') . ', `value` = ' . $GLOBALS['db']->quote($data['avatar']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row7 = $sql7->execute();
		
		if(!$row7) return $callback('User registered with Steam unsuccessfully (11)', null); //ERROR
		if($sql7->rowCount() <= 0) return $callback('User registered with Steam unsuccessfully (12)', null); //ERROR
		
		/**/
		
		$client_seed = generateHexCode(32);
		$server_seed = generateHexCode(64);
		
		$sql8 = $GLOBALS['db']->prepare('INSERT INTO `users_seeds_client` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `seed` = ' . $GLOBALS['db']->quote($client_seed) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row8 = $sql8->execute();
		
		if(!$row8) return $callback('User registered with Steam unsuccessfully (13)', null); //ERROR
		if($sql8->rowCount() <= 0) return $callback('User registered with Steam unsuccessfully (14)', null); //ERROR
		
		$sql9 = $GLOBALS['db']->prepare('INSERT INTO `users_seeds_server` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `seed` = ' . $GLOBALS['db']->quote($server_seed) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row9 = $sql9->execute();
		
		if(!$row9) return $callback('User registered with Steam unsuccessfully (15)', null); //ERROR
		if($sql9->rowCount() <= 0) return $callback('User registered with Steam unsuccessfully (16)', null); //ERROR
		
		return auth_checkSession(array('userid' => $userid, 'type' => 'steam_register'), $callback);
	}
}

function auth_authByGoogle($data, $callback){
	$sql1 = $GLOBALS['db']->query('SELECT `userid` FROM `users_binds` WHERE `bind` = ' . $GLOBALS['db']->quote('google') . ' AND `bindid` = ' . $GLOBALS['db']->quote($data['id']) . ' AND `removed` = 0');
	if($sql1->rowCount() > 0) {
		/* LOGIN */
		
		$row1 = $sql1->fetch(PDO::FETCH_ASSOC);
		
		$sql2 = $GLOBALS['db']->prepare('UPDATE `users` SET `name` = ' . $GLOBALS['db']->quote($data['name']) . ', `avatar` = ' . $GLOBALS['db']->quote($data['avatar']) . ' WHERE `userid` = ' . $GLOBALS['db']->quote($row1['userid']));
		$row2 = $sql2->execute();
		
		$sql3 = $GLOBALS['db']->prepare('INSERT INTO `users_logins` SET `type` = ' . $GLOBALS['db']->quote('google_login') . ', `userid` = ' . $GLOBALS['db']->quote($row1['userid']) . ', `ip` = ' . $GLOBALS['db']->quote(getUserIp()) . ', `agent` = ' . $GLOBALS['db']->quote(getUserAgent()) . ', `location` = ' . $GLOBALS['db']->quote(getUserLocation(getUserIp())) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row3 = $sql3->execute();
		
		if(!$row3) return $callback('User logged in with Google unsuccessfully (1)', null); //ERROR
		if($sql3->rowCount() <= 0) return $callback('User logged in with Google unsuccessfully (2)', null); //ERROR
		
		/**/
		
		$sql4 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($row1['userid']) . ', `change` = ' . $GLOBALS['db']->quote('name') . ', `value` = ' . $GLOBALS['db']->quote($data['name']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row4 = $sql4->execute();
		
		if(!$row4) return $callback('User logged in with Google unsuccessfully (3)', null); //ERROR
		if($sql4->rowCount() <= 0) return $callback('User logged in with Google unsuccessfully (4)', null); //ERROR
		
		$sql5 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($row1['userid']) . ', `change` = ' . $GLOBALS['db']->quote('avatar') . ', `value` = ' . $GLOBALS['db']->quote($data['avatar']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row5 = $sql5->execute();
		
		if(!$row5) return $callback('User logged in with Google unsuccessfully (5)', null); //ERROR
		if($sql5->rowCount() <= 0) return $callback('User logged in with Google unsuccessfully (6)', null); //ERROR
		
		/**/
		
		return auth_checkSession(array('userid' => $row1['userid'], 'type' => 'google_login'), $callback);
	} else {
		$sql2 = $GLOBALS['db']->query('SELECT * FROM `users` WHERE `email` = ' . $GLOBALS['db']->quote($data['email']));
		if($sql2->rowCount() > 0) {
			/* BIND BY EMAIL */
			
			$row2 = $sql2->fetch(PDO::FETCH_ASSOC);
			
			$sql3 = $GLOBALS['db']->query('SELECT * FROM `users_binds` WHERE `userid` = ' . $GLOBALS['db']->quote($row2['userid']) . ' AND `bind` = ' . $GLOBALS['db']->quote("google") . ' AND `removed` = 0');
			if($sql3->rowCount() > 0) return $callback('Account is already binded');
			
			$sql4 = $GLOBALS['db']->prepare('UPDATE `users` SET `name` = ' . $GLOBALS['db']->quote($data['name']) . ', `avatar` = ' . $GLOBALS['db']->quote($data['avatar']) . ' WHERE `userid` = ' . $GLOBALS['db']->quote($row2['userid']));
			$row4 = $sql4->execute();
			
			$sql5 = $GLOBALS['db']->prepare('INSERT INTO `users_binds` SET `userid` = ' . $GLOBALS['db']->quote($row2['userid']) . ', `bind` = ' . $GLOBALS['db']->quote('google') . ', `bindid` = ' . $GLOBALS['db']->quote($data['id']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row5 = $sql5->execute();
			
			if(!$row5) return $callback('User logged in and binded with Google unsuccessfully (1)', null); //ERROR
			if($sql5->rowCount() <= 0) return $callback('User logged in  and binded with Google unsuccessfully (2)', null); //ERROR
			
			$sql6 = $GLOBALS['db']->prepare('INSERT INTO `users_logins` SET `type` = ' . $GLOBALS['db']->quote('google_login_bind') . ', `userid` = ' . $GLOBALS['db']->quote($row2['userid']) . ', `ip` = ' . $GLOBALS['db']->quote(getUserIp()) . ', `agent` = ' . $GLOBALS['db']->quote(getUserAgent()) . ', `location` = ' . $GLOBALS['db']->quote(getUserLocation(getUserIp())) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row6 = $sql6->execute();
			
			if(!$row6) return $callback('User logged in and binded with Google unsuccessfully (3)', null); //ERROR
			if($sql6->rowCount() <= 0) return $callback('User logged in and binded with Google unsuccessfully (4)', null); //ERROR
			
			/**/
			
			$sql7 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($row2['userid']) . ', `change` = ' . $GLOBALS['db']->quote('name') . ', `value` = ' . $GLOBALS['db']->quote($data['name']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row7 = $sql7->execute();
			
			if(!$row7) return $callback('User logged in and binded with Google unsuccessfully (5)', null); //ERROR
			if($sql7->rowCount() <= 0) return $callback('User logged in and binded with Google unsuccessfully (6)', null); //ERROR
			
			$sql8 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($row2['userid']) . ', `change` = ' . $GLOBALS['db']->quote('avatar') . ', `value` = ' . $GLOBALS['db']->quote($data['avatar']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row8 = $sql8->execute();
			
			if(!$row8) return $callback('User logged in and binded with Google unsuccessfully (7)', null); //ERROR
			if($sql8->rowCount() <= 0) return $callback('User logged in and binded with Google unsuccessfully (8)', null); //ERROR
			
			/**/
			
			return auth_checkSession(array('userid' => $row2['userid'], 'type' => 'google_login_bind'), $callback);
		} else {
			/* REGISTER */
			
			$userid = generateHexCode(24);
			$username = 'user_' . generateHexCode(8);
			
			$sql3 = $GLOBALS['db']->prepare('INSERT INTO `users` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `username` = ' . $GLOBALS['db']->quote($username) . ', `email` = ' . $GLOBALS['db']->quote($data['email']) . ', `name` = ' . $GLOBALS['db']->quote($data['name']) . ', `avatar` = ' . $GLOBALS['db']->quote($data['avatar']) . ', `time_create` = ' . $GLOBALS['db']->quote(time()));
			$row3 = $sql3->execute();
			
			if(!$row3) return $callback('User registered with Google unsuccessfully (1)', null); //ERROR
			if($sql3->rowCount() <= 0) return $callback('User registered with Google unsuccessfully (2)', null); //ERROR
			
			$sql4 = $GLOBALS['db']->prepare('INSERT INTO `users_binds` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `bind` = ' . $GLOBALS['db']->quote('google') . ', `bindid` = ' . $GLOBALS['db']->quote($data['id']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row4 = $sql4->execute();
			
			if(!$row4) return $callback('User registered with Google unsuccessfully (3)', null); //ERROR
			if($sql4->rowCount() <= 0) return $callback('User registered with Google unsuccessfully (4)', null); //ERROR
			
			$sql5 = $GLOBALS['db']->prepare('INSERT INTO `users_logins` SET `type` = ' . $GLOBALS['db']->quote('google_register') . ', `userid` = ' . $GLOBALS['db']->quote($userid) . ', `ip` = ' . $GLOBALS['db']->quote(getUserIp()) . ', `agent` = ' . $GLOBALS['db']->quote(getUserAgent()) . ', `location` = ' . $GLOBALS['db']->quote(getUserLocation(getUserIp())) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row5 = $sql5->execute();
			
			if(!$row5) return $callback('User registered with Google unsuccessfully (5)', null); //ERROR
			if($sql5->rowCount() <= 0) return $callback('User registered with Google unsuccessfully (6)', null); //ERROR
			
			/**/
			
			$sql6 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `change` = ' . $GLOBALS['db']->quote('email') . ', `value` = ' . $GLOBALS['db']->quote($data['email']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row6 = $sql6->execute();
			
			if(!$row6) return $callback('User registered with Google unsuccessfully (7)', null); //ERROR
			if($sql6->rowCount() <= 0) return $callback('User registered with Google unsuccessfully (8)', null); //ERROR
		
			$sql7 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `change` = ' . $GLOBALS['db']->quote('username') . ', `value` = ' . $GLOBALS['db']->quote($username) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row7 = $sql7->execute();
			
			if(!$row7) return $callback('User registered with Google unsuccessfully (9)', null); //ERROR
			if($sql7->rowCount() <= 0) return $callback('User registered with Google unsuccessfully (10)', null); //ERROR
			
			$sql8 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `change` = ' . $GLOBALS['db']->quote('name') . ', `value` = ' . $GLOBALS['db']->quote($data['name']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row8 = $sql8->execute();
			
			if(!$row8) return $callback('User registered with Google unsuccessfully (11)', null); //ERROR
			if($sql8->rowCount() <= 0) return $callback('User registered with Google unsuccessfully (12)', null); //ERROR
			
			$sql9 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `change` = ' . $GLOBALS['db']->quote('avatar') . ', `value` = ' . $GLOBALS['db']->quote($data['avatar']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row9 = $sql9->execute();
			
			if(!$row9) return $callback('User registered with Google unsuccessfully (13)', null); //ERROR
			if($sql9->rowCount() <= 0) return $callback('User registered with Google unsuccessfully (14)', null); //ERROR
			
			/**/
			
			$client_seed = generateHexCode(32);
			$server_seed = generateHexCode(64);
			
			$sql10 = $GLOBALS['db']->prepare('INSERT INTO `users_seeds_client` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `seed` = ' . $GLOBALS['db']->quote($client_seed) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row10 = $sql10->execute();
			
			if(!$row10) return $callback('User registered with Google unsuccessfully (15)', null); //ERROR
			if($sql10->rowCount() <= 0) return $callback('User registered with Google unsuccessfully (16)', null); //ERROR
			
			$sql11 = $GLOBALS['db']->prepare('INSERT INTO `users_seeds_server` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `seed` = ' . $GLOBALS['db']->quote($server_seed) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row11 = $sql11->execute();
			
			if(!$row11) return $callback('User registered with Google unsuccessfully (17)', null); //ERROR
			if($sql11->rowCount() <= 0) return $callback('User registered with Google unsuccessfully (18)', null); //ERROR
			
			return auth_checkSession(array('userid' => $userid, 'type' => 'google_register'), $callback);
		}
	}
}

function auth_authByDiscord($data, $callback){
	$sql1 = $GLOBALS['db']->query('SELECT `userid` FROM `users_binds` WHERE `bind` = ' . $GLOBALS['db']->quote('discord') . ' AND `bindid` = ' . $GLOBALS['db']->quote($data['id']) . ' AND `removed` = 0');
	if($sql1->rowCount() > 0) {
		/* LOGIN */
		
		$row1 = $sql1->fetch(PDO::FETCH_ASSOC);
		
		$sql2 = $GLOBALS['db']->prepare('UPDATE `users` SET `name` = ' . $GLOBALS['db']->quote($data['name']) . ', `avatar` = ' . $GLOBALS['db']->quote($data['avatar']) . ' WHERE `userid` = ' . $GLOBALS['db']->quote($row1['userid']));
		$row2 = $sql2->execute();
		
		$sql3 = $GLOBALS['db']->prepare('INSERT INTO `users_logins` SET `type` = ' . $GLOBALS['db']->quote('discord_login') . ', `userid` = ' . $GLOBALS['db']->quote($row1['userid']) . ', `ip` = ' . $GLOBALS['db']->quote(getUserIp()) . ', `agent` = ' . $GLOBALS['db']->quote(getUserAgent()) . ', `location` = ' . $GLOBALS['db']->quote(getUserLocation(getUserIp())) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row3 = $sql3->execute();
		
		if(!$row3) return $callback('User logged in with Discord unsuccessfully (1)', null); //ERROR
		if($sql3->rowCount() <= 0) return $callback('User logged in with Discord unsuccessfully (2)', null); //ERROR
		
		/**/
		
		$sql4 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($row1['userid']) . ', `change` = ' . $GLOBALS['db']->quote('name') . ', `value` = ' . $GLOBALS['db']->quote($data['name']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row4 = $sql4->execute();
		
		if(!$row4) return $callback('User logged in with Discord unsuccessfully (3)', null); //ERROR
		if($sql4->rowCount() <= 0) return $callback('User logged in with Discord unsuccessfully (4)', null); //ERROR
		
		$sql5 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($row1['userid']) . ', `change` = ' . $GLOBALS['db']->quote('avatar') . ', `value` = ' . $GLOBALS['db']->quote($data['avatar']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row5 = $sql5->execute();
		
		if(!$row5) return $callback('User logged in with Discord unsuccessfully (5)', null); //ERROR
		if($sql5->rowCount() <= 0) return $callback('User logged in with Discord unsuccessfully (6)', null); //ERROR
		
		/**/
		
		return auth_checkSession(array('userid' => $row1['userid'], 'type' => 'discord_login'), $callback);
	} else {
		$sql2 = $GLOBALS['db']->query('SELECT * FROM `users` WHERE `email` = ' . $GLOBALS['db']->quote($data['email']));
		if($sql2->rowCount() > 0) {
			/* BIND BY EMAIL */
			
			$row2 = $sql2->fetch(PDO::FETCH_ASSOC);
			
			$sql3 = $GLOBALS['db']->query('SELECT * FROM `users_binds` WHERE `userid` = ' . $GLOBALS['db']->quote($row2['userid']) . ' AND `bind` = ' . $GLOBALS['db']->quote("discord") . ' AND `removed` = 0');
			if($sql3->rowCount() > 0) return $callback('Account is already binded');
			
			$sql4 = $GLOBALS['db']->prepare('UPDATE `users` SET `name` = ' . $GLOBALS['db']->quote($data['name']) . ', `avatar` = ' . $GLOBALS['db']->quote($data['avatar']) . ' WHERE `userid` = ' . $GLOBALS['db']->quote($row2['userid']));
			$row4 = $sql4->execute();
			
			$sql5 = $GLOBALS['db']->prepare('INSERT INTO `users_binds` SET `userid` = ' . $GLOBALS['db']->quote($row2['userid']) . ', `bind` = ' . $GLOBALS['db']->quote('discord') . ', `bindid` = ' . $GLOBALS['db']->quote($data['id']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row5 = $sql5->execute();
			
			if(!$row5) return $callback('User logged in and binded with Discord unsuccessfully (1)', null); //ERROR
			if($sql5->rowCount() <= 0) return $callback('User logged in  and binded with Discord unsuccessfully (2)', null); //ERROR
			
			$sql6 = $GLOBALS['db']->prepare('INSERT INTO `users_logins` SET `type` = ' . $GLOBALS['db']->quote('google_login_bind') . ', `userid` = ' . $GLOBALS['db']->quote($row2['userid']) . ', `ip` = ' . $GLOBALS['db']->quote(getUserIp()) . ', `agent` = ' . $GLOBALS['db']->quote(getUserAgent()) . ', `location` = ' . $GLOBALS['db']->quote(getUserLocation(getUserIp())) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row6 = $sql6->execute();
			
			if(!$row6) return $callback('User logged in and binded with Discord unsuccessfully (3)', null); //ERROR
			if($sql6->rowCount() <= 0) return $callback('User logged in and binded with Discord unsuccessfully (4)', null); //ERROR
			
			/**/
			
			$sql7 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($row2['userid']) . ', `change` = ' . $GLOBALS['db']->quote('name') . ', `value` = ' . $GLOBALS['db']->quote($data['name']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row7 = $sql7->execute();
			
			if(!$row7) return $callback('User logged in and binded with Discord unsuccessfully (5)', null); //ERROR
			if($sql7->rowCount() <= 0) return $callback('User logged in and binded with Discord unsuccessfully (6)', null); //ERROR
			
			$sql8 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($row2['userid']) . ', `change` = ' . $GLOBALS['db']->quote('avatar') . ', `value` = ' . $GLOBALS['db']->quote($data['avatar']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row8 = $sql8->execute();
			
			if(!$row8) return $callback('User logged in and binded with Discord unsuccessfully (7)', null); //ERROR
			if($sql8->rowCount() <= 0) return $callback('User logged in and binded with Discord unsuccessfully (8)', null); //ERROR
			
			/**/
			
			return auth_checkSession(array('userid' => $row2['userid'], 'type' => 'discord_login_bind'), $callback);
		} else {
			/* REGISTER */
			
			$userid = generateHexCode(24);
			$username = 'user_' . generateHexCode(8);
			
			$sql3 = $GLOBALS['db']->prepare('INSERT INTO `users` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `username` = ' . $GLOBALS['db']->quote($username) . ', `email` = ' . $GLOBALS['db']->quote($data['email']) . ', `name` = ' . $GLOBALS['db']->quote($data['name']) . ', `avatar` = ' . $GLOBALS['db']->quote($data['avatar']) . ', `time_create` = ' . $GLOBALS['db']->quote(time()));
			$row3 = $sql3->execute();
			
			if(!$row3) return $callback('User registered with Discord unsuccessfully (1)', null); //ERROR
			if($sql3->rowCount() <= 0) return $callback('User registered with Discord unsuccessfully (2)', null); //ERROR
			
			$sql4 = $GLOBALS['db']->prepare('INSERT INTO `users_binds` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `bind` = ' . $GLOBALS['db']->quote('discord') . ', `bindid` = ' . $GLOBALS['db']->quote($data['id']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row4 = $sql4->execute();
			
			if(!$row4) return $callback('User registered with Discord unsuccessfully (3)', null); //ERROR
			if($sql4->rowCount() <= 0) return $callback('User registered with Discord unsuccessfully (4)', null); //ERROR
			
			$sql5 = $GLOBALS['db']->prepare('INSERT INTO `users_logins` SET `type` = ' . $GLOBALS['db']->quote('google_register') . ', `userid` = ' . $GLOBALS['db']->quote($userid) . ', `ip` = ' . $GLOBALS['db']->quote(getUserIp()) . ', `agent` = ' . $GLOBALS['db']->quote(getUserAgent()) . ', `location` = ' . $GLOBALS['db']->quote(getUserLocation(getUserIp())) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row5 = $sql5->execute();
			
			if(!$row5) return $callback('User registered with Discord unsuccessfully (5)', null); //ERROR
			if($sql5->rowCount() <= 0) return $callback('User registered with Discord unsuccessfully (6)', null); //ERROR
			
			/**/
			
			$sql6 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `change` = ' . $GLOBALS['db']->quote('email') . ', `value` = ' . $GLOBALS['db']->quote($data['email']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row6 = $sql6->execute();
			
			if(!$row6) return $callback('User registered with Discord unsuccessfully (7)', null); //ERROR
			if($sql6->rowCount() <= 0) return $callback('User registered with Discord unsuccessfully (8)', null); //ERROR
		
			$sql7 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `change` = ' . $GLOBALS['db']->quote('username') . ', `value` = ' . $GLOBALS['db']->quote($username) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row7 = $sql7->execute();
			
			if(!$row7) return $callback('User registered with Discord unsuccessfully (9)', null); //ERROR
			if($sql7->rowCount() <= 0) return $callback('User registered with Discord unsuccessfully (10)', null); //ERROR
			
			$sql8 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `change` = ' . $GLOBALS['db']->quote('name') . ', `value` = ' . $GLOBALS['db']->quote($data['name']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row8 = $sql8->execute();
			
			if(!$row8) return $callback('User registered with Discord unsuccessfully (11)', null); //ERROR
			if($sql8->rowCount() <= 0) return $callback('User registered with Discord unsuccessfully (12)', null); //ERROR
			
			$sql9 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `change` = ' . $GLOBALS['db']->quote('avatar') . ', `value` = ' . $GLOBALS['db']->quote($data['avatar']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row9 = $sql9->execute();
			
			if(!$row9) return $callback('User registered with Discord unsuccessfully (13)', null); //ERROR
			if($sql9->rowCount() <= 0) return $callback('User registered with Discord unsuccessfully (14)', null); //ERROR
			
			/**/
			
			$client_seed = generateHexCode(32);
			$server_seed = generateHexCode(64);
			
			$sql10 = $GLOBALS['db']->prepare('INSERT INTO `users_seeds_client` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `seed` = ' . $GLOBALS['db']->quote($client_seed) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row10 = $sql10->execute();
			
			if(!$row10) return $callback('User registered with Discord unsuccessfully (15)', null); //ERROR
			if($sql10->rowCount() <= 0) return $callback('User registered with Discord unsuccessfully (16)', null); //ERROR
			
			$sql11 = $GLOBALS['db']->prepare('INSERT INTO `users_seeds_server` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `seed` = ' . $GLOBALS['db']->quote($server_seed) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row11 = $sql11->execute();
			
			if(!$row11) return $callback('User registered with Discord unsuccessfully (17)', null); //ERROR
			if($sql11->rowCount() <= 0) return $callback('User registered with Discord unsuccessfully (18)', null); //ERROR
			
			return auth_checkSession(array('userid' => $userid, 'type' => 'discord_register'), $callback);
		}
	}
}

function auth_bindAccount($data, $callback){
	if(!in_array($data['bind'], $GLOBALS['binds_allowed'])) return $callback('Invalid bind');
	
	$sql1 = $GLOBALS['db']->query('SELECT * FROM `users_binds` WHERE `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ' AND `bind` = ' . $GLOBALS['db']->quote($data['bind']) . ' AND `removed` = 0');
	if($sql1->rowCount() > 0) return $callback('Account is already binded');
	
	$sql2 = $GLOBALS['db']->query('SELECT * FROM `users_binds` WHERE `bind` = ' . $GLOBALS['db']->quote($data['bind']) . ' AND `bindid` = ' . $GLOBALS['db']->quote($data['bindid']) . ' AND `removed` = 0');
	if($sql2->rowCount() > 0) return $callback('Other account is already binded with your id');
	
	$sql3 = $GLOBALS['db']->prepare('INSERT INTO `users_binds` SET `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ', `bind` = ' . $GLOBALS['db']->quote($data['bind']) . ', `bindid` = ' . $GLOBALS['db']->quote($data['bindid']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
	$row3 = $sql3->execute();
	
	if(!$row3) return $callback('User binded unsuccessfully (1)'); //ERROR
	if($sql3->rowCount() <= 0) return $callback('User binded unsuccessfully (2)'); //ERROR
	
	return $callback(null);
}

function auth_logout($data, $callback){
	$sql1 = $GLOBALS['db']->query('SELECT * FROM `users_sessions` WHERE `session` = ' . $GLOBALS['db']->quote($data['session']) . ' AND `removed` = 0 AND `activated` = 1 AND `expire` > ' . $GLOBALS['db']->quote(time()));
	if($sql1->rowCount() <= 0) return $callback('User session already expired or it does not exists (1)'); //ERROR
	
	$row1 = $sql1->fetch(PDO::FETCH_ASSOC);
	
	if(intval($data['end']) == 0) {
		return $callback(null);
	} else {
		$sql2 = $GLOBALS['db']->prepare('UPDATE `users_sessions` SET `removed` = 1 WHERE `session` = ' . $GLOBALS['db']->quote($data['session']) . ' AND `removed` = 0 AND `activated` = 1 AND `expire` > ' . $GLOBALS['db']->quote(time()));
		$row2 = $sql2->execute();
		
		if(!$row2) return $callback('User session already expired or it does not exists (3)'); //ERROR
		if($sql2->rowCount() <= 0) return $callback('User session already expired or it does not exists (4)'); //ERROR
		
		return $callback(null);
	}
}

function auth_recoverPassword($data, $callback){
	$sql1 = $GLOBALS['db']->query('SELECT `email`, `userid`, `initialized` FROM `users` WHERE `email` = ' . $GLOBALS['db']->quote($data['username']) . ' OR `username` = ' . $GLOBALS['db']->quote($data['username']));
	if($sql1->rowCount() <= 0) return $callback('Invalid username or e-mail'); //ERROR
	
	$row1 = $sql1->fetch(PDO::FETCH_ASSOC);
	
	if(!intval($row1['initialized'])) return $callback('Your account is not initialized'); //ERROR
	
	$sql2 = $GLOBALS['db']->prepare('UPDATE `link_keys` SET `removed` = 1 WHERE `type` = ' . $GLOBALS['db']->quote("reset_password") . ' AND `userid` = ' . $GLOBALS['db']->quote($row1['userid']) . ' AND `used` = 0 AND `removed` = 0 AND (`expire` > ' . $GLOBALS['db']->quote(time()) . ' OR `expire` = -1)');
	$row2 = $sql2->execute();
	
	if(!$row2) return $callback('User recover password unsuccessfully (1)'); //ERROR
	
	$recover_key = generateHexCode(32);
	
	$sql3 = $GLOBALS['db']->prepare('INSERT INTO `link_keys` SET `type` = ' . $GLOBALS['db']->quote("reset_password") . ', `userid` = ' . $GLOBALS['db']->quote($row1['userid']) . ', `key` = ' . $GLOBALS['db']->quote($recover_key) . ', `expire` = ' . $GLOBALS['db']->quote(time() + $GLOBALS['countdown_recover'] * 60) . ', `created` = ' . $GLOBALS['db']->quote(time()));
	$row3 = $sql3->execute();
	
	if(!$row3) return $callback('User recover password unsuccessfully (2)'); //ERROR
	if($sql3->rowCount() <= 0) return $callback('User recover password unsuccessfully (3)'); //ERROR
	
	$mail_subject = 'Reset Password';
	$mail_message = 'Reset Password Link (expires in ' . $GLOBALS['countdown_recover'] . ' minutes): ' . $GLOBALS['siteurl'] . $GLOBALS['root'] . 'auth/reset?key=' . $recover_key;
	
	mailer_sendMail($row1['email'], $mail_subject, $mail_message, function($err1) use ($callback, $row1, $mail_subject, $mail_message){
		if($err1) return $callback('User recover password unsuccessfully (4)'); //ERROR
		
		$sql4 = $GLOBALS['db']->prepare('INSERT INTO `mailer_sent` SET `userid` = ' . $GLOBALS['db']->quote($row1['userid']) . ', `email` = ' . $GLOBALS['db']->quote($row1['email']) . ', `subject` = ' . $GLOBALS['db']->quote($mail_subject) . ', `message` = ' . $GLOBALS['db']->quote($mail_message) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row4 = $sql4->execute();
		
		if(!$row4) return $callback('User recover password unsuccessfully (5)'); //ERROR
		if($sql4->rowCount() <= 0) return $callback('User recover password unsuccessfully (6)'); //ERROR
		
		return $callback(null);
	});
}

function auth_resetPassword($data, $callback){
	if($data['password'] != $data['confirm_password']) return $callback('The passwords does not match'); //ERROR
	
	$pattern_password = '/^((?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*\W).{8,})$/';
	if(!preg_match($pattern_password, $data['password'])) return $callback('Invalid password. At least 8 characters, one uppercase, one lowercase, one number and one symbol'); //ERROR
	
	auth_checkLinkKey(array( 'key' => $data['key'], 'type' => 'reset_password', 'use' => true ), function($err1, $userid) use ($callback, $data){
		if($err1) return $callback($err1); //ERROR
		
		$crypted_password = hash('sha256', $data['password']);
		
		$sql2 = $GLOBALS['db']->prepare('UPDATE `users` SET `password` = ' . $GLOBALS['db']->quote($crypted_password) . ' WHERE `userid` = ' . $GLOBALS['db']->quote($userid));
		$row2 = $sql2->execute();
		
		$sql3 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($userid) . ', `change` = ' . $GLOBALS['db']->quote('password') . ', `value` = ' . $GLOBALS['db']->quote($crypted_password) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row3 = $sql3->execute();
		
		if(!$row3) return $callback('User password changed unsuccessfully (1)', null); //ERROR
		if($sql3->rowCount() <= 0) return $callback('User password changed unsuccessfully (2)', null); //ERROR
		
		return $callback(null);
	});
}

function auth_resendVerifyProfile($data, $callback){
	if(!intval($data['user']['initialized'])) return $callback('Your account is not initialized'); //ERROR
	if(intval($data['user']['verified'])) return $callback('Your account is already verified'); //ERROR
	
	$sql1 = $GLOBALS['db']->query('SELECT * FROM `link_keys` WHERE `type` = ' . $GLOBALS['db']->quote("verify_profile") . ' AND `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ' AND `used` = 0 AND `removed` = 0 AND (`expire` > ' . $GLOBALS['db']->quote(time()) . ' OR `expire` = -1) AND `created` > ' . $GLOBALS['db']->quote(time() - $GLOBALS['cooldown_verify']));
	if($sql1->rowCount() > 0) return $callback('Please wait ' . $GLOBALS['cooldown_verify'] . ' seconds before try again to resend the verify email!'); //ERROR
	
	$verify_key = generateHexCode(32);
	
	$sql2 = $GLOBALS['db']->prepare('INSERT INTO `link_keys` SET `type` = ' . $GLOBALS['db']->quote("verify_profile") . ', `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ', `key` = ' . $GLOBALS['db']->quote($verify_key) . ', `expire` = -1, `created` = ' . $GLOBALS['db']->quote(time()));
	$row2 = $sql2->execute();
	
	if(!$row2) return $callback('User recover password unsuccessfully (1)'); //ERROR
	if($sql2->rowCount() <= 0) return $callback('User recover password unsuccessfully (2)'); //ERROR
	
	$mail_subject = 'Verify Profile';
	$mail_message = 'Verify Profile Link: ' . $GLOBALS['siteurl'] . $GLOBALS['root'] . 'auth/verify?key=' . $verify_key;
	
	mailer_sendMail($data['user']['email'], $mail_subject, $mail_message, function($err1) use ($callback, $data, $mail_subject, $mail_message){
		if($err1) return $callback('User recover password unsuccessfully (3)'); //ERROR
		
		$sql3 = $GLOBALS['db']->prepare('INSERT INTO `mailer_sent` SET `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ', `email` = ' . $GLOBALS['db']->quote($data['user']['email']) . ', `subject` = ' . $GLOBALS['db']->quote($mail_subject) . ', `message` = ' . $GLOBALS['db']->quote($mail_message) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row3 = $sql3->execute();
		
		if(!$row3) return $callback('User recover password unsuccessfully (4)'); //ERROR
		if($sql3->rowCount() <= 0) return $callback('User recover password unsuccessfully (5)'); //ERROR
		
		return $callback(null);
	});
}

function auth_verifyProfile($data, $callback){
	if(intval($data['user']['verified'])) return $callback('Your account is already verified'); //ERROR
	
	auth_checkLinkKey(array( 'key' => $data['key'], 'type' => 'verify_profile', 'use' => true ), function($err1, $userid) use ($callback, $data){
		if($err1) return $callback($err1); //ERROR
		
		$sql2 = $GLOBALS['db']->prepare('UPDATE `users` SET `verified` = 1 WHERE `userid` = ' . $GLOBALS['db']->quote($userid));
		$row2 = $sql2->execute();
		
		return $callback(null);
	});
}

function auth_accountInitializing($data, $callback){
	$pattern_email = '/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*\.\w+$/';
	$pattern_username = '/^[a-z0-9_]{6,}$/';
	$pattern_password = '/^((?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*\W).{8,})$/';
	
	if(!preg_match($pattern_email, $data['email'])) return $callback('Invalid e-mail. Invalid format e-mail'); //ERROR
	if(!preg_match($pattern_username, $data['username'])) return $callback('Invalid username. At least 6 characters, only lowercase, numbers and underscore are allowed'); //ERROR
	if(!preg_match($pattern_password, $data['password'])) return $callback('Invalid password. At least 8 characters, one uppercase, one lowercase, one number and one symbol'); //ERROR
	if($data['confirm_password'] != $data['password']) return $callback('Invalid password. The passwords doesn\'t match'); //ERROR
	
	if(intval($data['user']['initialized']) == 1) return $callback('Your account is already initialized'); //ERROR
	
	$sql1 = $GLOBALS['db']->query('SELECT * FROM `users` WHERE `userid` != ' . $GLOBALS['db']->quote($data['user']['userid']) . ' AND `email` = ' . $GLOBALS['db']->quote($data['email']));
	if($sql1->rowCount() > 0) return $callback('E-mail already taken'); //ERROR
	
	$sql2 = $GLOBALS['db']->query('SELECT * FROM `users` WHERE `userid` != ' . $GLOBALS['db']->quote($data['user']['userid']) . ' AND `username` = ' . $GLOBALS['db']->quote($data['username']));
	if($sql2->rowCount() > 0) return $callback('Username already taken'); //ERROR
	
	$crypted_password = hash('sha256', $data['password']);

	$sql3 = $GLOBALS['db']->prepare('UPDATE `users` SET `initialized` = 1, `username` = ' . $GLOBALS['db']->quote($data['username']) . ', `email` = ' . $GLOBALS['db']->quote($data['email']) . ', `password` = ' . $GLOBALS['db']->quote($crypted_password) . ' WHERE `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']));
	$row3 = $sql3->execute();
	
	if(!$row3) return $callback('Account initialized unsuccessfully (1)'); //ERROR
	if($sql3->rowCount() <= 0) return $callback('Account initialized unsuccessfully (2)'); //ERROR
	
	/**/
	
	$sql4 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ', `change` = ' . $GLOBALS['db']->quote('email') . ', `value` = ' . $GLOBALS['db']->quote($data['email']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
	$row4 = $sql4->execute();
	
	if(!$row4) return $callback('Account initialized unsuccessfully (3)', null); //ERROR
	if($sql4->rowCount() <= 0) return $callback('Account initialized unsuccessfully (4)', null); //ERROR
	
	$sql5 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ', `change` = ' . $GLOBALS['db']->quote('username') . ', `value` = ' . $GLOBALS['db']->quote($data['username']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
	$row5 = $sql5->execute();
	
	if(!$row5) return $callback('Account initialized unsuccessfully (5)', null); //ERROR
	if($sql5->rowCount() <= 0) return $callback('Account initialized unsuccessfully (6)', null); //ERROR
	
	$sql6 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ', `change` = ' . $GLOBALS['db']->quote('password') . ', `value` = ' . $GLOBALS['db']->quote($crypted_password) . ', `time` = ' . $GLOBALS['db']->quote(time()));
	$row6 = $sql6->execute();
	
	if(!$row6) return $callback('Account initialized unsuccessfully (7)', null); //ERROR
	if($sql6->rowCount() <= 0) return $callback('Account initialized unsuccessfully (8)', null); //ERROR
	
	/**/
	
	$sql7 = $GLOBALS['db']->prepare('UPDATE `link_keys` SET `removed` = 1 WHERE `type` = ' . $GLOBALS['db']->quote("verify_profile") . ' AND `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ' AND `used` = 0 AND `removed` = 0 AND (`expire` > ' . $GLOBALS['db']->quote(time()) . ' OR `expire` = -1)');
	$row7 = $sql7->execute();
	
	if(!$row7) return $callback('Account initialized unsuccessfully (9)'); //ERROR
	
	$verify_key = generateHexCode(32);
	
	$sql8 = $GLOBALS['db']->prepare('INSERT INTO `link_keys` SET `type` = ' . $GLOBALS['db']->quote("verify_profile") . ', `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ', `key` = ' . $GLOBALS['db']->quote($verify_key) . ', `expire` = -1, `created` = ' . $GLOBALS['db']->quote(time()));
	$row8 = $sql8->execute();
	
	if(!$row8) return $callback('Account initialized unsuccessfully (10)'); //ERROR
	if($sql8->rowCount() <= 0) return $callback('Account initialized unsuccessfully (11)'); //ERROR
	
	$mail_subject = 'Verify Profile';
	$mail_message = 'Verify Profile Link: ' . $GLOBALS['siteurl'] . $GLOBALS['root'] . 'auth/verify?key=' . $verify_key;
	
	mailer_sendMail($data['email'], $mail_subject, $mail_message, function($err1) use ($callback, $data, $mail_subject, $mail_message){
		if($err1) return $callback('Account initialized unsuccessfully (12)'); //ERROR
		
		$sql9 = $GLOBALS['db']->prepare('INSERT INTO `mailer_sent` SET `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ', `email` = ' . $GLOBALS['db']->quote($data['email']) . ', `subject` = ' . $GLOBALS['db']->quote($mail_subject) . ', `message` = ' . $GLOBALS['db']->quote($mail_message) . ', `time` = ' . $GLOBALS['db']->quote(time()));
		$row9 = $sql9->execute();
		
		if(!$row9) return $callback('Account initialized unsuccessfully (13)'); //ERROR
		if($sql9->rowCount() <= 0) return $callback('Account initialized unsuccessfully (14)'); //ERROR
		
		return $callback(null);
	});
}

function auth_changePassword($data, $callback){
	$pattern_password = '/^((?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*\W).{8,})$/';
	
	if(!preg_match($pattern_password, $data['current_password'])) return $callback('Invalid current password. At least 8 characters, one uppercase, one lowercase, one number and one symbol'); //ERROR
	if(!preg_match($pattern_password, $data['password'])) return $callback('Invalid new password. At least 8 characters, one uppercase, one lowercase, one number and one symbol'); //ERROR
	if($data['confirm_password'] != $data['password']) return $callback('Invalid password. The passwords doesn\'t match'); //ERROR
	
	$crypted_current_password = hash('sha256', $data['current_password']);
	if($crypted_current_password != $data['user']['password']) return $callback('Invalid current password. Wrong password'); //ERROR
	
	$crypted_new_password = hash('sha256', $data['password']);
	if($crypted_new_password == $data['user']['password']) return $callback('Invalid new password. Same password'); //ERROR
	
	$sql1 = $GLOBALS['db']->prepare('UPDATE `users` SET `password` = ' . $GLOBALS['db']->quote($crypted_new_password) . ' WHERE `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']));
	$row1 = $sql1->execute();
	
	if(!$row1) return $callback('Password changed unsuccessfully (1)'); //ERROR
	if($sql1->rowCount() <= 0) return $callback('Password changed unsuccessfully (2)'); //ERROR
	
	$sql2 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ', `change` = ' . $GLOBALS['db']->quote('password') . ', `value` = ' . $GLOBALS['db']->quote($crypted_new_password) . ', `time` = ' . $GLOBALS['db']->quote(time()));
	$row2 = $sql2->execute();
	
	if(!$row2) return $callback('Password changed unsuccessfully (3)'); //ERROR
	if($sql2->rowCount() <= 0) return $callback('Password changed unsuccessfully (4)'); //ERROR
	
	return $callback(null);
}

function auth_userSettings($data, $callback){
	$pattern_email = '/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*\.\w+$/';
	$pattern_username = '/^[a-z0-9_]{6,}$/';
	
	if(!preg_match($pattern_email, $data['email'])) return $callback('Invalid e-mail. Invalid format e-mail', null); //ERROR
	if(!preg_match($pattern_username, $data['username'])) return $callback('Invalid username. At least 6 characters, only lowercase, numbers and underscore are allowed', null); //ERROR
	
	$sql1 = $GLOBALS['db']->query('SELECT * FROM `users` WHERE `userid` != ' . $GLOBALS['db']->quote($data['user']['userid']) . ' AND `email` = ' . $GLOBALS['db']->quote($data['email']));
	if($sql1->rowCount() > 0) return $callback('E-mail already taken'); //ERROR
	
	$sql2 = $GLOBALS['db']->query('SELECT * FROM `users` WHERE `userid` != ' . $GLOBALS['db']->quote($data['user']['userid']) . ' AND `username` = ' . $GLOBALS['db']->quote($data['username']));
	if($sql2->rowCount() > 0) return $callback('Username already taken'); //ERROR
	
	$sql3 = $GLOBALS['db']->prepare('UPDATE `users` SET `verified` = ' . intval(intval($data['user']['verified']) ? (($data['user']['email'] == $data['email']) ? 1 : 0) : 0) . ', `username` = ' . $GLOBALS['db']->quote($data['username']) . ', `email` = ' . $GLOBALS['db']->quote($data['email']) . ' WHERE `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']));
	$row3 = $sql3->execute();
	
	if(!$row3) return $callback('Account saved unsuccessfully (1)'); //ERROR
	
	/**/
	
	$sql4 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ', `change` = ' . $GLOBALS['db']->quote('email') . ', `value` = ' . $GLOBALS['db']->quote($data['email']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
	$row4 = $sql4->execute();
	
	if(!$row4) return $callback('Account saved unsuccessfully (2)', null); //ERROR
	if($sql4->rowCount() <= 0) return $callback('Account saved unsuccessfully (3)', null); //ERROR
	
	$sql5 = $GLOBALS['db']->prepare('INSERT INTO `users_changes` SET `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ', `change` = ' . $GLOBALS['db']->quote('username') . ', `value` = ' . $GLOBALS['db']->quote($data['username']) . ', `time` = ' . $GLOBALS['db']->quote(time()));
	$row5 = $sql5->execute();
	
	if(!$row5) return $callback('Account saved unsuccessfully (4)', null); //ERROR
	if($sql5->rowCount() <= 0) return $callback('Account saved unsuccessfully (5)', null); //ERROR
	
	/**/
	
	if($data['user']['email'] != $data['email']){
		$sql6 = $GLOBALS['db']->prepare('UPDATE `link_keys` SET `removed` = 1 WHERE `type` = ' . $GLOBALS['db']->quote("verify_profile") . ' AND `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ' AND `used` = 0 AND `removed` = 0 AND (`expire` > ' . $GLOBALS['db']->quote(time()) . ' OR `expire` = -1)');
		$row6 = $sql6->execute();
		
		if(!$row6) return $callback('Account saved unsuccessfully (6)'); //ERROR
		
		$verify_key = generateHexCode(32);
		
		$sql7 = $GLOBALS['db']->prepare('INSERT INTO `link_keys` SET `type` = ' . $GLOBALS['db']->quote("verify_profile") . ', `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ', `key` = ' . $GLOBALS['db']->quote($verify_key) . ', `expire` = -1, `created` = ' . $GLOBALS['db']->quote(time()));
		$row7 = $sql7->execute();
		
		if(!$row7) return $callback('Account saved unsuccessfully (7)'); //ERROR
		if($sql7->rowCount() <= 0) return $callback('Account saved unsuccessfully (8)'); //ERROR
		
		$mail_subject = 'Verify Profile';
		$mail_message = 'Verify Profile Link: ' . $GLOBALS['siteurl'] . $GLOBALS['root'] . 'auth/verify?key=' . $verify_key;
		
		mailer_sendMail($data['email'], $mail_subject, $mail_message, function($err1) use ($callback, $data, $mail_subject, $mail_message){
			if($err1) return $callback('Account saved unsuccessfully (9)'); //ERROR
			
			$sql8 = $GLOBALS['db']->prepare('INSERT INTO `mailer_sent` SET `userid` = ' . $GLOBALS['db']->quote($data['user']['userid']) . ', `email` = ' . $GLOBALS['db']->quote($data['email']) . ', `subject` = ' . $GLOBALS['db']->quote($mail_subject) . ', `message` = ' . $GLOBALS['db']->quote($mail_message) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row8 = $sql8->execute();
			
			if(!$row8) return $callback('Account saved unsuccessfully (10)'); //ERROR
			if($sql8->rowCount() <= 0) return $callback('Account saved unsuccessfully (11)'); //ERROR
			
			return $callback(null);
		});
	}
	
	return $callback(null);
}

function auth_checkSession($data, $callback){
	$device = hash('sha256', getUserAgent());
	
	$sql1 = $GLOBALS['db']->query('SELECT * FROM `users` WHERE `userid` = ' . $GLOBALS['db']->quote($data['userid']) . ' AND `initialized` = 1 AND `verified` = 1');
	$sql2 = $GLOBALS['db']->query('SELECT * FROM `users_twofa` WHERE `userid` = ' . $GLOBALS['db']->quote($data['userid']) . ' AND `removed` = 0 AND `activated` = 1');
	
	if($sql1->rowCount() <= 0 && $sql2->rowCount() <= 0){
		$sql3 = $GLOBALS['db']->query('UPDATE `users_sessions` SET `activated` = 1 WHERE `userid` = ' . $GLOBALS['db']->quote($data['userid']) . ' AND `removed` = 0 AND `activated` = 0 AND `expire` > ' . $GLOBALS['db']->quote(time()));
		$row3 = $sql3->execute();
		
		if(!$sql3) return $callback('Session checked unsuccessfully (1)'); //ERROR
	}
	
	$sql4 = $GLOBALS['db']->query('SELECT * FROM `users_sessions` WHERE `userid` = ' . $GLOBALS['db']->quote($data['userid']) . ' AND `device` = ' . $GLOBALS['db']->quote($device) . ' AND `removed` = 0 AND `expire` > ' . $GLOBALS['db']->quote(time()) . ' ORDER BY `id` DESC LIMIT 1');
	if($sql4->rowCount() <= 0) return auth_insertSession($data, $callback);
	
	$row4 = $sql4->fetch(PDO::FETCH_ASSOC);
	
	$session = $row4['session'];
	$expire = $row4['expire'];
	
	$sessionid = $row4['id'];
	
	$sql5 = $GLOBALS['db']->prepare('INSERT INTO `users_logins` SET `type` = ' . $GLOBALS['db']->quote($data['type']) . ', `userid` = ' . $GLOBALS['db']->quote($data['userid']) . ', `sessionid` = ' . $GLOBALS['db']->quote($sessionid) . ', `ip` = ' . $GLOBALS['db']->quote(getUserIp()) . ', `agent` = ' . $GLOBALS['db']->quote(getUserAgent()) . ', `location` = ' . $GLOBALS['db']->quote(getUserLocation(getUserIp())) . ', `time` = ' . $GLOBALS['db']->quote(time()));
	$row5 = $sql5->execute();
	
	if(!$row5) return $callback('Session checked unsuccessfully (2)', null); //ERROR
	if($sql5->rowCount() <= 0) return $callback('Session checked unsuccessfully (3)', null); //ERROR
	
	if($sql1->rowCount() > 0 && $sql2->rowCount() <= 0){
		$row1 = $sql1->fetch(PDO::FETCH_ASSOC);
		$email = $row1['email'];
		
		$sql8 = $GLOBALS['db']->query('UPDATE `users_sessions` SET `activated` = 0 WHERE `id` = ' . $GLOBALS['db']->quote($sessionid) . ' AND `removed` = 0 AND `activated` = 1 AND `expire` > ' . $GLOBALS['db']->quote(time()));
		$sql8 = $sql8->execute();
		
		if(!$sql8) return $callback('Session checked unsuccessfully (4)'); //ERROR
		
		$sql9 = $GLOBALS['db']->query('SELECT * FROM `security_codes` WHERE `type` = ' . $GLOBALS['db']->quote("login") . ' AND `userid` = ' . $GLOBALS['db']->quote($data['userid']) . ' AND `used` = 0 AND `removed` = 0 AND (`expire` > ' . $GLOBALS['db']->quote(time()) . ' OR `expire` = -1)');
		if($sql9->rowCount() > 0) return $callback(null, array( 'session' => $session, 'expire' => $expire ));
		
		$security_code = generateHexCode(6);
		
		$sql10 = $GLOBALS['db']->prepare('INSERT INTO `security_codes` SET `type` = ' . $GLOBALS['db']->quote("login") . ', `userid` = ' . $GLOBALS['db']->quote($data['userid']) . ', `code` = ' . $GLOBALS['db']->quote($security_code) . ', `expire` = ' . $GLOBALS['db']->quote(time() + $GLOBALS['cooldown_security_login']) . ', `created` = ' . $GLOBALS['db']->quote(time()));
		$row10 = $sql10->execute();
		
		if(!$row10) return $callback('Session checked unsuccessfully (5)'); //ERROR
		if($sql10->rowCount() <= 0) return $callback('Session checked unsuccessfully (6)'); //ERROR
		
		$mail_subject = 'Security Code';
		$mail_message = 'Security Code: ' . $security_code;
		
		mailer_sendMail($email, $mail_subject, $mail_message, function($err1) use ($callback, $data, $email, $mail_subject, $mail_message, $session, $expire){
			if($err1) return $callback('Session checked unsuccessfully (7)'); //ERROR
			
			$sql11 = $GLOBALS['db']->prepare('INSERT INTO `mailer_sent` SET `userid` = ' . $GLOBALS['db']->quote($data['userid']) . ', `email` = ' . $GLOBALS['db']->quote($email) . ', `subject` = ' . $GLOBALS['db']->quote($mail_subject) . ', `message` = ' . $GLOBALS['db']->quote($mail_message) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row11 = $sql11->execute();
			
			if(!$row11) return $callback('Session checked unsuccessfully (8)'); //ERROR
			if($sql11->rowCount() <= 0) return $callback('Session checked unsuccessfully (9)'); //ERROR
			
			return $callback(null, array( 'session' => $session, 'expire' => $expire ));
		});
	}
	
	return $callback(null, array( 'session' => $session, 'expire' => $expire ));
}

function auth_insertSession($data, $callback) {
	$sql1 = $GLOBALS['db']->query('SELECT * FROM `users` WHERE `userid` = ' . $GLOBALS['db']->quote($data['userid']));
	if($sql1->rowCount() < 0) return $callback('Session registered unsuccessfully (1)', null); //ERROR
	
	$row1 = $sql1->fetch(PDO::FETCH_ASSOC);
	
	$session = generateHexCode(32);
	$expire = time() + (in_array($GLOBALS['ranks_name'][$row1['rank']], $GLOBALS['session_extended']) ? 30 * 24 * 60 * 60 : 24 * 60 * 60);
	
	$activated = 1;
	$sql2 = $GLOBALS['db']->query('SELECT * FROM `users` WHERE `userid` = ' . $GLOBALS['db']->quote($data['userid']) . ' AND `initialized` = 1 AND `verified` = 1');
	if($sql2->rowCount() > 0) $activated = 0;
	
	$sql3 = $GLOBALS['db']->query('SELECT * FROM `users_twofa` WHERE `userid` = ' . $GLOBALS['db']->quote($data['userid']) . ' AND `removed` = 0 AND `activated` = 1');
	if($sql3->rowCount() > 0) $activated = 0;
	
	$device = hash('sha256', getUserAgent());
	
	$sql4 = $GLOBALS['db']->prepare('INSERT INTO `users_sessions` SET `userid` = ' . $GLOBALS['db']->quote($data['userid']) . ', `activated` = ' . $GLOBALS['db']->quote($activated) . ', `session` = ' . $GLOBALS['db']->quote($session) . ', `device` = ' . $GLOBALS['db']->quote($device) . ', `expire` = ' . $GLOBALS['db']->quote($expire) . ', `created` = ' . $GLOBALS['db']->quote(time()));
	$row4 = $sql4->execute();
	
	if(!$row4) return $callback('Session registered unsuccessfully (2)', null); //ERROR
	if($sql4->rowCount() <= 0) return $callback('Session registered unsuccessfully (3)', null); //ERROR
	
	$sessionid = $GLOBALS['db']->lastInsertId();
	
	$sql5 = $GLOBALS['db']->prepare('INSERT INTO `users_logins` SET `type` = ' . $GLOBALS['db']->quote($data['type']) . ', `userid` = ' . $GLOBALS['db']->quote($data['userid']) . ', `sessionid` = ' . $GLOBALS['db']->quote($sessionid) . ', `ip` = ' . $GLOBALS['db']->quote(getUserIp()) . ', `agent` = ' . $GLOBALS['db']->quote(getUserAgent()) . ', `location` = ' . $GLOBALS['db']->quote(getUserLocation(getUserIp())) . ', `time` = ' . $GLOBALS['db']->quote(time()));
	$row5 = $sql5->execute();
	
	if(!$row5) return $callback('Session registered unsuccessfully (4)', null); //ERROR
	if($sql5->rowCount() <= 0) return $callback('Session registered unsuccessfully (5)', null); //ERROR
	
	if($sql2->rowCount() > 0 && $sql3->rowCount() <= 0){
		$row2 = $sql2->fetch(PDO::FETCH_ASSOC);
		$email = $row2['email'];
		
		$sql6 = $GLOBALS['db']->query('SELECT * FROM `security_codes` WHERE `type` = ' . $GLOBALS['db']->quote("login") . ' AND `userid` = ' . $GLOBALS['db']->quote($data['userid']) . ' AND `used` = 0 AND `removed` = 0 AND (`expire` > ' . $GLOBALS['db']->quote(time()) . ' OR `expire` = -1)');
		if($sql6->rowCount() > 0) return $callback(null, array( 'session' => $session, 'expire' => $expire ));
		
		$security_code = generateHexCode(6);
		
		$sql7 = $GLOBALS['db']->prepare('INSERT INTO `security_codes` SET `type` = ' . $GLOBALS['db']->quote("login") . ', `userid` = ' . $GLOBALS['db']->quote($data['userid']) . ', `code` = ' . $GLOBALS['db']->quote($security_code) . ', `expire` = ' . $GLOBALS['db']->quote(time() + $GLOBALS['cooldown_security_login']) . ', `created` = ' . $GLOBALS['db']->quote(time()));
		$row7 = $sql7->execute();
		
		if(!$row7) return $callback('Session registered unsuccessfully (6)'); //ERROR
		if($sql7->rowCount() <= 0) return $callback('Session registered unsuccessfully (7)'); //ERROR
		
		$mail_subject = 'Security Code';
		$mail_message = 'Security Code: ' . $security_code;
		
		mailer_sendMail($email, $mail_subject, $mail_message, function($err1) use ($callback, $data, $email, $mail_subject, $mail_message, $session, $expire){
			if($err1) return $callback('Session registered unsuccessfully (8)'); //ERROR
			
			$sql8 = $GLOBALS['db']->prepare('INSERT INTO `mailer_sent` SET `userid` = ' . $GLOBALS['db']->quote($data['userid']) . ', `email` = ' . $GLOBALS['db']->quote($email) . ', `subject` = ' . $GLOBALS['db']->quote($mail_subject) . ', `message` = ' . $GLOBALS['db']->quote($mail_message) . ', `time` = ' . $GLOBALS['db']->quote(time()));
			$row8 = $sql8->execute();
			
			if(!$row8) return $callback('Session registered unsuccessfully (9)'); //ERROR
			if($sql8->rowCount() <= 0) return $callback('Session registered unsuccessfully (10)'); //ERROR
			
			return $callback(null, array( 'session' => $session, 'expire' => $expire ));
		});
	}
	
	return $callback(null, array( 'session' => $session, 'expire' => $expire ));
}

function auth_checkLinkKey($data, $callback){
	$sql1 = $GLOBALS['db']->query('SELECT * FROM `link_keys` WHERE `type` = ' . $GLOBALS['db']->quote($data['type']) . ' AND `key` = ' . $GLOBALS['db']->quote($data['key']) . ' AND `used` = 0 AND `removed` = 0 AND (`expire` > ' . $GLOBALS['db']->quote(time()) . ' OR `expire` = -1)');
	
	if($sql1->rowCount() <= 0) return $callback('Key already expired or it does not exists (1)', null); //ERROR
	$row1 = $sql1->fetch(PDO::FETCH_ASSOC);
	
	if($data['use']){
		$sql2 = $GLOBALS['db']->prepare('UPDATE `link_keys` SET `used` = 1 WHERE `type` = ' . $GLOBALS['db']->quote($data['type']) . ' AND `key` = ' . $GLOBALS['db']->quote($data['key']) . ' AND `used` = 0 AND `removed` = 0 AND (`expire` > ' . $GLOBALS['db']->quote(time()) . ' OR `expire` = -1)');
		$row2 = $sql2->execute();
		
		if(!$row2) return $callback('Key already expired or it does not exists (2)', null); //ERROR
		if($sql2->rowCount() <= 0) return $callback('Key already expired or it does not exists (3)', null); //ERROR
		
		$sql3 = $GLOBALS['db']->prepare('UPDATE `link_keys` SET `removed` = 1 WHERE `type` = ' . $GLOBALS['db']->quote($data['type']) . ' AND `userid` = ' . $GLOBALS['db']->quote($row1['userid']) . ' AND `used` = 0 AND `removed` = 0 AND (`expire` > ' . $GLOBALS['db']->quote(time()) . ' OR `expire` = -1)');
		$row3 = $sql3->execute();
	}
	
	return $callback(null, $row1['userid']);
}

?>