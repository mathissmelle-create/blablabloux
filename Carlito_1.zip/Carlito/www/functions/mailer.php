<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'vendors/mailer/vendor/autoload.php';

function mailer_sendMail($to, $subject, $message, $callback){
	$mail = new PHPMailer(true);
	
	try {
		$mail->isSMTP();
		$mail->Host = $GLOBALS['mailer']['host'];
		$mail->SMTPAuth = $GLOBALS['mailer']['secure'];
		$mail->Username = $GLOBALS['mailer']['email'];
		$mail->Password = $GLOBALS['mailer']['password'];
		$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
		$mail->Port = $GLOBALS['mailer']['port'];
		$mail->SMTPOptions = array(
			'ssl' => array(
				'verify_peer' => false,
				'verify_peer_name' => false,
				'allow_self_signed' => true
			)
		);
		
		$mail->setFrom($GLOBALS['mailer']['email']);
		$mail->addAddress($to);
		
		$mail->isHTML(true);
		$mail->Subject = $subject;
		$mail->Body = $message;
		
		$mail->send();
		
		return $callback(null);
	} catch (Exception $e) {
		return $callback($mail->ErrorInfo);
	}
}

?>