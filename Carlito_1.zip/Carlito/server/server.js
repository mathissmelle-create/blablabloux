var mysql = require('mysql');
var fs = require('fs');
var request = require('request');
var config = require('./config.js');
var log4js = require('log4js');
var sha256 = require('sha256');
var math = require('mathjs');
var crypto = require('crypto');
var twofactor = require('node-2fa');
var express = require('express');

/*

var options_ssl = {
    key: fs.readFileSync('./ssl/cloudflare.key'),
    cert: fs.readFileSync('./ssl/cloudflare.crt')
};

var server = require('https').createServer(options_ssl);
var io = require('socket.io')(server, { cors: { 
	origin: config.config_site.url,
	headers: [ 'Access-Control-Allow-Origin' ],
	credentials: true
}});
server.listen(config.config_site.server_port);

*/

var server = require('http').createServer();
var io = require('socket.io')(server, { cors: '*' });
server.listen(config.config_site.server_port);

updateLogs();
function updateLogs() {
	var date = dateFormat(new Date(), 'dd.MM.yyyy');
	
	log4js.configure({
		appenders: {
			out:{ type: 'console' },
			app:{ type: 'file', filename: 'logs/' + date + '.log' }
		},
		categories: {
			default: { appenders: [ 'out', 'app' ], level: 'all' }
		}
	});
	
	setTimeout(function(){
		updateLogs();
	}, 24 * 3600 * 1000);
}

var logger = log4js.getLogger();

var pool = mysql.createPool({
	database: config.config_site.database.database,
	host: config.config_site.database.host,
	user: config.config_site.database.user,
	password: config.config_site.database.password
});

function writeError(error){
	var date = dateFormat(new Date(), 'dd.MM.yyyy');
	
	try{
		error = error.stack.toString();
	} catch(e) {
		error = error.toString();
	}
	
	if(!fs.existsSync('errors/' + date + '.error')){
		fs.writeFileSync('errors/' + date + '.error', dateFormat(new Date(), 'hh:MM:ss.sss') + '\n' + error + '\n\n', function(err1){
			if(err1) {
				logger.error(err1);
				return;
			}
			
			logger.debug('Whriting error completed!');
		});
    } else {
		fs.appendFile('errors/' + date + '.error', dateFormat(new Date(), 'hh:MM:ss.sss') + ' \n' + error + '\n\n', function(err1){
			if(err1) {
				logger.error(err1);
				return;
			}
			
			logger.debug('Whriting error completed!');
		});
	}
}

process.on('uncaughtException', function (error) {
	logger.error('Strange error');
	logger.error(error);
	writeError(error);
});

//SITE
var users_requests = {};
var users_online = {};
var users_flood = {};

var site_settingsUpdate = false;

var site_pricesUpdate_items = false;
var site_pricesUpdate_steam = false;
var site_pricesUpdate_crypto = false;

/* -------------- CONNECT TO SOCKET -------------- */

io.on('connection', function(socket) {
	var user = {};
	var session = null;
	var paths = [];
	
	socket.on('join', function(join_data) {
		session = join_data.session;
		paths = join_data.paths;
		
		if(paths.length <= 0) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Your page is now inactive! Prease refresh the page.'
			});
			return;
		}
		
		pool.query('SELECT users.*, users_sessions.session FROM `users` INNER JOIN `users_sessions` ON users.userid = users_sessions.userid WHERE users_sessions.session = ' + pool.escape(session) + ' AND users_sessions.removed = 0 AND users_sessions.activated = 1 AND users_sessions.expire > ' + time(), function(err1, row1) {
			if(err1) {
				logger.error(err1);
				writeError(err1);
				return;
			}
			
			pool.query('SELECT * FROM `maintenance` WHERE `removed` = 0', function(err2, row2) {
				if(err2) {
					logger.error(err2);
					writeError(err2);
					return;
				}
			
				if(row1.length == 0){
					user = {
						bot: 0,
						userid: socket.client.request.headers['x-forwarded-for'] || socket.request.connection.remoteAddress,
						name: 'Guest',
						avatar: 'http://steamcdn-a.akamaihd.net/steamcommunity/public/images/avatars/fe/fef49e7fa7e1997310d705b2a6158ff8dc1cdfeb_full.jpg',
						balance: 0,
						rank: 0,
						xp: 0,
						tradelink: null,
						apikey: null,
						initialized: 0,
						verified: 0,
						email: null,
						available: 0,
						binds: {},
						settings: {
							'anonymous': 0,
							'private': 0
						},
						restrictions: {},
						exclusion: 0,
						deposit: {
							count: 0,
							total: 0
						},
						withdraw: {
							count: 0,
							total: 0
						},
					};
				} else {
					user = {
						bot: 0,
						userid: row1[0].userid,
						name: (row1[0]['anonymous'] == 1) ? '[anonymous]' : row1[0].name,
						avatar: (row1[0]['anonymous'] == 1) ? 'http://steamcdn-a.akamaihd.net/steamcommunity/public/images/avatars/fe/fef49e7fa7e1997310d705b2a6158ff8dc1cdfeb_full.jpg' : row1[0].avatar,
						balance: roundedToFixed(row1[0].balance, 2),
						rank: row1[0].rank,
						xp: row1[0].xp,
						tradelink: row1[0].tradelink,
						apikey: row1[0].apikey,
						initialized: row1[0].initialized,
						verified: row1[0].verified,
						email: row1[0].email,
						available: roundedToFixed(row1[0].available, 2),
						binds: {},
						settings: {
							'anonymous': row1[0]['anonymous'],
							'private': row1[0]['private']
						},
						restrictions: {
							play: 0,
							trade: 0,
							site: 0,
							mute: 0
						},
						exclusion: row1[0]['exclusion'],
						deposit: {
							count: row1[0]['deposit_count'],
							total: row1[0]['deposit_total']
						},
						withdraw: {
							count: row1[0]['withdraw_count'],
							total: row1[0]['withdraw_total']
						}
					};
				}
				
				if(users_requests[user.userid] === undefined) users_requests[user.userid] = { timeouts: {}, value: false };
				if(users_online[user.userid] === undefined) users_online[user.userid] = { count: 0, user: {
					userid: user.userid,
					name: user.name,
					avatar: user.avatar,
					level: calculateLevel(user.xp).level,
					rank: user.rank,
					guest: row1.length == 0
				} };
				
				var hrtime = process.hrtime();
				var nanotime = hrtime[0] * 1000000000 + hrtime[1];
				
				if(users_flood[user.userid] === undefined) users_flood[user.userid] = { time: nanotime, count: 0};
				
				//var pages = [];
				//for(var i = 0; i < 2) if(paths[i] !== undefined) pages.push(paths[i]);
				
				socket.join(user.userid);
				//socket.join(pages.join('_'));
				socket.join(paths[0]);
				
				users_online[user.userid].count++;
				
				logger.debug('[SERVER] User with userid ' + user.userid + ' is connected');
				
				//CHAT
				var user_chatMessages = [];
				chat_massages.forEach(function(message){
					if(message.channel == join_data.channel || message.type == 'system') user_chatMessages.push(message);
				});
				
				if(config.config_chat.greeting.active) {
					user_chatMessages.push({
						type: 'system',
						message: config.config_chat.greeting.message,
						time: new Date().getTime()
					});
				}
				
				if(chat_userLastMessage[user.userid] === undefined) chat_userLastMessage[user.userid] = time();
				
				var user_commands = []
				chat_commandsRank[user.rank].forEach(function(item){
					if(chat_commandsList[item] == 'userid' || chat_commandsList[item] == 'id'){
						user_commands.push({
							name: item,
							type: chat_commandsList[item]
						});
					}
				});
				
				//JACKPOT
				var user_jackpotFair = {
					server_seed_hashed: sha256(jackpotGame.server_seed),
					nonce: jackpotGame.id
				};
				
				if(jackpotGame.status == 'eos'){
					user_jackpotFair.block = jackpotGame.block;
				} else if(jackpotGame.status == 'rolling'){
					user_jackpotFair.server_seed = jackpotGame.server_seed;
					user_jackpotFair.public_seed = jackpotGame.public_seed;
					user_jackpotFair.block = jackpotGame.block;
				}
				
				var user_jackpotChance = 0;
				
				if(jackpotGame_usersBets[user.userid] !== undefined && jackpotGame_usersBets[user.userid].total > 0) {
					user_jackpotChance = roundedToFixed(parseFloat(jackpotGame_usersBets[user.userid].amount / jackpotGame_totalAmounts * 100), 2);
				}
				
				//CRASH
				var user_chashBetsWin = [];
				var user_chashBetsLose = [];
				
				if(crashGame_totalBets.length > 0){
					crashGame_totalBets.forEach(function(bet){
						if(crashGame_userBets[bet.user.userid] !== undefined){
							if(crashGame_userBets[bet.user.userid]['cashedout'] == true) {
								user_chashBetsWin.push({
									id: bet.id,
									cashout: roundedToFixed(parseFloat(crashGame_userBets[bet.user.userid]['point_cashedout'] / 100), 2),
									profit: getFormatAmount(crashGame_userBets[bet.user.userid]['amount'] * crashGame_userBets[bet.user.userid]['point_cashedout'] / 100 - crashGame_userBets[bet.user.userid]['amount'])
								});
							} else if((!crashGame_userBets[bet.user.userid]['infinity_cashout'] && crashGame_userBets[bet.user.userid]['auto_cashout'] < crashGame_settings.point) || crashGame.status == 'ended'){
								user_chashBetsLose.push({
									id: bet.id
								});
							}
						}
					});
				}
				
				//COINFLIP
				var user_coinflipBets = [];
				
				for(var bet in coinflipGame_games){
					var coinflip_data = {};
					
					coinflip_data.game = {
						server_seed_hashed: sha256(coinflipGame_games[bet].game.server_seed),
						nonce: bet
					};
					
					if(coinflipGame_games[bet].status == 1) {
						coinflip_data.time = config.config_games.games.coinflip.timer_wait_start - time() + coinflipGame_games[bet].time
					} else if(coinflipGame_games[bet].status == 2) {
						coinflip_data.game.block = coinflipGame_games[bet].game.block;
					} else if(coinflipGame_games[bet].status == 3) {
						coinflip_data.winner = coinflipGame_getWinner(bet);
						
						coinflip_data.game.block = coinflipGame_games[bet].game.block;
					} else if(coinflipGame_games[bet].status == 4) {
						coinflip_data.winner = coinflipGame_getWinner(bet);
						
						coinflip_data.game.server_seed = coinflipGame_games[bet].game.server_seed;
						coinflip_data.game.public_seed = coinflipGame_games[bet].game.public_seed;
						coinflip_data.game.block = coinflipGame_games[bet].game.block;
					}
					
					user_coinflipBets.push({
						status: coinflipGame_games[bet].status,
						coinflip: {
							id: bet,
							players: coinflipGame_games[bet].players,
							amount: coinflipGame_games[bet].amount,
							data: coinflip_data
						}
					});
				}
				
				//CASE BATTLE
				var user_casebattleBets = [];
				
				for(var bet in casebattleGame_games){
					if(!casebattleGame_games[bet].privacy){
						var casebattle_data = {};
						
						casebattle_data.game = {};
						
						if(casebattleGame_games[bet].status == 3) {
							casebattle_data.countdown = config.config_games.games.casebattle.timer_countdown;
						} else if(casebattleGame_games[bet].status == 4) {
							casebattle_data.round = casebattleGame_games[bet].round;
						} else if(casebattleGame_games[bet].status == 5) {
							casebattle_data.winners = casebattleGame_getWinners(casebattleGame_games[bet].players, casebattleGame_games[bet].mode, false);
						}
						
						user_casebattleBets.push({
							status: casebattleGame_games[bet].status,
							casebattle: {
								id: bet,
								players: casebattleGame_games[bet].players,
								mode: casebattleGame_games[bet].mode,
								cases: casebattleGame_games[bet].cases,
								amount: casebattleGame_games[bet].amount,
								free: casebattleGame_games[bet].free,
								time: casebattleGame_games[bet].time,
								data: casebattle_data
							}
						});
					}
				}
				
				//GAMES AMOUNTS
				var games_intervalAmounts = {};
				
				Object.keys(config.settings.games.enable).forEach(function(item){
					if(config.config_site.interval_amount[item] !== undefined) games_intervalAmounts[item] = config.config_site.interval_amount[item];
				});
				
				games_intervalAmounts['send_coins'] = config.config_site.interval_amount['send_coins'];
				
				var socket_return = {
					type: 'first',
					maintenance: row2.length > 0 && !config.config_site.maintenance_excluded.includes(config.config_site.ranks_name[user.rank]),
					alerts: site_getAlerts(),
					notifies: site_getNotifies(),
					amounts: games_intervalAmounts,
					user: {
						userid: user.userid,
						name: user.name,
						balance: user.balance,
						rank: user.rank,
						settings: user.settings,
						level: calculateLevel(user.xp)
					},
					chat: {
						messages: user_chatMessages,
						commands: user_commands,
						listignore: (chat_ignoreList[user.userid] === undefined) ? [] : chat_ignoreList[user.userid]
					},
					offers: {
						p2p_pendings: getP2PPendings(user.userid),
						steam_pendings: getSteamPendings(user.userid)
					}
				};
				
				if(paths[0] == 'roulette') {
					socket_return['roulette'] = {
						bets: rouletteGame_totalBets,
						last: rouletteGame_lastRoll,
						history: rouletteGame_lastGames,
						history100: rouletteGame_last100Games,
						info: {
							id: rouletteGame.id,
							public_seed: rouletteGame_seed.public_seed
						}
					};
				} else if(paths[0] == 'crash') {
					socket_return['crash'] = {
						history: crashGame_lastGames,
						bets_all: crashGame_totalBets,
						bets_win: user_chashBetsWin,
						bets_lose: user_chashBetsLose,
						info: {
							id: crashGame.id,
							public_seed: crashGame_seed.public_seed
						}
					};
				} else if(paths[0] == 'jackpot') {
					socket_return['jackpot'] = {
						fair: user_jackpotFair,
						avatars: jackpotGame_avatars,
						bets: jackpotGame_totalBets,
						total: jackpotGame_totalAmounts,
						chance: user_jackpotChance,
						history: jackpotGame_lastGames
					};
				} else if(paths[0] == 'coinflip') {
					socket_return['coinflip'] = {
						bets: user_coinflipBets
					};
				} else if(paths[0] == 'dice') {
					socket_return['dice'] = {
						history: diceGame_lastGames
					};
				} else if(paths[0] == 'unboxing') {
					socket_return['unboxing'] = {
						cases: casesGame_getCases(),
						history: casesGame_lastWinnings
					};
				} else if(paths[0] == 'casebattle') {
					socket_return['casebattle'] = {
						bets: user_casebattleBets,
						stats: casebattleGame_stats
					};
				} else if(paths[0] == 'minesweeper') {
					socket_return['minesweeper'] = {
						history: minesweeperGame_lastGames,
						game: {
							active: (minesweeperGame_countBets[user.userid]) ? true : false,
							total: (minesweeperGame_countBets[user.userid]) ? ((minesweeperGame_userBets[user.userid]['route'].length == 0) ? minesweeperGame_userBets[user.userid]['amount'] : getFormatAmount(minesweeperGame_generateAmount(minesweeperGame_userBets[user.userid]['amount'], minesweeperGame_userBets[user.userid]['bombs'])[minesweeperGame_userBets[user.userid]['route'].length - 1])) : 0,
							route: (minesweeperGame_countBets[user.userid]) ? minesweeperGame_userBets[user.userid]['route'] : [],
							amount: (minesweeperGame_countBets[user.userid]) ? minesweeperGame_userBets[user.userid]['amount'] : 0,
							multipliers: (minesweeperGame_countBets[user.userid]) ? config.config_games.games.minesweeper.multipliers[minesweeperGame_userBets[user.userid]['bombs']].slice(0, minesweeperGame_userBets[user.userid]['route'].length) : [],
							
						}
					};
				} else if(paths[0] == 'tower') {
					socket_return['tower'] = {
						history: towerGame_lastGames,
						game: {
							active: (towerGame_countBets[user.userid]) ? true : false,
							total: (towerGame_countBets[user.userid]) ? ((towerGame_userBets[user.userid]['route'].length == 0) ? towerGame_userBets[user.userid]['amount'] : getFormatAmount(towerGame_generateAmounts(towerGame_userBets[user.userid]['amount'])[towerGame_userBets[user.userid]['route'].length - 1])) : 0,
							route: (towerGame_countBets[user.userid]) ? towerGame_userBets[user.userid]['route'] : [],
							amount: (towerGame_countBets[user.userid]) ? towerGame_userBets[user.userid]['amount'] : 0
						},
						multipliers: config.config_games.games.tower.multipliers
					};
				} else if(paths[0] == 'plinko') {
					socket_return['plinko'] = {
						history: plinkoGame_lastGames
					};
				} else if(paths[0] == 'deposit' || paths[0] == 'withdraw') {
					if(paths[1] == 'crypto') {
						socket_return['offers']['crypto'] = {
							exchange: cryptoSystem_currencyAmount
						};
					} else if(paths[0] == 'withdraw' && paths[1] == 'steam') {
						socket_return['offers']['steam_bots'] = getSteamBots();
					}
				}
				
				//FIRST DATES
				socket.emit('message', socket_return);
				
				if(paths[0] == 'roulette') dRoulette(user, socket);
				else if(paths[0] == 'crash') dCrash(user, socket);
				else if(paths[0] == 'jackpot') dJackpot(user, socket);

				dRain(user, socket);
				
				rewards_dailyTime(user, socket);
				
				//USERS ONLINE
				io.sockets.emit('message', {
					type: 'online',
					online: Object.keys(users_online).length
				});
			});
		});
	});
	
	socket.on('request', function(request) {
		if(!user || Object.keys(user).length == 0) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Your page is now inactive! Prease refresh the page.'
			});
			return;
		}
		
		if(site_settingsUpdate){
			socket.emit('message', {
				type: 'error',
				error: 'Error: The server settings are updating. Please try again later!'
			});
			return;
		}
		
		var hrtime = process.hrtime();
		var nanotime = hrtime[0] * 1000000000 + hrtime[1];
		
		if(nanotime - users_flood[user.userid].time >= config.config_site.flood.time) users_flood[user.userid] = { time: nanotime, count: 1};
		else users_flood[user.userid].count++;
		
		if(users_flood[user.userid].count >= config.config_site.flood.count) {
			logger.debug('[SERVER] User with userid ' + user.userid + ' is disconnected for flooding');
			
			return socket_disconnect(user, socket, paths);
		}
		
		if(users_requests[user.userid].value == true){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Wait for ending last action!'
			});
			return;
		}
		
		pool.query('SELECT * FROM `maintenance` WHERE `removed` = 0', function(err1, row1) {
			if(err1) {
				logger.error(err1);
				writeError(err1);
				return;
			}
			
			pool.query('SELECT users.*, users_sessions.session FROM `users` INNER JOIN `users_sessions` ON users.userid = users_sessions.userid WHERE users_sessions.session = ' + pool.escape(session) + ' AND users_sessions.removed = 0 AND users_sessions.activated = 1 AND users_sessions.expire > ' + time(), function(err2, row2) {
				if(err2) {
					logger.error(err2);
					writeError(err2);
					return;
				}
				
				if(row1.length > 0 && !config.config_site.maintenance_excluded.includes(config.config_site.ranks_name[row2.length > 0 ? row2[0].rank : 0])){
					socket.emit('message', {
						type: 'error',
						error: 'Error: The server is now in maintenance. Please try again later!'
					});
					return;
				}
				
				if(row2.length <= 0) return userRequest_request(user, socket, request, false);
				
				pool.query('SELECT * FROM `bannedip` WHERE `ip` = ' + pool.escape(socket.client.request.headers['x-forwarded-for'] || socket.request.connection.remoteAddress) + ' AND `removed` = 0', function(err3, row3) {
					if(err3) {
						logger.error(err3);
						writeError(err3);
						return;
					}
					
					if(row3.length > 0 && !config.config_site.banip_excluded.includes(config.config_site.ranks_name[row2[0].rank])){
						socket.emit('message', {
							type: 'error',
							error: 'Error: Your IP is banned.'
						});
						return;
					}
				
					pool.query('SELECT `restriction`, `expire` FROM `users_restrictions` WHERE `removed` = 0 AND (`expire` = -1 OR `expire` > ' + pool.escape(time()) + ') AND `userid` = '+ pool.escape(user.userid), function(err4, row4){
						if(err4){
							logger.error(err4);
							writeError(err4);
							return;
						}
						
						user = {
							bot: 0,
							userid: row2[0].userid,
							username: row2[0].username,
							name: (row2[0]['anonymous'] == 1) ? '[anonymous]' : row2[0].name,
							avatar: (row2[0]['anonymous'] == 1) ? 'http://steamcdn-a.akamaihd.net/steamcommunity/public/images/avatars/fe/fef49e7fa7e1997310d705b2a6158ff8dc1cdfeb_full.jpg' : row2[0].avatar,
							balance: roundedToFixed(row2[0].balance, 2),
							rank: row2[0].rank,
							xp: row2[0].xp,
							tradelink: row2[0].tradelink,
							apikey: row2[0].apikey,
							initialized: row2[0].initialized,
							verified: row2[0].verified,
							email: row2[0].email,
							available: roundedToFixed(row2[0].available, 2),
							binds: {},
							settings: {
								'anonymous': row2[0]['anonymous'],
								'private': row2[0]['private']
							},
							restrictions: {
								play: 0,
								trade: 0,
								site: 0,
								mute: 0
							},
							exclusion: row2[0]['exclusion'],
							deposit: {
								count: row2[0]['deposit_count'],
								total: row2[0]['deposit_total']
							},
							withdraw: {
								count: row2[0]['withdraw_count'],
								total: row2[0]['withdraw_total']
							}
						};
						
						row4.forEach(function(item){
							if(user.restrictions[item.restriction] !== undefined) user.restrictions[item.restriction] = item.expire;
						});
						
						if((user.restrictions.site >= time() || user.restrictions.site == -1) && !config.config_site.ban_excluded.includes(config.config_site.ranks_name[user.rank])){
							socket.emit('message', {
								type: 'error',
								error: 'Error: You are restricted to use our site. The restriction expires ' + ((user.restrictions.site == -1) ? 'never' : makeDate(new Date(user.restrictions.site * 1000))) + '.'
							});
							return;
						}
						
						pool.query('SELECT `bind`, `bindid` FROM `users_binds` WHERE `userid` = ' + pool.escape(user.userid) + ' AND `removed` = 0', function(err5, row5) {
							if(err5) {
								logger.error(err5);
								writeError(err5);
								return;
							}
							
							row5.forEach(function(bind){
								if(Object.keys(config.settings.server.binds).filter(key => config.settings.server.binds[key] == true).includes(bind.bind)) user.binds[bind.bind] = bind.bindid;
							});
							
							return userRequest_request(user, socket, request, true);
						});
					});
				});
			});
		});
	});
	
	socket.on('disconnect', function() {
		socket_disconnect(user, socket, paths);
	});
});

function socket_disconnect(user, socket, paths){
	socket.disconnect();
	
	socket.leave(user.userid);
	socket.leave(paths[0]);
	
	if(users_online[user.userid] !== undefined) {
		users_online[user.userid].count--;
		if(users_online[user.userid].count <= 0) delete users_online[user.userid];
	}
	
	//USERS ONLINE
	io.sockets.emit('message', {
		type: 'online',
		online: Object.keys(users_online).length
	});
}

function userRequest_cooldown(userid, action, value, urgent, request){
	if(users_requests[userid].timeouts[action] !== undefined) {
		clearTimeout(users_requests[userid].timeouts[action]);
		delete users_requests[userid].timeouts[action];
	}
	
	if(value){
		users_requests[userid].timeouts[action] = setTimeout(function(){
			clearTimeout(users_requests[userid].timeouts[action]);
			delete users_requests[userid].timeouts[action];
			
			users_requests[userid].value = false;
			
			if(action == 'dice_bet') diceGame_cooldown[userid] = false;
			if(action == 'unboxing_open') unboxingGame_cooldown[userid] = false;
			if(action == 'plinko_bet') plinkoGame_cooldown[userid] = false;
			
			if(action == 'coinflip_join') {
				if(coinflipGame_secure[request.id] !== undefined) if(coinflipGame_secure[request.id][userid] !== undefined) delete coinflipGame_secure[request.id][userid];
			} else if(action == 'casebattle_join') {
				if(casebattleGame_secure[request.id] !== undefined) if(casebattleGame_secure[request.id][request.position] !== undefined) if(casebattleGame_secure[request.id][request.position][userid] !== undefined) delete casebattleGame_secure[request.id][request.position][userid];
			}
			
			logger.warn('[SERVER] Old request not finished for Userid: ' + userid + ' | Action: ' + action);
		}, 10 * 1000);
	} else {
		if(action == 'coinflip_join') {
			if(coinflipGame_secure[request.id] !== undefined) if(coinflipGame_secure[request.id][userid] !== undefined) delete coinflipGame_secure[request.id][userid];
		} else if(action == 'casebattle_join') {
			if(casebattleGame_secure[request.id] !== undefined) if(casebattleGame_secure[request.id][request.position] !== undefined) if(casebattleGame_secure[request.id][request.position][userid] !== undefined) delete casebattleGame_secure[request.id][request.position][userid];
		}
	}
	
	users_requests[userid].value = value;
	
	if(value || urgent){
		if(action == 'dice_bet') diceGame_cooldown[userid] = value;
		if(action == 'unboxing_open') unboxingGame_cooldown[userid] = value;
		if(action == 'plinko_bet') plinkoGame_cooldown[userid] = value;
	}
}

function userRequest_request(user, socket, request, logged){
	if(request) logger.debug(user.name + '(' + user.userid + ') - New request: ' + JSON.stringify(request));
	
	function request_cooldown(value, urgent){ 
		userRequest_cooldown(user.userid, [ request.type, request.command ].join('_'), value, urgent, request); 
	}
	
	if(!logged) {
		if(request.type == 'steam' || request.type == 'p2p'){
			if(site_pricesUpdate_steam){
				socket.emit('message', {
					type: 'error',
					error: 'Error: The steam items prices are updating. Please try again later!'
				});
				return;
			}
			
			if(request.type == 'steam') if(request.command == 'load_shop') return steamSystem_withdrawInventory(user, socket, 'steam', request.game, config.config_offers.steam.withdraw_offset, request_cooldown);
			if(request.type == 'p2p') if(request.command == 'get_listings') return p2pSystem_getListings(user, socket, request.game, request_cooldown);
			
			socket.emit('message', {
				type: 'offers',
				command: 'error',
				error: 'Session expired or you are not logged in. Please refresh the page and try again.'
			});
			
			return;
		}
		
		if(request.type == 'chat') if(request.command == 'get_channel') return chat_loadChannel(user, socket, request.channel, request_cooldown);
		
		if(request.type == 'unboxing') {
			if(site_pricesUpdate_items){
				socket.emit('message', {
					type: 'error',
					error: 'Error: The server items prices are updating. Please try again later!'
				});
				return;
			}
			
			if(request.command == 'show') return casesGame_show(user, socket, request.id, request_cooldown);
			if(request.command == 'spinner') return casesGame_spinner(user, socket, request.id, request.amount, request_cooldown);
			if(request.command == 'demo') return casesGame_demo(user, socket, request.id, request.amount, request_cooldown);
		}
		
		if(request.type == 'casebattle') {
			if(site_pricesUpdate_items){
				socket.emit('message', {
					type: 'error',
					error: 'Error: The server items prices are updating. Please try again later!'
				});
				return;
			}
			
			if(request.command == 'cases') return casebattleGame_load(user, socket, request_cooldown);
			if(request.command == 'show') return casebattleGame_show(user, socket, request.id, request_cooldown);
		}
		
		socket.emit('message', {
			type: 'error',
			error: 'Error: Session expired or you are not logged in. Please refresh the page and try again.'
		});
		
		return;
	}
	
	if(!user.initialized) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Your account is not initialized. Please initialize your account and try again.'
		});
		
		return;
	}
	
	//ACCOUNT
	if(request.type == 'account') {
		if(request.command == 'save_tradelink') return user_saveTradelink(user, socket, request.tradelink, request.recaptcha, request_cooldown);
		if(request.command == 'save_apikey') return user_saveApikey(user, socket, request.apikey, request.recaptcha, request_cooldown);
		
		if(request.command == 'deposit_bonus') return user_applyDepositBonus(user, socket, request.code, request.recaptcha, request_cooldown);
		if(request.command == 'profile_settings') return user_saveProfileSettings(user, socket, request.data, request_cooldown);
		if(request.command == 'exclusion') return user_exclusionAccount(user, socket, request.exclusion, request.recaptcha, request_cooldown);
		if(request.command == 'remove_session') return user_removeSessionAccount(user, socket, request.session, request_cooldown);
		if(request.command == 'recover'){
			socket.emit('message', {
				type: 'error',
				error: 'Error: You are logged in. You can\'t recover your password!'
			});
			
			return;
		}
	}
	
	//REWARDS
	if(request.type == 'rewards'){
		if(user.exclusion > time()) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Your exclusion expires ' + makeDate(new Date(user.exclusion * 1000)) + '.'
			});
			
			return;
		}
		
		if(!user.verified) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Your account is not verified. Please verify your account and try again.'
			});
			
			return;
		}
		
		if(request.command == 'bind') return rewards_bindRedeem(user, socket, request.data, request.recaptcha, request_cooldown);
		if(request.command == 'referral_redeem') return rewards_referralRedeem(user, socket, request.data, request.recaptcha, request_cooldown);
		if(request.command == 'referral_create') return rewards_referralCreate(user, socket, request.data, request.recaptcha, request_cooldown);
		if(request.command == 'bonus_redeem') return rewards_bonusRedeem(user, socket, request.data, request.recaptcha, request_cooldown);
		if(request.command == 'bonus_create') return rewards_bonusCreate(user, socket, request.data, request.recaptcha, request_cooldown);
		if(request.command == 'daily_redeem') return rewards_dailyRedeem(user, socket, request.recaptcha, request_cooldown);
	}
	
	//AFFILIATES
	if(request.type == 'affiliates') {
		if(request.command == 'collect') return affiliates_collectAvailable(user, socket, request.recaptcha, request_cooldown);
	}
	
	//CHAT
	if(request.type == 'chat') {
		if(request.command == 'get_channel') return chat_loadChannel(user, socket, request.channel, request_cooldown);
		if(request.command == 'message') return chat_checkMessage(user, socket, request.message, request.channel, request_cooldown);
		if(request.command == 'send_coins') return user_sendCoins(user, socket, request.to, request.amount, request.recaptcha, request_cooldown);
	}
	
	//RAIN
	if(request.type == 'rain') {
		if(request.command == 'join') return rain_joinGame(user, socket, request.recaptcha, request_cooldown);
	}
	
	//FAIR
	if(request.type == 'fair') {
		if(request.command == 'save_clientseed') return fair_changeClientSeed(user, socket, request.seed, request.recaptcha, request_cooldown);
		if(request.command == 'regenerate_serverseed') return fair_regenerateServerSeed(user, socket, request.recaptcha, request_cooldown);
	}
	
	//DAILY CASES
	if(request.type == 'dailycases') {
		if(site_pricesUpdate_items){
			socket.emit('message', {
				type: 'error',
				error: 'Error: The server items prices are updating. Please try again later!'
			});
			return;
		}
		
		if(request.command == 'cases') return dailycases_getCases(user, socket, request_cooldown);
		if(request.command == 'get') return dailycases_getCase(user, socket, request.id, request_cooldown);
		if(request.command == 'open') return dailycases_openCase(user, socket, request.id, request_cooldown);
	}
	
	//INVENTORY
	if(request.type == 'inventory') {
		if(site_pricesUpdate_items){
			socket.emit('message', {
				type: 'error',
				error: 'Error: The server items prices are updating. Please try again later!'
			});
			return;
		}
		
		if(request.command == 'sell_item') return user_inventorySellItem(user, socket, request.id, request_cooldown);
		if(request.command == 'sell_all') return user_inventorySellAll(user, socket, request_cooldown);
	}
	
	//GAME BOTS
	if(request.type == 'gamebots') {
		if(request.command == 'show') return gamebots_showBots(user, socket, request.game, request.data, request_cooldown);
		if(request.command == 'confirm') return gamebots_confirmBot(user, socket, request.userid, request.game, request.data, request_cooldown);
	}
	
	//DASHBOARD
	if(request.type == 'dashboard') {
		if(request.command == 'graph') return dashboard_getGraph(user, socket, request.graph, request_cooldown);
		if(request.command == 'graphs') return dashboard_getAllGraphs(user, socket, request.graphs, request_cooldown);
		if(request.command == 'stats') return dashboard_getAllStats(user, socket, request.stats, request_cooldown);
	}
	
	//ADMIN
	if(request.type == 'admin') {
		if(site_pricesUpdate_items && (request.command == 'casecreator_create' || request.command == 'casecreator_remove' || request.command == 'casecreator_cases' || request.command == 'casecreator_get' || request.command == 'casecreator_edit')){
			socket.emit('message', {
				type: 'error',
				error: 'Error: The server items prices are updating. Please try again later!'
			});
			return;
		}
		
		if(request.command == 'maintenance') return admin_setMaintenance(user, socket, request.status, request.reason, request.secret, request_cooldown);
		if(request.command == 'settings') return admin_setSettings(user, socket, request.settings, request.status, request_cooldown);
		if(request.command == 'remove_bind') return admin_userRemoveBind(user, socket, request.userid, request.bind, request.secret, request_cooldown);
		if(request.command == 'remove_exclusion') return admin_userRemoveExclusion(user, socket, request.userid, request.secret, request_cooldown);
		if(request.command == 'remove_sessions') return admin_userRemoveSessions(user, socket, request.userid, request.secret, request_cooldown);
		if(request.command == 'ban_ip') return admin_userBanIp(user, socket, request.userid, request.ip, request.secret, request_cooldown);
		if(request.command == 'unban_ip') return admin_userUnbanIp(user, socket, request.userid, request.ip, request.secret, request_cooldown);
		if(request.command == 'set_rank') return admin_userSetRank(user, socket, request.userid, request.rank, request.secret, request_cooldown);
		if(request.command == 'edit_balance') return admin_userEditBalance(user, socket, request.userid, request.amount, request.secret, request_cooldown);
		if(request.command == 'set_restriction') return admin_userSetRestriction(user, socket, request.userid, request.restriction, request.time, request.reason, request.secret, request_cooldown);
		if(request.command == 'unset_restriction') return admin_userUnsetRestriction(user, socket, request.userid, request.restriction, request.secret, request_cooldown);
		if(request.command == 'join_referral_create') return admin_joinReferralCreate(user, socket, request.expire, request.usage, request.secret, request_cooldown);
		if(request.command == 'join_referral_remove') return admin_joinReferralRemove(user, socket, request.id, request.secret, request_cooldown);
		
		if(request.command == 'deposit_bonus_create') return admin_depositBonusCreate(user, socket, request.referral, request.code, request.secret, request_cooldown);
		if(request.command == 'deposit_bonus_remove') return admin_depositBonusRemove(user, socket, request.id, request.secret, request_cooldown);
		
		if(request.command == 'trade_confirm') return admin_tradeConfirm(user, socket, request.method, request.trade, request.secret, request_cooldown);
		if(request.command == 'trade_cancel') return admin_tradeCancel(user, socket, request.method, request.trade, request.secret, request_cooldown);
		if(request.command == 'trades_manually_amount') return admin_tradesManuallyAmount(user, socket, request.amount, request.secret, request_cooldown);
		
		if(request.command == 'admin_access_set') return admin_adminAccessSet(user, socket, request.userid, request.secret, request_cooldown);
		if(request.command == 'admin_access_unset') return admin_adminAccessUnset(user, socket, request.userid, request.secret, request_cooldown);
		if(request.command == 'dashboard_access_set') return admin_dashboardAccessSet(user, socket, request.userid, request.secret, request_cooldown);
		if(request.command == 'dashboard_access_unset') return admin_dashboardAccessUnset(user, socket, request.userid, request.secret, request_cooldown);
		
		if(request.command == 'alert_set') return admin_alertSet(user, socket, request.alert, request.secret, request_cooldown);
		if(request.command == 'alert_unset') return admin_alertUnset(user, socket, request.id, request.secret, request_cooldown);
		if(request.command == 'notify_set') return admin_notifySet(user, socket, request.notify, request.secret, request_cooldown);
		if(request.command == 'notify_unset') return admin_notifyUnset(user, socket, request.id, request.secret, request_cooldown);
		
		if(request.command == 'casecreator_create') {
			if(request.creator == 'cases') return admin_casecreatorCreateCases(user, socket, request.name, request.image, request.items, request.data, request.secret, request_cooldown);
			if(request.creator == 'dailycases') return admin_casecreatorCreateDailycases(user, socket, request.name, request.image, request.items, request.data, request.secret, request_cooldown);
		}
		
		if(request.command == 'casecreator_remove') {
			if(request.creator == 'cases') return admin_casecreatorRemoveCases(user, socket, request.id, request.secret, request_cooldown);
			if(request.creator == 'dailycases') return admin_casecreatorRemoveDailycases(user, socket, request.id, request.secret, request_cooldown);
		}
		
		if(request.command == 'casecreator_cases') return admin_casecreatorCases(user, socket, request.creator, request_cooldown);
		
		if(request.command == 'casecreator_get') {
			if(request.creator == 'cases') return admin_casecreatorGetCases(user, socket, request.id, request_cooldown);
			if(request.creator == 'dailycases') return admin_casecreatorGetDailycases(user, socket, request.id, request_cooldown);
		}
		
		if(request.command == 'casecreator_edit') {
			if(request.creator == 'cases') return admin_casecreatorEditCases(user, socket, request.id, request.name, request.image, request.items, request.data, request.secret, request_cooldown);
			if(request.creator == 'dailycases') return admin_casecreatorEditDailycases(user, socket, request.id, request.name, request.image, request.items, request.data, request.secret, request_cooldown);
		}
		
		if(request.command == 'gamebots_create') return admin_gamebotsCreate(user, socket, request.name, request.secret, request_cooldown);
	}
	
	//PAGINATION
	if(request.type == 'pagination') {
		if(site_pricesUpdate_items && (request.command == 'inventory_items' || request.command == 'casecreator_items' || request.command == 'upgrader_myitems' || request.command == 'upgrader_siteitems')){
			socket.emit('message', {
				type: 'error',
				error: 'Error: The server items prices are updating. Please try again later!'
			});
			return;
		}
		
		if(request.command == 'admin_users') return admin_getUsers(user, socket, request.page, request.order, request.search, request_cooldown);
		if(request.command == 'admin_crypto_confirmations') return admin_cryptoConfirmations(user, socket, request.page, request_cooldown);
		if(request.command == 'admin_steam_confirmations') return admin_steamConfirmations(user, socket, request.page, request_cooldown);
		if(request.command == 'admin_join_referrals') return admin_joinReferrals(user, socket, request.page, request.search, request_cooldown);
		if(request.command == 'admin_deposit_bonuses') return admin_depositBonuses(user, socket, request.page, request.search, request_cooldown);
		
		if(request.command == 'user_transactions') return user_userTransactions(user, socket, request.page, request.userid, request_cooldown);
		if(request.command == 'user_transfers') return user_userTransfers(user, socket, request.page, request.userid, request_cooldown);
		if(request.command == 'inventory_items') return user_inventoryItems(user, socket, request.page, user.userid, request_cooldown);
		
		if(request.command == 'crypto_transactions') return user_cryptoTransactions(user, socket, request.page, request.userid, request_cooldown);
		
		if(request.command == 'steam_transactions') return user_steamTransactions(user, socket, request.page, request.userid, request_cooldown);
		if(request.command == 'p2p_transactions') return user_p2pTransactions(user, socket, request.page, request.userid, request_cooldown);
		
		if(request.command == 'casecreator_items') return admin_casecreatorItems(user, socket, request.page, request.order, request.search, request_cooldown);
		
		if(request.command == 'upgrader_myitems') return upgraderGame_myItems(user, socket, request.page, request.order, request_cooldown);
		if(request.command == 'upgrader_siteitems') return upgraderGame_siteItems(user, socket, request.page, request.order, request.search, request.items, request.amount, request.multiplier, request_cooldown);
		
		if(request.command == 'admin_gamebots') return admin_getGamebots(user, socket, request.page, request.order, request.search, request_cooldown);
	}
	
	//GAMES
	if(request.type == 'roulette' || request.type == 'crash' || request.type == 'jackpot' || request.type == 'coinflip' || request.type == 'dice' || request.type == 'unboxing' || request.type == 'casebattle' || request.type == 'upgrader' || request.type == 'minesweeper' || request.type == 'tower' || request.type == 'plinko'){
		if(!config.settings.games.status && !config.config_site.playoffline_allowed.includes(config.config_site.ranks_name[user.rank])){
			socket.emit('message', {
				type: 'error',
				error: 'Error: The server bets is now offline. Please try again later!'
			});
			
			return;
		}
		
		if((config.settings.games.enable[request.type] === undefined || !config.settings.games.enable[request.type]) && !config.config_site.playoffline_allowed.includes(config.config_site.ranks_name[user.rank])){
			socket.emit('message', {
				type: 'error',
				error: 'Error: This game is offline. Please try again later!'
			});
			
			return;
		}
		
		if((user.restrictions.play >= time() || user.restrictions.play == -1) && !config.config_site.banplay_excluded.includes(config.config_site.ranks_name[user.rank])){
			socket.emit('message', {
				type: 'error',
				error: 'Error: You are restricted to use our games. The restriction expires ' + ((user.restrictions.play == -1) ? 'never' : makeDate(new Date(user.restrictions.play * 1000))) + '.'
			});
			
			return;
		}
		
		if(user.exclusion > time() && !(request.type == 'unboxing' && (request.command == 'show' || request.command == 'demo'))) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Your exclusion expires ' + makeDate(new Date(user.exclusion * 1000)) + '.'
			});
			
			return;
		}
		
		if(request.type == 'roulette') {
			if(request.command == 'bet') return rouletteGame_bet(user, socket, request.amount, request.color, request_cooldown);	
		}
		
		if(request.type == 'crash') {
			if(request.command == 'bet') return crashGame_bet(user, socket, request.amount, request.auto, request_cooldown);
			if(request.command == 'cashout') return crashGame_cashout(user, socket, request_cooldown);
			//if(request.command == 'prebet') return crashGame_prebet(user, socket, request.amount, request.auto, request_cooldown);
		}
		
		if(request.type == 'jackpot') {
			if(request.command == 'bet') return jackpotGame_bet(user, socket, request.amount, request_cooldown);
		}
		
		if(request.type == 'coinflip') {
			if(request.command == 'create') return coinflipGame_create(user, socket, request.amount, request.position, request_cooldown);
			if(request.command == 'join') return coinflipGame_join(user, socket, request.id, request_cooldown);
		}
		
		if(request.type == 'dice') {
			if(request.command == 'bet') return diceGame_bet(user, socket, request.amount, request.chance, request.game, request.slow, request_cooldown);
		}
		
		if(request.type == 'unboxing') {
			if(site_pricesUpdate_items){
				socket.emit('message', {
					type: 'error',
					error: 'Error: The server items prices are updating. Please try again later!'
				});
				return;
			}
			
			if(request.command == 'show') return casesGame_show(user, socket, request.id, request_cooldown);
			if(request.command == 'spinner') return casesGame_spinner(user, socket, request.id, request.amount, request_cooldown);
			if(request.command == 'demo') return casesGame_demo(user, socket, request.id, request.amount, request_cooldown);
			if(request.command == 'open') return casesGame_open(user, socket, request.id, request.amount, request_cooldown);
		}
		
		if(request.type == 'casebattle') {
			if(site_pricesUpdate_items){
				socket.emit('message', {
					type: 'error',
					error: 'Error: The server items prices are updating. Please try again later!'
				});
				return;
			}
			
			if(request.command == 'finished') return casebattleGame_finished(user, socket, request_cooldown);
			if(request.command == 'my') return casebattleGame_my(user, socket, request_cooldown);
			
			if(request.command == 'cases') return casebattleGame_load(user, socket, request_cooldown);
			if(request.command == 'show') return casebattleGame_show(user, socket, request.id, request_cooldown);
			if(request.command == 'create') return casebattleGame_create(user, socket, request.cases, request.mode, request.privacy, request.free, request_cooldown);
			if(request.command == 'join') return casebattleGame_join(user, socket, request.id, request.position, request_cooldown);
			if(request.command == 'leave') return casebattleGame_leave(user, socket, request.id, request.position, request_cooldown);
		}
		
		if(request.type == 'upgrader') {
			if(site_pricesUpdate_items){
				socket.emit('message', {
					type: 'error',
					error: 'Error: The server items prices are updating. Please try again later!'
				});
				return;
			}
			
			if(request.command == 'chance') return upgraderGame_getChance(user, socket, request.myitems, request.siteitems, request.amount, request_cooldown);
			if(request.command == 'bet') return upgraderGame_bet(user, socket, request.myitems, request.siteitems, request.amount, request.game, request_cooldown);
		}
		
		if(request.type == 'minesweeper') {
			if(request.command == 'bet') return minesweeperGame_bet(user, socket, request.amount, request.bombs, request_cooldown);
			if(request.command == 'cashout') return minesweeperGame_cashout(user, socket, request_cooldown);
			if(request.command == 'bomb') return minesweeperGame_bomb(user, socket, request.bomb, request_cooldown);
		}
		
		if(request.type == 'tower') {
			if(request.command == 'bet') return towerGame_bet(user, socket, request.amount, request_cooldown);
			if(request.command == 'cashout') return towerGame_cashout(user, socket, request_cooldown);
			if(request.command == 'stage') return towerGame_stage(user, socket, request.stage, request.button, request_cooldown);
		}
		
		if(request.type == 'plinko') {
			if(request.command == 'bet') return plinkoGame_bet(user, socket, request.amount, request.game, request_cooldown);
		}
	}
	
	//OFFERS
	if(request.type == 'steam' || request.type == 'p2p' || request.type == 'currency'){	
		if(!config.settings.trades.status && !config.config_site.tradeoffline_allowed.includes(config.config_site.ranks_name[user.rank])){
			if(request.type == 'steam' || request.type == 'p2p'){
				socket.emit('message', {
					type: 'offers',
					command: 'error',
					error: 'The server trades is now offline. Try again later!'
				});
			} else if(request.type == 'currency'){
				socket.emit('message', {
					type: 'error',
					error: 'The server trades is now offline. Try again later!'
				});
			}
			
			return;
		}
		
		if(site_pricesUpdate_steam && (request.type == 'steam' || request.type == 'p2p')){
			socket.emit('message', {
				type: 'error',
				error: 'Error: The steam items prices are updating. Please try again later!'
			});
			return;
		}
		
		if(request.type == 'steam'){
			if(request.command == 'load_inventory') return steamSystem_depositInventory(user, socket, 'steam', request.game, config.config_offers.steam.deposit_offset, request_cooldown);
			if(request.command == 'load_shop') return steamSystem_withdrawInventory(user, socket, 'steam', request.game, config.config_offers.steam.withdraw_offset, request_cooldown);
			if(request.command == 'deposit') return steamSystem_deposit(user, socket, request.game, request.items, request.refill, request.recaptcha, request_cooldown);
			if(request.command == 'withdraw') return steamSystem_withdraw(user, socket, request.game, request.items, request.bot, request.recaptcha, request_cooldown);
		}
		
		if(request.type == 'p2p'){
			if(request.command == 'create_listing') return p2pSystem_listingBundle(user, socket, request.items, request.offset, request.game, request.recaptcha, request_cooldown);
			if(request.command == 'load_inventory') return steamSystem_depositInventory(user, socket, 'p2p', request.game, 0, request_cooldown);
			if(request.command == 'load_shop') return p2pSystem_getListings(user, socket, request.game, request_cooldown);
			
			if(request.command == 'cancel_listing') return p2pSystem_cancelBundle(user, socket, request.id, request.recaptcha, request_cooldown);
			if(request.command == 'buy_listing') return p2pSystem_buyBundle(user, socket, user.binds['steam'], request.bundles, request.recaptcha, request_cooldown);
			if(request.command == 'confirm_listing') return p2pSystem_confirmBundle(user, socket, request.id, request.recaptcha, request_cooldown);
		}
		
		if(request.type == 'currency') {
			if(site_pricesUpdate_crypto){
				socket.emit('message', {
					type: 'error',
					error: 'Error: The ctypto currencies prices are updating. Please try again later!'
				});
				return;
			}
			
			if(request.command == 'generate_address') return cryptoSystem_generateAddress(user, socket, request.currency, request.recaptcha, request_cooldown);
			if(request.command == 'withdraw') return cryptoSystem_withdraw(user, socket, request.currency, request.amount, request.address, request.recaptcha, request_cooldown);
		}
	}
	
	socket.emit('message', {
		type: 'error',
		error: 'Error: This is a null request! Please refresh the page.'
	});
}

function dRain(user, socket){
	socket.emit('message', {
		type: 'rain',
		command: 'ended'
	});
	
	if(rain_game.status != 'wait'){
		if(rain_userBets[user.userid] === undefined){
			if(rain_game.status == 'started'){
				socket.emit('message', {
					type: 'rain',
					command: 'started'
				});
			} else {
				socket.emit('message', {
					type: 'rain',
					command: 'waiting'
				});
			}
		} else {
			socket.emit('message', {
				type: 'rain',
				command: 'joined'
			});
		}
	}
}

function dJackpot(user, socket){
	if(jackpotGame.status == 'rolling'){
		io.sockets.in('jackpot').emit('message', {
			type: 'jackpot',
			command: 'roll',
			avatars: jackpotGame_settings.avatars_rolling,
			cooldown: new Date().getTime() - jackpotGame_settings.start_time
		});
		
	} else if(jackpotGame.status == 'picking'){
		io.sockets.in('jackpot').emit('message', {
			type: 'jackpot',
			command: 'picking'
		});
	}
}

function dRoulette(user, socket){
	if(rouletteGame.status == 'rolling'){
		io.sockets.in('roulette').emit('message', {
			type: 'roulette',
			command: 'timer',
			time: 0
		});
		
		io.sockets.in('roulette').emit('message', {
			type: 'roulette',
			command: 'roll',
			roll: {
				id: rouletteGame.id,
				roll: rouletteGame.roll,
				color: rouletteGame.color,
				progress: rouletteGame.progress
			},
			cooldown: config.config_games.games.roulette.cooldown_rolling - rouletteGame_settings.timer - 3
		});
	} else {
		if(rouletteGame_settings.timer - config.config_games.games.roulette.cooldown_rolling >= 0){
			io.sockets.in('roulette').emit('message', {
				type: 'roulette',
				command: 'timer',
				time: rouletteGame_settings.timer - config.config_games.games.roulette.cooldown_rolling
			});
		}
	}
}

function dCrash(user, socket){
	if(crashGame.status == 'started'){
		io.sockets.in('crash').emit('message', {
			type: 'crash',
			command: 'reset'
		});
		
		io.sockets.in('crash').emit('message', {
			type: 'crash',
			command: 'starting',
			time: (crashGame_settings.start_time > 0) ? parseInt(config.config_games.games.crash.timer * 1000 - new Date().getTime() + crashGame_settings.start_time) : parseInt(config.config_games.games.crash.timer * 1000)
		});
		
	} else if(crashGame.status == 'counting'){
		io.sockets.in('crash').emit('message', {
			type: 'crash',
			command: 'started',
			difference: new Date().getTime() - crashGame_settings.progress_time
		});
		
		if(crashGame_userBets[user.userid] !== undefined){
			if(crashGame_userBets[user.userid]['cashedout'] == true){
				var winning = getFormatAmount(crashGame_userBets[user.userid]['amount'] * crashGame_userBets[user.userid]['point_cashedout'] / 100);
				
				io.sockets.in(user.userid).emit('message', {
					type: 'crash',
					command: 'cashed_out',
					amount: winning
				});
			}
		}
	} else if(crashGame.status == 'ended'){
		io.sockets.in('crash').emit('message', {
			type: 'crash',
			command: 'crashed',
			number: crashGame.roll,
			time: crashGame_settings.end_time,
			history: false
		});
		
		if(crashGame_userBets[user.userid] !== undefined){
			if(crashGame_userBets[user.userid]['cashedout'] == true){
				var winning = getFormatAmount(crashGame_userBets[user.userid]['amount'] * crashGame_userBets[user.userid]['point_cashedout'] / 100);
				
				io.sockets.in(user.userid).emit('message', {
					type: 'crash',
					command: 'cashed_out',
					amount: winning
				});
			}
		}
	}
}

/* -------------- END CONNECT TO SOCKET -------------- */

eval(fs.readFileSync('./scripts/site.js')+''); //LOAD SITE SCRIPT
eval(fs.readFileSync('./scripts/user.js')+''); //LOAD USER SCRIPT

eval(fs.readFileSync('./scripts/fair.js')+''); //LOAD FAIR SCRIPT

eval(fs.readFileSync('./scripts/items.js') + ''); //LOAD ITEMS SCRIPT

eval(fs.readFileSync('./scripts/dailycases.js') + ''); //LOAD DAILY CASES SCRIPT

eval(fs.readFileSync('./scripts/games/roulette.js')+''); //LOAD ROULETTE SCRIPT
eval(fs.readFileSync('./scripts/games/crash.js')+''); //LOAD CRASH SCRIPT
eval(fs.readFileSync('./scripts/games/jackpot.js')+''); //LOAD JACKPOT SCRIPT
eval(fs.readFileSync('./scripts/games/coinflip.js')+''); //LOAD COINFLIP SCRIPT
eval(fs.readFileSync('./scripts/games/dice.js')+''); //LOAD DICE SCRIPT
eval(fs.readFileSync('./scripts/games/unboxing.js')+''); //LOAD UNBOXING SCRIPT
eval(fs.readFileSync('./scripts/games/casebattle.js')+''); //LOAD CASE BATTLE SCRIPT
eval(fs.readFileSync('./scripts/games/upgrader.js')+''); //LOAD UPGRADER SCRIPT
eval(fs.readFileSync('./scripts/games/minesweeper.js')+''); //LOAD MINESWEEPER SCRIPT
eval(fs.readFileSync('./scripts/games/tower.js')+''); //LOAD TOWER SCRIPT
eval(fs.readFileSync('./scripts/games/plinko.js')+''); //LOAD PLINKO SCRIPT

eval(fs.readFileSync('./scripts/rewards.js')+''); //LOAD REWARDS SCRIPT
eval(fs.readFileSync('./scripts/affiliates.js')+''); //LOAD AFFILIATES SCRIPT

eval(fs.readFileSync('./scripts/rain.js')+''); //LOAD RAIN SCRIPT

eval(fs.readFileSync('./scripts/chat.js')+''); //LOAD CHAT SCRIPT

eval(fs.readFileSync('./scripts/trading/steam_bot.js')+''); //LOAD BOT SCRIPT
eval(fs.readFileSync('./scripts/trading/steam.js')+''); //LOAD STEAM SCRIPT
eval(fs.readFileSync('./scripts/trading/crypto.js')+''); //LOAD CRYPTO SCRIPT
eval(fs.readFileSync('./scripts/trading/p2p.js')+''); //LOAD P2P SCRIPT

eval(fs.readFileSync('./scripts/prices.js')+''); //LOAD PRICES SCRIPT

eval(fs.readFileSync('./scripts/dashboard.js')+''); //LOAD DASHBOARD SCRIPT
eval(fs.readFileSync('./scripts/admin.js')+''); //LOAD ADMIN SCRIPT

eval(fs.readFileSync('./scripts/mailer.js')+''); //LOAD MAILER SCRIPT

function getColorByQuality(quality){
	return {
		'consumer_grade': '#b0c3d9',
		'mil_spec_grade': '#4b69ff',
		'industrial_grade': '#5e98d9',
		'restricted': '#8847ff',
		'classified': '#d32ce6',
		'covert': '#eb4b4b',
		'base_grade': '#b0c3d9',
		'extraordinary': '#eb4b4b',
		'high_grade': '#4b69ff',
		'remarkable': '#8847ff',
		'exotic': '#d32ce6',
		'contraband': '#e4ae39',
		'distinguished': '#4b69ff',
		'exceptional': '#8847ff',
		'superior': '#d32ce6',
		'master': '#eb4b4b'
	}[quality];
}

function generateItem(item, data){
	var new_item = {
		'id': item.assetid || item.id || null,
		'game': item.game || null,
		'name': item.name || null,
		'image': item.image || null,
		'price': item.price || 0,
		'offset': item.offset || 0,
		'color': item.color || null,
		'stickers': item.stickers || [],
		'wear': item.wear || null,
	};
	
	Object.keys(data).forEach(function(prop){
		if(new_item[prop] !== undefined){
			new_item[prop] = data[prop];
		}
	});
	
	return new_item;
}

function getSqlItems(items){
	return JSON.stringify({items});
}

function getItemsFromSql(items){
	return JSON.parse(items).items;
}

function isJsonString(string) {
    try {
        JSON.parse(string);
    } catch (e) {
        return false;
    }
	
    return true;
}

function setObjectProperty(object, path, value){
	var parts = path.split('.');
	
  	for (var i = 0; i < parts.length - 1; ++i) {
      	var key = parts[i];
    	object = object[key];
    }
	
    object[parts[parts.length - 1]] = value;
};

function getInfosByItemName(name){
	var infos = {
		brand: null,
		name: null,
		exterior: null
	}
	
	var stage1 = name.split(' | ');
	
	if(stage1.length > 0){
		infos.brand = stage1[0];
		
		if(stage1.length > 1){
			if(stage1[1].indexOf('(') >= 0 && stage1[1].indexOf(')') >= 0){
				var stage2 = stage1[1].split(' (');
				infos.name = stage2[0];
				
				var stage3 = stage2[1].split(')');
				infos.exterior = stage3[0];
			} else infos.name = stage1[1];
		}
	}
	
	return infos;
}

function lowercaseKeysObject(object) {
	return Object.keys(object).reduce((accumulator, key) => {
		accumulator[key.toLowerCase()] = object[key];
		
		return accumulator;
	}, {});
}

function getFeeFromCommission(amount, commission){
	return roundedToFixed(amount * commission / 100, 5);
}

function roundedToFixed(number, decimals){
	if(isNaN(Number(number))) return 0;
	
	number = Number((Number(number).toFixed(5)));
	
	var number_string = number.toString();
	var decimals_string = 0;
	
	if(number_string.split('.')[1] !== undefined) decimals_string = number_string.split('.')[1].length;
	
	while(decimals_string - decimals > 0) {
		number_string = number_string.slice(0, -1);
		
		decimals_string--;
	}
	
	return Number(number_string);
}

function getFormatAmount(amount){
	return roundedToFixed(amount, 2);
}

function getFormatAmountString(amount){
	return getFormatAmount(amount).toFixed(2);
}

function getXpByAmount(amount){
	var xp = parseInt(getFormatAmount(amount) * 100);
	
	if(new Date().getDay() == 0 || new Date().getDay() == 6) xp *= 2;
	
	return xp;
}

function getAvailableAmount(amount){
	return getFormatAmount(amount * config.config_site.multiplier_wager_withdraw);
}

function getAffiliateCommission(deposits, type){
	var tier = 0;
	for(tier = 0; tier < config.config_site.affiliates_requirements.length; tier++) {
		if(deposits < config.config_site.affiliates_requirements[tier]) break;
	}
	
	return tier * config.config_site.affiliates_commission[type];
}

function getSteamBots(){
	var steam_bots = [];
	
	offers_steamBots.forEach(function(item, index){
		if(item.can_trade) steam_bots.push({ index: index, active: item.active });
	});
	
	return steam_bots;
}

function getP2PPendings(userid){
	var pendings = [];
	
	//DEPOSIT
	var offers_deposit_props = Object.keys(p2pSystem_listings).filter(a => p2pSystem_listings[a].seller.user.userid == userid);
	offers_deposit_props.forEach(function(key){
		var data = {};
		
		if(p2pSystem_listings[key].status == 0) data.time = p2pSystem_listings[key].time_created;
		if(p2pSystem_listings[key].status == 1) data.time = p2pSystem_listings[key].time + config.config_offers.p2p.timer_confirm;
		if(p2pSystem_listings[key].status == 1 || p2pSystem_listings[key].status == 2 || p2pSystem_listings[key].status == 3) {
			data.user = p2pSystem_listings[key].buyer.user;
			data.steamid = p2pSystem_listings[key].buyer.steamid;
		}
		if(p2pSystem_listings[key].status == 2 || p2pSystem_listings[key].status == 3) {
			data.time = p2pSystem_listings[key].time + config.config_offers.p2p.timer_send;
			data.tradelink = p2pSystem_listings[key].tradelink;
		}
		
		pendings.push({
			id: p2pSystem_listings[key].id,
			type: 'deposit',
			method: 'p2p',
			status: p2pSystem_listings[key].status,
			items: p2pSystem_listings[key].items,
			data: data
		});
	});
	
	//WITHDRAW
	var offers_withdraw_props = Object.keys(p2pSystem_listings).filter(a => p2pSystem_listings[a].buyer.user !== undefined);
	offers_withdraw_props = offers_withdraw_props.filter(a => p2pSystem_listings[a].buyer.user.userid == userid);
	offers_withdraw_props.forEach(function(key){
		var data = {};
		
		if(p2pSystem_listings[key].status == 1) data.time =  p2pSystem_listings[key].time + config.config_offers.p2p.timer_confirm;
		if(p2pSystem_listings[key].status == 2 || p2pSystem_listings[key].status == 3) data.time =  p2pSystem_listings[key].time + config.config_offers.p2p.timer_send;
		if(p2pSystem_listings[key].status == 3) data.tradeoffer = 'https://steamcommunity.com/tradeoffer/' + p2pSystem_listings[key].tradeofferid;
		
		pendings.push({
			id: p2pSystem_listings[key].id,
			type: 'withdraw',
			method: 'p2p',
			status: p2pSystem_listings[key].status,
			items: p2pSystem_listings[key].items,
			data: data
		});
	});
	
	return pendings;
}

function getSteamPendings(userid){
	var pendings = [];
	
	var offers_props = Object.keys(offers_steamActiveOffers).filter(a => offers_steamActiveOffers[a].user.userid == userid);
	offers_props.forEach(function(key){
		var data = {
			tradeofferid: offers_steamActiveOffers[key].tradeofferid
		};
		
		if(offers_steamActiveOffers[key].status == 0 || offers_steamActiveOffers[key].status == 1) data.code = offers_steamActiveOffers[key].code;
		if(offers_steamActiveOffers[key].status == 1) data.time = offers_steamActiveOffers[key].time + config.config_offers.steam.time_cancel_trade;
		
		pendings.push({
			id: offers_steamActiveOffers[key].id,
			type: offers_steamActiveOffers[key].type,
			method: 'steam',
			status: offers_steamActiveOffers[key].status,
			items: offers_steamActiveOffers[key].items,
			data: data
		});
	});
	
	return pendings;
}

function calculateLevel(xp){
	var start = 0;
	var next = config.config_site.level.start;
	
	var level = 0;
	
	for(var i = 1; next <= xp && level < 100; i++){
		start = next;
		next += parseInt(next * config.config_site.level.next * (1.00 - 0.0095 * level));
		
		level++;
	}
	
	return {
		level: level,
		start: 0,
		next: next - start,
		have: ((xp > next) ? next : xp) - start
	};
}

function generateHexCode(length) {
    var text = '';
    var possible = 'abcdef0123456789';

    for(var i = 0; i < length; i++) text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
}

function makeDate(date){
	var months = [ 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December' ];
	
	var type_time = (date.getHours() < 12) ? 'AM' : 'PM';
	
	return '0'.concat(date.getDate()).slice(-2) + ' ' + months[date.getMonth()] + ' ' + date.getFullYear() + ', ' + ('0'.concat(date.getHours() % 12).slice(-2)) + ':' + ('0'.concat(date.getMinutes()).slice(-2)) + ' ' + type_time;
}

function dateFormat(date, format){
	var year = date.getFullYear();
	var month = date.getMonth() + 1;
	var day = date.getDate();
	var hour = date.getHours();
	var minutes = date.getMinutes();
	var seconds = date.getSeconds();
	var milliseconds = date.getMilliseconds();
	
	month = '0'.concat(month).slice(-2);
	day = '0'.concat(day).slice(-2);
	hour = '0'.concat(hour).slice(-2);
	minutes = '0'.concat(minutes).slice(-2);
	seconds = '0'.concat(seconds).slice(-2);
	milliseconds = '00'.concat(milliseconds).slice(-3);
	
	format = format.replace('sss', milliseconds);
	format = format.replace('ss', seconds);
	format = format.replace('mm', minutes);
	format = format.replace('hh', hour);
	format = format.replace('dd', day);
	format = format.replace('MM', month);
	format = format.replace('yyyy', year);
	
	return format;
}

function getFormatSeconds(time){
	var days = parseInt((time) / (24 * 60 * 60));
	var hours = parseInt((time - (days * 24 * 60 * 60)) / (60 * 60));
	var minutes = parseInt((time - (days * 24 * 60 * 60) - (hours * 60 * 60)) / (60));
	var seconds = parseInt((time - (days * 24 * 60 * 60) - (hours * 60 * 60) - (minutes * 60)));
	
	days = '0'.concat(days).slice(-2);
	hours = '0'.concat(hours).slice(-2);
	minutes = '0'.concat(minutes).slice(-2);
	seconds = '0'.concat(seconds).slice(-2);
	
	return {
		days,
		hours,
		minutes,
		seconds
	};
}

function getTimeString(string){
	var time_restriction = 0;
	
	if(string == 'permanent'){
		time_restriction = -1; //PERMANENT
	} else {
		var reg = /^([0-9]*)([a-zA-Z]*)/.exec(string);
		
		if(reg[2] == 'minutes') time_restriction = parseInt(time() + (reg[1] * 60)); //MINUTES
		else if(reg[2] == 'hours') time_restriction = parseInt(time() + (reg[1] * 60 * 60)); //HOURS
		else if(reg[2] == 'days') time_restriction = parseInt(time() + (reg[1] * 60 * 60 * 24)); //DAYS
		else if(reg[2] == 'months') time_restriction = parseInt(time() + (reg[1] * 60 * 60 * 24 * 30)); //MONTHS
		else if(reg[2] == 'years') time_restriction = parseInt(time() + (reg[1] * 60 * 60 * 24 * 30 * 12)); //YEARS
	}
	
	return time_restriction;
}

function getRandomInt(min, max) {
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

function countDecimals(value) {
    if (Math.floor(value) !== value) return value.toString().split('.')[1].length || 0;
    
	return 0;
}

function time() {
	return parseInt(new Date().getTime()/1000);
}

Object.size = function(obj) {
	var size = 0,
		key;
	for (key in obj) {
		if (obj.hasOwnProperty(key)) size++;
	}
	return size;
};

Number.prototype.format = function(n, x) {
    var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\.' : '$') + ')';
    return this.toFixed(Math.max(0, ~~n)).replace(new RegExp(re, 'g'), '$&.');
};