function admin_saveSetting(path, value, callback){
	if(site_settingsUpdate) return callback(new Error('Unable to write the server settings (1)'));
	
	site_settingsUpdate = true;
	
	var settings = { ...config.settings };
	
	setObjectProperty(settings, path, value);
	
	fs.writeFile('./settings.json', JSON.stringify(settings, null, 4), function(err1) {
		if(err1) {
			site_settingsUpdate = false;
			
			return callback(new Error('Unable to write the server settings (2)'));
		}
		
		config.settings = require('./settings.json');
		
		site_settingsUpdate = false;
		
		callback(null);
	});
}

function admin_setMaintenance(user, socket, status, reason, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	pool.query('SELECT * FROM `maintenance` WHERE `removed` = 0', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(status && row1.length > 0) {
			socket.emit('message', {
				type: 'success',
				success: 'Maintenance is already enabled!'
			});
			
			return cooldown(false, true);
		} else if(!status && row1.length <= 0) {
			socket.emit('message', {
				type: 'success',
				success: 'Maintenance is already disabled!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('UPDATE `maintenance` SET `removed` = 1 WHERE `removed` = 0', function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			if(!status) {
				socket.emit('message', {
					type: 'success',
					success: 'Maintenance disabled!'
				});
				
				io.sockets.emit('message', {
					type: 'reload'
				});
				
				return cooldown(false, true);
			}
			
			pool.query('INSERT INTO `maintenance` SET `userid` = ' + pool.escape(user.userid) + ', `reason` = ' + pool.escape(reason) + ', `time` = ' + pool.escape(time()), function(err3, row3){
				if(err3){
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				socket.emit('message', {
					type: 'success',
					success: 'Maintenance enabled!'
				});
				
				io.sockets.emit('message', {
					type: 'reload'
				});
				
				cooldown(false, false);
			});
		});
	});
}

function admin_setSettings(user, socket, settings, status, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	var settings_allowed = [
		'trades_steam_enable_deposit_csgo', 'trades_steam_enable_deposit_dota2', 'trades_steam_enable_deposit_tf2', 'trades_steam_enable_deposit_rust', 'trades_steam_enable_deposit_h1z1',
		'trades_steam_enable_withdraw_csgo', 'trades_steam_enable_withdraw_dota2', 'trades_steam_enable_withdraw_tf2', 'trades_steam_enable_withdraw_rust', 'trades_steam_enable_withdraw_h1z1',
		'trades_p2p_enable_deposit_csgo', 'trades_p2p_enable_deposit_dota2', 'trades_p2p_enable_deposit_tf2', 'trades_p2p_enable_deposit_rust', 'trades_p2p_enable_deposit_h1z1',
		'trades_p2p_enable_withdraw_csgo', 'trades_p2p_enable_withdraw_dota2', 'trades_p2p_enable_withdraw_tf2', 'trades_p2p_enable_withdraw_rust', 'trades_p2p_enable_withdraw_h1z1',
		
		'trades_crypto_enable_deposit_btc', 'trades_crypto_enable_deposit_eth', 'trades_crypto_enable_deposit_ltc', 'trades_crypto_enable_deposit_bch', 'trades_crypto_enable_deposit_usdc', 'trades_crypto_enable_deposit_usdt', 'trades_crypto_enable_deposit_doge', 'trades_crypto_enable_deposit_xrp',
		'trades_crypto_enable_withdraw_btc', 'trades_crypto_enable_withdraw_eth', 'trades_crypto_enable_withdraw_ltc', 'trades_crypto_enable_withdraw_bch', 'trades_crypto_enable_withdraw_usdc', 'trades_crypto_enable_withdraw_usdt', 'trades_crypto_enable_withdraw_doge', 'trades_crypto_enable_withdraw_xrp',
		
		'games_status', 'trades_status', 'trades_manually_enable_crypto', 'trades_manually_enable_steam',
		'games_enable_roulette', 'games_enable_crash', 'games_enable_jackpot', 'games_enable_coinflip', 'games_enable_dice', 'games_enable_unboxing', 'games_enable_casebattle', 'games_enable_upgrader', 'games_enable_tower', 'games_enable_minesweeper', 'games_enable_plinko',
		
		'games_bots_enable_coinflip', 'games_bots_enable_casebattle'
	];
	if(!settings_allowed.includes(settings)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid settings!'
		});
		
		return cooldown(false, true);
	}
	
	var settings_copy = { ...config.settings };
	settings.split('_').forEach(function(item){ settings_copy = settings_copy[item]; });
	
	if(settings_copy == status){
		socket.emit('message', {
			type: 'error',
			error: 'Property already setted!'
		});
		
		return cooldown(false, true);
	}
	
	admin_saveSetting(settings.split('_').join('.'), status, function(err1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		socket.emit('message', {
			type: 'success',
			success: 'Settings saved!'
		});
		
		socket.emit('message', {
			type: 'refresh'
		});
		
		cooldown(false, false);
	});
}

function admin_getUsers(user, socket, page, order, search, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	var order_allowed = [ 0, 1, 2, 3, 4, 5 ];
	if(!order_allowed.includes(order)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid order!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(page))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid page!'
		});
		
		return cooldown(false, true);
	}
	
	page = parseInt(page);
	search = search.trim();
	
	pool.query('SELECT `userid` FROM `users_logins` WHERE `ip` = ' + pool.escape(search) + ' GROUP BY `userid`', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		var userids = row1.map(a => '"' + a.userid + '"').join(',') || 'null';
		
		pool.query('SELECT COUNT(*) AS `count` FROM `users` WHERE `bot` = 0 AND (`userid` LIKE ' + pool.escape('%' + search + '%') + ' OR `username` LIKE ' + pool.escape('%' + search + '%') + ' OR `name` LIKE ' + pool.escape('%' + search + '%') + ' OR `userid` IN (' + userids + '))', function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			var pages = parseInt(row2[0].count / 10) + (row2[0].count % 10 > 0 ? 1 : 0);
			
			if(pages <= 0){
				socket.emit('message', {
					type: 'pagination',
					command: 'admin_users',
					list: [],
					pages: 1,
					page: 1
				});
				
				return cooldown(false, false);
			}
			
			if(page <= 0 || page > pages) {
				socket.emit('message', {
					type: 'error',
					error: 'Error: Invalid page!'
				});
				
				return cooldown(false, true);
			}
			
			var order_query = { 
				0: 'ORDER BY `time_create` ASC',
				1: 'ORDER BY `name` ASC',
				2: 'ORDER BY `name` DESC',
				3: 'ORDER BY `balance` ASC',
				4: 'ORDER BY `balance` DESC',
				5: 'ORDER BY `rank` DESC'
			}[order];
			
			pool.query('SELECT `userid`, `name`, `avatar`, `xp`,  `balance`, `rank`, `time_create` FROM `users` WHERE `bot` = 0 AND (`userid` LIKE ' + pool.escape('%' + search + '%') + ' OR `username` LIKE ' + pool.escape('%' + search + '%') + ' OR `name` LIKE ' + pool.escape('%' + search + '%') + ' OR `userid` IN (' + userids + ')) ' + order_query + ' LIMIT 10 OFFSET ' + pool.escape(page * 10 - 10), function(err3, row3){
				if(err3){
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				var list = [];
				
				row3.forEach(function(item){
					list.push({
						user: {
							userid: item.userid,
							name: item.name,
							avatar: item.avatar,
							level: calculateLevel(item.xp).level
						},
						balance: getFormatAmount(item.balance),
						rank: item.rank,
						time_create: makeDate(new Date(item.time_create * 1000))
					});
				});
				
				socket.emit('message', {
					type: 'pagination',
					command: 'admin_users',
					list: list,
					pages: pages,
					page: page
				});
				
				cooldown(false, false);
			});
		});
	});
}

function admin_userRemoveBind(user, socket, userid, bind, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	if(!Object.keys(config.settings.server.binds).filter(key => config.settings.server.binds[key] == true).includes(bind)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid bind!'
		});
		
		return cooldown(false, true);
	}
	
	pool.query('SELECT * FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Unknown user!'
			});
			
			return cooldown(false, true);
		}
	
		pool.query('SELECT * FROM `users_binds` WHERE `userid` = ' + pool.escape(userid) + ' AND `bind` = ' + pool.escape(bind) + ' AND `removed` = 0', function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			if(row2.length <= 0){
				socket.emit('message', {
					type: 'error',
					error: 'Error: User not binded with ' + bind + '!'
				});
				
				return cooldown(false, true);
			}
			
			pool.query('UPDATE `users_binds` SET `removed` = 1 WHERE `userid` = ' + pool.escape(userid) + ' AND `bind` = ' + pool.escape(bind), function(err3){
				if(err3){
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				socket.emit('message', {
					type: 'success',
					success: 'Bind removed!'
				});
				
				socket.emit('message', {
					type: 'refresh'
				});
				
				cooldown(false, false);
			});
		});
	});
}

function admin_userRemoveExclusion(user, socket, userid, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	pool.query('SELECT * FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Unknown user!'
			});
			
			return cooldown(false, true);
		}
		
		if(row1[0].exclusion <= time()){
			socket.emit('message', {
				type: 'error',
				error: 'Error: User have no exclusion!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('UPDATE `users` SET `exclusion` = 0 WHERE `userid` = ' + pool.escape(userid), function(err2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'success',
				success: 'Exclusion removed!'
			});
			
			socket.emit('message', {
				type: 'refresh'
			});
			
			cooldown(false, false);
		});
	});
}

function admin_userRemoveSessions(user, socket, userid, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	pool.query('SELECT * FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Unknown user!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('SELECT * FROM `users_sessions` WHERE `userid` = ' + pool.escape(userid) + ' AND `removed` = 0 AND `expire` > ' + pool.escape(time()), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			if(row2.length <= 0){
				socket.emit('message', {
					type: 'error',
					error: 'Error: User have no active sessions!'
				});
				
				return cooldown(false, true);
			}
			
			pool.query('UPDATE `users_sessions` SET `removed` = 1 WHERE `userid` = ' + pool.escape(userid) + ' AND `removed` = 0 AND `expire` > ' + pool.escape(time()), function(err3){
				if(err3){
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				socket.emit('message', {
					type: 'success',
					success: 'Sessions successfully removed. User has been disconnected!'
				});
				
				socket.emit('message', {
					type: 'refresh'
				});
				
				cooldown(false, false);
			});
		});
	});
}

function admin_userBanIp(user, socket, userid, ip, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	pool.query('SELECT * FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Unknown user!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('SELECT * FROM `users_logins` WHERE `userid` = ' + pool.escape(userid) + ' AND `ip` = ' + pool.escape(ip), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			if(row2.length <= 0){
				socket.emit('message', {
					type: 'error',
					error: 'Error: Unknown ip!'
				});
				
				return cooldown(false, true);
			}
			
			pool.query('SELECT * FROM `bannedip` WHERE `ip` = ' + pool.escape(ip) + ' AND `removed` = 0', function(err3, row3){
				if(err3){
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				if(row3.length > 0){
					socket.emit('message', {
						type: 'error',
						error: 'Error: Ip already banned!'
					});
					
					return cooldown(false, true);
				}
			
				pool.query('INSERT INTO `bannedip` SET `ip` = ' + pool.escape(ip) + ', `userid` = ' + pool.escape(user.userid) + ', `time` = ' + pool.escape(time()), function(err4){
					if(err4){
						logger.error(err4);
						writeError(err4);
						
						return cooldown(false, true);
					}
					
					socket.emit('message', {
						type: 'success',
						success: 'IP banned successfully!'
					});
					
					socket.emit('message', {
						type: 'refresh'
					});
					
					cooldown(false, false);
				});
			});
		});
	});
}

function admin_userUnbanIp(user, socket, userid, ip, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	pool.query('SELECT * FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Unknown user!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('SELECT * FROM `users_logins` WHERE `userid` = ' + pool.escape(userid) + ' AND `ip` = ' + pool.escape(ip), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			if(row2.length <= 0){
				socket.emit('message', {
					type: 'error',
					error: 'Error: Unknown user ip!'
				});
				
				return cooldown(false, true);
			}
			
			pool.query('SELECT * FROM `bannedip` WHERE `ip` = ' + pool.escape(ip) + ' AND `removed` = 0', function(err3, row3){
				if(err3){
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				if(row3.length <= 0){
					socket.emit('message', {
						type: 'error',
						error: 'Error: Ip not banned!'
					});
					
					return cooldown(false, true);
				}
				
				pool.query('UPDATE `bannedip` SET `removed` = 1 WHERE `ip` = ' + pool.escape(ip) + ' AND `removed` = 0', function(err4){
					if(err4){
						logger.error(err4);
						writeError(err4);
						
						return cooldown(false, true);
					}
					
					socket.emit('message', {
						type: 'success',
						success: 'IP unbanned successfully!'
					});
					
					socket.emit('message', {
						type: 'refresh'
					});
					
					cooldown(false, false);
				});
			});
		});
	});
}

function admin_userSetRank(user, socket, userid, rank, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	var allowed_ranks = [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 100 ];
	if(!allowed_ranks.includes(rank)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid rank!'
		});
		
		return cooldown(false, true);
	}
	
	pool.query('SELECT * FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Unknown user!'
			});
			
			return cooldown(false, true);
		}
		
		if(row1[0].rank == rank){
			socket.emit('message', {
				type: 'error',
				error: 'Error: User have already this rank!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('UPDATE `users` SET `rank` = ' + pool.escape(rank) + ' WHERE `userid` = ' + pool.escape(userid), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'success',
				success: 'Rank setted!'
			});
			
			socket.emit('message', {
				type: 'refresh'
			});
			
			cooldown(false, false);
		});
	});
}

function admin_userEditBalance(user, socket, userid, amount, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	site_verifyFormatAmount(amount, function(err1, amount){
		if(err1){
			socket.emit('message', {
				type: 'error',
				error: err1.message
			});
			
			return cooldown(false, true);
		}
	
		pool.query('SELECT * FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			if(row2.length <= 0){
				socket.emit('message', {
					type: 'error',
					error: 'Error: Unknown user!'
				});
				
				return cooldown(false, true);
			}
			
			if(getFormatAmount(row2[0].balance) + amount < 0) amount = -getFormatAmount(row2[0].balance);
			
			//EDIT BALANCE
			user_editBalance(userid, amount, 'change_balance', function(err3){
				if(err3) {
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				io.sockets.in(userid).emit('message', {
					type: 'info',
					info: 'You got ' + getFormatAmountString(amount) + ' coins from ' + user.name + '!'
				});
				
				socket.emit('message', {
					type: 'info',
					info: 'You gave ' + getFormatAmountString(amount) + ' coins to ' + row2[0].name + '.'
				});
				
				user_updateBalance(userid);
				
				socket.emit('message', {
					type: 'refresh'
				});
				
				cooldown(false, false);
			});
		});
	});
}

function admin_userSetRestriction(user, socket, userid, restriction, time, reason, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	user_setRestriction(user, socket, {
		userid: userid,
		restriction: restriction,
		time: time,
		reason: reason
	}, true, function(err1){
		if(err1){
			socket.emit('message', {
				type: 'error',
				error: err1.message
			});
			
			return cooldown(false, true);
		}
		
		socket.emit('message', {
			type: 'success',
			success: 'The user was successfully restricted!'
		});
		
		socket.emit('message', {
			type: 'refresh'
		});
		
		cooldown(false, false);
	});
}

function admin_userUnsetRestriction(user, socket, userid, restriction, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	user_unsetRestriction(user, socket, {
		userid: userid,
		restriction: restriction
	}, function(err1){
		if(err1){
			socket.emit('message', {
				type: 'error',
				error: err1.message
			});
			
			return cooldown(false, true);
		}
		
		socket.emit('message', {
			type: 'success',
			success: 'The user was successfully unrestricted!'
		});
		
		socket.emit('message', {
			type: 'refresh'
		});
		
		cooldown(false, false);
	});
}

function admin_adminAccessSet(user, socket, userid, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	pool.query('SELECT * FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Unknown user!'
			});
			
			return cooldown(false, true);
		}
	
		var admin_allowed = [ ...config.settings.allowed.admin ];
		
		if(admin_allowed.includes(userid)) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Userid already in list!'
			});
			
			return cooldown(false, true);
		}
		
		admin_allowed.push(userid);
		
		admin_saveSetting('allowed.admin', admin_allowed, function(err2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'success',
				success: 'Settings saved!'
			});
			
			socket.emit('message', {
				type: 'refresh'
			});
			
			cooldown(false, false);
		});
	});
}

function admin_adminAccessUnset(user, socket, userid, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	pool.query('SELECT * FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Unknown user!'
			});
			
			return cooldown(false, true);
		}
	
		var admin_allowed = [ ...config.settings.allowed.admin ];
		
		if(!admin_allowed.includes(userid)) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Userid not in list!'
			});
			
			return cooldown(false, true);
		}
		
		var index = admin_allowed.indexOf(userid);
		admin_allowed.splice(index, 1);
		
		admin_saveSetting('allowed.admin', admin_allowed, function(err2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'success',
				success: 'Settings saved!'
			});
			
			socket.emit('message', {
				type: 'refresh'
			});
			
			cooldown(false, false);
		});
	});
}

function admin_dashboardAccessSet(user, socket, userid, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	pool.query('SELECT * FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Unknown user!'
			});
			
			return cooldown(false, true);
		}
	
		var dashboard_allowed = [ ...config.settings.allowed.dashboard ];
		
		if(dashboard_allowed.includes(userid)) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Userid already in list!'
			});
			
			return cooldown(false, true);
		}
		
		dashboard_allowed.push(userid);
		
		admin_saveSetting('allowed.dashboard', dashboard_allowed, function(err2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'success',
				success: 'Settings saved!'
			});
			
			socket.emit('message', {
				type: 'refresh'
			});
			
			cooldown(false, false);
		});
	});
}

function admin_dashboardAccessUnset(user, socket, userid, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	pool.query('SELECT * FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Unknown user!'
			});
			
			return cooldown(false, true);
		}
	
		var dashboard_allowed = [ ...config.settings.allowed.dashboard ];
		
		if(!dashboard_allowed.includes(userid)) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Userid not in list!'
			});
			
			return cooldown(false, true);
		}
		
		var index = dashboard_allowed.indexOf(userid);
		dashboard_allowed.splice(index, 1);
		
		admin_saveSetting('allowed.dashboard', dashboard_allowed, function(err2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'success',
				success: 'Settings saved!'
			});
			
			socket.emit('message', {
				type: 'refresh'
			});
			
			cooldown(false, false);
		});
	});
}

function admin_alertSet(user, socket, alert, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	/* CHECK DATA */
	
	alert = alert.trim();
	
	if(alert.length <= 0) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid alert!'
		});
		
		return cooldown(false, true);
	}
	
	/* END CHECK DATA */
	
	var alerts = [ ...config.settings.server.alerts ];
	alerts.push(alert);
	
	admin_saveSetting('server.alerts', alerts, function(err1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		socket.emit('message', {
			type: 'success',
			success: 'Settings saved!'
		});
		
		socket.emit('message', {
			type: 'refresh'
		});
		
		socket.emit('message', {
			type: 'alerts',
			alerts: site_getAlerts()
		});
		
		cooldown(false, false);
	});
}

function admin_alertUnset(user, socket, id, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	/* CHECK DATA */
	
	if(isNaN(Number(id))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid id alert!'
		});
		
		return cooldown(false, true);
	}
	
	id = parseInt(id);
	
	if(id < 0){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid id alert!'
		});
		
		return cooldown(false, true);
	}
	
	/* END CHECK DATA */
	
	var alerts = [ ...config.settings.server.alerts ];
	
	if(id >= alerts.length){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid id alert!'
		});
		
		return cooldown(false, true);
	}
	
	alerts.splice(id, 1);
	
	admin_saveSetting('server.alerts', alerts, function(err1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		socket.emit('message', {
			type: 'success',
			success: 'Settings saved!'
		});
		
		socket.emit('message', {
			type: 'refresh'
		});
		
		socket.emit('message', {
			type: 'alerts',
			alerts: site_getAlerts()
		});
		
		cooldown(false, false);
	});
}

function admin_notifySet(user, socket, notify, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	/* CHECK DATA */
	
	notify = notify.trim();
	
	if(notify.length <= 0) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid notify!'
		});
		
		return cooldown(false, true);
	}
	
	/* END CHECK DATA */
	
	var notifies = [ ...config.settings.server.notifies ];
	notifies.push(notify);
	
	admin_saveSetting('server.notifies', notifies, function(err1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		socket.emit('message', {
			type: 'success',
			success: 'Settings saved!'
		});
		
		socket.emit('message', {
			type: 'refresh'
		});
		
		socket.emit('message', {
			type: 'notifies',
			notifies: site_getNotifies()
		});
		
		cooldown(false, false);
	});
}

function admin_notifyUnset(user, socket, id, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	/* CHECK DATA */
	
	if(isNaN(Number(id))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid id alert!'
		});
		
		return cooldown(false, true);
	}
	
	id = parseInt(id);
	
	if(id < 0){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid id alert!'
		});
		
		return cooldown(false, true);
	}
	
	/* END CHECK DATA */
	
	var notifies = [ ...config.settings.server.notifies ];
	
	if(id >= notifies.length){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid id alert!'
		});
		
		return cooldown(false, true);
	}
	
	notifies.splice(id, 1);
	
	admin_saveSetting('server.notifies', notifies, function(err1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		socket.emit('message', {
			type: 'success',
			success: 'Settings saved!'
		});
		
		socket.emit('message', {
			type: 'refresh'
		});
		
		socket.emit('message', {
			type: 'notifies',
			notifies: site_getNotifies()
		});
		
		cooldown(false, false);
	});
}

function admin_joinReferralCreate(user, socket, expire, usage, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	usage = usage.trim();
	
	if(usage.length < config.config_site.join_referral.usage_length.min){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You need to put a usage with minimum ' + config.config_site.join_referral.usage_length.min + ' characters!'
		});
		
		return cooldown(false, true);
	}
	
	if(usage.length > config.config_site.join_referral.usage_length.max){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You need to put a usage with maximum ' + config.config_site.join_referral.usage_length.max + ' characters!'
		});
		
		return cooldown(false, true);
	}
	
	var expire_value = getTimeString(expire);
	var referral = generateHexCode(config.config_site.join_referral.code_length);
	
	pool.query('INSERT INTO `link_referrals` SET `userid` = ' + pool.escape(user.userid) + ', `referral` = ' + pool.escape(referral) + ', `usage` = ' + pool.escape(usage) + ', `expire` = ' + pool.escape(expire_value) + ', `time` = ' + pool.escape(time()), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		socket.emit('message', {
			type: 'success',
			success: 'Referral link created successfully!'
		});
		
		socket.emit('message', {
			type: 'refresh'
		});
		
		cooldown(false, false);
	});
}

function admin_joinReferralRemove(user, socket, id, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	pool.query('SELECT * FROM `link_referrals` WHERE `id` = ' + pool.escape(id) + ' AND `removed` = 0 AND (`expire` > ' +  pool.escape(time()) + ' OR `expire` = -1)', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Unknown referral!'
			});
			
			return cooldown(false, true);
		}
	
		pool.query('UPDATE `link_referrals` SET `removed` = 1 WHERE `id` = ' + pool.escape(id) + ' AND `removed` = 0 AND (`expire` > ' +  pool.escape(time()) + ' OR `expire` = -1)', function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'success',
				success: 'Referral link removed successfully!'
			});
			
			socket.emit('message', {
				type: 'refresh'
			});
			
			cooldown(false, false);
		});
	});
}

function admin_depositBonusCreate(user, socket, referral, code, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	code = code.trim().toLowerCase();
	
	if(code.length < config.config_site.deposit_bonuses.code_length.min){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You need to put a code with minimum ' + config.config_site.deposit_bonuses.code_length.min + ' characters!'
		});
		
		return cooldown(false, true);
	}
	
	if(code.length > config.config_site.deposit_bonuses.code_length.max){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You need to put a code with maximum ' + config.config_site.deposit_bonuses.code_length.max + ' characters!'
		});
		
		return cooldown(false, true);
	}
	
	pool.query('SELECT * FROM `users` WHERE `userid` = ' + pool.escape(referral), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Unknown user referral!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('SELECT * FROM `deposit_codes` WHERE `code` = ' + pool.escape(code) + ' AND `removed` = 0', function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			if(row2.length > 0){
				socket.emit('message', {
					type: 'error',
					error: 'Error: Deposit bonus code already used!'
				});
				
				return cooldown(false, true);
			}
		
			pool.query('INSERT INTO `deposit_codes` SET `userid` = ' + pool.escape(user.userid) + ', `referral` = ' + pool.escape(row1[0].userid) + ', `code` = ' + pool.escape(code) + ', `time` = ' + pool.escape(time()), function(err3, row3){
				if(err3){
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				socket.emit('message', {
					type: 'success',
					success: 'Deposit bonus code created successfully!'
				});
				
				socket.emit('message', {
					type: 'refresh'
				});
				
				cooldown(false, false);
			});
		});
	});
}

function admin_depositBonusRemove(user, socket, id, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	pool.query('SELECT * FROM `deposit_codes` WHERE `id` = ' + pool.escape(id) + ' AND `removed` = 0', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Unknown deposit bonus code!'
			});
			
			return cooldown(false, true);
		}
	
		pool.query('UPDATE `deposit_codes` SET `removed` = 1 WHERE `id` = ' + pool.escape(id) + ' AND `removed` = 0', function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'success',
				success: 'Deposit bonus code removed successfully!'
			});
			
			socket.emit('message', {
				type: 'refresh'
			});
			
			cooldown(false, false);
		});
	});
}

function admin_tradeConfirm(user, socket, method, trade, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	var allowed_method = [ 'crypto', 'steam' ];
	if(!allowed_method.includes(method)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid method!'
		});
		
		return cooldown(false, true);
	}
	
	if(method == 'steam'){
		steamSystem_listingConfirm(user, trade, function(err1, transactionid){
			if(err1){
				socket.emit('message', {
					type: 'error',
					error: err1.message
				});
				
				return;
			}
			
			socket.emit('message', {
				type: 'info',
				info: 'Steam withdraw order was confirmed successfully!'
			});
			
			socket.emit('message', {
				type: 'refresh'
			});
			
			cooldown(false, false);
		});
	} else if(method == 'crypto') {
		cryptoSystem_listingConfirm(user, trade, function(err1, transactionid){
			if(err1){
				socket.emit('message', {
					type: 'error',
					error: err1.message
				});
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'info',
				info: 'Crypto withdraw order was confirmed successfully!'
			});
			
			socket.emit('message', {
				type: 'refresh'
			});
			
			cooldown(false, false);
		});
	}
}

function admin_tradeCancel(user, socket, method, trade, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	var allowed_method = [ 'crypto', 'steam' ];
	if(!allowed_method.includes(method)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid method!'
		});
		
		return cooldown(false, true);
	}
	
	if(method == 'steam'){
		steamSystem_listingCancel(user, trade, function(err1){
			if(err1){
				socket.emit('message', {
					type: 'error',
					error: err1.message
				});
				
				return;
			}
			
			socket.emit('message', {
				type: 'info',
				info: 'Steam withdraw order was canceled successfully!'
			});
			
			socket.emit('message', {
				type: 'refresh'
			});
			
			cooldown(false, false);
		});
	} else if(method == 'crypto') {
		cryptoSystem_listingCancel(user, trade, function(err1){
			if(err1){
				socket.emit('message', {
					type: 'error',
					error: err1.message
				});
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'info',
				info: 'Crypto withdraw order was canceled successfully!'
			});
			
			socket.emit('message', {
				type: 'refresh'
			});
			
			cooldown(false, false);
		});
	}
}

function admin_tradesManuallyAmount(user, socket, amount, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	site_verifyFormatAmount(amount, function(err1, amount){
		if(err1){
			socket.emit('message', {
				type: 'error',
				error: err1.message
			});
			
			return cooldown(false, true);
		}
		
		if(amount < 0.01){
			socket.emit('message', {
				type: 'error',
				error: 'Error: The amount must have a greater value!'
			});
			
			return cooldown(false, true);
		}
		
		admin_saveSetting('trades.manually.amount', getFormatAmount(amount), function(err1){
			if(err1){
				logger.error(err1);
				writeError(err1);
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'success',
				success: 'Amount saved!'
			});
			
			socket.emit('message', {
				type: 'refresh'
			});
			
			cooldown(false, false);
		});
	});
}

function admin_cryptoConfirmations(user, socket, page, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(page))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid page!'
		});
		
		return cooldown(false, true);
	}
	
	page = parseInt(page);
	
	pool.query('SELECT COUNT(*) AS `count` FROM `crypto_listings` WHERE `confirmed` = 0 AND `canceled` = 0', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		var pages = parseInt(row1[0].count / 10) + (row1[0].count % 10 > 0 ? 1 : 0);
		
		if(pages <= 0){
			socket.emit('message', {
				type: 'pagination',
				command: 'admin_crypto_confirmations',
				list: [],
				pages: 1,
				page: 1
			});
			
			return cooldown(false, false);
		}
		
		if(page <= 0 || page > pages) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid page!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('SELECT `id`, `userid`, `amount`, `currency`, `time` FROM `crypto_listings` WHERE `confirmed` = 0 AND `canceled` = 0 ORDER BY `id` ASC LIMIT 10 OFFSET ' + pool.escape(page * 10 - 10), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			var list = [];
			
			row2.forEach(function(item){
				list.push({
					id: item.id,
					userid: item.userid,
					amount: getFormatAmount(item.amount),
					currency: item.currency,
					time: makeDate(new Date(item.time * 1000))
				});
			});
			
			socket.emit('message', {
				type: 'pagination',
				command: 'admin_crypto_confirmations',
				list: list,
				pages: pages,
				page: page
			});
			
			cooldown(false, false);
		});
	});
}

function admin_steamConfirmations(user, socket, page, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(page))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid page!'
		});
		
		return cooldown(false, true);
	}
	
	page = parseInt(page);
	
	pool.query('SELECT COUNT(*) AS `count` FROM `steam_listings` WHERE `confirmed` = 0 AND `canceled` = 0', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		var pages = parseInt(row1[0].count / 10) + (row1[0].count % 10 > 0 ? 1 : 0);
		
		if(pages <= 0){
			socket.emit('message', {
				type: 'pagination',
				command: 'admin_steam_confirmations',
				list: [],
				pages: 1,
				page: 1
			});
			
			return cooldown(false, false);
		}
		
		if(page <= 0 || page > pages) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid page!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('SELECT `id`, `userid`, `items`, `amount`, `game`, `time` FROM `steam_listings` WHERE `confirmed` = 0 AND `canceled` = 0 ORDER BY `id` ASC LIMIT 10 OFFSET ' + pool.escape(page * 10 - 10), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			var list = [];
			
			row2.forEach(function(item){
				list.push({
					id: item.id,
					userid: item.userid,
					amount: getFormatAmount(item.amount),
					items: item.items,
					game: item.game,
					time: makeDate(new Date(item.time * 1000))
				});
			});
			
			socket.emit('message', {
				type: 'pagination',
				command: 'admin_steam_confirmations',
				list: list,
				pages: pages,
				page: page
			});
			
			cooldown(false, false);
		});
	});
}

function admin_joinReferrals(user, socket, page, search, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(page))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid page!'
		});
		
		return cooldown(false, true);
	}
	
	page = parseInt(page);
	search = search.trim();
	
	pool.query('SELECT COUNT(*) AS `count` FROM `link_referrals` WHERE `referral` LIKE ' + pool.escape('%' + search + '%') + ' AND `removed` = 0 AND (`expire` > ' + pool.escape(time()) + ' OR `expire` = -1)', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		var pages = parseInt(row1[0].count / 10) + (row1[0].count % 10 > 0 ? 1 : 0);
		
		if(pages <= 0){
			socket.emit('message', {
				type: 'pagination',
				command: 'admin_join_referrals',
				list: [],
				pages: 1,
				page: 1
			});
			
			return cooldown(false, false);
		}
		
		if(page <= 0 || page > pages) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid page!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('SELECT `id`, `userid`, `referral`, `usage` FROM `link_referrals` WHERE `referral` LIKE ' + pool.escape('%' + search + '%') + ' AND `removed` = 0 AND (`expire` > ' + pool.escape(time()) + ' OR `expire` = -1) ORDER BY `id` ASC LIMIT 10 OFFSET ' + pool.escape(page * 10 - 10), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			var list = [];
			
			row2.forEach(function(item){
				list.push({
					id: item.id,
					userid: item.userid,
					referral: item.referral,
					usage: item.usage,
					link: config.config_site.url + config.config_site.root.slice(0, -1) + '?ref=' + item.referral
				});
			});
			
			socket.emit('message', {
				type: 'pagination',
				command: 'admin_join_referrals',
				list: list,
				pages: pages,
				page: page
			});
			
			cooldown(false, false);
		});
	});
}

function admin_depositBonuses(user, socket, page, search, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(page))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid page!'
		});
		
		return cooldown(false, true);
	}
	
	page = parseInt(page);
	search = search.trim();
	
	pool.query('SELECT COUNT(*) AS `count` FROM `deposit_codes` WHERE (`referral` LIKE ' + pool.escape('%' + search + '%') + ' OR `code` LIKE ' + pool.escape('%' + search.toLowerCase() + '%') + ') AND `removed` = 0', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		var pages = parseInt(row1[0].count / 10) + (row1[0].count % 10 > 0 ? 1 : 0);
		
		if(pages <= 0){
			socket.emit('message', {
				type: 'pagination',
				command: 'admin_deposit_bonuses',
				list: [],
				pages: 1,
				page: 1
			});
			
			return cooldown(false, false);
		}
		
		if(page <= 0 || page > pages) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid page!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('SELECT `id`, `referral`, `code`, `uses`, `amount` FROM `deposit_codes` WHERE (`referral` LIKE ' + pool.escape('%' + search + '%') + ' OR `code` LIKE ' + pool.escape('%' + search + '%') + ') AND `removed` = 0 ORDER BY `id` ASC LIMIT 10 OFFSET ' + pool.escape(page * 10 - 10), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'pagination',
				command: 'admin_deposit_bonuses',
				list: row2,
				pages: pages,
				page: page
			});
			
			cooldown(false, false);
		});
	});
}

/* CASE CREATOR */

function admin_casecreatorItems(user, socket, page, order, search, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	var order_allowed = [ 0, 1, 2, 3 ];
	if(!order_allowed.includes(order)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid order!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(page))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid page!'
		});
		
		return cooldown(false, true);
	}
	
	page = parseInt(page);
	search = search.trim();
	
	pool.query('SELECT COUNT(*) AS `count` FROM `items_list` WHERE `name` LIKE ' + pool.escape('%' + search + '%'), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		var pages = parseInt(row1[0].count / 100) + (row1[0].count % 100 > 0 ? 1 : 0);
		
		if(pages <= 0){
			socket.emit('message', {
				type: 'pagination',
				command: 'casecreator_items',
				list: [],
				pages: 1,
				page: 1
			});
			
			return cooldown(false, false);
		}
		
		if(page <= 0 || page > pages) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid page!'
			});
			
			return cooldown(false, true);
		}
		
		var order_query = { 
			0: 'ORDER BY `name` ASC',
			1: 'ORDER BY `name` DESC',
			2: 'ORDER BY `price` ASC',
			3: 'ORDER BY `price` DESC'
		}[order];
		
		pool.query('SELECT * FROM `items_list` WHERE `name` LIKE ' + pool.escape('%' + search + '%') + ' ' + order_query + ' LIMIT 100 OFFSET ' + pool.escape(page * 100 - 100), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			var list = [];
			
			row2.forEach(function(item){
				list.push({
					id: item.itemid,
					name: item.name,
					image: item.image,
					price: item.price,
					color: getColorByQuality(item.quality)
				});
			});
			
			socket.emit('message', {
				type: 'pagination',
				command: 'casecreator_items',
				list: list,
				pages: pages,
				page: page
			});
			
			cooldown(false, false);
		});
	});
}

function admin_casecreatorCreateCases(user, socket, name, image, items, data, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	/* CHECK DATA */
	
	name = name.trim();
	
	if(name.length < config.config_site.admin.casecreator_requirements.name_length.min || name.length > config.config_site.admin.casecreator_requirements.name_length.max){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid name length [' + config.config_site.admin.casecreator_requirements.name_length.min + '-' + config.config_site.admin.casecreator_requirements.name_length.max + ']!'
		});
		
		return cooldown(false, true);
	}
	
	if(!/^[a-zA-Z0-9\s~`!@#\$%^&*()\-_+={[}\]|\\:;"'<,>.?\/]+$/.exec(name)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid name characters!'
		});
		
		return cooldown(false, true);
	}
	
	if(!Buffer.isBuffer(image)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid image!'
		});
		
		return cooldown(false, true);
	}
	
	var receivedData = Buffer.alloc(0);
	receivedData = Buffer.concat([receivedData, image]);
	
	var magicNumber = receivedData.toString('hex', 0, 4);
	
	var allowed_extensions = [ '89504e47', 'ffd8ffe0', 'ffd8ffe1' ];
	if(!allowed_extensions.includes(magicNumber)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid image format!'
		});
		
		return cooldown(false, true);
	}
	
	if(items.length < config.config_site.admin.casecreator_requirements.items_length.min || items.length > config.config_site.admin.casecreator_requirements.items_length.max){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid items amount [' + config.config_site.admin.casecreator_requirements.items_length.min + '-' + config.config_site.admin.casecreator_requirements.items_length.max + ']!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(data.offset))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid offset!'
		});
		
		return cooldown(false, true);
	}
	
	var offset = roundedToFixed(data.offset, 2);
	
	if(offset < config.config_site.admin.casecreator_requirements.unboxing.offset.min || offset > config.config_site.admin.casecreator_requirements.unboxing.offset.max){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid offset [' + roundedToFixed(config.config_site.admin.casecreator_requirements.unboxing.offset.min, 2).toFixed(2) + '-' + roundedToFixed(config.config_site.admin.casecreator_requirements.unboxing.offset.max, 2).toFixed(2) + ']!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(data.battle))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid battle!'
		});
		
		return cooldown(false, true);
	}
	
	var battle = parseInt(data.battle);
	
	var allowed_casebattle = [ 0, 1 ];
	if(!allowed_casebattle.includes(battle)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid battle!'
		});
		
		return cooldown(false, true);
	}
	
	/* END CHECK DATA */
	
	var available = true;
	var chance = 0;
	
	var available_items = [];
	
	items.forEach(function(item){
		if(itemsSystem_items[item.id] === undefined) available = false
		if(item.chance <= 0) available = false
		
		var item_chance = roundedToFixed(item.chance, 5);
		
		chance = roundedToFixed(chance + item_chance, 5);
		
		if(!available_items.includes(item.id)) available_items.push(item.id);
	});
	
	if(!available){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid items!'
		});
		
		return cooldown(false, true);
	}
	
	if(available_items.length != items.length){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid items!'
		});
		
		return cooldown(false, true);
	}
	
	if(chance != 100){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid chance!'
		});
		
		return cooldown(false, true);
	}
	
	var extension = { '89504e47': 'png', 'ffd8ffe0': 'jpg', 'ffd8ffe1': 'jpg' }[magicNumber];
	
	var caseid = name.replace(/[^\w\s\-]/gi, '').trim().replace(/[\s\-_]+/g, '_').toLowerCase();
	var caseimage = caseid + '.' + extension;
	
	pool.query('SELECT * FROM `cases_cases` WHERE `caseid` = ' + pool.escape(caseid) + ' AND `removed` = 0', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length > 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: A case with this name already created!'
			});
			
			return cooldown(false, true);
		}
		
		var price = 0;
		var newitems = [];
		
		items.forEach(function(item){
			var item_price = getFormatAmount(itemsSystem_items[item.id].price);
			var item_chance = roundedToFixed(item.chance, 5);
			
			price += item_price * item_chance / 100;
			
			newitems.push({
				id: item.id,
				chance: item_chance
			})
		});
		
		newitems.sort((a, b) => itemsSystem_items[b.id].price - itemsSystem_items[a.id].price);
		
		price = getFormatAmount(price * (1 + offset / 100));
		
		fs.writeFile(config.config_site.frontend + config.config_site.root + 'template/img/cases/' + caseimage, image, function(err2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			pool.query('INSERT INTO `cases_cases` SET `caseid` = ' + pool.escape(caseid) + ', `items` = ' + pool.escape(JSON.stringify(newitems)) + ', `name` = ' + pool.escape(name) + ', `image` = ' + pool.escape(caseimage) + ', `offset` = ' + offset + ', `battle` = ' + battle + ', `time` = ' + pool.escape(time()), function(err3){
				if(err3){
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				socket.emit('message', {
					type: 'success',
					success: 'Case successfully created!'
				});
				
				var caseitem = {
					name: name,
					image: caseimage,
					price: price,
					category: 0,
					items: newitems
				}
				
				casesGame_cases[caseid] = caseitem; //UNBOXING
				if(battle) casebattleGame_cases[caseid] = caseitem; //CASE BATTLE
				
				cooldown(false, false);
			});
		});
	});
}

function admin_casecreatorCreateDailycases(user, socket, name, image, items, data, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	/* CHECK DATA */
	
	name = name.trim();
	
	if(name.length < config.config_site.admin.casecreator_requirements.name_length.min || name.length > config.config_site.admin.casecreator_requirements.name_length.max){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid name length [' + config.config_site.admin.casecreator_requirements.name_length.min + '-' + config.config_site.admin.casecreator_requirements.name_length.max + ']!'
		});
		
		return cooldown(false, true);
	}
	
	if(!/^[a-zA-Z0-9\s~`!@#\$%^&*()\-_+={[}\]|\\:;"'<,>.?\/]+$/.exec(name)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid name characters!'
		});
		
		return cooldown(false, true);
	}
	
	if(!Buffer.isBuffer(image)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid image!'
		});
		
		return cooldown(false, true);
	}
	
	var receivedData = Buffer.alloc(0);
	receivedData = Buffer.concat([receivedData, image]);
	
	var magicNumber = receivedData.toString('hex', 0, 4);
	
	var allowed_extensions = [ '89504e47', 'ffd8ffe0', 'ffd8ffe1' ];
	if(!allowed_extensions.includes(magicNumber)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid image format!'
		});
		
		return cooldown(false, true);
	}
	
	if(items.length < config.config_site.admin.casecreator_requirements.items_length.min || items.length > config.config_site.admin.casecreator_requirements.items_length.max){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid items amount [' + config.config_site.admin.casecreator_requirements.items_length.min + '-' + config.config_site.admin.casecreator_requirements.items_length.max + ']!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(data.level))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid level!'
		});
		
		return cooldown(false, true);
	}
	
	var level = parseInt(data.level);
	
	if(level < config.config_site.admin.casecreator_requirements.dailycases.level.min || level > config.config_site.admin.casecreator_requirements.dailycases.level.max){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid level [' + config.config_site.admin.casecreator_requirements.dailycases.level.min + '-' + config.config_site.admin.casecreator_requirements.dailycases.level.max + ']!'
		});
		
		return cooldown(false, true);
	}
	
	/* END CHECK DATA */
	
	var available = true;
	var chance = 0;
	
	var available_items = [];
	
	items.forEach(function(item){
		if(itemsSystem_items[item.id] === undefined) available = false
		if(item.chance <= 0) available = false
		
		var item_chance = roundedToFixed(item.chance, 5);
		
		chance = roundedToFixed(chance + item_chance, 5);
		
		if(!available_items.includes(item.id)) available_items.push(item.id);
	});
	
	if(!available){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid items!'
		});
		
		return cooldown(false, true);
	}
	
	if(available_items.length != items.length){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid items!'
		});
		
		return cooldown(false, true);
	}
	
	if(chance != 100){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid chance!'
		});
		
		return cooldown(false, true);
	}
	
	var extension = { '89504e47': 'png', 'ffd8ffe0': 'jpg', 'ffd8ffe1': 'jpg' }[magicNumber];
	
	var caseid = name.replace(/[^\w\s\-]/gi, '').trim().replace(/[\s\-_]+/g, '_').toLowerCase();
	var caseimage = caseid + '.' + extension;
	
	pool.query('SELECT * FROM `cases_dailycases` WHERE `caseid` = ' + pool.escape(caseid) + ' AND `removed` = 0', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length > 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: A daily case with this name already created!'
			});
			
			return cooldown(false, true);
		}
		
		var newitems = [];
		
		items.forEach(function(item){
			var item_chance = roundedToFixed(item.chance, 5);
			
			newitems.push({
				id: item.id,
				chance: item_chance
			})
		});
		
		newitems.sort((a, b) => itemsSystem_items[b.id].price - itemsSystem_items[a.id].price);
		
		fs.writeFile(config.config_site.frontend + config.config_site.root + 'template/img/dailycases/' + caseimage, image, function(err2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			pool.query('INSERT INTO `cases_dailycases` SET `caseid` = ' + pool.escape(caseid) + ', `items` = ' + pool.escape(JSON.stringify(newitems)) + ', `name` = ' + pool.escape(name) + ', `image` = ' + pool.escape(caseimage) + ', `level` = ' + level + ', `time` = ' + pool.escape(time()), function(err3){
				if(err3){
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				socket.emit('message', {
					type: 'success',
					success: 'Daily case successfully created!'
				});
				
				var caseitem = {
					name: name,
					image: caseimage,
					items: newitems,
					level: level
				}
				
				dailycases_cases[caseid] = caseitem; //DAILY CASES
				
				cooldown(false, false);
			});
		});
	});
}

function admin_casecreatorCases(user, socket, creator, cooldown){
	cooldown(true, true);
	
	var allowed_creator = [ 'cases', 'dailycases' ];
	if(!allowed_creator.includes(creator)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid type!'
		});
		
		return cooldown(false, true);
	}
	
	var cases = { 'cases': casesGame_cases, 'dailycases': dailycases_cases }[creator];
	var list_cases = [];
	
	Object.keys(cases).forEach(function(id){
		list_cases.push({
			id: id,
			name: cases[id].name,
			image: cases[id].image,
			price: getFormatAmount(cases[id].price)
		});
	});
	
	list_cases.sort(function(a, b){ return b.price - a.price });
	
	socket.emit('message', {
		type: 'casecreator',
		command: 'cases',
		cases: list_cases,
		creator: creator
	});
	
	cooldown(false, false);
}

function admin_casecreatorRemoveCases(user, socket, id, secret, cooldown){
	cooldown(true, true);
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	pool.query('SELECT * FROM `cases_cases` WHERE `caseid` = ' + pool.escape(id) + ' AND `removed` = 0', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Unknown caseid!'
			});
			
			return cooldown(false, true);
		}
		
		var battle = parseInt(row1[0].battle);
		
		pool.query('UPDATE `cases_cases` SET `removed` = 1 WHERE `caseid` = ' + pool.escape(id) + ' AND `removed` = 0', function(err2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			delete casesGame_cases[id]; //UNBOXING
			if(battle) delete casebattleGame_cases[id]; //CASE BATTLE
			
			socket.emit('message', {
				type: 'casecreator',
				command: 'remove',
				id: id,
			});
			
			cooldown(false, false);
		});
	});
}

function admin_casecreatorRemoveDailycases(user, socket, id, secret, cooldown){
	cooldown(true, true);
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	pool.query('SELECT * FROM `cases_dailycases` WHERE `caseid` = ' + pool.escape(id) + ' AND `removed` = 0', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Unknown caseid!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('UPDATE `cases_dailycases` SET `removed` = 1 WHERE `caseid` = ' + pool.escape(id) + ' AND `removed` = 0', function(err2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			delete dailycases_cases[id]; //DAILY CASES
			
			socket.emit('message', {
				type: 'casecreator',
				command: 'remove',
				id: id,
			});
			
			cooldown(false, false);
		});
	});
}

function admin_casecreatorGetCases(user, socket, id, cooldown){
	cooldown(true, true);
	
	pool.query('SELECT * FROM `cases_cases` WHERE `caseid` = ' + pool.escape(id) + ' AND `removed` = 0', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Unknown caseid!'
			});
			
			return cooldown(false, true);
		}
		
		var items = JSON.parse(row1[0].items);
		var newitems = [];
		
		items.forEach(function(item){
			newitems.push({
				item: {
					id: item.id,
					name: itemsSystem_items[item.id].name,
					image: itemsSystem_items[item.id].image,
					price: itemsSystem_items[item.id].price,
					color: getColorByQuality(itemsSystem_items[item.id].quality)
				},
				chance: roundedToFixed(item.chance, 5)
			});
		});
		
		fs.readFile(config.config_site.frontend + config.config_site.root + 'template/img/cases/' + row1[0].image, function(err2, data2){
			var casecreator = {
				'name': row1[0].name,
				'image': row1[0].image,
				'items': newitems,
				'buffer': data2,
				'battle': parseInt(row1[0].battle),
				'offset': roundedToFixed(row1[0].offset, 2)
			}
			
			socket.emit('message', {
				type: 'casecreator',
				command: 'case',
				creator: 'cases',
				data: casecreator,
			});
			
			cooldown(false, false);
		});
	});
}

function admin_casecreatorGetDailycases(user, socket, id, cooldown){
	cooldown(true, true);
	
	pool.query('SELECT * FROM `cases_dailycases` WHERE `caseid` = ' + pool.escape(id) + ' AND `removed` = 0', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Unknown caseid!'
			});
			
			return cooldown(false, true);
		}
		
		var items = JSON.parse(row1[0].items);
		var newitems = [];
		
		items.forEach(function(item){
			newitems.push({
				item: {
					id: item.id,
					name: itemsSystem_items[item.id].name,
					image: itemsSystem_items[item.id].image,
					price: itemsSystem_items[item.id].price,
					color: getColorByQuality(itemsSystem_items[item.id].quality)
				},
				chance: roundedToFixed(item.chance, 5)
			});
		});
		
		fs.readFile(config.config_site.frontend + config.config_site.root + 'template/img/dailycases/' + row1[0].image, function(err2, data2){
			var casecreator = {
				'name': row1[0].name,
				'image': row1[0].image,
				'items': newitems,
				'buffer': data2,
				'level': parseInt(row1[0].level)
			}
			
			socket.emit('message', {
				type: 'casecreator',
				command: 'case',
				creator: 'dailycases',
				data: casecreator,
			});
			
			cooldown(false, false);
		});
	});
}

function admin_casecreatorEditCases(user, socket, id, name, image, items, data, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	/* CHECK DATA */
	
	name = name.trim();
	
	if(name.length < config.config_site.admin.casecreator_requirements.name_length.min || name.length > config.config_site.admin.casecreator_requirements.name_length.max){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid name length [' + config.config_site.admin.casecreator_requirements.name_length.min + '-' + config.config_site.admin.casecreator_requirements.name_length.max + ']!'
		});
		
		return cooldown(false, true);
	}
	
	if(!/^[a-zA-Z0-9\s~`!@#\$%^&*()\-_+={[}\]|\\:;"'<,>.?\/]+$/.exec(name)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid name characters!'
		});
		
		return cooldown(false, true);
	}
	
	if(!Buffer.isBuffer(image)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid image!'
		});
		
		return cooldown(false, true);
	}
	
	var receivedData = Buffer.alloc(0);
	receivedData = Buffer.concat([receivedData, image]);
	
	var magicNumber = receivedData.toString('hex', 0, 4);
	
	var allowed_extensions = [ '89504e47', 'ffd8ffe0', 'ffd8ffe1' ];
	if(!allowed_extensions.includes(magicNumber)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid image format!'
		});
		
		return cooldown(false, true);
	}
	
	if(items.length < config.config_site.admin.casecreator_requirements.items_length.min || items.length > config.config_site.admin.casecreator_requirements.items_length.max){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid items amount [' + config.config_site.admin.casecreator_requirements.items_length.min + '-' + config.config_site.admin.casecreator_requirements.items_length.max + ']!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(data.offset))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid offset!'
		});
		
		return cooldown(false, true);
	}
	
	var offset = roundedToFixed(data.offset, 2);
	
	if(offset < config.config_site.admin.casecreator_requirements.unboxing.offset.min || offset > config.config_site.admin.casecreator_requirements.unboxing.offset.max){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid offset [' + roundedToFixed(config.config_site.admin.casecreator_requirements.unboxing.offset.min, 2).toFixed(2) + '-' + roundedToFixed(config.config_site.admin.casecreator_requirements.unboxing.offset.max, 2).toFixed(2) + ']!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(data.battle))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid battle!'
		});
		
		return cooldown(false, true);
	}
	
	var battle = parseInt(data.battle);
	
	var allowed_casebattle = [ 0, 1 ];
	if(!allowed_casebattle.includes(battle)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid battle!'
		});
		
		return cooldown(false, true);
	}
	
	/* END CHECK DATA */
	
	var available = true;
	var chance = 0;
	
	var available_items = [];
	
	items.forEach(function(item){
		if(itemsSystem_items[item.id] === undefined) available = false
		if(item.chance <= 0) available = false
		
		var item_chance = roundedToFixed(item.chance, 5);
		
		chance = roundedToFixed(chance + item_chance, 5);
		
		if(!available_items.includes(item.id)) available_items.push(item.id);
	});
	
	if(!available){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid items!'
		});
		
		return cooldown(false, true);
	}
	
	if(available_items.length != items.length){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid items!'
		});
		
		return cooldown(false, true);
	}
	
	if(chance != 100){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid chance!'
		});
		
		return cooldown(false, true);
	}
	
	var extension = { '89504e47': 'png', 'ffd8ffe0': 'jpg', 'ffd8ffe1': 'jpg' }[magicNumber];
	
	var caseid = name.replace(/[^\w\s\-]/gi, '').trim().replace(/[\s\-_]+/g, '_').toLowerCase();
	var caseimage = caseid + '.' + extension;
	
	pool.query('SELECT * FROM `cases_cases` WHERE `caseid` = ' + pool.escape(id) + ' AND `removed` = 0', function(err2, row2){
		if(err2){
			logger.error(err2);
			writeError(err2);
			
			return cooldown(false, true);
		}
		
		if(row2.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Unknown caseid!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('SELECT * FROM `cases_cases` WHERE `caseid` = ' + pool.escape(caseid) + ' AND `removed` = 0 AND `id` != ' + pool.escape(row2[0].id), function(err1, row1){
			if(err1){
				logger.error(err1);
				writeError(err1);
				
				return cooldown(false, true);
			}
			
			if(row1.length > 0){
				socket.emit('message', {
					type: 'error',
					error: 'Error: A case with this name already created!'
				});
				
				return cooldown(false, true);
			}
			
			delete casesGame_cases[row2[0].caseid]; //UNBOXING
			if(parseInt(row2[0].battle)) delete casebattleGame_cases[row2[0].caseid]; //CASE BATTLE
			
			var price = 0;
			var newitems = [];
			
			items.forEach(function(item){
				var item_price = getFormatAmount(itemsSystem_items[item.id].price);
				var item_chance = roundedToFixed(item.chance, 5);
				
				price += item_price * item_chance / 100;
				
				newitems.push({
					id: item.id,
					chance: item_chance
				})
			});
			
			newitems.sort((a, b) => itemsSystem_items[b.id].price - itemsSystem_items[a.id].price);
			
			price = getFormatAmount(price * (1 + offset / 100));
			
			fs.unlink(config.config_site.frontend + config.config_site.root + 'template/img/cases/' + row2[0].image, function(err3){
				if(err3){
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				fs.writeFile(config.config_site.frontend + config.config_site.root + 'template/img/cases/' + caseimage, image, function(err4){
					if(err4){
						logger.error(err4);
						writeError(err4);
						
						return cooldown(false, true);
					}
					
					pool.query('UPDATE `cases_cases` SET `caseid` = ' + pool.escape(caseid) + ', `items` = ' + pool.escape(JSON.stringify(newitems)) + ', `name` = ' + pool.escape(name) + ', `image` = ' + pool.escape(caseimage) + ', `offset` = ' + offset + ', `battle` = ' + battle + ' WHERE `id` = ' + pool.escape(row2[0].id), function(err5){
						if(err5){
							logger.error(err5);
							writeError(err5);
							
							return cooldown(false, true);
						}
						
						socket.emit('message', {
							type: 'success',
							success: 'Case successfully edited!'
						});
						
						socket.emit('message', {
							type: 'casecreator',
							command: 'redirect',
							creator: 'cases',
							caseid: caseid
						});
						
						var caseitem = {
							name: name,
							image: caseimage,
							price: price,
							category: 0,
							items: newitems
						}
						
						casesGame_cases[caseid] = caseitem; //UNBOXING
						if(battle) casebattleGame_cases[caseid] = caseitem; //CASE BATTLE
						
						cooldown(false, false);
					});
				});
			});
		});
	});
}

function admin_casecreatorEditDailycases(user, socket, id, name, image, items, data, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	/* CHECK DATA */
	
	name = name.trim();
	
	if(name.length < config.config_site.admin.casecreator_requirements.name_length.min || name.length > config.config_site.admin.casecreator_requirements.name_length.max){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid name length [' + config.config_site.admin.casecreator_requirements.name_length.min + '-' + config.config_site.admin.casecreator_requirements.name_length.max + ']!'
		});
		
		return cooldown(false, true);
	}
	
	if(!/^[a-zA-Z0-9\s~`!@#\$%^&*()\-_+={[}\]|\\:;"'<,>.?\/]+$/.exec(name)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid name characters!'
		});
		
		return cooldown(false, true);
	}
	
	if(!Buffer.isBuffer(image)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid image!'
		});
		
		return cooldown(false, true);
	}
	
	var receivedData = Buffer.alloc(0);
	receivedData = Buffer.concat([receivedData, image]);
	
	var magicNumber = receivedData.toString('hex', 0, 4);
	
	var allowed_extensions = [ '89504e47', 'ffd8ffe0', 'ffd8ffe1' ];
	if(!allowed_extensions.includes(magicNumber)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid image format!'
		});
		
		return cooldown(false, true);
	}
	
	if(items.length < config.config_site.admin.casecreator_requirements.items_length.min || items.length > config.config_site.admin.casecreator_requirements.items_length.max){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid items amount [' + config.config_site.admin.casecreator_requirements.items_length.min + '-' + config.config_site.admin.casecreator_requirements.items_length.max + ']!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(data.level))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid level!'
		});
		
		return cooldown(false, true);
	}
	
	var level = parseInt(data.level);
	
	if(level < config.config_site.admin.casecreator_requirements.dailycases.level.min || level > config.config_site.admin.casecreator_requirements.dailycases.level.max){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid level [' + config.config_site.admin.casecreator_requirements.dailycases.level.min + '-' + config.config_site.admin.casecreator_requirements.dailycases.level.max + ']!'
		});
		
		return cooldown(false, true);
	}
	
	/* END CHECK DATA */
	
	var available = true;
	var chance = 0;
	
	var available_items = [];
	
	items.forEach(function(item){
		if(itemsSystem_items[item.id] === undefined) available = false
		if(item.chance <= 0) available = false
		
		var item_chance = roundedToFixed(item.chance, 5);
		
		chance = roundedToFixed(chance + item_chance, 5);
		
		if(!available_items.includes(item.id)) available_items.push(item.id);
	});
	
	if(!available){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid items!'
		});
		
		return cooldown(false, true);
	}
	
	if(available_items.length != items.length){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid items!'
		});
		
		return cooldown(false, true);
	}
	
	if(chance != 100){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid chance!'
		});
		
		return cooldown(false, true);
	}
	
	var extension = { '89504e47': 'png', 'ffd8ffe0': 'jpg', 'ffd8ffe1': 'jpg' }[magicNumber];
	
	var caseid = name.replace(/[^\w\s\-]/gi, '').trim().replace(/[\s\-_]+/g, '_').toLowerCase();
	var caseimage = caseid + '.' + extension;
	
	pool.query('SELECT * FROM `cases_dailycases` WHERE `caseid` = ' + pool.escape(id) + ' AND `removed` = 0', function(err2, row2){
		if(err2){
			logger.error(err2);
			writeError(err2);
			
			return cooldown(false, true);
		}
		
		if(row2.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Unknown caseid!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('SELECT * FROM `cases_dailycases` WHERE `caseid` = ' + pool.escape(caseid) + ' AND `removed` = 0 AND `id` != ' + pool.escape(row2[0].id), function(err1, row1){
			if(err1){
				logger.error(err1);
				writeError(err1);
				
				return cooldown(false, true);
			}
			
			if(row1.length > 0){
				socket.emit('message', {
					type: 'error',
					error: 'Error: A case with this name already created!'
				});
				
				return cooldown(false, true);
			}
			
			delete dailycases_cases[row2[0].caseid]; //DAILY CASES
			
			var newitems = [];
			
			items.forEach(function(item){
				var item_chance = roundedToFixed(item.chance, 5);
				
				newitems.push({
					id: item.id,
					chance: item_chance
				})
			});
			
			newitems.sort((a, b) => itemsSystem_items[b.id].price - itemsSystem_items[a.id].price);
			
			fs.unlink(config.config_site.frontend + config.config_site.root + 'template/img/dailycases/' + row2[0].image, function(err3){
				if(err3){
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				fs.writeFile(config.config_site.frontend + config.config_site.root + 'template/img/dailycases/' + caseimage, image, function(err4){
					if(err4){
						logger.error(err4);
						writeError(err4);
						
						return cooldown(false, true);
					}
					
					pool.query('UPDATE `cases_dailycases` SET `caseid` = ' + pool.escape(caseid) + ', `items` = ' + pool.escape(JSON.stringify(newitems)) + ', `name` = ' + pool.escape(name) + ', `image` = ' + pool.escape(caseimage) + ', `level` = ' + level + ' WHERE `id` = ' + pool.escape(row2[0].id), function(err5){
						if(err5){
							logger.error(err5);
							writeError(err5);
							
							return cooldown(false, true);
						}
						
						socket.emit('message', {
							type: 'success',
							success: 'Daily case successfully edited!'
						});
						
						socket.emit('message', {
							type: 'casecreator',
							command: 'redirect',
							creator: 'dailycases',
							caseid: caseid
						});
						
						var caseitem = {
							name: name,
							image: caseimage,
							items: newitems,
							level: level
						}
						
						dailycases_cases[caseid] = caseitem; //DAILY CASES
						
						cooldown(false, false);
					});
				});
			});
		});
	});
}

/* END CASE CREATOR */

/* GAME BOTS */

function gamebots_showBots(user, socket, game, data, cooldown){
	cooldown(true, true);
	
	var allowed_games = [ 'coinflip', 'casebattle' ];
	if(!allowed_games.includes(game)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid game!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.settings.games.bots.enable[game] && !config.config_site.gamebots_allowed.includes(config.config_site.ranks_name[user.rank])){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Calling bots for this game are disabled. Please try again later!'
		});
		
		return cooldown(false, true);
	}
	
	if(game == 'coinflip'){
		gamebots_showBots_coinflip(parseInt(data.id), function(err1, bots){
			if(err1){
				socket.emit('message', {
					type: 'error',
					error: err1.message
				});
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'gamebots',
				command: 'show',
				bots: bots,
				game: game,
				data: data
			});
			
			cooldown(false, false);
		});
	} else if(game == 'casebattle'){
		gamebots_showBots_casebattle(data.id, parseInt(data.position), function(err1, bots){
			if(err1){
				socket.emit('message', {
					type: 'error',
					error: err1.message
				});
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'gamebots',
				command: 'show',
				bots: bots,
				game: game,
				data: data
			});
			
			cooldown(false, false);
		});
	}
}

function gamebots_showBots_coinflip(id, callback){
	if(isNaN(Number(id))) return callback(new Error('Error: Invalid game. Please join in a valid game!'));
	
	if(coinflipGame_games[id] === undefined) return callback(new Error('Error: Invalid game. Please join in a valid game!'));
	if(coinflipGame_games[id]['status'] != 0) return callback(new Error('Error: This game are already ended!'));
	
	if(Object.keys(coinflipGame_secure[id]).length > 0) return callback(new Error('Error: Another user are trying to join in this game. Please try again later!'));

	var amount = getFormatAmount(coinflipGame_games[id]['amount']);
	
	pool.query('SELECT users.userid, users.name, users.avatar, users.xp, users.balance, COALESCE(COUNT(coinflip_winnings.id), 0) AS `bets`, COALESCE(SUM(IF(coinflip_bets.position = coinflip_winnings.position, 1, 0)), 0) AS `winnings` FROM `coinflip_games` INNER JOIN `coinflip_bets` ON coinflip_games.id = coinflip_bets.gameid INNER JOIN `coinflip_winnings` ON coinflip_winnings.gameid = coinflip_games.id RIGHT JOIN `users` ON users.userid = coinflip_bets.userid WHERE (coinflip_games.canceled = 0 OR coinflip_games.canceled IS NULL) AND (coinflip_games.ended = 1 OR coinflip_games.ended IS NULL) AND users.bot = 1 GROUP BY users.userid', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return callback(new Error('Error: Error (1)'));
		}
		
		var bots = [];
		
		row1.forEach(function(item){
			var available = true;
			
			if(getFormatAmount(item.balance) < amount) available = false;
			if(coinflipGame_games[id].players.filter(a => a.user.userid == item.userid).length > 0) available = false;
			
			if(available){
				bots.push({
					user: {
						userid: item.userid,
						name: item.name,
						avatar: item.avatar,
						level: calculateLevel(item.xp).level
					},
					bets: parseInt(item.bets),
					winnings: parseInt(item.winnings)
				});
			}
		});
		
		callback(null, bots);
	});
}

function gamebots_showBots_casebattle(id, position, callback){
	if(isNaN(Number(position))) return callback(new Error('Error: Invalid position!'));
	
	if(casebattleGame_games[id] === undefined) return callback(new Error('Error: Invalid case battle id!'));
	if(casebattleGame_games[id].status != 0) return callback(new Error('Error: This case battle are already ended!'));
	
	var total_players = [ 2, 3, 4, 4 ][casebattleGame_games[id].mode];
	if(position < 0 || position >= total_players) return callback(new Error('Error: That position is invalid!'));
	if(casebattleGame_games[id].players.filter(a => a.position == position).length > 0) return callback(new Error('Error: That position is already taked!'));
	
	if(Object.keys(casebattleGame_secure[id][position]).length > 0) return callback(new Error('Error: Another user are trying to join in this game. Please try again later!'));
	
	var amount = getFormatAmount(casebattleGame_games[id]['amount']);
	
	if(casebattleGame_games[id]['free']) amount = 0;
	
	pool.query('SELECT users.userid, users.name, users.avatar, users.xp, users.balance, COALESCE(COUNT(casebattle_winnings.id), 0) AS `bets`, COALESCE(SUM(IF(casebattle_bets.position = casebattle_winnings.position, 1, 0)), 0) AS `winnings` FROM `casebattle_games` INNER JOIN `casebattle_bets` ON casebattle_games.id = casebattle_bets.gameid INNER JOIN `casebattle_winnings` ON casebattle_winnings.gameid = casebattle_games.id RIGHT JOIN `users` ON users.userid = casebattle_bets.userid WHERE (casebattle_games.canceled = 0 OR casebattle_games.canceled IS NULL) AND (casebattle_games.ended = 1 OR casebattle_games.ended IS NULL) AND (casebattle_bets.canceled = 0 OR casebattle_bets.canceled IS NULL) AND users.bot = 1 GROUP BY users.userid', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return callback(new Error('Error: Error (1)'));
		}
		
		var bots = [];
		
		row1.forEach(function(item){
			var available = true;
			
			if(getFormatAmount(item.balance) < amount) available = false;
			if(casebattleGame_games[id].players.filter(a => a.user.userid == item.userid).length > 0) available = false;
			
			if(available){
				bots.push({
					user: {
						userid: item.userid,
						name: item.name,
						avatar: item.avatar,
						level: calculateLevel(item.xp).level
					},
					bets: parseInt(item.bets),
					winnings: parseInt(item.winnings)
				});
			}
		});
		
		callback(null, bots);
	});
}

function gamebots_confirmBot(user, socket, userid, game, data, cooldown){
	cooldown(true, true);
	
	var allowed_games = [ 'coinflip', 'casebattle' ];
	if(!allowed_games.includes(game)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid game!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.settings.games.bots.enable[game] && !config.config_site.gamebots_allowed.includes(config.config_site.ranks_name[user.rank])){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Calling bots for this game are disabled. Please try again later!'
		});
		
		return cooldown(false, true);
	}
	
	if(game == 'coinflip'){
		gamebots_confirmBot_coinflip(userid, parseInt(data.id), function(err1, bot){
			if(err1){
				socket.emit('message', {
					type: 'error',
					error: err1.message
				});
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'success',
				success: bot.name + ' successfully called in your coinflip!'
			});
			
			socket.emit('message', {
				type: 'gamebots',
				command: 'hide'
			});
			
			cooldown(false, false);
		});
	} else if(game == 'casebattle'){
		gamebots_confirmBot_casebattle(userid, data.id, parseInt(data.position), function(err1, bot){
			if(err1){
				socket.emit('message', {
					type: 'error',
					error: err1.message
				});
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'success',
				success: bot.name + ' successfully called in your casebattle!'
			});
			
			socket.emit('message', {
				type: 'gamebots',
				command: 'hide'
			});
			
			cooldown(false, false);
		});
	}
}

function gamebots_confirmBot_coinflip(userid, id, callback){
	pool.query('SELECT `userid`, `name`, `avatar`, `xp`, `balance` FROM `users` WHERE `userid` = ' + pool.escape(userid) + ' AND `bot` = 1', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return callback(new Error('Error: Error (1)'));
		}
		
		if(row1.length < 0) return callback(new Error('Error: Invalid bot!'));
		
		var bot = {
			userid: row1[0].userid,
			name: row1[0].name,
			avatar: row1[0].avatar,
			xp: row1[0].xp,
			bot: 1
		};
	
		if(isNaN(Number(id))) return callback(new Error('Error: Invalid game. Please join in a valid game!'));
		
		if(coinflipGame_games[id] === undefined) return callback(new Error('Error: Invalid game. Please join in a valid game!'));
		if(coinflipGame_games[id]['status'] != 0) return callback(new Error('Error: This game are already ended!'));
		if(coinflipGame_games[id].players.filter(a => a.user.userid == bot.userid).length > 0) return callback(new Error('Error: You cannot join your game!'));
		if(Object.keys(coinflipGame_secure[id]).length > 0) return callback(new Error('Error: Another user are trying to join in this game. Please try again later!'));
		
		var amount = getFormatAmount(coinflipGame_games[id]['amount']);
		
		if(getFormatAmount(row1[0].balance) < amount) return callback(new Error('Error: This bot is not available to join in this case battle!'));
		
		coinflipGame_secure[id][bot.userid] = true;
		
		coinflipGame_joinConfirm(bot, id, function(err2){
			if(err2) return callback(err2);
			
			if(coinflipGame_secure[id] !== undefined) if(coinflipGame_secure[id][bot.userid] !== undefined) delete coinflipGame_secure[id][bot.userid];
			
			callback(null, {
				userid: bot.userid,
				name: bot.name,
				avatar: bot.avatar,
				level: calculateLevel(bot.xp).level
			});
		});
	});
}

function gamebots_confirmBot_casebattle(userid, id, position, callback){
	pool.query('SELECT `userid`, `name`, `avatar`, `xp`, `balance` FROM `users` WHERE `userid` = ' + pool.escape(userid) + ' AND `bot` = 1', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return callback(new Error('Error: Error (1)'));
		}
		
		if(row1.length < 0) return callback(new Error('Error: Invalid bot!'));
		
		var bot = {
			userid: row1[0].userid,
			name: row1[0].name,
			avatar: row1[0].avatar,
			xp: row1[0].xp,
			bot: 1
		};
	
		if(isNaN(Number(position))) return callback(new Error('Error: Invalid position!'));
		
		if(casebattleGame_games[id] === undefined) return callback(new Error('Error: Invalid case battle id!'));
		if(casebattleGame_games[id].status != 0) return callback(new Error('Error: This case battle are already ended!'));
		
		var total_players = [ 2, 3, 4, 4 ][casebattleGame_games[id].mode];
		if(position < 0 || position >= total_players) return callback(new Error('Error: That position is invalid!'));
		if(casebattleGame_games[id].players.filter(a => a.position == position).length > 0) return callback(new Error('Error: That position is already taked!'));
		if(casebattleGame_games[id].players.filter(a => a.user.userid == bot.userid).length > 0) return callback(new Error('Error: This bot already joined in this case battle!'));
		if(Object.keys(casebattleGame_secure[id][position]).length > 0) return callback(new Error('Error: Another user are trying to join in this game. Please try again later!'));
		
		var amount = getFormatAmount(casebattleGame_games[id]['amount']);
		
		if(casebattleGame_games[id]['free']) amount = 0;
		
		if(getFormatAmount(row1[0].balance) < amount) return callback(new Error('Error: This bot is not available to join in this case battle!'));
		
		casebattleGame_secure[id][position][bot.userid] = true;
		
		casebattleGame_joinConfirm(bot, id, position, function(err2){
			if(err2) return callback(err2);
			
			if(casebattleGame_secure[id] !== undefined) if(casebattleGame_secure[id][position] !== undefined) if(casebattleGame_secure[id][position][bot.userid] !== undefined) delete casebattleGame_secure[id][position][bot.userid];
			
			callback(null, {
				userid: bot.userid,
				name: bot.name,
				avatar: bot.avatar,
				level: calculateLevel(bot.xp).level
			});
		});
	});
}

function admin_gamebotsCreate(user, socket, name, secret, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_site.access_secrets.includes(secret)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid secret!'
		});
		
		return cooldown(false, true);
	}
	
	name = name.trim();
	
	if(name.length < config.config_site.admin.gamebots_requirements.name_length.min){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You need to put a name with minimum ' + config.config_site.admin.gamebots_requirements.name_length.min + ' characters!'
		});
		
		return cooldown(false, true);
	}
	
	if(name.length > config.config_site.admin.gamebots_requirements.name_length.max){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You need to put a name with maximum ' + config.config_site.admin.gamebots_requirements.name_length.max + ' characters!'
		});
		
		return cooldown(false, true);
	}
	
	var userid = generateHexCode(24);
	var username = 'bot_' + generateHexCode(8);
	
	name = 'Bot ' + name;
	
	var avatar = config.config_site.url + config.config_site.root + 'template/img/avatar.jpg';
	
	pool.query('INSERT INTO `users` SET `bot` = 1, `userid` = ' + pool.escape(userid) + ', `username` = ' + pool.escape(username) + ', `name` = ' + pool.escape(name) + ', `avatar` = ' + pool.escape(avatar) + ', `time_create` = ' + pool.escape(time()), function(err1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		pool.query('INSERT INTO `users_changes` SET `userid` = ' + pool.escape(userid) + ', `change` = ' + pool.escape('username') + ', `value` = ' + pool.escape(username) + ', `time` = ' + pool.escape(time()), function(err2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			pool.query('INSERT INTO `users_changes` SET `userid` = ' + pool.escape(userid) + ', `change` = ' + pool.escape('name') + ', `value` = ' + pool.escape(name) + ', `time` = ' + pool.escape(time()), function(err3){
				if(err3){
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				pool.query('INSERT INTO `users_changes` SET `userid` = ' + pool.escape(userid) + ', `change` = ' + pool.escape('avatar') + ', `value` = ' + pool.escape(avatar) + ', `time` = ' + pool.escape(time()), function(err4){
					if(err4){
						logger.error(err4);
						writeError(err4);
						
						return cooldown(false, true);
					}
					
					var client_seed = generateHexCode(32);
					var server_seed = generateHexCode(64);
					
					pool.query('INSERT INTO `users_seeds_client` SET `userid` = ' + pool.escape(userid) + ', `seed` = ' + pool.escape(client_seed) + ', `time` = ' + pool.escape(time()), function(err5){
						if(err5){
							logger.error(err5);
							writeError(err5);
							
							return cooldown(false, true);
						}
						
						pool.query('INSERT INTO `users_seeds_server` SET `userid` = ' + pool.escape(userid) + ', `seed` = ' + pool.escape(server_seed) + ', `time` = ' + pool.escape(time()), function(err6){
							if(err6){
								logger.error(err6);
								writeError(err6);
								
								return cooldown(false, true);
							}
							
							socket.emit('message', {
								type: 'success',
								success: 'Game bot created successfully!'
							});
							
							socket.emit('message', {
								type: 'refresh'
							});
							
							cooldown(false, false);
						});
					});
				});
			});
		});
	});
}

function admin_getGamebots(user, socket, page, order, search, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.admin.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	var order_allowed = [ 0, 1, 2, 3, 4 ];
	if(!order_allowed.includes(order)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid order!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(page))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid page!'
		});
		
		return cooldown(false, true);
	}
	
	page = parseInt(page);
	search = search.trim();
	
	pool.query('SELECT COUNT(*) AS `count` FROM `users` WHERE `bot` = 1 AND (`userid` LIKE ' + pool.escape('%' + search + '%') + ' OR `username` LIKE ' + pool.escape('%' + search + '%') + ' OR `name` LIKE ' + pool.escape('%' + search + '%') + ')', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		var pages = parseInt(row1[0].count / 10) + (row1[0].count % 10 > 0 ? 1 : 0);
		
		if(pages <= 0){
			socket.emit('message', {
				type: 'pagination',
				command: 'admin_gamebots',
				list: [],
				pages: 1,
				page: 1
			});
			
			return cooldown(false, false);
		}
		
		if(page <= 0 || page > pages) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid page!'
			});
			
			return cooldown(false, true);
		}
		
		var order_query = { 
			0: 'ORDER BY `time_create` ASC',
			1: 'ORDER BY `name` ASC',
			2: 'ORDER BY `name` DESC',
			3: 'ORDER BY `balance` ASC',
			4: 'ORDER BY `balance` DESC'
		}[order];
		
		pool.query('SELECT `userid`, `name`, `avatar`, `xp`,  `balance`, `time_create` FROM `users` WHERE `bot` = 1 AND (`userid` LIKE ' + pool.escape('%' + search + '%') + ' OR `username` LIKE ' + pool.escape('%' + search + '%') + ' OR `name` LIKE ' + pool.escape('%' + search + '%') + ') ' + order_query + ' LIMIT 10 OFFSET ' + pool.escape(page * 10 - 10), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			var list = [];
			
			row2.forEach(function(item){
				list.push({
					user: {
						userid: item.userid,
						name: item.name,
						avatar: item.avatar,
						level: calculateLevel(item.xp).level
					},
					balance: getFormatAmount(item.balance),
					time_create: makeDate(new Date(item.time_create * 1000))
				});
			});
			
			socket.emit('message', {
				type: 'pagination',
				command: 'admin_gamebots',
				list: list,
				pages: pages,
				page: page
			});
			
			cooldown(false, false);
		});
	});
}

/* END GAME BOTS */