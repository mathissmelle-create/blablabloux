//fair_initializing();

var fair_generateQueue = [];
var fair_haveGenerateQueue = false;

var fair_getQueue = [];
var fair_haveGetQueue = false;

function fair_generateEosSeed(initialize, callback){
	fair_generateQueue.push({ initialize, callback });
	
	if(!fair_haveGenerateQueue) fair_queueGenerateEosSeed();
}

function fair_queueGenerateEosSeed(){
	fair_haveGenerateQueue = true;
	
	var link = 'https://eos.greymass.com/v1/chain/get_info'
	
	request(link, function(err1, response1, body1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return setTimeout(function(){
				fair_queueGenerateEosSeed();
			}, 1000);
		}
		
		if(response1 && response1.statusCode != 200) {
			return setTimeout(function(){
				fair_queueGenerateEosSeed();
			}, 1000);
		}
		
		if(!isJsonString(body1)) {
			return setTimeout(function(){
				fair_queueGenerateEosSeed();
			}, 1000);
		}
		
		var data = JSON.parse(body1);
		
		var last_block = data.head_block_num;
		var target_block = last_block + config.config_games.eos_future;
		
		fair_generateQueue[0].initialize({ block: target_block });
		
		var callback = fair_generateQueue[0].callback;
		fair_getEosSeed(target_block, function(target_hash){
			callback({
				block: target_block,
				hash: target_hash
			});
		});
		
		fair_generateQueue.shift();
		
		setTimeout(function(){
			if(fair_generateQueue.length > 0) return fair_queueGenerateEosSeed();
			
			fair_haveGenerateQueue = false;
		}, 1000);
	});
}

function fair_getEosSeed(block, callback){
	fair_getQueue.push({ block, callback });
	
	if(!fair_haveGetQueue) fair_queueGetEosSeed();
}

function fair_queueGetEosSeed(){
	fair_haveGetQueue = true;
	
	var options = {
		uri: 'https://eos.greymass.com/v1/chain/get_block',
		method: 'POST',
		body: JSON.stringify({ block_num_or_id: fair_getQueue[0].block })
	}
	
	request(options, function(err1, response1, body1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return setTimeout(function(){
				fair_queueGetEosSeed();
			}, 1000);
		}
		
		if(response1 && response1.statusCode != 200) {
			return setTimeout(function(){
				fair_queueGetEosSeed();
			}, 1000);
		}
		
		if(!isJsonString(body1)) {
			return setTimeout(function(){
				fair_queueGetEosSeed();
			}, 1000);
		}
		
		var data = JSON.parse(body1);
		
		var hash = data.id;
		
		fair_getQueue[0].callback(hash);
		
		fair_getQueue.shift();
		
		setTimeout(function(){
			if(fair_getQueue.length > 0) return fair_queueGetEosSeed();
			
			fair_haveGetQueue = false;
		}, 1000);
	});
}

function fair_generateServerSeed(){
	var server_seed = generateHexCode(64);
	
	return server_seed;
}

function fair_generatePublicSeed(){
	var public_seed = generateHexCode(64);
	
	return public_seed;
}

function fair_getCombinedSeed(server_seed, client_seed, nonce) {
	return [server_seed, client_seed, nonce].join('-');
}

function fair_generateSaltHash(seed) {
	return crypto.createHmac('sha256', seed).digest('hex');
}

function fair_getShuffle(salt, max) {
	//Set shuffle inexes
	var array = [];
	for(var i = 0; i < max; i++) array.push(i);
	
	//Fisher-yates shuffle implementation
	for(var i = array.length - 1, k = 0; i > 0; i--, k++) {
		var salt_position = fair_generateSaltHash(salt + '-' + k);
		var roll = fair_getRoll(salt_position, Math.pow(10, 8)) / Math.pow(10, 8);
		
		var j = Math.floor(roll * (i + 1));
		
		[array[i], array[j]] = [array[j], array[i]];
	}
	
	return array;
}

function fair_getRoll(salt, max) {
	return Math.abs(parseInt(salt.substr(0, 12), 16)) % max;
}

function fair_getRollTower(salt) {
	var array = [];
	
	//Get tower roll by stage
	for(var i = 0; i < 10; i++){
		var salt_position = fair_generateSaltHash(salt + '-' + i);
		
		var roll = fair_getRoll(salt_position, 3);
		
		array.push(roll);
	}
	
	return array;
}

function fair_getRollPlinko(salt) {
	var array = [];
	
	//Get plinko roll by stage
	for(var i = 0; i < 14; i++){
		var salt_position = fair_generateSaltHash(salt + '-' + i);
		
		var roll = fair_getRoll(salt_position, 2);
		
		array.push(roll);
	}
	
	return array;
}

function fair_getRollCaseBattle(salt, rounds, players) {
	var array = [];
	
	for(var i = 0; i < rounds; i++) {
		array.push([]);
		
		for(var j = 0; j < players; j++) {
			var salt_position = fair_generateSaltHash(salt + '-' + i + '-' + j);
			var roll = fair_getRoll(salt_position, Math.pow(10, 8)) / Math.pow(10, 8);
			
			array[i].push(roll);
		}
	}
	
	return array;
}

function fair_getRollCrash(salt){
	var INSTANT_CRASH_PERCENTAGE = config.config_games.games.crash.instant_chance;
	
	// Use the most significant 52-bit from the salt to calculate the crash point
    var h = parseInt(salt.slice(0, 52 / 4), 16);
    var e = Math.pow(2, 52);
    var result = (100 * e - h) / (e - h);
	
    // INSTANT_CRASH_PERCENTAGE of 5.00 will result in modifier of 0.95 = 5.00% house edge with a lowest crashpoint of 1.00x
    var houseEdgeModifier = 1 - INSTANT_CRASH_PERCENTAGE / 100;
    var endResult = Math.max(100, result * houseEdgeModifier);

    return Math.floor(endResult);
}

function fair_getUserSeeds(userid, callback){
	pool.query('SELECT users_seeds_client.seed AS `client_seed`, users_seeds_server.seed AS `server_seed`, users_seeds_server.nonce AS `nonce`, users_seeds_client.id AS `client_seedid`, users_seeds_server.id AS `server_seedid` FROM `users_seeds_client` INNER JOIN `users_seeds_server` ON users_seeds_client.userid = users_seeds_server.userid WHERE users_seeds_client.userid = ' + pool.escape(userid) + ' AND users_seeds_client.removed = 0 AND users_seeds_server.removed = 0 LIMIT 1', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return callback(new Error('Unable to get user seeds (1)'));
		}
		
		if(row1.length <= 0) return callback(new Error('Unable to get user seeds (2)'));
		
		var client_seedid = row1[0].client_seedid;
		var server_seedid = row1[0].server_seedid;
		
		var client_seed = row1[0].client_seed;
		var server_seed = row1[0].server_seed;
		
		var nonce = row1[0].nonce;
		
		callback(null, { client_seedid, server_seedid, client_seed, server_seed, nonce });
	});
}

function fair_regenerateServerSeed(user, socket, recaptcha, cooldown){
	cooldown(true, true);
	
	site_verifyRecaptcha(recaptcha, function(verified){
		if(!verified){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid recaptcha!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('UPDATE `users_seeds_server` SET `removed` = 1 WHERE `userid` = ' + pool.escape(user.userid) + ' AND `removed` = 0', function(err1, row1){
			if(err1) {
				logger.error(err1);
				writeError(err1);
				
				return cooldown(false, true);
			}
			
			var server_seed = generateHexCode(64);
			
			pool.query('INSERT INTO `users_seeds_server` SET `userid` = ' + pool.escape(user.userid) + ', `seed` = ' + pool.escape(server_seed) + ', `time` = ' + pool.escape(time()), function(err2, row2){
				if(err2) {
					logger.error(err2);
					writeError(err2);
					
					return cooldown(false, true);
				}
				
				socket.emit('message', {
					type: 'refresh'
				});
				
				socket.emit('message', {
					type: 'success',
					success: 'Server seed successfully regenerated!'
				});
				
				cooldown(false, false);
			});
		});
	});
}

function fair_changeClientSeed(user, socket, seed, recaptcha, cooldown){
	cooldown(true, true);
	
	site_verifyRecaptcha(recaptcha, function(verified){
		if(!verified){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid recaptcha!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('UPDATE `users_seeds_client` SET `removed` = 1 WHERE `userid` = ' + pool.escape(user.userid) + ' AND `removed` = 0', function(err1, row1){
			if(err1) {
				logger.error(err1);
				writeError(err1);
				
				return cooldown(false, true);
			}
			
			pool.query('INSERT INTO `users_seeds_client` SET `userid` = ' + pool.escape(user.userid) + ', `seed` = ' + pool.escape(seed) + ', `time` = ' + pool.escape(time()), function(err2, row2){
				if(err2) {
					logger.error(err2);
					writeError(err2);
					
					return cooldown(false, true);
				}
				
				socket.emit('message', {
					type: 'success',
					success: 'Client seed successfully changed!'
				});
				
				cooldown(false, false);
			});
		});
	});
}

function fair_useServerSeed(userid, callback){
	pool.query('SELECT * FROM `users_seeds_server` WHERE `userid` = ' + pool.escape(user.userid) + ' AND `removed` = 0 ORDER BY `id` DESC LIMIT 1', function(err1, row1){
		if(err1) return callback(new Error('Error'));
		
		if(row1.length <= 0) return callback(new Error('Error: You don\'t have a server seed.'));
		
		var server_seed = row1[0].seed;
		var nonce = row1[0].nonce;
		
		pool.query('UPDATE `users_seeds_server` SET `nonce` = `nonce` + 1 WHERE `userid` = ' + pool.escape(user.userid) + ' AND `seed` = ' + pool.escape(server_seed) + ' AND `removed` = 0', function(err2, row2){
			if(err2) {
				logger.error(err2);
				writeError(err2);
				return;
			}
			
			if(row2.affectedRows <= 0) return callback(new Error('Error'));
			
			callback(null, {
				seed: server_seed,
				nonce: nonce
			});
		});
	});
}

function fair_initializing(){
	pool.query('SELECT `userid` FROM `users`', function(err1, row1){
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		row1.forEach(function(user){
			var client_seed = generateHexCode(32);
			var server_seed = generateHexCode(64);
			
			pool.query('INSERT INTO `users_seeds_client` SET `userid` = ' + pool.escape(user.userid) + ', `seed` = ' + pool.escape(client_seed) + ', `time` = ' + pool.escape(time()), function(err2){
				if(err2) {
					logger.error(err2);
					writeError(err2);
					return;
				}
			});
			
			pool.query('INSERT INTO `users_seeds_server` SET `userid` = ' + pool.escape(user.userid) + ', `seed` = ' + pool.escape(server_seed) + ', `time` = ' + pool.escape(time()), function(err2){
				if(err2) {
					logger.error(err2);
					writeError(err2);
					return;
				}
			});
		});
	});
}