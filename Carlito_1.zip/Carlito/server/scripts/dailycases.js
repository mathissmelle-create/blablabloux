var dailycases_cases = {};

function dailycases_getCases(user, socket, cooldown){
	cooldown(true, true);
	
	var list_cases = [];
	
	dailycases_getCasesCase(user, 0, dailycases_cases, [], function(err1, list_cases){
		if(err1) return cooldown(false, true);
		
		list_cases.sort(function(a, b){ return a.level - b.level });
		
		socket.emit('message', {
			type: 'dailycases',
			command: 'cases',
			cases: list_cases,
			level: calculateLevel(user.xp).level
		});
		
		cooldown(false, false);
	});
}

function dailycases_getCasesCase(user, caseid, cases, list, callback){
	if(caseid >= Object.keys(dailycases_cases).length) return callback(null, list);
	
	pool.query('SELECT * FROM `dailycases_bets` WHERE `userid` = ' + pool.escape(user.userid) + ' AND `caseid` = ' + pool.escape(Object.keys(dailycases_cases)[caseid]) + ' AND `time` > ' + pool.escape(time() - config.config_site.dailycases.time * 60 * 60), function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return callback(new Error('Error (1)'));
		}
		
		var time_cooldown = row1.length > 0 ? (parseInt(row1[0].time) - time() + config.config_site.dailycases.time * 60 * 60) : -1;
		
		list.push({
			id: Object.keys(dailycases_cases)[caseid],
			name: dailycases_cases[Object.keys(dailycases_cases)[caseid]].name,
			image: dailycases_cases[Object.keys(dailycases_cases)[caseid]].image,
			level: dailycases_cases[Object.keys(dailycases_cases)[caseid]].level,
			time: time_cooldown
		});
		
		dailycases_getCasesCase(user, caseid + 1, cases, list, callback);
	});
}

function dailycases_getItems(items){
	var newitems = [];
	
	items.forEach(function(item){
		newitems.push({
			id: item.id,
			name: itemsSystem_items[item.id].name,
			image: itemsSystem_items[item.id].image,
			price: getFormatAmount(itemsSystem_items[item.id].price),
			chance: roundedToFixed(item.chance, 5),
			quality: itemsSystem_items[item.id].quality
		});
	});
	
	return newitems;
}

function dailycases_getCase(user, socket, id, cooldown){
	cooldown(true, true);
	
	if(dailycases_cases[id] === undefined) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid case id!'
		});
		
		return cooldown(false, true);
	}
	
	var items = dailycases_getItems(dailycases_cases[id].items);
	
	var tickets = dailycases_generateTickets(items);
	var newitems = [];
	
	items.forEach(function(item, index){
		newitems.push({
			name: item.name,
			image: item.image,
			price: getFormatAmount(item.price),
			chance: roundedToFixed(item.chance, 5),
			color: getColorByQuality(item.quality),
			tickets: tickets[index]
		});
	})
	
	socket.emit('message', {
		type: 'dailycases',
		command: 'show',
		items: newitems,
		dailycase: {
			id: id,
			name: dailycases_cases[id].name,
			image: dailycases_cases[id].image,
			level: dailycases_cases[id].level
		},
		level: calculateLevel(user.xp).level,
		spinner: dailycases_generateSpinner(items)
	});
	
	cooldown(false, false);
}

function dailycases_openCase(user, socket, id, cooldown){
	cooldown(true, true);
	
	if(dailycases_cases[id] === undefined) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid case id!'
		});
		
		return cooldown(false, true);
	}
	
	if(calculateLevel(user.xp).level < dailycases_cases[id].level) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: You need to level up to open this case!'
		});
		
		return cooldown(false, true);
	}
	
	pool.query('SELECT * FROM `dailycases_bets` WHERE `userid` = ' + pool.escape(user.userid) + ' AND `caseid` = ' + pool.escape(id) + ' AND `time` > ' + pool.escape(time() - config.config_site.dailycases.time * 60 * 60), function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length > 0) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: You already opened this daily case in the last ' + config.config_site.dailycases.time + ' hours!'
			});
			
			return cooldown(false, true);
		}
	
		//SEEDS
		fair_getUserSeeds(user.userid, function(err2, fair){
			if(err2) {
				socket.emit('message', {
					type: 'error',
					error: err2.message
				});
				
				return cooldown(false, true);
			}
			
			var seed = fair_getCombinedSeed(fair.server_seed, fair.client_seed, fair.nonce);
			var salt = fair_generateSaltHash(seed);
			
			var items = dailycases_getItems(dailycases_cases[id].items);
			
			var tickets = dailycases_generateTickets(items);
			var total = tickets[tickets.length - 1].max;
			
			var spinner = dailycases_generateSpinner(items);
			
			var roll = fair_getRoll(salt, total) + 1;
			
			var winning_item = null;
			
			for(var i = 0; i < tickets.length; i++){
				if(roll >= tickets[i].min && roll <= tickets[i].max) {
					winning_item = {
						id: items[i].id,
						name: items[i].name,
						image: items[i].image,
						price: getFormatAmount(items[i].price),
						chance: roundedToFixed(items[i].chance, 5),
						color: getColorByQuality(items[i].quality)
					};
					
					break;
				}
			}
			
			spinner[99] = winning_item;
			
			var winning = getFormatAmount(winning_item.price);
			
			pool.query('INSERT INTO `dailycases_bets` SET `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + parseInt(user.xp) + ', `caseid` = ' + pool.escape(id) + ', `itemid` = ' + pool.escape(winning_item.id) + ', `roll` = ' + roll + ', `tickets` = ' + total + ', `server_seedid` = ' + pool.escape(fair.server_seedid) + ', `client_seedid` = ' + pool.escape(fair.client_seedid) + ', `nonce` = ' + pool.escape(fair.nonce) + ', `time` = ' + pool.escape(time()), function(err3) {
				if(err3) {
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
			
				pool.query('UPDATE `users_seeds_server` SET `nonce` = `nonce` + 1 WHERE `userid` = ' + pool.escape(user.userid) + ' AND `id` = ' + pool.escape(fair.server_seedid), function(err4){
					if(err4) {
						logger.debug(err4);
						writeError(err4);
						
						return cooldown(false, true);
					}
					
					//EDIT BALANCE
					user_editBalance(user.userid, 0, 'dailycase_win', function(err5){
						if(err5) {
							logger.error(err5);
							writeError(err5);
							
							return cooldown(false, true);
						}
						
						user_addItems(user.userid, [ winning_item.id ], 'dailycase_win', function(err6){
							if(err6) {
								logger.error(err6);
								writeError(err6);
								
								return cooldown(false, true);
							}
						
							socket.emit('message', {
								type: 'dailycases',
								command: 'countdown',
								dailycase: {
									id: id,
									level: dailycases_cases[id].level,
									time: config.config_site.dailycases.time * 60 * 60
								}
							});
							
							socket.emit('message', {
								type: 'dailycases',
								command: 'roll',
								items: spinner
							});
							
							setTimeout(function(){
								socket.emit('message', {
									type: 'dailycases',
									command: 'finish'
								});
								
								logger.debug('[DAILY CASE] Win registed. ' + user.name + ' did win $' + getFormatAmountString(winning) + ' with chance ' + roundedToFixed(winning_item.chance, 2).toFixed(2) + '%');
							}, 5000);
							
							logger.debug('[DAILY CASE] Bet registed. ' + user.name + ' did open a daily case level' + dailycases_cases[id].level);
							
							cooldown(false, false);
						});
					});
				});
			});
		});
	});
}

function dailycases_generateTickets(items){
	var decimals = 0; 
	items.forEach(function(item){
		if(countDecimals(item.chance) > decimals) decimals = countDecimals(item.chance);
	});

	var tickets = [];
	var total = 0;

	items.forEach(function(item){
		tickets.push({
			min: total + 1,
			max: total + item.chance * Math.pow(10, decimals)
		});
		
		total += item.chance * Math.pow(10, decimals);
	});
	
	return tickets;
}

function dailycases_generateSpinner(items){
	var tickets = dailycases_generateTickets(items);
	var total = tickets[tickets.length - 1].max;
	
	var spinner = [];
	
	for(var i = 0; i < 150; i++){
		var ticket = getRandomInt(1, total);
		
		for(var j = 0; j < tickets.length; j++){
			if(ticket >= tickets[j].min && ticket <= tickets[j].max) {
				spinner.push({
					name: items[j].name,
					image: items[j].image,
					price: getFormatAmount(items[j].price),
					chance: roundedToFixed(items[j].chance, 5),
					color: getColorByQuality(items[j].quality)
				});
			}
		}
	}
	
	return spinner;
}