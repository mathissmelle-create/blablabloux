var itemsSystem_items = {};

itemsSystem_loadItems(function(){
	itemsSystem_initializing();
});

function itemsSystem_initializing(){
	logger.warn('[ITEMS SYSTEM] Loading Prices');
	
	itemsSystem_loadPrices(730, function(err1, count){
		if(err1){
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		logger.warn('[ITEMS SYSTEM] Loaded ' + count + ' Prices Successfully');
		
		site_pricesUpdate_items = true;
		
		itemsSystem_loadItems(function(){
			site_pricesUpdate_items = false;
		});
		
		setTimeout(function(){
			logger.warn('[ITEMS SYSTEM] Loading Prices');
			
			itemsSystem_loadPrices(730, function(err1, count){
				if(err1){
					logger.error(err1);
					writeError(err1);
					return;
				}
				
				logger.warn('[ITEMS SYSTEM] Loaded ' + count + ' Prices Successfully');
				
				site_pricesUpdate_items = true;
				
				itemsSystem_loadItems(function(){
					site_pricesUpdate_items = false;
				});
			});
		}, config.config_site.items.prices.cooldown_load * 1000);
	});
}

function itemsSystem_loadItems(callback){
	logger.warn('[ITEMS SYSTEM] Loading Items');
	
	pool.query('SELECT * FROM `items_list`', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		row1.forEach(function(item){
			itemsSystem_items[item.itemid] = {
				id: item.itemid,
				name: item.name,
				image: item.image,
				price: parseFloat(item.price),
				quality: item.quality,
				update: parseInt(item.update)
			};
		});
		
		itemsSystem_loadCases(function(){
			itemsSystem_loadDailycases(function(){
				if(callback) callback();
			});
		});
	});
}

function itemsSystem_loadPrices(game, callback){
	var options = {
		headers: {
			'content-type': 'application/json',
			'x-apikey': config.config_site.items.prices.apikey.key,
		},
		uri: 'https://api.bitskins.com/market/skin/' + game,
		qs: {}
	}
	
	request(options, function(err1, response1, body1) {
		if(err1) return callback(err1);
		
		if (200 != response1.statusCode) return callback(new Error('Error'));
		
		if (!isJsonString(body1)) return callback(new Error('Error'));
		
		var body = JSON.parse(body1);
		
		var prices = [];
		
		body.forEach(function(item){
			var itemid = crypto.createHash('md5').update(item.name).digest().toString('hex');
			
			if(itemsSystem_items[itemid] !== undefined && item.suggested_price != null){
				prices.push({
					name: item.name,
					price: roundedToFixed(item.suggested_price / 1000, 2)
				});
			}
		});
		
		itemsSystem_updatePrices(0, prices, 0, function(err2, count){
			if(err2) return callback(err2);
			
			callback(null, count);
		});
	});
}

function itemsSystem_updatePrices(index, prices, count, callback){
	if(index >= prices.length) return callback(null, count);
	
	if(prices[index].price <= 0) return itemsSystem_updatePrices(index + 1, prices, count, callback);
	
	var itemid = crypto.createHash('md5').update(prices[index].name).digest().toString('hex');
	
	pool.query('UPDATE `items_list` SET `price` = ' + prices[index].price + ', `update` = ' + pool.escape(time()) + ' WHERE `itemid` = ' + pool.escape(itemid), function(err1, row1){
		if(err1) return callback(err1);
		
		if(row1.affectedRows > 0) count++;
		
		itemsSystem_updatePrices(index + 1, prices, count, callback);
	});
}

function itemsSystem_loadCases(callback){
	logger.warn('[ITEMS SYSTEM] Loading Cases');
	
	pool.query('SELECT * FROM `cases_cases` WHERE `removed` = 0', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		row1.forEach(function(caseitem){
			var items = JSON.parse(caseitem.items);
			var offset = roundedToFixed(caseitem.offset, 2);
			
			var battle = parseInt(caseitem.battle);
			
			var price = 0;
			
			items.forEach(function(item){
				var item_price = getFormatAmount(itemsSystem_items[item.id].price);
				
				price += item_price * item.chance / 100;
			});
			
			price = getFormatAmount(price * (1 + offset / 100));
			
			var item = {
				name: caseitem.name,
				image: caseitem.image,
				price: price,
				category: 0,
				items: items
			}
			
			casesGame_cases[caseitem.caseid] = item; //UNBOXING
			if(battle) casebattleGame_cases[caseitem.caseid] = item; //CASE BATTLE
		});
		
		unboxingGame_loadHistory();
		casebattleGame_loadHistory();
		
		if(callback) callback();
	});
}

function itemsSystem_loadDailycases(callback){
	logger.warn('[ITEMS SYSTEM] Loading Daily Cases');
	
	pool.query('SELECT * FROM `cases_dailycases` WHERE `removed` = 0', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		row1.forEach(function(caseitem){
			var items = JSON.parse(caseitem.items);
			var level = parseInt(caseitem.level);
			
			var item = {
				name: caseitem.name,
				image: caseitem.image,
				items: items,
				level: level
			}
			
			dailycases_cases[caseitem.caseid] = item; //DAILY CASES
		});
		
		if(callback) callback();
	});
}

function itemsSyatem_addUserItem(userid, itemid, callback){
	if(itemsSystem_items[itemid] === undefined) return callback(new Error('Unknown itemid!'));
	
	pool.query('INSERT INTO `users_items` SET `itemid` = ' + pool.escape(itemid) + ', `userid` = ' + pool.escape(userid) + ', `time` = ' + pool.escape(time()), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return callback(err1);
		}
		
		if(row1.affectedRows <= 0) return callback(new Error('User item unsuccessfully added!'));
		
		callback(null, {
			id: row1.insertId,
			itemid: itemid,
			price: itemsSystem_items[itemid].price
		});
	});
}