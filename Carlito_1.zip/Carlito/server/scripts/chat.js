var chat_massages = [];
var chat_ignoreList = {};
var chat_userLastMessage = {};

var chat_mode = 'normal';

var chat_commandsList = {
	'ignore': 'userid',
	'unignore': 'userid',
	'ignorelist': 'none',
	'mute': 'userid',
	'unmute': 'userid',
	'deletemessage': 'id',
	'cleanchat': 'none',
	'chatmode': 'none',
	'tiprain': 'none',
	'lastrain': 'none',
	'rollrain': 'none',
	'online': 'none',
};

var chat_commandsRank = {
	0: ['ignore', 'unignore', 'ignorelist', 'tiprain', 'lastrain'],
	1: ['ignore', 'unignore', 'ignorelist', 'mute', 'unmute', 'deletemessage', 'cleanchat', 'chatmode', 'tiprain', 'lastrain', 'rollrain', 'online'],
	2: ['ignore', 'unignore', 'ignorelist', 'mute', 'deletemessage', 'cleanchat', 'chatmode', 'tiprain', 'lastrain', 'rollrain', 'online'],
	3: ['ignore', 'unignore', 'ignorelist', 'tiprain', 'lastrain'],
	4: ['ignore', 'unignore', 'ignorelist', 'tiprain', 'lastrain'],
	5: ['ignore', 'unignore', 'ignorelist', 'tiprain', 'lastrain'],
	6: ['ignore', 'unignore', 'ignorelist', 'tiprain', 'lastrain'],
	7: ['ignore', 'unignore', 'ignorelist', 'tiprain', 'lastrain'],
	8: ['ignore', 'unignore', 'ignorelist', 'mute', 'unmute', 'deletemessage', 'cleanchat', 'chatmode', 'tiprain', 'lastrain', 'rollrain', 'online'],
	100: ['ignore', 'unignore', 'ignorelist', 'mute', 'unmute', 'deletemessage', 'cleanchat', 'chatmode', 'tiprain', 'lastrain', 'rollrain', 'online']
}

var chat_ranksList = [
	{ rank: 'player', code: 0 },
	{ rank: 'admin', code: 1 },
	{ rank: 'moderator', code: 2 },
	{ rank: 'helper', code: 3 },
	{ rank: 'veteran', code: 4 },
	{ rank: 'pro', code: 5 },
	{ rank: 'youtuber', code: 6 },
	{ rank: 'streamer', code: 7 },
	{ rank: 'developer', code: 8 },
	{ rank: 'owner', code: 100 }
]

chat_loadMessages();
function chat_loadMessages(){
	pool.query('SELECT * FROM `chat_messages` WHERE `deleted` = 0 ORDER BY `id` DESC LIMIT ' + config.config_chat.max_messages, async function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		if(row1.length <= 0) return;
			
		row1.reverse();
		
		loadMessage(0, row1);
		function loadMessage(index, messages){
			if(index >= messages.length) return chat_refreshMessages(io.sockets);
			
			chat_getMentions(messages[index].message, function(mentions){
				var new_message = {
					type: 'player',
					id: messages[index].id,
					user: {
						userid: messages[index].userid,
						name: messages[index].name,
						avatar: messages[index].avatar,
						level: calculateLevel(messages[index].xp).level
					},
					rank: messages[index].rank,
					private: messages[index]['private'],
					message: messages[index].message,
					channel: messages[index].channel,
					mentions: mentions,
					time: messages[index].time
				}
				
				chat_massages.push(new_message);
				
				loadMessage(index + 1, messages);
			});
		}
	});
}

chat_loadIgnoreList();
function chat_loadIgnoreList(){
	pool.query('SELECT * FROM `chat_ignore` WHERE `removed` = 0 ORDER BY `id` DESC', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		if(row1.length <= 0) return;
		
		if(chat_ignoreList[row1[0].userid] === undefined) chat_ignoreList[row1[0].userid] = [];
		
		chat_ignoreList[row1[0].userid].push(row1[0].ignoreid);
	});
}

if(config.config_chat.support.active){
	setInterval(function(){
		otherMessages(config.config_chat.support.message, io.sockets, true);
	}, config.config_chat.support.cooldown * 1000);
}

function chat_loadChannel(user, socket, channel, cooldown){
	cooldown(true, true);
	
	logger.debug(user.name + '(' + user.userid + ') - Chat Changed to ' + channel);
	
	socket.emit('message', {
		type: 'chat',
		command: 'channel',
		channel: channel
	});
	
	chat_massages.forEach(function(item){
		socket.emit('message', {
			type: 'chat',
			command: 'message',
			message: item,
			added: false
		});
	});
	
	if(config.config_chat.greeting.active) otherMessages(config.config_chat.greeting.message, socket, false);
	
	cooldown(false, false);
}

function chat_refreshMessages(socket){
	socket.emit('message', {
		type: 'chat',
		command: 'clean'
	});
	
	chat_massages.forEach(function(item){
		socket.emit('message', {
			type: 'chat',
			command: 'message',
			message: item,
			added: false
		});
	});
}

function otherMessages(message, socket, keep){
	var new_message = {
		type: 'system',
		message: message,
		time: new Date().getTime()
	}
	
	socket.emit('message', {
		type: 'chat',
		command: 'message',
		message: new_message,
		added: false
	});
	
	if(keep){
		chat_massages.push(new_message);
		
		while(chat_massages.length > config.config_chat.max_messages) chat_massages.shift();
	}
}

function chat_checkCommand(command, rank){
	if(chat_commandsList[command] === undefined) return false;
	if(!chat_commandsRank[rank].includes(command)) return false;
	
	return true;
}

function chat_checkMessage(user, socket, message, channel, cooldown) {
	cooldown(true, true);
	
	if(message.trim().length <= 0){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Message is empty!'
		});
		
		return cooldown(false, true);
	}
	
	var res = null;
	
	logger.debug(user.name + '(' + user.userid + ') - Chat Message | Message: ' + message);
	
	if (res = /^\/help ([a-zA-Z0-9 ]*)/.exec(message)) {
		if(!chat_checkCommand(res[1], user.rank)){
			socket.emit('message', {
				type: 'error',
				error: 'Invalid command name provided!'
			});
			
			return cooldown(false, true);
		}
	
		if(res[1] == 'mute'){
			var text_message = 'By using this command you can mute the people that infringe the rules of chat! If you mute innocent people you can lose this rank.';
			text_message += '<br><br>Type /mute [user id] [time] [reason]<br><br>For exemple [time] can be [amount][minutes/hours/days/months/years] or [permanent].';
		} else if(res[1] == 'unmute'){
			var text_message = 'By using this command you can unmute innocent people who have received the mute! If you unmute guilty people you can lose this rank.';
			text_message += '<br><br>Type /unmute [user id]';
		} else if(res[1] == 'deletemessage'){
			var text_message = 'By using this command you can delete messages that are spammed or contain mistakes or others!';
			text_message += '<br><br>Type /deletemessage [message id]';
		} else if(res[1] == 'cleanchat'){
			var text_message = 'By using this command you can clean the chat to be fresh!';
			text_message += '<br><br>Type /cleanchat';
		} else if(res[1] == 'ignorelist'){
			var text_message = 'By using this command you can view the list who contail all players ignored!';
			text_message += '<br><br>Type /ignorelist';
		} else if(res[1] == 'ignore'){
			var text_message = 'By using this command you can ignore the player who has annoyed you or who is spamming you or something else!';
			text_message += '<br><br>Type /ignore [user id]';
		} else if(res[1] == 'unignore'){
			var text_message = 'By using this command you can unignore the player who is ignored!';
			text_message += '<br><br>Type /unignore [user id]';
		} else if(res[1] == 'chatmode'){
			var text_message = 'By using this command you can change the chat mode to be a chat who contain spam or a chat who is stopped or a normal chat!';
			text_message += '<br><br>Type /chatmode [normal / fast / pause]';
		} else if(res[1] == 'tiprain'){
			var text_message = 'By using this command you can tip coins to rain!';
			text_message += '<br><br>Type /tiprain [amount]';
		} else if(res[1] == 'lastrain'){
			var text_message = 'By using this command you can see when was the last rain!';
			text_message += '<br><br>Type /lastrain';
		} else if(res[1] == 'rollrain'){
			var text_message = 'By using this command you can roll the rain faster than it should have been!';
			text_message += '<br><br>Type /rollrain';
		} else if(res[1] == 'online'){
			var text_message = 'By using this command you can see the online players!';
			text_message += '<br><br>Type /online';
		}
		
		otherMessages(text_message, socket, false);
		
		cooldown(false, false);
	} else if (res = /^\/help/.exec(message)) {
		var text_message = 'Available commands: ';
		
		chat_commandsRank[user.rank].forEach(function(item, index){
			text_message += '/' + item;
			
			if(index < chat_commandsRank[user.rank].length - 1) text_message += ', ';
			else text_message += '.';
		});
		
		text_message += '<br><br>If you need help for a command please send /help [command] (Ex: /help ignore).'
		
		otherMessages(text_message, socket, false);
		
		cooldown(false, false);
	} else if (res = /^\/mute ([a-z0-9_]*) ([a-zA-Z0-9]*) ([a-zA-Z0-9 ]*)/.exec(message)) {
		if(!chat_checkCommand('mute', user.rank)){
			socket.emit('message', {
				type: 'error',
				error: 'Invalid command name provided!'
			});
			
			return cooldown(false, true);
		}
		
		user_setRestriction(user, socket, {
			userid: res[1],
			restriction: 'mute',
			time: res[2],
			reason: res[3]
		}, true, function(err1){
			if(err1){
				socket.emit('message', {
					type: 'error',
					error: err1.message
				});
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'success',
				success: 'The user was successfully restricted!'
			});
			
			cooldown(false, false);
		});
	} else if (res = /^\/unmute ([a-z0-9_]*)/.exec(message)) {
		if(!chat_checkCommand('unmute', user.rank)){
			socket.emit('message', {
				type: 'error',
				error: 'Invalid command name provided!'
			});
			
			return cooldown(false, true);
		}
		
		user_unsetRestriction(user, socket, {
			userid: res[1],
			restriction: 'mute'
		}, function(err1){
			if(err1){
				socket.emit('message', {
					type: 'error',
					error: err1.message
				});
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'success',
				success: 'The user was successfully unrestricted!'
			});
			
			cooldown(false, false);
		});
	} else if (res = /^\/deletemessage ([0-9]*)/.exec(message)) {
		if(!chat_checkCommand('deletemessage', user.rank)){
			socket.emit('message', {
				type: 'error',
				error: 'Invalid command name provided!'
			});
			
			return cooldown(false, true);
		}
		
		if(isNaN(Number(res[1]))){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid message id!'
			});
			
			return cooldown(false, true);
		}
		
		var message_id = res[1];
		
		var message_index = chat_massages.findIndex(item => item.id == message_id);
		
		if(message_index == -1){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Unknown message id or already deleted!'
			});
			
			return cooldown(false, true);
		}
			
		pool.query('UPDATE `chat_messages` SET `deleted` = 1 WHERE `id` = ' + message_id);
		
		chat_massages.splice(message_index, 1);
		
		io.sockets.emit('message', {
			type: 'chat',
			command: 'delete',
			id: message_id
		});
		
		cooldown(false, false);
	} else if (res = /^\/cleanchat/.exec(message)) {
		if(!chat_checkCommand('cleanchat', user.rank)){
			socket.emit('message', {
				type: 'error',
				error: 'Invalid command name provided!'
			});
			
			return cooldown(false, true);
		}
		
		if(chat_massages.length <=  0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: There are no messages!'
			});
			
			return cooldown(false, true);
		}
		
		chat_massages = [];
		
		io.sockets.emit('message', {
			type: 'chat',
			command: 'clean'
		});
		
		var text_message = 'Chat history has been wiped.';
		otherMessages(text_message, io.sockets, false);
		
		cooldown(false, false);
	} else if (res = /^\/ignorelist/.exec(message)) {
		if(!chat_checkCommand('ignorelist', user.rank)){
			socket.emit('message', {
				type: 'error',
				error: 'Invalid command name provided!'
			});
			
			return cooldown(false, true);
		}
		
		if(chat_ignoreList[user.userid] === undefined){
			var text_message = 'Your ignore list is empty.';
			otherMessages(text_message, socket, false);
			
			return cooldown(false, true);
		}
		
		if(chat_ignoreList[user.userid].length <= 0){
			var text_message = 'Your ignore list is empty.';
			otherMessages(text_message, socket, false);
			
			return cooldown(false, true);
		}
		
		var text_message = 'Ignored users: ' + chat_ignoreList[user.userid].join(', ');
		otherMessages(text_message, socket, false);
		
		cooldown(false, false);
	} else if (res = /^\/ignore ([a-z0-9_]*)/.exec(message)) {
		if(!chat_checkCommand('ignore', user.rank)){
			socket.emit('message', {
				type: 'error',
				error: 'Invalid command name provided!'
			});
			
			return cooldown(false, true);
		}
		
		if(res[1] == user.userid){
			socket.emit('message', {
				type: 'error',
				error: 'Error: You can\'t ignore yourself!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('SELECT `name` FROM `users` WHERE `userid` = ' + pool.escape(res[1]), function(err1, row1) {
			if(err1){
				logger.error(err1);
				writeError(err1);
				
				return cooldown(false, true);
			}
			
			if(row1.length <= 0) {
				socket.emit('message', {
					type: 'error',
					error: 'Error: Unknown user!'
				});
				
				return cooldown(false, true);
			}
			
			pool.query('SELECT * FROM `chat_ignore` WHERE `removed` = 0 AND `ignoreid` = ' + pool.escape(res[1]), function(err2, row2){
				if(err2){
					logger.error(err2);
					writeError(err2);
					
					return cooldown(false, true);
				}
				
				if(row2.length > 0){
					socket.emit('message', {
						type: 'error',
						error: 'Error: This user is already ignored!'
					});
					
					return cooldown(false, true);
				}
				
				pool.query('INSERT INTO `chat_ignore` SET `userid` = ' + pool.escape(user.userid) + ', `ignoreid` = ' + pool.escape(res[1]) + ', `time` = ' + pool.escape(time()), function(err3, row3){
					if(err3){
						logger.error(err3);
						writeError(err3);
						
						return cooldown(false, true);
					}
					
					if(chat_ignoreList[user.userid] === undefined) chat_ignoreList[user.userid] = [];
					
					chat_ignoreList[user.userid].push(res[1]);
					
					socket.emit('message', {
						type: 'chat',
						command: 'ignorelist',
						list: chat_ignoreList[user.userid]
					});
					
					chat_refreshMessages(socket);
					
					socket.emit('message', {
						type: 'info',
						info: 'User ' + row1[0].name + ' successfully ignored!'
					});
					
					cooldown(false, false);
				});
			});
		});
	} else if (res = /^\/unignore ([a-z0-9_]*)/.exec(message)) {
		if(!chat_checkCommand('unignore', user.rank)){
			socket.emit('message', {
				type: 'error',
				error: 'Invalid command name provided!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('SELECT `name` FROM `users` WHERE `userid` = ' + pool.escape(res[1]), function(err1, row1) {
			if(err1){
				logger.error(err1);
				writeError(err1);
				
				return cooldown(false, true);
			}
			
			if(row1.length <= 0) {
				socket.emit('message', {
					type: 'error',
					error: 'Error: Unknown user!'
				});
				
				return cooldown(false, true);
			}
			
			pool.query('SELECT * FROM `chat_ignore` WHERE `removed` = 0 AND `ignoreid` = ' + pool.escape(res[1]), function(err2, row2){
				if(err2){
					logger.error(err2);
					writeError(err2);
					
					return cooldown(false, true);
				}
				
				if(row2.length <= 0){
					socket.emit('message', {
						type: 'error',
						error: 'Error: This user is not ignored!'
					});
					
					return cooldown(false, true);
				}
				
				pool.query('UPDATE `chat_ignore` SET `removed` = 1 WHERE `ignoreid` = ' + pool.escape(res[1]), function(err3, row3){
					if(err3){
						logger.error(err3);
						writeError(err3);
						
						return cooldown(false, true);
					}
					
					var index = chat_ignoreList[user.userid].indexOf(res[1]);
					chat_ignoreList[user.userid].splice(index, 1);
					
					socket.emit('message', {
						type: 'chat',
						command: 'ignorelist',
						list: chat_ignoreList[user.userid]
					});
					
					chat_refreshMessages(socket);
					
					socket.emit('message', {
						type: 'info',
						info: 'User ' + row1[0].name + ' successfully unignored!'
					});
					
					cooldown(false, false);
				});
			});
		});
	} else if (res = /^\/chatmode ([a-zA-Z0-9]*)/.exec(message)) {
		if(!chat_checkCommand('chatmode', user.rank)){
			socket.emit('message', {
				type: 'error',
				error: 'Invalid command name provided!'
			});
			
			return cooldown(false, true);
		}
		
		if(res[1] != 'normal' && res[1] != 'fast' && res[1] != 'pause'){
			socket.emit('message', {
				type: 'error',
				error: 'Invalid chat mode!'
			});
			
			return cooldown(false, true);
		}
		
		chat_mode = res[1];
		
		var text_message = 'Chat has changed to ' + res[1] + ' mode.';
		otherMessages(text_message, io.sockets, true);
		
		cooldown(false, false);
	} else if (res = /^\/tiprain ([0-9.]*)/.exec(message)) {
		if(!chat_checkCommand('tiprain', user.rank)){
			socket.emit('message', {
				type: 'error',
				error: 'Invalid command name provided!'
			});
			
			return cooldown(false, true);
		}
		
		rain_tipGame(user, socket, res[1], cooldown);
	} else if (res = /^\/lastrain/.exec(message)) {
		if(!chat_checkCommand('lastrain', user.rank)){
			socket.emit('message', {
				type: 'error',
				error: 'Invalid command name provided!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('SELECT `time_roll` FROM `rain_history` WHERE `ended` = 1 ORDER BY `id` DESC LIMIT 1', function(err1, row1) {
			if(err1) {
				logger.error(err1);
				writeError(err1);
				
				return cooldown(false, true);
			}
			
			if(row1.length > 0){
				var last_rain = getFormatSeconds(time() - row1[0].time_roll);
				
				var text_message = 'Last rain was now ' + last_rain.minutes + ' minutes and ' + last_rain.seconds + ' seconds ago.';
				otherMessages(text_message, socket, false);
			} else {
				var text_message = 'This is first rain.';
				otherMessages(text_message, socket, false);
			}
			
			cooldown(false, false);
		});
	} else if (res = /^\/rollrain/.exec(message)) {
		if(!chat_checkCommand('rollrain', user.rank)){
			socket.emit('message', {
				type: 'error',
				error: 'Invalid command name provided!'
			});
			
			return cooldown(false, true);
		}
		
		if(rain_game.status != 'wait') {
			socket.emit('message', {
				type: 'error',
				error: 'Error: You can only roll the rain until starts!'
			});
			
			return cooldown(false, true);
		}
		
		rain_rollGame();
		
		cooldown(false, false);
	} else if (res = /^\/online/.exec(message)) {
		if(!chat_checkCommand('online', user.rank)){
			socket.emit('message', {
				type: 'error',
				error: 'Invalid command name provided!'
			});
			
			return cooldown(false, true);
		}
		
		var list = [];
		
		Object.keys(users_online).forEach(function(item){
			list.push(users_online[item].user);
		});
		
		socket.emit('message', {
			type: 'list',
			list: list
		});
		
		cooldown(false, false);
	} else if (res = /^\/([a-zA-Z0-9]*)/.exec(message)) {
		socket.emit('message', {
			type: 'error',
			error: 'Invalid command provided!'
		});
		
		cooldown(false, false);
	} else {
		chat_writeMessage(user, socket, message, channel, cooldown);
	}
}

function chat_writeMessage(user, socket, message, channel, cooldown){
	cooldown(true, true);
	
	if(chat_mode == 'pause' && !config.config_site.pause_excluded.includes(config.config_site.ranks_name[user.rank])) {
		return cooldown(false, true);
	}
	
	if(chat_mode == 'normal') if(chat_userLastMessage[user.userid] + config.config_chat.cooldown_massage > time()) {
		return cooldown(false, true);
	}
	
	chat_userLastMessage[user.userid] = time();
	
	var message = chat_safeMessage(message).trim();
	
	if(message.length <= 0) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: You can\'t send a empty message.'
		});
		
		return cooldown(false, true);
	}
	
	if (message.length > 200) message = message.substr(0, 200);
	
	if((user.restrictions.mute >= time() || user.restrictions.mute == -1) && !config.config_site.mute_excluded.includes(config.config_site.ranks_name[user.rank])){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You are restricted to use our chat. The restriction expires ' + ((user.restrictions.mute == -1) ? 'never' : makeDate(new Date(user.restrictions.mute * 1000))) + '.'
		});
		
		return cooldown(false, true);
	}
	
	if(!config.config_chat.channels.includes(channel)){
		socket.emit('message', {
			type: 'error',
			error: 'Invalid channel!'
		});
		
		return cooldown(false, true);
	}
	
	chat_getMentions(message, function(mentions){
		pool.query('INSERT INTO `chat_messages` SET `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `rank` = ' + parseInt(user.rank) + ', `xp` = ' + parseInt(user.xp) + ', `private` = ' + parseInt(user.settings['private']) + ', `message` = ' + pool.escape(message) + ', `channel` = ' + pool.escape(channel) + ', `time` = ' + pool.escape(new Date().getTime()), function(err1, row1){
			if(err1){
				logger.error(err1);
				writeError(err1);
				
				return cooldown(false, true);
			}
			
			var new_message = {
				type: 'player',
				id: row1.insertId,
				user: {
					userid: user.userid,
					name: user.name,
					avatar: user.avatar,
					level: calculateLevel(user.xp).level
				},
				rank: user.rank,
				private: user.settings['private'],
				message: message,
				channel: channel,
				mentions: mentions,
				time: new Date().getTime()
			}
			
			io.sockets.emit('message', {
				type: 'chat',
				command: 'message',
				message: new_message,
				added: true
			});
			
			chat_massages.push(new_message);
			
			while(chat_massages.length > config.config_chat.max_messages) chat_massages.shift();
			
			cooldown(false, false);
		});
	});
}

//GET MENTIONS
function chat_getMentions(message, callback){
	var reg = /\B@([a-f\d]+)/gi;
	var mentions = message.match(reg);
	
	var array = [];
	
	if(!mentions) return callback(array);
	if(mentions.length <= 0) return callback(array);
	
	for(var i = 0; i < mentions.length; i++) mentions[i] = mentions[i].replace('@', '');
	
	pool.query('SELECT * FROM `users` WHERE `userid` IN (' + pool.escape(mentions.join(',')) + ')', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		row1.forEach(function(mention){
			array.push({
				mention: '@' + mention.userid,
				name: '@' + mention.name
			});
		});
		
		callback(array);
	});
}

function chat_safeMessage(message) {
	function chat_replaceTag(tag) { return {'&': '&amp;', '<': '&lt;', '>': '&gt;'}[tag] || tag; }
	
    return message.replace(/[&<>]/g, chat_replaceTag);
}