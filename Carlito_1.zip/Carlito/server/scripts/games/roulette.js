/* ROULETTE */

var rouletteGame_lastGames = []; 
var rouletteGame_last100Games = [];

var rouletteGame_lastRoll = {
	roll: 0,
	progress: 0.5
};

var rouletteGame_seed = {
	id: null,
	server_seed: null,
	public_seed: null,
	uses: 0
};

var rouletteGame_settings = {
	timer: 0
}

var rouletteGame_totalBets = [];
var rouletteGame_countBets = {};
var rouletteGame_amountBets = {};

var rouletteGame = {
	status: 'ended',
	id: null,
	roll: null,
	color: null,
	progress: null,
	public_seed: null,
	nonce: null
}

rouletteGame_loadHistory();
rouletteGame_checkSeed(true);

function rouletteGame_checkSeed(start){
	pool.query('SELECT * FROM `roulette_seeds` WHERE `removed` = 0 AND `time` > ' + pool.escape(time() - (24 * 60 * 60)) + ' ORDER BY `id` DESC LIMIT 1', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		if(row1.length <= 0) rouletteGame_createSeed(start);
		else {
			rouletteGame_seed = {
				id: parseInt(row1[0].id),
				server_seed: row1[0].server_seed,
				public_seed: row1[0].public_seed,
				uses: parseInt(row1[0].uses)
			};
			
			if(start) rouletteGame_checkRound();
			else rouletteGame_generateRound();
		}
	});
}

function rouletteGame_createSeed(start){
	logger.debug('[ROULETTE] Creating New Seed');
	
	var server_seed = fair_generateServerSeed();
	var public_seed = fair_generatePublicSeed();
	
	pool.query('INSERT INTO `roulette_seeds` SET `server_seed` = ' + pool.escape(server_seed) + ', `public_seed` = ' + pool.escape(public_seed) + ', `time` = ' + pool.escape(time()), function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		rouletteGame_seed = {
			id: row1.insertId,
			server_seed: server_seed,
			public_seed: public_seed,
			uses: 0
		};
		
		if(start) rouletteGame_checkRound();
		else rouletteGame_generateRound();
	});
}

function rouletteGame_checkRound(){
	pool.query('SELECT roulette_rolls.id, roulette_rolls.roll, roulette_rolls.color, roulette_rolls.progress, roulette_seeds.public_seed, roulette_rolls.nonce FROM `roulette_rolls` INNER JOIN `roulette_seeds` ON roulette_rolls.seedid = roulette_seeds.id WHERE roulette_rolls.ended = 0 ORDER BY roulette_rolls.id DESC LIMIT 1', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		if(row1.length > 0){
			logger.debug('[ROULETTE] Loaded Last Round');
			
			rouletteGame = {
				status: 'ended',
				id: parseInt(row1[0].id),
				roll: parseInt(row1[0].roll),
				color: row1[0].color,
				progress: parseFloat(row1[0].progress),
				public_seed: row1[0].public_seed,
				nonce: parseFloat(row1[0].nonce)
			}
			
			pool.query('SELECT * FROM `roulette_bets` WHERE `game_id` = ' + parseInt(rouletteGame.id), function(err2, row2){
				if(err2){
					logger.error(err2);
					writeError(err2);
					return;
				}
				
				row2.forEach(function(bet){
					var amount = getFormatAmount(bet.amount);
					
					if(rouletteGame_countBets[bet.userid] === undefined) {
						rouletteGame_countBets[bet.userid] = 1;
					} else {
						rouletteGame_countBets[bet.userid]++;
					}
					
					if(rouletteGame_amountBets[bet.userid] === undefined) {
						rouletteGame_amountBets[bet.userid] = {
							'red': 0,
							'black': 0,
							'purple': 0
						};
					}
					
					rouletteGame_amountBets[bet.userid][bet.color] += amount;
					
					rouletteGame_totalBets.push({
						id: bet.id,
						user: {
							userid: bet.userid,
							name: bet.name,
							avatar: bet.avatar,
							level: calculateLevel(bet.xp).level
						},
						amount: amount,
						color: bet.color
					});
					
					logger.debug('[ROULETTE] Bet registed. ' + bet.name + ' did bet $' + getFormatAmountString(amount));
				});
			});
			
			rouletteGame_checkTimer();
		} else rouletteGame_generateRound();
	});
}

function rouletteGame_generateRound(){
	pool.query('SELECT `id` FROM `roulette_rolls` ORDER BY `id` DESC LIMIT 1', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		var seedid = rouletteGame_seed.id;
		
		var server_seed = rouletteGame_seed.server_seed;
		var public_seed = rouletteGame_seed.public_seed;
		
		var nonce = 1;
		if(row1.length > 0) nonce = parseInt(row1[0].id) + 1;
		
		var seed = fair_getCombinedSeed(server_seed, public_seed, nonce);
		var salt = fair_generateSaltHash(seed);
		
		var roll = fair_getRoll(salt, 15);
		
		var progress = roundedToFixed(Math.random(), 5);
		
		var color = 'purple';
		if(roll >= 1 && roll <= 7) { 
			color = 'red';
		} else if(roll >= 8 && roll <= 14) { 
			color = 'black';
		}
		
		pool.query('INSERT INTO `roulette_rolls` SET `roll` = ' + parseInt(roll) + ', `color` = ' + pool.escape(color) + ', `progress` = ' + pool.escape(progress) + ', `seedid` = ' + pool.escape(seedid) + ', `nonce` = ' + pool.escape(nonce) + ', `time` = ' + pool.escape(time()), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				return;
			}
			
			pool.query('UPDATE `roulette_seeds` SET `uses` = `uses` + 1 WHERE `id` = ' + pool.escape(seedid), function(err3){
				if(err3){
					logger.error(err3);
					writeError(err3);
					return;
				}
				
				rouletteGame_seed.uses++;
			
				rouletteGame.id = row2.insertId;
				rouletteGame.roll = roll;
				rouletteGame.color = color;
				rouletteGame.progress = progress;
				rouletteGame.public_seed = public_seed;
				rouletteGame.nonce = nonce;
				
				rouletteGame_checkTimer();
			});
		});
	});
}

function rouletteGame_loadHistory(){
	logger.debug('[ROULETTE] Loading History');
	
	pool.query('SELECT * FROM `roulette_rolls` WHERE `ended` = 1 ORDER BY `id` DESC LIMIT 10', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		if(row1.length == 0) return;
		
		rouletteGame_lastRoll = {
			roll: row1[0].roll,
			progress: row1[0].progress
		};
		
		row1.reverse();
		
		row1.forEach(function(roll){
			rouletteGame_lastGames.push({roll: roll.roll, color: roll.color});
		});
	});

	pool.query('SELECT * FROM `roulette_rolls` WHERE `ended` = 1 ORDER BY `id` DESC LIMIT 100', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		if(row1.length == 0) return;
		
		row1.reverse();
		
		row1.forEach(function(roll){
			rouletteGame_last100Games.push({roll: roll.roll, color: roll.color});
		});
	});
}

function rouletteGame_bet(user, socket, amount, color, cooldown) {
	cooldown(true, true);
	
	if((rouletteGame_countBets[user.userid] !== undefined) && (rouletteGame_countBets[user.userid] >= config.config_games.games.roulette.total_bets)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: You have entered too many times in roulette!'
		});
		
		return cooldown(false, true);
	}
	
	if(rouletteGame.status != 'started') {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Betting for this round is closed!'
		});
		
		return cooldown(false, true);
	}
	
	/* CHECK DATA GAME */
	
	var allowed_colors = [ 'red', 'black', 'purple' ];
	if(!allowed_colors.includes(color)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid color [red or purple or black]!'
		});
		
		return cooldown(false, true);
	}
	
	var dismiss_opposite = { 'red': 'black', 'black': 'red' };
	if(rouletteGame_amountBets[user.userid] !== undefined){
		if(rouletteGame_amountBets[user.userid][dismiss_opposite[color]] > 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: You cann\'t place bets on both colors [red or black]!'
			});
			
			return cooldown(false, true);
		}
	}
	
	/* END CHECK DATA GAME */
	
	//VERIFY FORMAT AMOUNT
	site_verifyFormatAmount(amount, function(err1, amount){
		if(err1) {
			socket.emit('message', {
				type: 'error',
				error: err1.message
			});
			
			return cooldown(false, true);
		}
		
		//REGISTER BET
		user_registerBet(user.userid, amount, [], 'roulette', true, function(err2){
			if(err2) {
				socket.emit('message', {
					type: 'error',
					error: err2.message
				});
				
				return cooldown(false, true);
			}
			
			pool.query('INSERT INTO `roulette_bets` SET `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + parseInt(user.xp) + ', `amount` = ' + amount + ', `color` = ' + pool.escape(color) + ', `game_id` = ' + parseInt(rouletteGame.id) + ', `time` = ' + pool.escape(time()), function(err3, row3) {
				if(err3) {
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				if(rouletteGame_countBets[user.userid] === undefined) {
					rouletteGame_countBets[user.userid] = 1;
				} else {
					rouletteGame_countBets[user.userid]++;
				}
				
				if(rouletteGame_amountBets[user.userid] === undefined) {
					rouletteGame_amountBets[user.userid] = {
						'red': 0,
						'black': 0,
						'purple': 0
					};
				}
				
				rouletteGame_amountBets[user.userid][color] += amount;
				
				rouletteGame_totalBets.push({
					id: row3.insertId,
					user: {
						userid: user.userid,
						name: user.name,
						avatar: user.avatar,
						level: calculateLevel(user.xp).level
					},
					amount: amount,
					color: color
				});
				
				socket.emit('message', {
					type: 'roulette',
					command: 'bet_confirmed'
				});
				
				io.sockets.in('roulette').emit('message', {
					type: 'roulette',
					command: 'bet',
					bet: {
						id: row3.insertId,
						user: {
							userid: user.userid,
							name: user.name,
							avatar: user.avatar,
							level: calculateLevel(user.xp).level
						},
						amount: amount,
						color: color
					}
				});
				
				user_updateBalance(user.userid);
				
				logger.debug('[ROULETTE] Bet registed. ' + user.name + ' did bet $' + getFormatAmountString(amount));
				
				cooldown(false, false);
			});
		});
	});
}

function rouletteGame_checkTimer() {
	logger.debug('[ROULETTE] New Round. Public Seed: ' + rouletteGame.public_seed + ', Nonce: ' + rouletteGame.nonce);
	
	rouletteGame.status = 'started';
	
	io.sockets.in('roulette').emit('message', {
		type: 'roulette',
		command: 'info',
		info: {
			id: rouletteGame.id,
			public_seed: rouletteGame.public_seed
		}
	});
	
	if(rouletteGame_settings.timer == 0) {
		logger.debug('[ROULETTE] Starting');
		
		rouletteGame_settings.timer = config.config_games.games.roulette.timer + config.config_games.games.roulette.cooldown_rolling;
		
		io.sockets.in('roulette').emit('message', {
			type: 'roulette',
			command: 'timer',
			time: rouletteGame_settings.timer - config.config_games.games.roulette.cooldown_rolling
		});
		
		var interval = setInterval(function() {
			if(rouletteGame_settings.timer == config.config_games.games.roulette.cooldown_rolling) {
				logger.debug('[ROULETTE] Rolling');
				
				rouletteGame.status = 'rolling';
				
				rouletteGame_finish();
			}
			
			if(rouletteGame_settings.timer == 0 && rouletteGame.status == 'ended') {
				clearInterval(interval);
				
				logger.debug('[ROULETTE] Ended. Rolled: ' + rouletteGame.roll);
				
				pool.query('UPDATE `roulette_rolls` SET `ended` = 1 WHERE `id` = ' + parseInt(rouletteGame.id), function(err1){
					if(err1){
						logger.error(err1);
						writeError(err1);
						return;
					}
					
					rouletteGame_lastGames.push({roll: rouletteGame.roll, color: rouletteGame.color});
					while(rouletteGame_lastGames.length > 10) rouletteGame_lastGames.shift();
					
					rouletteGame_last100Games.push({roll: rouletteGame.roll, color: rouletteGame.color});
					while(rouletteGame_last100Games.length > 100) rouletteGame_last100Games.shift();
					
					rouletteGame_lastRoll = {
						roll: rouletteGame.roll,
						progress: rouletteGame.progress
					};
					
					rouletteGame_totalBets = [];
					rouletteGame_countBets = {};
					rouletteGame_amountBets = {};
					
					rouletteGame_checkSeed(false);
				});
			}
			
			if(rouletteGame_settings.timer > 0) rouletteGame_settings.timer--;
		}, 1000);
	}
}

function rouletteGame_finish() {
	var multiplier = 0;
	
	if(rouletteGame.roll == 0) multiplier = config.config_games.games.roulette.color_multiplier; 
	else if(rouletteGame.roll >= 1 && rouletteGame.roll <= 14) multiplier = config.config_games.games.roulette.normal_multiplier;
	
	io.sockets.in('roulette').emit('message', {
		type: 'roulette',
		command: 'roll',
		roll: {
			roll: rouletteGame.roll,
			progress: rouletteGame.progress,
			color: rouletteGame.color,
			id: rouletteGame.id
		},
		cooldown: 0
	});
	
	var total_winnings = {};
	var winnings = [];
	
	rouletteGame_totalBets.forEach(function(item) {
		if(rouletteGame.color == item.color) {
			var winning = getFormatAmount(item.amount * multiplier);
			
			winnings.push({
				id: item.id,
				user: item.user,
				amount: item.amount,
				winning: winning
			});
			
			if(total_winnings[item.user.userid] === undefined) total_winnings[item.user.userid] = {
				user: item.user,
				winning: 0
			};
			
			total_winnings[item.user.userid]['winning'] += winning;
		} else {
			winnings.push({
				id: item.id,
				user: item.user,
				amount: item.amount,
				winning: 0
			});
		}
	});
	
	rouletteGame_winnings(0, winnings, function(err1){
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		setTimeout(function(){
			winnings.forEach(function(item){
				if(item.winning > 0){
					user_updateLevel(item.user.userid);
					user_updateBalance(item.user.userid);
					
					logger.debug('[ROULETTE] Win registed. ' + item.user.userid + ' did win $' + getFormatAmountString(item.winning) + ' with multiplier x' + multiplier);
				}
			});
			
			var props = Object.keys(total_winnings);
			props.forEach(function(item){
				if(total_winnings[item].winning >= config.config_games.winning_to_chat){
					var send_message = total_winnings[item].user.name + ' won ' + getFormatAmountString(total_winnings[item].winning) + ' to roulette on '  + rouletteGame.color + '!';
					otherMessages(send_message, io.sockets, true);
				}
			});
			
			rouletteGame.status = 'ended';
		}, rouletteGame_settings.timer * 1000);
	});
}

function rouletteGame_winnings(index, winnings, callback) {
	if(index >= winnings.length) return callback(null);
	
	//FINISH BET
	user_finishBet(winnings[index].user.userid, winnings[index].amount, winnings[index].winning, winnings[index].winning, [], 'roulette', function(err1){
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return callback(new Error('[ROULETTE] Bet #' + winnings[index].id + ' unfinished'));
		}
		
		rouletteGame_winnings(index + 1, winnings, callback);
	});
}

/* END ROULETTE */