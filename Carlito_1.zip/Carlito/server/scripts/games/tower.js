/* TOWER */

var towerGame_lastGames = [];

towerGame_loadHistory();
function towerGame_loadHistory(){
	logger.debug('[TOWER] Loading History');
	
	pool.query('SELECT * FROM `tower_bets` WHERE `ended` = 1 ORDER BY `id` DESC LIMIT 10', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		if(row1.length == 0) return;
		
		row1.reverse();
		
		row1.forEach(function(tower){
			towerGame_lastGames.push({
				id: tower.id,
				user: {
					userid: tower.userid,
					name: tower.name,
					avatar: tower.avatar,
					level: calculateLevel(tower.xp).level,
				},
				amount: getFormatAmount(tower.amount),
				roll: tower.roll,
				stage: tower.route.split('').length,
				winning: getFormatAmount(tower.winning)
			});
		});
	});
}

var towerGame_countBets = {};
var towerGame_userBets = {};

pool.query('SELECT * FROM `tower_bets` WHERE `ended` = 0', function(err1, row1) {
	if(err1) {
		logger.error(err1);
		writeError(err1);
		return;
	}
	
	if(row1.length == 0) return;
	
	row1.forEach(function(tower){
		var amount = getFormatAmount(tower.amount)
		
		if(towerGame_countBets[tower.userid] === undefined){
			towerGame_countBets[tower.userid] = 1;
			
			towerGame_userBets[tower.userid] = {
				id: tower.id,
				amount: tower.amount,
				route: (tower.route) ? tower.route.split('') : [],
				tower: (tower.roll) ? tower.roll.split('') : [],
				roll: tower.roll,
				cashout: false,
				ended: false
			};
		}
	});
});

function towerGame_bet(user, socket, amount, cooldown){
	cooldown(true, true);
	
	if((towerGame_countBets[user.userid] !== undefined) && (towerGame_countBets[user.userid] == 1)) {
		socket.emit('message', {
			type: 'error',
			error: 'You\'ve already started a game.'
		});
		
		return cooldown(false, true);
	}
	
	//VERIFY FORMAT AMOUNT
	site_verifyFormatAmount(amount, function(err1, amount){
		if(err1) {
			socket.emit('message', {
				type: 'error',
				error: err1.message
			});
			
			return cooldown(false, true);
		}
		
		//SEEDS
		fair_getUserSeeds(user.userid, function(err2, fair){
			if(err2) {
				socket.emit('message', {
					type: 'error',
					error: err2.message
				});
				
				return cooldown(false, true);
			}
			
			//REGISTER BET
			user_registerBet(user.userid, amount, [], 'tower', true, function(err3){
				if(err3) {
					socket.emit('message', {
						type: 'error',
						error: err3.message
					});
					
					return cooldown(false, true);
				}
				
				var seed = fair_getCombinedSeed(fair.server_seed, fair.client_seed, fair.nonce);
				
				var salt = fair_generateSaltHash(seed);
				var array = fair_getRollTower(salt);
				
				var roll = array.join('');
				
				pool.query('INSERT INTO `tower_bets` SET `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + parseInt(user.xp) + ', `amount` = ' + amount + ', `roll` = ' + pool.escape(roll) + ', `server_seedid` = ' + pool.escape(fair.server_seedid) + ', `client_seedid` = ' + pool.escape(fair.client_seedid) + ', `nonce` = ' + pool.escape(fair.nonce) + ', `time` = ' + pool.escape(time()), function(err4, row4) {
					if(err4) {
						logger.error(err4);
						writeError(err4);
						
						return cooldown(false, true);
					}
					
					pool.query('UPDATE `users_seeds_server` SET `nonce` = `nonce` + 1 WHERE `userid` = ' + pool.escape(user.userid) + ' AND `id` = ' + pool.escape(fair.server_seedid), function(err5){
						if(err5) {
							logger.debug(err5);
							writeError(err5);
							
							return cooldown(false, true);
						}
				
						towerGame_countBets[user.userid] = 1;
					
						towerGame_userBets[user.userid] = {
							id: row4.insertId,
							amount: amount,
							route: [],
							tower: array,
							roll: roll,
							cashout: false,
							ended: false
						};
						
						socket.emit('message', {
							type: 'tower',
							command: 'bet_confirmed',
							stage: towerGame_userBets[user.userid]['route'].length,
							total: amount
						});
						
						user_updateBalance(user.userid);
						
						logger.debug('[ROULETTE] Bet registed. ' + user.name + ' did bet $' + getFormatAmountString(amount));
						
						cooldown(false, false);
					});
				});
			});
		});
	});
}

function towerGame_cashout(user, socket, cooldown){
	cooldown(true, true);
	
	if(towerGame_userBets[user.userid]['cashout']){
		socket.emit('message', {
			type: 'error',
			error: 'Error: The game is already cashout!'
		});
		
		return cooldown(false, true);
	}
	
	if(towerGame_userBets[user.userid]['ended']){
		socket.emit('message', {
			type: 'error',
			error: 'Error: The game is already ended!'
		});
		
		return cooldown(false, true);
	}
	
	if(towerGame_userBets[user.userid]['route'].length == 0){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You need to play one time to withdraw your winnings!'
		});
		
		return cooldown(false, true);
	}
	
	var route = towerGame_userBets[user.userid]['route'].join('');
	
	var winning = getFormatAmount(towerGame_generateAmounts(towerGame_userBets[user.userid]['amount'])[towerGame_userBets[user.userid]['route'].length - 1]);
	
	pool.query('UPDATE `tower_bets` SET `route` = ' + pool.escape(route) + ', `winning` = ' + winning + ', `ended` = 1, `cashout` = 1 WHERE `id` = ' + pool.escape(towerGame_userBets[user.userid]['id']), function(err1){
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
	
		//FINISH BET
		user_finishBet(user.userid, towerGame_userBets[user.userid]['amount'], winning, winning, [], 'tower', function(err2){
			if(err2) {
				socket.emit('message', {
					type: 'error',
					error: err2.message
				});
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'tower',
				command: 'result_stage',
				result: 'lose',
				data: {
					tower: towerGame_userBets[user.userid]['tower']
				}
			});
			
			var history = {
				id: towerGame_userBets[user.userid]['id'], 
				user: {
					userid: user.userid,
					name: user.name,
					avatar: user.avatar,
					level: calculateLevel(user.xp).level,
				},
				amount: towerGame_userBets[user.userid]['amount'],
				roll: towerGame_userBets[user.userid]['roll'],
				stage: towerGame_userBets[user.userid]['route'].length,
				winning: winning
			};
			
			towerGame_lastGames.push(history);
			if(towerGame_lastGames.length > 10) towerGame_lastGames.shift();
			
			io.sockets.in('tower').emit('message', {
				type: 'tower',
				command: 'history',
				history: history
			});
			
			towerGame_userBets[user.userid]['cashout'] = true;
			towerGame_countBets[user.userid] = 0;
			
			user_updateLevel(user.userid);
			user_updateBalance(user.userid);
			
			if(winning >= config.config_games.winning_to_chat){
				var send_message = user.name + ' won ' + getFormatAmountString(winning) + ' to tower!';
				otherMessages(send_message, io.sockets, true);
			}
			
			logger.debug('[TOWER] Win registed. ' + user.name + ' did win $' + getFormatAmountString(winning));
			
			cooldown(false, false);
		});
	});
}

function towerGame_stage(user, socket, stage, button, cooldown){
	cooldown(true, true);
	
	if((towerGame_countBets[user.userid] == undefined) || (towerGame_countBets[user.userid] == 0)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: The game is not started!'
		});
		
		return cooldown(false, true);
	}
	
	if(towerGame_userBets[user.userid]['ended']){
		socket.emit('message', {
			type: 'error',
			error: 'Error: The game is already ended!'
		});
		
		return cooldown(false, true);
	}
	
	/* CHECK DATA GAME */
	
	if(isNaN(Number(stage))){
		socket.emit('message', {
			type: 'error',
			error: 'Invalid stage.'
		});
		
		return cooldown(false, true);
	}
	
	stage = parseInt(stage);
	
	if(stage < 0 || stage > 9) {
		socket.emit('message', {
			type: 'error',
			error: 'Invalid stage.'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(button))){
		socket.emit('message', {
			type: 'error',
			error: 'Invalid code button.'
		});
		
		return cooldown(false, true);
	}
	
	button = parseInt(button);
	
	if(button < 0 || button > 2) {
		socket.emit('message', {
			type: 'error',
			error: 'Invalid code button.'
		});
		
		return cooldown(false, true);
	}
	
	/* END CHECK DATA GAME */
	
	if(stage < towerGame_userBets[user.userid]['route'].length){
		socket.emit('message', {
			type: 'error',
			error: 'Stage already reached'
		});
		
		return cooldown(false, true);
	}
	
	if(stage > towerGame_userBets[user.userid]['route'].length){
		socket.emit('message', {
			type: 'error',
			error: 'Stage not reached yet'
		});
		
		return cooldown(false, true);
	}
	
	if(towerGame_userBets[user.userid]['tower'][towerGame_userBets[user.userid]['route'].length] == button){
		towerGame_userBets[user.userid]['route'].push(button);
		towerGame_userBets[user.userid]['ended'] = true;
		towerGame_countBets[user.userid] = 0;
		
		var route = towerGame_userBets[user.userid]['route'].join('');
		
		pool.query('UPDATE `tower_bets` SET `route` = ' + pool.escape(route) + ', `ended` = 1 WHERE `id` = ' + pool.escape(towerGame_userBets[user.userid]['id']), function(err1){
			if(err1) {
				logger.error(err1);
				writeError(err1);
				
				return cooldown(false, true);
			}
			
			//FINISH BET
			user_finishBet(user.userid, towerGame_userBets[user.userid]['amount'], 0, 0, [], 'tower', function(err2){
				if(err2) {
					socket.emit('message', {
						type: 'error',
						error: err2.message
					});
					
					return cooldown(false, true);
				}
			
				socket.emit('message', {
					type: 'tower',
					command: 'result_stage',
					result: 'lose',
					data: {
						tower: towerGame_userBets[user.userid]['tower']
					}
				});
				
				var history = {
					id: towerGame_userBets[user.userid]['id'],
					user: {
						userid: user.userid,
						name: user.name,
						avatar: user.avatar,
						level: calculateLevel(user.xp).level,
					},
					amount: towerGame_userBets[user.userid]['amount'],
					roll: towerGame_userBets[user.userid]['roll'],
					stage: towerGame_userBets[user.userid]['route'].length,
					winning: 0
				};
				
				towerGame_lastGames.push(history);
				if(towerGame_lastGames.length > 10) towerGame_lastGames.shift();
				
				io.sockets.in('tower').emit('message', {
					type: 'tower',
					command: 'history',
					history: history
				});
				
				cooldown(false, false);
			});
		});
	} else {
		towerGame_userBets[user.userid]['route'].push(button);
		
		var route = towerGame_userBets[user.userid]['route'].join('');
		
		pool.query('UPDATE `tower_bets` SET `route` = ' + pool.escape(route) + ' WHERE `id` = ' + pool.escape(towerGame_userBets[user.userid]['id']), function(err1){
			if(err1) {
				logger.error(err1);
				writeError(err1);
				
				return cooldown(false, true);
			}
		
			socket.emit('message', {
				type: 'tower',
				command: 'result_stage',
				result: 'win',
				data: {
					stage: towerGame_userBets[user.userid]['route'].length - 1,
					button: button,
					total: getFormatAmount(towerGame_generateAmounts(towerGame_userBets[user.userid]['amount'])[towerGame_userBets[user.userid]['route'].length - 1])
				}
			});
			
			if(towerGame_userBets[user.userid]['route'].length < 10) {
				return cooldown(false, false);
			}
			
			var winning = getFormatAmount(towerGame_generateAmounts(towerGame_userBets[user.userid]['amount'])[towerGame_userBets[user.userid]['route'].length - 1]);
			
			pool.query('UPDATE `tower_bets` SET `winning` = ' + winning + ', `ended` = 1, `cashout` = 1 WHERE `id` = ' + pool.escape(towerGame_userBets[user.userid]['id']), function(err2){
				if(err2) {
					logger.error(err2);
					writeError(err2);
					
					return cooldown(false, true);
				}
				
				//FINISH BET
				user_finishBet(user.userid, towerGame_userBets[user.userid]['amount'], winning, winning, [], 'tower', function(err3){
					if(err3) {
						socket.emit('message', {
							type: 'error',
							error: err3.message
						});
						
						return cooldown(false, true);
					}
					
					towerGame_userBets[user.userid]['cashout'] = true;
					towerGame_countBets[user.userid] = 0;
					
					socket.emit('message', {
						type: 'tower',
						command: 'result_stage',
						result: 'lose',
						data: {
							tower: towerGame_userBets[user.userid]['tower']
						}
					});
					
					var history = {
						id: towerGame_userBets[user.userid]['id'],
						user: {
							userid: user.userid,
							name: user.name,
							avatar: user.avatar,
							level: calculateLevel(user.xp).level,
						},
						amount: towerGame_userBets[user.userid]['amount'],
						roll: towerGame_userBets[user.userid]['roll'],
						stage: towerGame_userBets[user.userid]['route'].length,
						winning: winning
					}
					
					towerGame_lastGames.push(history);
					if(towerGame_lastGames.length > 10) towerGame_lastGames.shift();
					
					io.sockets.in('tower').emit('message', {
						type: 'tower',
						command: 'history',
						history: history
					});
					
					user_updateLevel(user.userid);
					user_updateBalance(user.userid);
					
					if(winning >= config.config_games.winning_to_chat){
						var send_message = user.name + ' won ' + getFormatAmountString(winning) + ' to tower!';
						otherMessages(send_message, io.sockets, true);
					}
					
					logger.debug('[TOWER] Win registed. ' + user.name + ' did win $' + getFormatAmountString(winning));
					
					cooldown(false, false);
				});
			});
		});
	}
}

function towerGame_generateGame(){
	var array = [];
	
	for(var i = 0; i < 10; i++){
		array.push(getRandomInt(1, 3));
	}
	
	return array;
}

function towerGame_generateAmounts(amount){
	var amounts = [];
	
	for(var i = 0; i < config.config_games.games.tower.multipliers.length; i++) amounts.push(roundedToFixed(parseFloat(amount * config.config_games.games.tower.multipliers[i]), 5));
	
	return amounts;
}

/* END TOWER */