var casebattleGame_cases = {};

var casebattleGame_games = {};

var casebattleGame_secure = {};

var casebattleGame_stats = {
	active: 0,
	total: 0
};

var casebattleGame_loadedHistory = false;

casebattleGame_loadStats();
function casebattleGame_loadStats(){
	logger.debug('[CASE BATTLE] Loading Stats');
	
	pool.query('SELECT COUNT(*) AS `count` FROM `casebattle_games` WHERE `canceled` = 0', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		pool.query('SELECT COUNT(*) AS `count` FROM `casebattle_games` WHERE `ended` = 0 AND `canceled` = 0', function(err2, row2) {
			if(err2) {
				logger.error(err2);
				writeError(err2);
				return;
			}
			
			casebattleGame_stats = {
				active: parseInt(row2[0].count),
				total: parseInt(row1[0].count)
			};
		});
	});
}

function casebattleGame_loadHistory(){
	if(casebattleGame_loadedHistory) return;
	casebattleGame_loadedHistory = true;
	
	logger.debug('[CASE BATTLE] Loading History');
	
	pool.query('SELECT * FROM `casebattle_games` WHERE `ended` = 0 AND `canceled` = 0', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		if(row1.length == 0) return;
		
		row1.reverse();
		
		row1.forEach(function(casebattle){
			var amount = getFormatAmount(casebattle.amount);
			
			var cases = [];
			JSON.parse(casebattle.cases).forEach(function(item){
				cases.push({
					id: item,
					name: casebattleGame_cases[item].name,
					image: casebattleGame_cases[item].image,
					price: getFormatAmount(casebattleGame_cases[item].price)
				});
			});
			
			var mode = parseInt(casebattle.mode);
			var privacy = parseInt(casebattle.privacy);
			var free = parseInt(casebattle.free);
			
			casebattleGame_games[casebattle.battleid] = {
				id: casebattle.id,
				battleid: casebattle.battleid,
				status: 0,
				players: [],
				mode: mode,
				privacy: privacy,
				free: free,
				cases: cases,
				amount: amount,
				round: 0,
				game: {
					server_seed: casebattle.server_seed,
					public_seed: null,
					block: null
				},
				time: parseInt(casebattle.time)
			}
			
			var total_players = [ 2, 3, 4, 4 ][mode];
			
			casebattleGame_secure[casebattle.battleid] = {};
			for(var i = 0; i < total_players; i++) casebattleGame_secure[casebattle.battleid][i] = {};
			
			pool.query('SELECT * FROM `casebattle_bets` WHERE `gameid` = ' + pool.escape(casebattle.id) + ' AND `canceled` = 0', function(err2, row2) {
				if(err2) {
					logger.error(err2);
					writeError(err2);
					return;
				}
				
				if(row2.length >= total_players) {
					casebattleGame_games[casebattle.battleid].status = 1;
					casebattleGame_games[casebattle.battleid].time = time();
				}
				
				row2.forEach(function(bet){
					casebattleGame_games[casebattle.battleid]['players'].push({
						user: {
							userid: bet.userid,
							name: bet.name,
							avatar: bet.avatar,
							level: calculateLevel(bet.xp).level
						},
						position: parseInt(bet.position),
						creator: parseInt(bet.creator),
						bot:  parseInt(bet.bot),
						items: [],
						total: 0
					});
				});
				
				if(casebattleGame_games[casebattle.battleid].status) casebattleGame_continue(casebattle.battleid);
			});
		});
	});
}

function casebattleGame_getItems(items){
	var newitems = [];
	
	items.forEach(function(item){
		newitems.push({
			id: item.id,
			name: itemsSystem_items[item.id].name,
			image: itemsSystem_items[item.id].image,
			price: getFormatAmount(itemsSystem_items[item.id].price),
			chance: roundedToFixed(item.chance, 5),
			quality: itemsSystem_items[item.id].quality
		});
	});
	
	return newitems;
}

function casebattleGame_load(user, socket, cooldown){
	cooldown(true, true);
	
	var list_cases = [];
	
	Object.keys(casebattleGame_cases).forEach(function(id){
		list_cases.push({
			id: id,
			name: casebattleGame_cases[id].name,
			image: casebattleGame_cases[id].image,
			price: getFormatAmount(casebattleGame_cases[id].price)
		});
	});
	
	list_cases.sort(function(a, b){ return a.price - b.price });
	
	socket.emit('message', {
		type: 'casebattle',
		command: 'cases',
		cases: list_cases
	});
	
	cooldown(false, false);
}

function casebattleGame_show(user, socket, id, cooldown){
	cooldown(true, true);
	
	pool.query('SELECT * FROM `casebattle_games` WHERE `battleid` = ' + pool.escape(id) + ' AND `canceled` = 0', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid battle id!'
			});
			
			return cooldown(false, true);
		}
		
		if(casebattleGame_games[id] !== undefined && parseInt(row1[0].ended) == 0) {
			var casebattle_data = {
				privacy: casebattleGame_games[id].privacy,
				free: casebattleGame_games[id].free,
				round: casebattleGame_games[id].round
			};
			
			casebattle_data.game = {
				server_seed_hashed: sha256(casebattleGame_games[id].game.server_seed),
				nonce: casebattleGame_games[id].id
			};
			
			if(casebattleGame_games[id].status == 2){
				casebattle_data.game.block = casebattleGame_games[id].game.block;
			} else if(casebattleGame_games[id].status == 3) {
				casebattle_data.countdown = config.config_games.games.casebattle.timer_countdown
				
				casebattle_data.game.block = casebattleGame_games[id].game.block;
			} else if(casebattleGame_games[id].status == 4){
				casebattle_data.round = casebattleGame_games[id].round;
				casebattle_data.positions = casebattleGame_getWinners(casebattleGame_games[id].players, casebattleGame_games[id].mode, true);
				
				casebattle_data.game.block = casebattleGame_games[id].game.block;
			} else if(casebattleGame_games[id].status == 5) {
				casebattle_data.winners = casebattleGame_getWinners(casebattleGame_games[id].players, casebattleGame_games[id].mode, false);
				
				casebattle_data.game.server_seed = casebattleGame_games[id].game.server_seed;
				casebattle_data.game.public_seed = casebattleGame_games[id].game.public_seed;
				casebattle_data.game.block = casebattleGame_games[id].game.block;
			}
			
			socket.emit('message', {
				type: 'casebattle',
				command: 'show',
				status: casebattleGame_games[id].status,
				casebattle: {
					id: id,
					players: casebattleGame_games[id].players,
					mode: casebattleGame_games[id].mode,
					cases: casebattleGame_games[id].cases,
					amount: casebattleGame_games[id].amount,
					data: casebattle_data
				}
			});
			
			cooldown(false, false);
		} else {
			var amount = getFormatAmount(row1[0].amount);
			
			var cases = [];
			JSON.parse(row1[0].cases).forEach(function(item){
				if(casebattleGame_cases[item] !== undefined){
					cases.push({
						id: item,
						name: casebattleGame_cases[item].name,
						image: casebattleGame_cases[item].image,
						price: getFormatAmount(casebattleGame_cases[item].price)
					});
				}
			});
			
			var mode = parseInt(row1[0].mode);
			var privacy = parseInt(row1[0].privacy);
			
			pool.query('SELECT * FROM `casebattle_bets` WHERE `gameid` = ' + pool.escape(row1[0].id) + ' AND `canceled` = 0', function(err2, row2) {
				if(err2) {
					logger.error(err2);
					writeError(err2);
					
					return cooldown(false, true);
				}
				
				var players = [];
				
				row2.forEach(function(bet){
					players.push({
						user: {
							userid: bet.userid,
							name: bet.name,
							avatar: bet.avatar,
							level: calculateLevel(bet.xp).level
						},
						position: parseInt(bet.position),
						creator: parseInt(bet.creator),
						bot:  parseInt(bet.bot),
						items: [],
						total: 0
					});
				});
				
				pool.query('SELECT * FROM `casebattle_items` WHERE `gameid` = ' + pool.escape(row1[0].id), function(err3, row3) {
					if(err3) {
						logger.error(err3);
						writeError(err3);
						
						return cooldown(false, true);
					}
					
					JSON.parse(row3[0].items).forEach(function(item){
						players[players.slice().findIndex(a => a.position == item.position)].items.push({
							name: itemsSystem_items[item.itemid].name,
							image: itemsSystem_items[item.itemid].image,
							price: getFormatAmount(itemsSystem_items[item.itemid].price),
							color: getColorByQuality(itemsSystem_items[item.itemid].quality)
						});
						
						players[players.slice().findIndex(a => a.position == item.position)].total = getFormatAmount(players[players.slice().findIndex(a => a.position == item.position)].total + getFormatAmount(itemsSystem_items[item.itemid].price));
					});
					
					pool.query('SELECT `position` FROM `casebattle_winnings` WHERE `gameid` = ' + pool.escape(row1[0].id), function(err4, row4) {
						if(err4) {
							logger.error(err4);
							writeError(err4);
							
							return cooldown(false, true);
						}
						
						pool.query('SELECT * FROM `casebattle_rolls` WHERE `gameid` = ' + pool.escape(row1[0].id), function(err5, row5) {
							if(err5) {
								logger.error(err5);
								writeError(err5);
								
								return cooldown(false, true);
							}
							
							socket.emit('message', {
								type: 'casebattle',
								command: 'show',
								status: 5,
								casebattle: {
									id: id,
									players: players,
									mode: mode,
									cases: cases,
									amount: amount,
									data: {
										game: {
											server_seed_hashed: sha256(row1[0].server_seed),
											server_seed: row1[0].server_seed,
											public_seed: row5[0].public_seed,
											block: row5[0].blockid,
											nonce: row1[0].id
										},
										round: cases.length - 1,
										privacy: parseInt(row1[0].privacy),
										free: parseInt(row1[0].free),
										winners: row4.slice().map(a => parseInt(a.position))
									}
								}
							});
							
							cooldown(false, false);
						});
					});
				});
			});
		}
	});
}

function casebattleGame_create(user, socket, cases, mode, privacy, free, cooldown) {
	cooldown(true, true);
	
	/* CHECK DATA GAME */
	
	if(!Array.isArray(cases)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid cases!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(mode))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid mode!'
		});
		
		return cooldown(false, true);
	}
	
	mode = parseInt(mode);

	var allowed_mode = [0, 1, 2, 3];
	if(!allowed_mode.includes(mode)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid mode [1v1, 1v1v1, 1v1v1v1 or 2v2]!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(privacy))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid privacy!'
		});
		
		return cooldown(false, true);
	}
	
	privacy = parseInt(privacy);

	var allowed_privacy = [0, 1];
	if(!allowed_privacy.includes(privacy)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid privacy [public or private]!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(free))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid free!'
		});
		
		return cooldown(false, true);
	}
	
	free = parseInt(free);

	var allowed_privacy = [0, 1];
	if(!allowed_privacy.includes(free)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid free!'
		});
		
		return cooldown(false, true);
	}
	
	/* END CHECK DATA GAME */
	
	if(cases.length < config.config_games.games.casebattle.interval_cases.min) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: You have to sellect minimum ' + config.config_games.games.casebattle.interval_cases.min + ' cases!'
		});
		
		return cooldown(false, true);
	}
	
	if(cases.length > config.config_games.games.casebattle.interval_cases.max) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: You have to sellect maximum ' + config.config_games.games.casebattle.interval_cases.max + ' cases!'
		});
		
		return cooldown(false, true);
	}
	
	var amount = 0;
	var available = true;
	
	for(var i = 0; i < cases.length; i++){
		if(!Object.keys(casebattleGame_cases).includes(cases[i])) {
			available = false;
			break;
		}
		
		amount += getFormatAmount(casebattleGame_cases[cases[i]].price);
	}
	
	if(!available) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid cases in your battle!'
		});
		
		return cooldown(false, true);
	}
	
	var total_players = [ 2, 3, 4, 4 ][mode];
	
	var casebattle_amount = getFormatAmount(amount);
	
	amount = getFormatAmount(amount);
	if(free) amount = getFormatAmount(amount * total_players);
	
	//REGISTER BET
	user_registerBet(user.userid, amount, [], 'casebattle', false, function(err1){
		if(err1) {
			socket.emit('message', {
				type: 'error',
				error: err1.message
			});
			
			return cooldown(false, true);
		}
		
		var server_seed = fair_generateServerSeed();
		
		var id = generateHexCode(24);
		
		pool.query('INSERT INTO `casebattle_games` SET `cases` = ' + pool.escape(JSON.stringify(cases)) + ', `amount` = ' + casebattle_amount + ', `mode` = ' + mode + ', `privacy` = ' + privacy + ', `free` = ' + free + ', `server_seed` = ' + pool.escape(server_seed) + ', `battleid` = ' + pool.escape(id) + ', `time` = ' + pool.escape(time()), function(err2, row2){
			if(err2) {
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			pool.query('INSERT INTO `casebattle_bets` SET `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + parseInt(user.xp) + ', `bot` = ' + parseInt(user.bot) + ', `gameid` = ' + row2.insertId + ', `position` = 0, `creator` = 1, `time` = ' + pool.escape(time()), function(err3){
				if(err3) {
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				var list = [];
				cases.forEach(function(item){
					list.push({
						id: item,
						name: casebattleGame_cases[item].name,
						image: casebattleGame_cases[item].image,
						price: getFormatAmount(casebattleGame_cases[item].price)
					});
				});
			
				casebattleGame_games[id] = {
					id: row2.insertId,
					battleid: id,
					status: 0,
					players: [],
					mode: mode,
					privacy: privacy,
					free: free,
					cases: list,
					amount: casebattle_amount,
					round: 0,
					game: {
						server_seed: server_seed,
						public_seed: null,
						block: null
					},
					time: time()
				}
				
				casebattleGame_secure[id] = [];
				for(var i = 0; i < total_players; i++) casebattleGame_secure[id][i] = {};
				
				casebattleGame_games[id]['players'].push({
					user: {
						userid: user.userid,
						name: user.name,
						avatar: user.avatar,
						level: calculateLevel(user.xp).level
					},
					position: 0,
					creator: 1,
					bot: user.bot,
					items: [],
					total: 0
				});
				
				socket.emit('message', {
					type: 'casebattle',
					command: 'bet_confirmed'
				});
				
				socket.emit('message', {
					type: 'casebattle',
					command: 'redirect',
					action: 'join',
					id: id
				});
				
				if(!privacy){
					io.sockets.in('casebattle').emit('message', {
						type: 'casebattle',
						command: 'add',
						casebattle: {
							id: id,
							players: casebattleGame_games[id]['players'],
							mode: mode,
							cases: list,
							amount: casebattle_amount,
							free: free,
							time: casebattleGame_games[id]['time'],
							data: {}
						}
					});
				}
				
				casebattleGame_stats.active++;
				casebattleGame_stats.total++;
				
				io.sockets.in('casebattle').emit('message', {
					type: 'casebattle',
					command: 'stats',
					stats: casebattleGame_stats
				});
				
				user_updateBalance(user.userid);
				
				logger.debug('[CASE BATTLE] Bet registed. ' + user.name + ' did bet $' + getFormatAmountString(amount));
				
				cooldown(false, false);
			});
		});
	});
}

function casebattleGame_join(user, socket, id, position, cooldown) {
	cooldown(true, true);
	
	/* CHECK DATA GAME */
	
	if(isNaN(Number(position))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid position!'
		});
		
		return cooldown(false, true);
	}
	
	position = parseInt(position);
	
	/* END CHECK DATA GAME */
	
	if(casebattleGame_games[id] === undefined) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid case battle id!'
		});
		
		return cooldown(false, true);
	}
	
	if(casebattleGame_games[id].status != 0) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: This case battle are already ended!'
		});
		
		return cooldown(false, true);
	}
	
	var total_players = [ 2, 3, 4, 4 ][casebattleGame_games[id].mode];
	
	if(position < 0 || position >= total_players) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: That position is invalid!'
		});
		
		return cooldown(false, true);
	}
	
	if(casebattleGame_games[id].players.filter(a => a.position == position).length > 0) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: That position is already taked!'
		});
		
		return cooldown(false, true);
	}
	
	if(casebattleGame_games[id].players.filter(a => a.user.userid == user.userid).length > 0) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: You already joined in this case battle!'
		});
		
		return cooldown(false, true);
	}
	
	if(Object.keys(casebattleGame_secure[id][position]).length > 0){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Another user are trying to join in this game. Please try again later!'
		});
		
		return cooldown(false, true);
	}
	
	casebattleGame_secure[id][position][user.userid] = true;
	
	casebattleGame_joinConfirm(user, id, position, function(err1){
		if(err1){
			socket.emit('message', {
				type: 'error',
				error: err1.message
			});
			
			return cooldown(false, true);
		}
		
		socket.emit('message', {
			type: 'casebattle',
			command: 'bet_confirmed'
		});
		
		for(var i = 0; i < total_players; i++){
			if(casebattleGame_games[id]['players'].filter(a => a.position == i).length <= 0){
				socket.emit('message', {
					type: 'casebattle',
					command: 'update',
					stage: 'position',
					status: casebattleGame_games[id].status,
					position: i,
					casebattle: {
						id: id,
						players: casebattleGame_games[id]['players'],
						mode: casebattleGame_games[id]['mode'],
						cases: casebattleGame_games[id]['cases'],
						amount: casebattleGame_games[id]['amount'],
						data: {}
					}
				});
			}
		}
		
		user_updateBalance(user.userid);
		
		cooldown(false, false);
	})
}

function casebattleGame_joinConfirm(user, id, position, callback){
	var amount = getFormatAmount(casebattleGame_games[id]['amount']);
	
	if(casebattleGame_games[id]['free']) amount = 0;
	
	var total_players = [ 2, 3, 4, 4 ][casebattleGame_games[id].mode];
	
	//REGISTER BET
	user_registerBet(user.userid, amount, [], 'casebattle', false, function(err1){
		if(err1) return callback(err1);
		
		pool.query('SELECT * FROM `casebattle_bets` WHERE `userid` = ' + pool.escape(user.userid) + ' AND `gameid` = ' + pool.escape(casebattleGame_games[id].id) + ' AND `canceled` = 1 AND `creator` = 1', function(err2, row2){
			if(err2) {
				logger.error(err2);
				writeError(err2);
				
				return callback(new Error('Error: Error (1)'));
			}
			
			var creator = row2.length > 0 ? 1 : 0;
			
			pool.query('INSERT INTO `casebattle_bets` SET `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + parseInt(user.xp) + ', `bot` = ' + parseInt(user.bot) + ', `gameid` = ' + pool.escape(casebattleGame_games[id].id) + ', `position` = ' + position + ', `creator` = ' + parseInt(creator) + ', `time` = ' + pool.escape(time()), function(err3){
				if(err3) {
					logger.error(err3);
					writeError(err3);
					
					return callback(new Error('Error: Error (2)'));
				}
				
				casebattleGame_games[id]['players'].push({
					user: {
						userid: user.userid,
						name: user.name,
						avatar: user.avatar,
						level: calculateLevel(user.xp).level
					},
					position: position,
					bot: user.bot,
					creator: creator,
					items: [],
					total: 0
				});
				
				if(casebattleGame_games[id]['players'].length >= total_players) casebattleGame_games[id].status = 1;
				
				if(!casebattleGame_games[id].privacy){
					io.sockets.in('casebattle').emit('message', {
						type: 'casebattle',
						command: 'edit',
						status: casebattleGame_games[id].status,
						casebattle: {
							id: id,
							players: casebattleGame_games[id]['players'],
							mode: casebattleGame_games[id]['mode'],
							cases: casebattleGame_games[id]['cases'],
							amount: casebattleGame_games[id]['amount'],
							free: casebattleGame_games[id]['free'],
							time: casebattleGame_games[id]['time'],
							data: {}
						}
					});
				}
				
				io.sockets.in('casebattle').emit('message', {
					type: 'casebattle',
					command: 'update',
					stage: 'position',
					status: casebattleGame_games[id].status,
					position: position,
					casebattle: {
						id: id,
						players: casebattleGame_games[id]['players'],
						mode: casebattleGame_games[id]['mode'],
						cases: casebattleGame_games[id]['cases'],
						amount: casebattleGame_games[id]['amount'],
						data: {}
					}
				});
				
				if(casebattleGame_games[id].status == 1) casebattleGame_continue(id);
				
				logger.debug('[CASE BATTLE] Join registed. ' + user.name + ' did bet $' + getFormatAmountString(amount));
				
				callback(null);
			});
		});
	});
}

function casebattleGame_leave(user, socket, id, position, cooldown){
	cooldown(true, true);
	
	/* CHECK DATA GAME */
	
	if(isNaN(Number(position))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid position!'
		});
		
		return cooldown(false, true);
	}
	
	position = parseInt(position);
	
	/* END CHECK DATA GAME */
	
	if(casebattleGame_games[id] === undefined) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid case battle id!'
		});
		
		return cooldown(false, true);
	}
	
	if(casebattleGame_games[id].status != 0) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: This case battle are already ended!'
		});
		
		return cooldown(false, true);
	}
	
	var total_players = [ 2, 3, 4, 4 ][casebattleGame_games[id].mode];
	
	if(position < 0 || position >= total_players) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: That position is invalid!'
		});
		
		return cooldown(false, true);
	}
	
	if(casebattleGame_games[id].players.filter(a => a.position == position).length <= 0) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: That position is not taked!'
		});
		
		return cooldown(false, true);
	}
	
	if(casebattleGame_games[id].players.find(a => a.position == position).user.userid != user.userid) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: That potition is not yours!'
		});
		
		return cooldown(false, true);
	}
	
	var remove_position = casebattleGame_games[id]['players'].findIndex(a => a.position == position);
	
	if(casebattleGame_games[id]['players'][remove_position]['creator'] && casebattleGame_games[id]['players'].length > 1 && casebattleGame_games[id]['free']) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: The creator can\'t leave a free case battle once others players already joined!'
		});
		
		return cooldown(false, true);
	}
	
	var amount = getFormatAmount(casebattleGame_games[id]['amount']);
	
	if(casebattleGame_games[id]['free']) {
		if(casebattleGame_games[id]['players'][remove_position]['creator']) amount = getFormatAmount(amount * total_players);
		else amount = 0;
	}
	
	//REGISTER BET
	user_refundBet(user.userid, amount, 'casebattle', function(err1){
		if(err1) {
			socket.emit('message', {
				type: 'error',
				error: err1.message
			});
			
			return cooldown(false, true);
		}

		pool.query('UPDATE `casebattle_bets` SET `canceled` = 1 WHERE `gameid` = ' + pool.escape(casebattleGame_games[id].id) + ' AND `position` = ' + position, function(err2){
			if(err2) {
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			pool.query('SELECT COUNT(*) AS `count` FROM `casebattle_bets` WHERE `gameid` = ' + pool.escape(casebattleGame_games[id].id) + ' AND `canceled` = 0', function(err3, row3){
				if(err3) {
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				if(row3[0].count <= 0){
					pool.query('UPDATE `casebattle_games` SET `canceled` = 1 WHERE `id` = ' + pool.escape(casebattleGame_games[id].id), function(err4){
						if(err4) {
							logger.error(err4);
							writeError(err4);
							
							return cooldown(false, true);
						}
						
						io.sockets.in('casebattle').emit('message', {
							type: 'casebattle',
							command: 'redirect',
							action: 'leave',
							id: id
						});
						
						if(!casebattleGame_games[id].privacy){
							io.sockets.in('casebattle').emit('message', {
								type: 'casebattle',
								command: 'remove',
								casebattle: {
									id: id
								}
							});
						}
						
						casebattleGame_stats.active--;
						
						io.sockets.in('casebattle').emit('message', {
							type: 'casebattle',
							command: 'stats',
							stats: casebattleGame_stats
						});
						
						delete casebattleGame_games[id];
						
						user_updateBalance(user.userid);
						
						logger.debug('[CASE BATTLE] Leave Registed. Bet #' + id + ' was canceled');
						
						cooldown(false, false);
					});
				} else {
					casebattleGame_games[id]['players'].splice(remove_position, 1);
					
					if(!casebattleGame_games[id].privacy){
						io.sockets.in('casebattle').emit('message', {
							type: 'casebattle',
							command: 'edit',
							status: casebattleGame_games[id].status,
							casebattle: {
								id: id,
								players: casebattleGame_games[id]['players'],
								mode: casebattleGame_games[id]['mode'],
								cases: casebattleGame_games[id]['cases'],
								amount: casebattleGame_games[id]['amount'],
								free: casebattleGame_games[id]['free'],
								time: casebattleGame_games[id]['time'],
								data: {}
							}
						});
					}
					
					for(var i = 0; i < total_players; i++){
						if(casebattleGame_games[id]['players'].filter(a => a.position == i).length <= 0){
							io.sockets.in('casebattle').emit('message', {
								type: 'casebattle',
								command: 'update',
								stage: 'position',
								status: casebattleGame_games[id].status,
								position: i,
								casebattle: {
									id: id,
									players: casebattleGame_games[id]['players'],
									mode: casebattleGame_games[id]['mode'],
									cases: casebattleGame_games[id]['cases'],
									amount: casebattleGame_games[id]['amount'],
									data: {}
								}
							});
						}
					}
					
					user_updateBalance(user.userid);
					
					logger.debug('[CASE BATTLE] Leave Registed. Bet #' + id + ' was updated');
					
					cooldown(false, false);
				}
			});
		});
	});
}

function casebattleGame_continue(id){
	delete casebattleGame_secure[id];
	
	var total_players = [ 2, 3, 4, 4 ][casebattleGame_games[id].mode];
	
	io.sockets.in('casebattle').emit('message', {
		type: 'casebattle',
		command: 'update',
		stage: 'refresh',
		status: casebattleGame_games[id]['status'],
		casebattle: {
			id: id,
			players: casebattleGame_games[id]['players'],
			mode: casebattleGame_games[id]['mode'],
			cases: casebattleGame_games[id]['cases'],
			amount: casebattleGame_games[id]['amount'],
			data: {
				game: {
					server_seed_hashed: sha256(casebattleGame_games[id].game.server_seed),
					nonce: casebattleGame_games[id].id
				}
			}
		}
	});
	
	setTimeout(function(){
		fair_generateEosSeed(function(data){
			casebattleGame_games[id].status = 2;
			
			casebattleGame_games[id].game.block = data.block;
			
			io.sockets.in('casebattle').emit('message', {
				type: 'casebattle',
				command: 'update',
				stage: 'refresh',
				status: casebattleGame_games[id]['status'],
				casebattle: {
					id: id,
					players: casebattleGame_games[id]['players'],
					mode: casebattleGame_games[id]['mode'],
					cases: casebattleGame_games[id]['cases'],
					amount: casebattleGame_games[id]['amount'],
					data: {
						game: {
							server_seed_hashed: sha256(casebattleGame_games[id].game.server_seed),
							block: casebattleGame_games[id].game.block,
							nonce: casebattleGame_games[id].id
						}
					}
				}
			});
			
			if(!casebattleGame_games[id].privacy){
				io.sockets.in('casebattle').emit('message', {
					type: 'casebattle',
					command: 'edit',
					status: casebattleGame_games[id].status,
					casebattle: {
						id: id,
						players: casebattleGame_games[id]['players'],
						mode: casebattleGame_games[id]['mode'],
						cases: casebattleGame_games[id]['cases'],
						amount: casebattleGame_games[id]['amount'],
						free: casebattleGame_games[id]['free'],
						time: casebattleGame_games[id]['time'],
						data: {}
					}
				});
			}
		}, function(data){
			pool.query('UPDATE `casebattle_rolls` SET `removed` = 1 WHERE `gameid` = ' + pool.escape(casebattleGame_games[id].id), function(err1) {
				if(err1) {
					logger.error(err1);
					writeError(err1);
					return;
				}
				
				var seed = fair_getCombinedSeed(casebattleGame_games[id].game.server_seed, data.hash, id);
				var salt = fair_generateSaltHash(seed);
				
				var roll = fair_getRollCaseBattle(salt, casebattleGame_games[id]['cases'].length, total_players);
				
				pool.query('INSERT INTO `casebattle_rolls` SET `gameid` = ' + pool.escape(casebattleGame_games[id].id) + ', `blockid` = ' + pool.escape(data.block) + ', `public_seed` = ' + pool.escape(data.hash) + ', `roll` = ' + pool.escape(JSON.stringify(roll)) + ', `time` = ' + pool.escape(time()), function(err2) {
					if(err2) {
						logger.error(err2);
						writeError(err2);
						return;
					}
					
					casebattleGame_games[id].status = 3;
					
					io.sockets.in('casebattle').emit('message', {
						type: 'casebattle',
						command: 'update',
						stage: 'refresh',
						status: casebattleGame_games[id]['status'],
						casebattle: {
							id: id,
							players: casebattleGame_games[id]['players'],
							mode: casebattleGame_games[id]['mode'],
							cases: casebattleGame_games[id]['cases'],
							amount: casebattleGame_games[id]['amount'],
							data: {
								game: {
									server_seed_hashed: sha256(casebattleGame_games[id].game.server_seed),
									block: casebattleGame_games[id].game.block,
									nonce: casebattleGame_games[id].id
								},
								countdown: config.config_games.games.casebattle.timer_countdown
							}
						}
					});
					
					setTimeout(function(){
						casebattleGame_games[id].status = 4;
						
						casebattleGame_games[id].game.public_seed = data.hash;
						casebattleGame_games[id].game.block = data.block;
						
						var round = 0;
						var winnings = [];	
						
						casebattleGame_roundRoll();
						
						function casebattleGame_roundRoll(){
							casebattleGame_games[id]['round'] = round;
							
							var items = casebattleGame_getItems(casebattleGame_cases[casebattleGame_games[id]['cases'][round].id].items);
							
							var tickets = casebattleGame_generateTickets(items);
							var total = tickets[tickets.length - 1].max;
							
							if(!casebattleGame_games[id].privacy){
								io.sockets.in('casebattle').emit('message', {
									type: 'casebattle',
									command: 'edit',
									status: casebattleGame_games[id].status,
									casebattle: {
										id: id,
										players: casebattleGame_games[id]['players'],
										mode: casebattleGame_games[id]['mode'],
										cases: casebattleGame_games[id]['cases'],
										amount: casebattleGame_games[id]['amount'],
										free: casebattleGame_games[id]['free'],
										time: casebattleGame_games[id]['time'],
										data: {
											round: casebattleGame_games[id]['round']
										}
									}
								});
							}
							
							var round_winnings = {};
							
							for(var i = 0; i < total_players; i++){
								var spinner = casebattleGame_generateSpinner(items);
								
								var roll_position = parseInt(roll[round][i] * total) + 1;
								
								var winning_item = null;
								
								for(var j = 0; j < tickets.length; j++){
									if(roll_position >= tickets[j].min && roll_position <= tickets[j].max) {
										winning_item = {
											id: items[j].id,
											name: items[j].name,
											image: items[j].image,
											price: getFormatAmount(items[j].price),
											color: getColorByQuality(items[j].quality)
										};
										
										break;
									}
								}
								
								spinner[99] = { image: winning_item.image };
								
								io.sockets.in('casebattle').emit('message', {
									type: 'casebattle',
									command: 'update',
									stage: 'position',
									status: casebattleGame_games[id].status,
									position: i,
									casebattle: {
										id: id,
										players: casebattleGame_games[id]['players'],
										mode: casebattleGame_games[id]['mode'],
										cases: casebattleGame_games[id]['cases'],
										amount: casebattleGame_games[id]['amount'],
										data: {
											spinner: spinner,
											positions: casebattleGame_getWinners(casebattleGame_games[id]['players'], casebattleGame_games[id]['mode'], true)
										}
									}
								});
								
								round_winnings[i] = winning_item;
							}
							
							io.sockets.in('casebattle').emit('message', {
								type: 'casebattle',
								command: 'update',
								stage: 'roll',
								casebattle: {
									id: id
								}
							});
							
							io.sockets.in('casebattle').emit('message', {
								type: 'casebattle',
								command: 'update',
								stage: 'round',
								round: round,
								casebattle: {
									id: id
								}
							});
							
							setTimeout(function(){
								for(var i = 0; i < total_players; i++){
									var winning = getFormatAmount(round_winnings[i].price);
									
									casebattleGame_games[id]['players'][casebattleGame_games[id]['players'].slice().findIndex(a => a.position == i)].items.push(round_winnings[i]);
									casebattleGame_games[id]['players'][casebattleGame_games[id]['players'].slice().findIndex(a => a.position == i)].total = getFormatAmount(casebattleGame_games[id]['players'][casebattleGame_games[id]['players'].slice().findIndex(a => a.position == i)].total + winning);
									
									winnings.push({
										'caseid': casebattleGame_games[id]['cases'][round].id,
										'itemid': round_winnings[i].id,
										'position': i
									});
								}
								
								io.sockets.in('casebattle').emit('message', {
									type: 'casebattle',
									command: 'update',
									stage: 'items',
									players: casebattleGame_games[id]['players'].slice().map(a => ({ position: a.position, item: a.items.slice(-1)[0], total: a.total })),
									positions: casebattleGame_getWinners(casebattleGame_games[id]['players'], casebattleGame_games[id]['mode'], true),
									casebattle: {
										id: id,
										mode: casebattleGame_games[id]['mode']
									}
								});
								
								round++;
								
								setTimeout(function(){
									if(round >= casebattleGame_games[id]['cases'].length) return casebattleGame_roundFinish();
									
									casebattleGame_roundRoll();
								}, 1000);
							}, 6000);
						}
						
						function casebattleGame_roundFinish(){
							var winners_positions = casebattleGame_getWinners(casebattleGame_games[id]['players'], casebattleGame_games[id]['mode'], false);
							
							var winners = casebattleGame_games[id]['players'].slice().filter(a => winners_positions.includes(a.position));
							var opponents = casebattleGame_games[id]['players'].slice().filter(a => !winners_positions.includes(a.position));
							
							pool.query('UPDATE `casebattle_games` SET `ended` = 1 WHERE `id` = ' + pool.escape(casebattleGame_games[id].id), function(err3){
								if(err3) {
									logger.error(err3);
									writeError(err3);
									return;
								}
								
								var amount = casebattleGame_games[id].amount;
								var winning = 0;
								
								casebattleGame_games[id]['players'].forEach(function(item){
									winning = getFormatAmount(winning + item.total);
								});
								
								//FINISH BET
								casebattleGame_start(0, function(err4){
									if(err4) {
										logger.error(err4);
										writeError(err4);
										return;
									}
									
									casebattleGame_finish(0, function(){
										pool.query('INSERT INTO `casebattle_items` SET `gameid` = ' + pool.escape(casebattleGame_games[id].id) + ', `items` = ' + pool.escape(JSON.stringify(winnings)) + ', `time` = ' + pool.escape(time()), function(err5){
											if(err5) {
												logger.error(err5);
												writeError(err5);
												return;
											}
											
											casebattleGame_games[id].status = 5;
											
											io.sockets.in('casebattle').emit('message', {
												type: 'casebattle',
												command: 'update',
												stage: 'refresh',
												status: casebattleGame_games[id]['status'],
												casebattle: {
													id: id,
													players: casebattleGame_games[id]['players'],
													mode: casebattleGame_games[id]['mode'],
													cases: casebattleGame_games[id]['cases'],
													amount: casebattleGame_games[id]['amount'],
													data: {
														game: {
															server_seed_hashed: sha256(casebattleGame_games[id].game.server_seed),
															server_seed: casebattleGame_games[id].game.server_seed,
															public_seed: casebattleGame_games[id].game.public_seed,
															block: casebattleGame_games[id].game.block,
															nonce: casebattleGame_games[id].id
														},
														winners: winners.slice().map(a => a.position)
													}
												}
											});
											
											io.sockets.in('casebattle').emit('message', {
												type: 'casebattle',
												command: 'update',
												stage: 'finish',
												casebattle: {
													id: id
												}
											});
											
											if(!casebattleGame_games[id].privacy){
												io.sockets.in('casebattle').emit('message', {
													type: 'casebattle',
													command: 'edit',
													status: casebattleGame_games[id].status,
													casebattle: {
														id: id,
														players: casebattleGame_games[id]['players'],
														mode: casebattleGame_games[id]['mode'],
														cases: casebattleGame_games[id]['cases'],
														amount: casebattleGame_games[id]['amount'],
														free: casebattleGame_games[id]['free'],
														time: casebattleGame_games[id]['time'],
														data: {
															winners: winners.slice().map(a => a.position)
														}
													}
												});
											}
											
											setTimeout(function(){
												if(!casebattleGame_games[id].privacy){
													io.sockets.in('casebattle').emit('message', {
														type: 'casebattle',
														command: 'remove',
														casebattle: {
															id: id
														}
													});
												}
												
												casebattleGame_stats.active--;
												
												io.sockets.in('casebattle').emit('message', {
													type: 'casebattle',
													command: 'stats',
													stats: casebattleGame_stats
												});
												
												delete casebattleGame_games[id];
											}, config.config_games.games.casebattle.timer_delete * 1000);
											
											winners.forEach(function(item){
												var winnings_amount = winning;
												
												if(casebattleGame_games[id]['mode'] == 3){
													winnings_amount = [
														getFormatAmount(winning / 2),
														getFormatAmount(winning - getFormatAmount(winning / 2))
													][item.position % 2];
												}
												
												if(winnings_amount >= config.config_games.winning_to_chat){
													var send_message = item.user.name + ' won ' + getFormatAmountString(winnings_amount) + ' to case battle!';
													otherMessages(send_message, io.sockets, true);
												}
												
												io.sockets.in(item.user.userid).emit('message', {
													type: 'success',
													success: 'The game of ' + getFormatAmountString(winnings_amount) + ' on case battle ended as win!'
												});
												
												user_updateLevel(item.user.userid);
												
												logger.debug('[CASE BATTLE] Win registed. ' + item.user.name + ' did win $' + getFormatAmountString(winnings_amount));
											});
											
											opponents.forEach(function(item){
												io.sockets.in(item.user.userid).emit('message', {
													type: 'error',
													error: 'The game of ' + getFormatAmountString(winning) + ' on case battle ended as lose!'
												});
												
												user_updateLevel(item.user.userid);
											});
										});
									});
								});
								
								function casebattleGame_start(index, callback){
									if(index >= winners.length) return callback();
									
									var winnings_items = winnings;
									var winnings_amount = winning;
									var winnings_amount_add = 0;
									
									if(casebattleGame_games[id]['mode'] == 3){
										winnings_items = [];
										
										winnings_amount = [
											getFormatAmount(winning / 2),
											getFormatAmount(winning - getFormatAmount(winning / 2))
										][winners[index].position % 2];
										
										winnings_amount_add = winnings_amount;
									}
									
									//FINISH BET
									user_finishBet(winners[index].user.userid, amount, winnings_amount, winnings_amount_add, winnings_items.slice().map(a => a.itemid), 'casebattle', function(err4, items){
										if(err4) {
											logger.error(err4);
											writeError(err4);
											return;
										}
										
										pool.query('INSERT INTO `casebattle_winnings` SET `gameid` = ' + pool.escape(casebattleGame_games[id].id) + ', `items` = ' + pool.escape(JSON.stringify(items.slice().map(a => a.id))) + ', `amount` = ' + winnings_amount_add + ', `position` = ' + pool.escape(winners[index].position) + ', `time` = ' + pool.escape(time()), function(err5){
											if(err5) {
												logger.error(err5);
												writeError(err5);
												return;
											}
											
											if(!winners[index].bot) return casebattleGame_start(index + 1, callback);
											
											user_inventorySellAll_sell({ userid: winners[index].user.userid }, 0, items, [], function(err6, items_success){
												if(err6){
													logger.error(err6);
													writeError(err6);
													return;
												}
												
												var amount_sold = items_success.reduce(function(acc, val) { return getFormatAmount(acc + itemsSystem_items[val.itemid].price) }, 0);
												
												user_editBalance(winners[index].user.userid, amount_sold, 'sell_items', function(err7){
													if(err7) {
														logger.error(err7);
														writeError(err7);
														return;
													}
													
													casebattleGame_start(index + 1, callback);
												});
											});
										});
									});
								}
								
								function casebattleGame_finish(index, callback){
									if(index >= opponents.length) return callback();
									
									//FINISH BET
									user_finishBet(opponents[index].user.userid, amount, 0, 0, [], 'casebattle', function(err4){
										if(err4) {
											logger.error(err4);
											writeError(err4);
											return;
										}
										
										return casebattleGame_finish(index + 1, callback);
									});
								}
							});
						}
					}, config.config_games.games.casebattle.timer_countdown * 1000 + 1000);
				});
			});
		});
	}, config.config_games.games.casebattle.timer_wait_start * 1000 + 1000);
}

function casebattleGame_generateTickets(items){
	var decimals = 0; 
	items.forEach(function(item){
		if(countDecimals(item.chance) > decimals) decimals = countDecimals(item.chance);
	});

	var tickets = [];
	var total = 0;

	items.forEach(function(item){
		tickets.push({
			min: total + 1,
			max: total + item.chance * Math.pow(10, decimals)
		});
		
		total += item.chance * Math.pow(10, decimals);
	});
	
	return tickets;
}

function casebattleGame_generateSpinner(items){
	var tickets = casebattleGame_generateTickets(items);
	var total = tickets[tickets.length - 1].max;
	
	var spinner = [];
	
	for(var i = 0; i < 150; i++){
		var ticket = getRandomInt(1, total);
		
		for(var j = 0; j < tickets.length; j++){
			if(ticket >= tickets[j].min && ticket <= tickets[j].max) {
				spinner.push({
					image: items[j].image
				});
			}
		}
	}
	
	return spinner;
}

function casebattleGame_finished(user, socket, cooldown){
	cooldown(true, true);
	
	pool.query('SELECT * FROM `casebattle_games` WHERE `ended` = 1 ORDER BY `id` DESC LIMIT 20', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		casebattleGame_list(row1, 0, [], function(err2, battles){
			if(err2) {
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			io.sockets.in('casebattle').emit('message', {
				type: 'casebattle',
				command: 'list',
				battles: battles
			});
			
			cooldown(false, false);
		});
	});
}

function casebattleGame_my(user, socket, cooldown){
	cooldown(true, true);
	
	pool.query('SELECT casebattle_games.* FROM `casebattle_games` INNER JOIN `casebattle_bets` ON casebattle_games.id = casebattle_bets.gameid WHERE casebattle_games.ended = 1 AND casebattle_bets.userid = ' + pool.escape(user.userid) + ' AND casebattle_bets.canceled = 0 ORDER BY casebattle_games.id DESC LIMIT 20', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		casebattleGame_list(row1, 0, [], function(err2, battles){
			if(err2) {
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			var myactive = Object.values(casebattleGame_games).filter(a => a.status != 5 && a.players.filter(b => b.user.userid == user.userid).length > 0);
			
			var myactive_battles = [];
			
			myactive.forEach(function(item){
				myactive_battles.push({
					status: item.status,
					casebattle: {
						id: item.battleid,
						players: item.players,
						mode: item.mode,
						cases: item.cases,
						amount: item.amount,
						time: parseInt(item.time),
						data: {}
					}
				})
			});
			
			socket.emit('message', {
				type: 'casebattle',
				command: 'list',
				battles: [ ...battles, ...myactive_battles]
			});
			
			cooldown(false, false);
		});
	});
}

function casebattleGame_list(list, index, battles, callback){
	if(index >= list.length) return callback(null, battles);
	
	var amount = getFormatAmount(list[index].amount);
	
	var cases = [];
	JSON.parse(list[index].cases).forEach(function(item){
		if(casebattleGame_cases[item] !== undefined){
			cases.push({
				id: item,
				name: casebattleGame_cases[item].name,
				image: casebattleGame_cases[item].image,
				price: getFormatAmount(casebattleGame_cases[item].price)
			});
		}
	});
	
	var mode = parseInt(list[index].mode);
	var privacy = parseInt(list[index].privacy);
	
	pool.query('SELECT * FROM `casebattle_bets` WHERE `gameid` = ' + pool.escape(list[index].id) + ' AND `canceled` = 0', function(err1, row1) {
		if(err1) return callback(err1);
		
		var players = [];
		
		row1.forEach(function(bet){
			players.push({
				user: {
					userid: bet.userid,
					name: bet.name,
					avatar: bet.avatar,
					level: calculateLevel(bet.xp).level
				},
				position: parseInt(bet.position),
				creator: parseInt(bet.creator),
				bot: parseInt(bet.bot),
				items: [],
				total: 0
			});
		});
		
		pool.query('SELECT `position` FROM `casebattle_winnings` WHERE `gameid` = ' + pool.escape(list[index].id), function(err2, row2) {
			if(err2) return callback(err2);
			
			battles.push({
				status: 5,
				casebattle: {
					id: list[index].battleid,
					players: players,
					mode: mode,
					cases: cases,
					amount: amount,
					time: parseInt(list[index].time),
					data: {
						winners: row2.slice().map(a => parseInt(a.position))
					}
				}
			});
			
			casebattleGame_list(list, index + 1, battles, callback);
		});
	});
}

function casebattleGame_getWinners(players, mode, draw){
	if(mode == 3){
		var total_team = [
			{ team: 0, total: 0 },
			{ team: 1, total: 0 }
		];
		
		players.forEach(function(item){
			total_team[total_team.slice().findIndex(a => a.team == parseInt(item.position / 2))].total = getFormatAmount(total_team[total_team.slice().findIndex(a => a.team == parseInt(item.position / 2))].total + item.total);
		});
		
		var max_total_team = getFormatAmount(total_team.slice().sort(function(a, b){ return getFormatAmount(b.total - a.total) })[0].total);
		
		if(draw) return total_team.slice().filter(a => a.total >= max_total_team).map(a => [ [0, 1], [2, 3] ][a.team] ).reduce((acc, arr) => {  return [ ...acc, ...arr ] }, []);
		
		var winners_team = total_team.slice().filter(a => a.total >= max_total_team).sort(function(a, b){ return a.team - b.team })[0];
		return [ [0, 1], [2, 3] ][winners_team.team];
	}
	
	var max_total = getFormatAmount(players.slice().sort(function(a, b){ return getFormatAmount(b.total - a.total) })[0].total);
	
	if(draw) return players.slice().filter(a => a.total >= max_total).map(a => a.position);
	
	return [ players.slice().filter(a => a.total >= max_total).sort(function(a, b){ return a.position - b.position })[0].position ];
}