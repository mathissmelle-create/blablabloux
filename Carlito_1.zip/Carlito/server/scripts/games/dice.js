/* DICE */

var diceGame_lastGames = [];

var diceGame_cooldown = {};

diceGame_loadHistory();
function diceGame_loadHistory(){
	logger.debug('[DICE] Loading History');
	
	pool.query('SELECT * FROM `dice_bets` ORDER BY `id` DESC LIMIT 10', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		if(row1.length == 0) return;
		
		row1.reverse();
		
		row1.forEach(function(item){
			var game = item.game;
			var chance = roundedToFixed(item.chance, 2);
			var number = chance;
			if(game == 'over') number = roundedToFixed(100 - chance, 2);
			
			diceGame_lastGames.push({
				id: item.id,
				user: {
					userid: item.userid, 
					avatar: item.avatar, 
					name: item.name, 
					level: calculateLevel(item.xp).level, 
				},
				amount: getFormatAmount(item.amount),
				game: { game, number },
				roll: item.roll,
				multiplier: roundedToFixed(item.multiplier, 2)
			});
		});
	});
}

function diceGame_bet(user, socket, amount, chance, game, slow, cooldown){
	if(diceGame_cooldown[user.userid]){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Wait for ending last dice game!'
		});
		return;
	}
	
	cooldown(true, true);
	
	/* CHECK DATA GAME */
	
	var allowed_games = ['under', 'over'];
	if(!allowed_games.includes(game)) {
		socket.emit('message', {
			type: 'error',
			error: 'Invalid type game [over or under]!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(chance))){
		socket.emit('message', {
			type: 'error',
			error: 'Invalid chance!'
		});
		
		return cooldown(false, true);
	}
	
	chance = roundedToFixed(chance, 2);
	
	if(chance < 0.01 || chance > 94) {
		socket.emit('message', {
			type: 'error',
			error: 'Invalid chance [0.01 - 94]!'
		});
		
		return cooldown(false, true);
	}
	
	/* END CHECK DATA GAME */
	
	//VERIFY FORMAT AMOUNT
	site_verifyFormatAmount(amount, function(err1, amount){
		if(err1) {
			socket.emit('message', {
				type: 'error',
				error: err1.message
			});
			
			return cooldown(false, true);
		}
		
		//SEEDS
		fair_getUserSeeds(user.userid, function(err2, fair){
			if(err2) {
				socket.emit('message', {
					type: 'error',
					error: err2.message
				});
				
				return cooldown(false, true);
			}
			
			//REGISTER BET
			user_registerBet(user.userid, amount, [], 'dice', true, function(err3){
				if(err3) {
					socket.emit('message', {
						type: 'error',
						error: err3.message
					});
					
					return cooldown(false, true);
				}
				
				var seed = fair_getCombinedSeed(fair.server_seed, fair.client_seed, fair.nonce);
				var salt = fair_generateSaltHash(seed);
				
				var roll = (fair_getRoll(salt, 10000) / 100) % 100;
				
				var multiplier = roundedToFixed(95 / chance, 2);
				var win = false;
			
				if(game == 'under' && roll < chance) win = true;
				if(game == 'over' && roll >= roundedToFixed(100 - chance, 2)) win = true;
				
				var winning = 0;
				if(win) winning = getFormatAmount(multiplier * amount);
				
				pool.query('INSERT INTO `dice_bets` SET `userid` = ' + pool.escape(user.userid) + ', `avatar` = ' + pool.escape(user.avatar) + ', `name` = ' + pool.escape(user.name) + ', `xp` = ' + parseInt(user.xp) + ', `amount` = ' + amount + ', `game` = ' + pool.escape(game) + ', `chance` = ' + chance + ', `multiplier` = ' + multiplier + ', `roll` = ' + roll + ', `server_seedid` = ' + pool.escape(fair.server_seedid) + ', `client_seedid` = ' + pool.escape(fair.client_seedid) + ', `nonce` = ' + pool.escape(fair.nonce) + ', `time` = ' + pool.escape(time()), function(err4, row4) {
					if(err4) {
						logger.debug(err4);
						writeError(err4);
						
						return cooldown(false, true);
					}
					
					pool.query('UPDATE `users_seeds_server` SET `nonce` = `nonce` + 1 WHERE `userid` = ' + pool.escape(user.userid) + ' AND `id` = ' + pool.escape(fair.server_seedid), function(err5){
						if(err5) {
							logger.debug(err5);
							writeError(err5);
							
							return cooldown(false, true);
						}
						
						//FINISH BET
						user_finishBet(user.userid, amount, winning, winning, [], 'dice', function(err6){
							if(err6) {
								socket.emit('message', {
									type: 'error',
									error: err6.message
								});
								
								return cooldown(false, true);
							}
							
							socket.emit('message', {
								type: 'dice',
								command: 'bet',
								win: win,
								roll: roll,
							});
							
							setTimeout(function(){
								var number = chance;
								if(game == 'over') number = roundedToFixed(100 - chance, 2);
								
								var history = {
									id: row4.insertId,
									user: {
										userid: user.userid,
										avatar: user.avatar,
										name: user.name,
										level: calculateLevel(user.xp).level,
									},
									amount: amount,
									game: { game, number },
									roll: roll,
									multiplier: multiplier
								}
								
								diceGame_lastGames.push(history);
								if(diceGame_lastGames.length > 10) diceGame_lastGames.shift();
								
								io.sockets.in('dice').emit('message', {
									type: 'dice',
									command: 'history',
									history: history
								});
								
								user_updateLevel(user.userid);
								user_updateBalance(user.userid);
								
								if(win){
									if(winning >= config.config_games.winning_to_chat){
										var send_message = user.name + ' won ' + getFormatAmountString(winning) + ' to dice with chance '  + chance.toFixed(2) + '!';
										otherMessages(send_message, io.sockets, true);
									}
									
									logger.debug('[DICE] Win registed. ' + user.name + ' did win $' + getFormatAmountString(winning) + ' with chance ' + chance.toFixed(2));
								}
								
								diceGame_cooldown[user.userid] = false;
							}, 6500 * slow);
							
							user_updateBalance(user.userid);
							
							logger.debug('[DICE] Bet registed. ' + user.name + ' did bet $' + getFormatAmountString(amount));
							
							cooldown(false, false);
						});
					});
				});
			});
		});
	});
}

/* END DICE */