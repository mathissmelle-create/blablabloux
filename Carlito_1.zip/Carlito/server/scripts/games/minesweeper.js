/* MINESWEEPER */

var minesweeperGame_lastGames = [];

minesweeperGame_loadHistory();
function minesweeperGame_loadHistory(){
	logger.debug('[MINESWEEPER] Loading History');
	
	pool.query('SELECT * FROM `minesweeper_bets` WHERE `ended` = 1 ORDER BY `id` DESC LIMIT 10', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		if(row1.length == 0) return;
		
		row1.reverse();
		
		row1.forEach(function(minesweeper){
			minesweeperGame_lastGames.push({
				id: minesweeper.id,
				user: {
					userid: minesweeper.userid,
					name: minesweeper.name,
					avatar: minesweeper.avatar,
					level: calculateLevel(minesweeper.xp).level,
				},
				amount: getFormatAmount(minesweeper.amount),
				bombs: parseInt(minesweeper.bombs),
				roll: minesweeper.roll,
				winning: getFormatAmount(minesweeper.winning)
			});
		});
	});
}

var minesweeperGame_countBets = {};
var minesweeperGame_userBets = {};

pool.query('SELECT * FROM `minesweeper_bets` WHERE `ended` = 0', function(err1, row1) {
	if(err1) {
		logger.error(err1);
		writeError(err1);
		return;
	}
	
	if(row1.length == 0) return;
	
	row1.forEach(function(minesweeper){
		if(minesweeperGame_countBets[minesweeper.userid] === undefined){
			minesweeperGame_countBets[minesweeper.userid] = 1;
			
			var amount = getFormatAmount(minesweeper.amount);
			var bombs = parseInt(minesweeper.bombs);
			
			var route = [];
			var mines = [];
			
			if(minesweeper.route) for(var i = 0; i < minesweeper.route.length; i += 2) route.push(parseInt(minesweeper.route.slice(i, i + 2)));
			if(minesweeper.roll) for(var i = 0; i < minesweeper.roll.length && i / 2 < bombs; i += 2) mines.push(parseInt(minesweeper.roll.slice(i, i + 2)));
			
			minesweeperGame_userBets[minesweeper.userid] = {
				id: minesweeper.id,
				amount: amount,
				bombs: bombs,
				route: route,
				mines: mines,
				roll: minesweeper.roll,
				cashout: false,
				ended: false
			};
		}
	});
});

function minesweeperGame_bet(user, socket, amount, bombs, cooldown){
	cooldown(true, true);
	
	if((minesweeperGame_countBets[user.userid] !== undefined) && (minesweeperGame_countBets[user.userid] == 1)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: You\'ve already started a game!'
		});
		
		return cooldown(false, true);
	}
	
	/* CHECK DATA GAME */
	
	if(isNaN(Number(bombs))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid bombs amount!'
		});
		
		return cooldown(false, true);
	}

	bombs = parseInt(bombs);

	if(bombs < 1 || bombs > 24) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid bombs amount [1 - 24]!'
		});
		
		return cooldown(false, true);
	}
	
	/* END CHECK DATA GAME */
	
	//VERIFY FORMAT AMOUNT
	site_verifyFormatAmount(amount, function(err1, amount){
		if(err1) {
			socket.emit('message', {
				type: 'error',
				error: err1.message
			});
			
			return cooldown(false, true);
		}
		
		//SEEDS
		fair_getUserSeeds(user.userid, function(err2, fair){
			if(err2) {
				socket.emit('message', {
					type: 'error',
					error: err2.message
				});
				
				return cooldown(false, true);
			}
			
			//REGISTER BET
			user_registerBet(user.userid, amount, [], 'minesweeper', true, function(err3){
				if(err3) {
					socket.emit('message', {
						type: 'error',
						error: err3.message
					});
					
					return cooldown(false, true);
				}
				
				var seed = fair_getCombinedSeed(fair.server_seed, fair.client_seed, fair.nonce);
				
				var salt = fair_generateSaltHash(seed);
				var array = fair_getShuffle(salt, 25);
				
				var roll = '';
				array.forEach(function(item){
					if(item < 10) roll += '0' + item;
					else roll += item;
				});
		
				var mines = array.slice(0, bombs);
			
				pool.query('INSERT INTO `minesweeper_bets` SET `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + parseInt(user.xp) + ', `amount` = ' + amount + ', `bombs` = ' + bombs + ', `roll` = ' + pool.escape(roll) + ', `server_seedid` = ' + pool.escape(fair.server_seedid) + ', `client_seedid` = ' + pool.escape(fair.client_seedid) + ', `nonce` = ' + pool.escape(fair.nonce) + ', `time` = '+ pool.escape(time()), function(err4, row4) {
					if(err4) {
						logger.error(err4);
						writeError(err4);
						
						return cooldown(false, true);
					}
					
					pool.query('UPDATE `users_seeds_server` SET `nonce` = `nonce` + 1 WHERE `userid` = ' + pool.escape(user.userid) + ' AND `id` = ' + pool.escape(fair.server_seedid), function(err6){
						if(err6) {
							logger.debug(err6);
							writeError(err6);
							
							return cooldown(false, true);
						}
					
						minesweeperGame_countBets[user.userid] = 1;
					
						minesweeperGame_userBets[user.userid] = {
							id: row4.insertId,
							amount: amount,
							bombs: bombs,
							route: [],
							mines: mines,
							roll: roll,
							cashout: false,
							ended: false
						};
						
						socket.emit('message', {
							type: 'minesweeper',
							command: 'bet_confirmed',
							total: amount
						});
						
						user_updateBalance(user.userid);
						
						logger.debug('[MINESWEEPER] Bet registed. ' + user.name + ' did bet $' + getFormatAmountString(amount));
						
						cooldown(false, false);
					});
				});
			});
		});
	});
}

function minesweeperGame_cashout(user, socket, cooldown){
	cooldown(true, true);
	
	if(minesweeperGame_userBets[user.userid]['cashout']){
		socket.emit('message', {
			type: 'error',
			error: 'Error: The game is already cashout!'
		});
		
		return cooldown(false, true);
	}
	
	if(minesweeperGame_userBets[user.userid]['ended']){
		socket.emit('message', {
			type: 'error',
			error: 'Error: The game is already ended!'
		});
		
		return cooldown(false, true);
	}
	
	if(minesweeperGame_userBets[user.userid]['route'].length == 0){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You need to play one time to withdraw your winnings!'
		});
		
		return cooldown(false, true);
	}
	
	var route = '';
	minesweeperGame_userBets[user.userid]['route'].forEach(function(item){
		if(item < 10) route += '0' + item;
		else route += item;
	});
	
	var winning = getFormatAmount(minesweeperGame_generateAmount(minesweeperGame_userBets[user.userid]['amount'], minesweeperGame_userBets[user.userid]['bombs'])[minesweeperGame_userBets[user.userid]['route'].length - 1]); 
	
	pool.query('UPDATE `minesweeper_bets` SET `route` = ' + pool.escape(route) + ', `winning` = ' + winning + ', `ended` = 1, `cashout` = 1 WHERE `id` = ' + pool.escape(minesweeperGame_userBets[user.userid]['id']), function(err1){
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		//FINISH BET
		user_finishBet(user.userid, minesweeperGame_userBets[user.userid]['amount'], winning, winning, [], 'minesweeper', function(err2){
			if(err2) {
				socket.emit('message', {
					type: 'error',
					error: err2.message
				});
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'minesweeper',
				command: 'result_bomb',
				result: 'lose',
				data: {
					mines: minesweeperGame_userBets[user.userid]['mines']
				}
			});
			
			var history = {
				id: minesweeperGame_userBets[user.userid]['id'], 
				user: {
					userid: user.userid,
					name: user.name,
					avatar: user.avatar,
					level: calculateLevel(user.xp).level
				},
				amount: minesweeperGame_userBets[user.userid]['amount'],
				bombs: minesweeperGame_userBets[user.userid]['bombs'],
				roll: minesweeperGame_userBets[user.userid]['roll'],
				winning: winning
			}
		
			minesweeperGame_lastGames.push(history);
			if(minesweeperGame_lastGames.length > 10) minesweeperGame_lastGames.shift();
		
			io.sockets.in('minesweeper').emit('message', {
				type: 'minesweeper',
				command: 'history',
				history: history
			});
		
			minesweeperGame_userBets[user.userid]['cashout'] = true;
			minesweeperGame_countBets[user.userid] = 0;
			
			user_updateLevel(user.userid);
			user_updateBalance(user.userid);
			
			if(winning >= config.config_games.winning_to_chat){
				var send_message = user.name + ' won ' + getFormatAmountString(winning) + ' to minesweeper!';
				otherMessages(send_message, io.sockets, true);
			}
			
			logger.debug('[MINESWEEPER] Win registed. ' + user.name + ' did win $' + getFormatAmountString(winning));
			
			cooldown(false, false);
		});
	});
}

function minesweeperGame_bomb(user, socket, bomb, cooldown){
	cooldown(true, true);
	
	if((minesweeperGame_countBets[user.userid] == undefined) || (minesweeperGame_countBets[user.userid] == 0)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: The game is not started!'
		});
		
		return cooldown(false, true);
	}
	
	if(minesweeperGame_userBets[user.userid]['ended']){
		socket.emit('message', {
			type: 'error',
			error: 'Error: The game is already ended!'
		});
		
		return cooldown(false, true);
	}
	
	if(minesweeperGame_userBets[user.userid]['route'].includes(bomb)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You already pressed this button!'
		});
		
		return cooldown(false, true);
	}
	
	/* CHECK DATA GAME */
	
	if(isNaN(Number(bomb))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid bomb!'
		});
		
		return cooldown(false, true);
	}

	bomb = parseInt(bomb);

	if(bomb < 0 || bomb > 24) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid bomb!'
		});
		
		return cooldown(false, true);
	}
	
	/* END CHECK DATA GAME */
	
	if(minesweeperGame_userBets[user.userid]['mines'].includes(bomb)){
		minesweeperGame_userBets[user.userid]['route'].push(bomb);
		minesweeperGame_userBets[user.userid]['ended'] = true;
		minesweeperGame_countBets[user.userid] = 0;
		
		var route = '';
		minesweeperGame_userBets[user.userid]['route'].forEach(function(item){
			if(item < 10) route += '0' + item;
			else route += item;
		});
		
		pool.query('UPDATE `minesweeper_bets` SET `route` = ' + pool.escape(route) + ', `ended` = 1 WHERE `id` = ' + pool.escape(minesweeperGame_userBets[user.userid]['id']), function(err1){
			if(err1) {
				logger.error(err1);
				writeError(err1);
				
				return cooldown(false, true);
			}
			
			//FINISH BET
			user_finishBet(user.userid, minesweeperGame_userBets[user.userid]['amount'], 0, 0, [], 'minesweeper', function(err2){
				if(err2) {
					socket.emit('message', {
						type: 'error',
						error: err2.message
					});
					
					return cooldown(false, true);
				}
			
				socket.emit('message', {
					type: 'minesweeper',
					command: 'result_bomb',
					result: 'lose',
					data: {
						mines: minesweeperGame_userBets[user.userid]['mines']
					}
				});
				
				var history = {
					id: minesweeperGame_userBets[user.userid]['id'],
					user: {
						userid: user.userid,
						name: user.name,
						avatar: user.avatar,
						level: calculateLevel(user.xp).level
					},
					amount: minesweeperGame_userBets[user.userid]['amount'],
					bombs: minesweeperGame_userBets[user.userid]['bombs'],
					roll: minesweeperGame_userBets[user.userid]['roll'], 
					winning: 0
				}
				
				minesweeperGame_lastGames.push(history);
				if(minesweeperGame_lastGames.length > 10) minesweeperGame_lastGames.shift();
			
				io.sockets.in('minesweeper').emit('message', {
					type: 'minesweeper',
					command: 'history',
					history: history
				});
				
				cooldown(false, true);
			});
		});
	} else {
		minesweeperGame_userBets[user.userid]['route'].push(bomb);
		
		var route = '';
		minesweeperGame_userBets[user.userid]['route'].forEach(function(item){
			if(item < 10) route += '0' + item;
			else route += item;
		});
		
		pool.query('UPDATE `minesweeper_bets` SET `route` = ' + pool.escape(route) + ' WHERE `id` = ' + pool.escape(minesweeperGame_userBets[user.userid]['id']), function(err1){
			if(err1) {
				logger.error(err1);
				writeError(err1);
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'minesweeper',
				command: 'result_bomb',
				result: 'win',
				data: {
					bomb: bomb,
					total: getFormatAmount(minesweeperGame_generateAmount(minesweeperGame_userBets[user.userid]['amount'], minesweeperGame_userBets[user.userid]['bombs'])[minesweeperGame_userBets[user.userid]['route'].length - 1]),
					multiplier: config.config_games.games.minesweeper.multipliers[minesweeperGame_userBets[user.userid]['bombs']][minesweeperGame_userBets[user.userid]['route'].length - 1]
				}
			});
			
			if(minesweeperGame_userBets[user.userid]['bombs'] + minesweeperGame_userBets[user.userid]['route'].length < 25) {
				return cooldown(false, false);
			}
			
			var winning = getFormatAmount(minesweeperGame_generateAmount(minesweeperGame_userBets[user.userid]['amount'], minesweeperGame_userBets[user.userid]['bombs'])[minesweeperGame_userBets[user.userid]['route'].length - 1]);
			
			pool.query('UPDATE `minesweeper_bets` SET `winning` = ' + winning + ', `ended` = 1, `cashout` = 1 WHERE `id` = ' + pool.escape(minesweeperGame_userBets[user.userid]['id']), function(err2){
				if(err2) {
					logger.error(err2);
					writeError(err2);
					
					return cooldown(false, true);
				}
				
				//FINISH BET
				user_finishBet(user.userid, minesweeperGame_userBets[user.userid]['amount'], winning, winning, [], 'minesweeper', function(err3){
					if(err3) {
						socket.emit('message', {
							type: 'error',
							error: err3.message
						});
						
						return cooldown(false, true);
					}
					
					minesweeperGame_userBets[user.userid]['cashout'] = true;
					minesweeperGame_countBets[user.userid] = 0;
					
					socket.emit('message', {
						type: 'minesweeper',
						command: 'result_bomb',
						result: 'lose',
						data: {
							mines: minesweeperGame_userBets[user.userid]['mines']
						}
					});
				
					var history = {
						id: minesweeperGame_userBets[user.userid]['id'],
						user: {
							userid: user.userid,
							name: user.name,
							avatar: user.avatar,
							level: calculateLevel(user.xp).level
						},
						amount: minesweeperGame_userBets[user.userid]['amount'],
						bombs: minesweeperGame_userBets[user.userid]['bombs'],
						roll: minesweeperGame_userBets[user.userid]['roll'], 
						winning: winning
					}
				
					minesweeperGame_lastGames.push(history);
					if(minesweeperGame_lastGames.length > 10) minesweeperGame_lastGames.shift();
				
					io.sockets.in('minesweeper').emit('message', {
						type: 'minesweeper',
						command: 'history',
						history: history
					});
					
					user_updateLevel(user.userid);
					user_updateBalance(user.userid);
					
					if(winning >= config.config_games.winning_to_chat){
						var send_message = user.name + ' won ' + getFormatAmountString(winning) + ' to minesweeper!';
						otherMessages(send_message, io.sockets, true);
					}
					
					logger.debug('[MINESWEEPER] Win registed. ' + user.name + ' did win $' + getFormatAmountString(winning));
					
					cooldown(false, false);
				});
			});
		});
	}
}

function minesweeperGame_generateAmount(amount, bombs){
	var amounts = [];
	
	for(var i = 0; i < config.config_games.games.minesweeper.multipliers[bombs].length; i++) amounts.push(roundedToFixed(parseFloat(amount * config.config_games.games.minesweeper.multipliers[bombs][i]), 5));
	
	return amounts;
}

/* END MINESWEEPER */