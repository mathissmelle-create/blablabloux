/* CRASH */

var crashGame_lastGames = [];

var crashGame_seed = {
	id: null,
	server_seed: null,
	public_seed: null,
	uses: 0
};

var crashGame_settings = {
	point: 0,
	start_time: 0,
	progress_time: 0,
	end_time: 0,
	timeout: null
};

var crashGame_totalBets = [];
var crashGame_userBets = {};

var crashGame = {
	status: 'ended',
	id: null,
	roll: null,
	public_seed: null,
	nonce: null
}

crashGame_loadHistory();
crashGame_checkSeed(true);

function crashGame_checkSeed(start){
	pool.query('SELECT * FROM `crash_seeds` WHERE `removed` = 0 AND `time` > ' + pool.escape(time() - (24 * 60 * 60)) + ' ORDER BY `id` DESC LIMIT 1', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		if(row1.length <= 0) crashGame_createSeed(start);
		else {
			crashGame_seed = {
				id: parseInt(row1[0].id),
				server_seed: row1[0].server_seed,
				public_seed: row1[0].public_seed,
				uses: parseInt(row1[0].uses)
			};
			
			if(start) crashGame_checkRound();
			else crashGame_generateRound();
		}
	});
}

function crashGame_createSeed(start){
	logger.debug('[CRASH] Creating New Seed');
	
	var server_seed = fair_generateServerSeed();
	var public_seed = fair_generatePublicSeed();
	
	pool.query('INSERT INTO `crash_seeds` SET `server_seed` = ' + pool.escape(server_seed) + ', `public_seed` = ' + pool.escape(public_seed) + ', `time` = ' + pool.escape(time()), function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		crashGame_seed = {
			id: row1.insertId,
			server_seed: server_seed,
			public_seed: public_seed,
			uses: 0
		};
		
		if(start) crashGame_checkRound();
		else crashGame_generateRound();
	});
}

function crashGame_checkRound(){
	pool.query('SELECT crash_rolls.id, crash_rolls.point, crash_seeds.public_seed, crash_rolls.nonce FROM `crash_rolls` INNER JOIN `crash_seeds` ON crash_rolls.seedid = crash_seeds.id WHERE crash_rolls.ended = 0 ORDER BY crash_rolls.id DESC LIMIT 1', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		if(row1.length > 0){
			crashGame = {
				status: 'ended',
				id: parseInt(row1[0].id),
				roll: parseInt(parseFloat(row1[0].point) * 100),
				public_seed: row1[0].public_seed,
				nonce: parseInt(row1[0].nonce)
			}
			
			pool.query('SELECT * FROM `crash_bets` WHERE `game_id` = ' + parseInt(crashGame.id), function(err2, row2){
				if(err2){
					logger.error(err2);
					writeError(err2);
					return;
				}
				
				row2.forEach(function(bet){
					var amount = getFormatAmount(bet.amount);
					
					if(crashGame_userBets[bet.userid] === undefined) {
						crashGame_userBets[bet.userid] = {
							id: bet.id,
							amount: amount,
							infinity_cashout: (parseFloat(bet.auto_cashout) * 100 == 0) ? true : false,
							auto_cashout: parseInt(parseFloat(bet.auto_cashout) * 100),
							cashedout: (parseInt(bet.cashedout) == 1) ? true : false,
							point_cashedout: parseFloat(bet.point_cashedout)
						};
					}
					
					crashGame_totalBets.push({
						id: bet.id,
						user: {
							userid: bet.userid,
							name: bet.name,
							avatar: bet.avatar,
							level: calculateLevel(bet.xp).level
						},
						amount: amount,
						auto_cashout: parseInt(parseFloat(bet.auto_cashout) * 100)
					});
					
					logger.debug('[CRASH] Bet registed. ' + bet.name + ' did bet $' + getFormatAmountString(amount));
				});
			});
			
			crashGame.status = 'started';
			
			setTimeout(function() {
				crashGame_start();
			}, config.config_games.games.crash.timer * 1000 + 1000);
		} else crashGame_generateRound();
	});
}

function crashGame_generateRound(){
	pool.query('SELECT `id` FROM `crash_rolls` ORDER BY `id` DESC LIMIT 1', function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		logger.debug('[CRASH] Starting');
		
		io.sockets.in('crash').emit('message', {
			type: 'crash',
			command: 'reset'
		});
		
		io.sockets.in('crash').emit('message', {
			type: 'crash',
			command: 'starting',
			time: parseInt(config.config_games.games.crash.timer * 1000)
		});
		
		crashGame_settings.start_time = new Date().getTime();
		
		var seedid = crashGame_seed.id;
		
		var server_seed = crashGame_seed.server_seed;
		var public_seed = crashGame_seed.public_seed;
		
		var nonce = 1;
		if(row1.length > 0) nonce = parseInt(row1[0].id) + 1;
		
		var seed = fair_getCombinedSeed(server_seed, public_seed, nonce);
		var salt = fair_generateSaltHash(seed);
		
		var roll = fair_getRollCrash(salt);
		
		pool.query('INSERT INTO `crash_rolls` SET `point` = ' + roundedToFixed(roll / 100, 2) + ', `seedid` = ' + pool.escape(seedid) + ', `nonce` = ' + pool.escape(nonce) + ', `time` = ' + pool.escape(time()), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				return;
			}
			
			pool.query('UPDATE `crash_seeds` SET `uses` = `uses` + 1 WHERE `id` = ' + pool.escape(seedid), function(err3){
				if(err3){
					logger.error(err3);
					writeError(err3);
					return;
				}
			
				crashGame_seed.uses++;
				
				crashGame.id = row2.insertId;
				crashGame.roll = roll;
				crashGame.public_seed = public_seed;
				crashGame.nonce = nonce;
				
				crashGame.status = 'started';
				
				io.sockets.in('crash').emit('message', {
					type: 'crash',
					command: 'info',
					info: {
						id: crashGame.id,
						public_seed: public_seed
					}
				});
				
				setTimeout(function() {
					crashGame_start();
				}, config.config_games.games.crash.timer * 1000 + 1000);
			});
		});
	});
}

function crashGame_loadHistory(){
	logger.debug('[CRASH] Loading History');
	
	pool.query('SELECT `point` FROM `crash_rolls` WHERE `ended` = 1 ORDER BY `id` DESC LIMIT 50', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		if(row1.length == 0) return;
		
		row1.reverse();
		
		row1.forEach(function(crash){
			crashGame_lastGames.push(crash.point);
		});
	});
}

function crashGame_bet(user, socket, amount, auto, cooldown) {
	cooldown(true, true);
	
	if(crashGame_userBets[user.userid] !== undefined) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: You have already joined the crash!'
		});
		
		return cooldown(false, true);
	}
	
	if(crashGame.status != 'started') {
		socket.emit('message', {
			type: 'error',
			error: 'Error: The game have been already started!'
		});
		
		return cooldown(false, true);
	}
	
	/* CHECK DATA GAME */
	
	if(isNaN(Number(auto))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid auto cashout!'
		});
		
		return cooldown(false, true);
	}

	auto = parseInt(auto);

	if(auto <= 100 && auto != 0) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Auto cashout needs to be more than 1.00x!'
		});
		
		return cooldown(false, true);
	}
	
	/* END CHECK DATA GAME */
	
	//VERIFY FORMAT AMOUNT
	site_verifyFormatAmount(amount, function(err1, amount){
		if(err1) {
			socket.emit('message', {
				type: 'error',
				error: err1.message
			});
			
			return cooldown(false, true);
		}
			
		//REGISTER BET
		user_registerBet(user.userid, amount, [], 'crash', true, function(err2){
			if(err2) {
				socket.emit('message', {
					type: 'error',
					error: err2.message
				});
				
				return cooldown(false, true);
			}
			
			pool.query('INSERT INTO `crash_bets` SET `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + parseInt(user.xp) + ', `amount` = ' + amount + ', `game_id` = ' + parseInt(crashGame.id) + ', `auto_cashout` = ' + roundedToFixed(parseFloat(auto / 100), 2) + ', `time` = ' + pool.escape(time()), function(err3, row3) {
				if(err3) {
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				if(crashGame_userBets[user.userid] === undefined) {
					crashGame_userBets[user.userid] = {
						id: row3.insertId,
						amount: amount,
						infinity_cashout: (auto == 0) ? true : false,
						auto_cashout: auto,
						cashedout: false,
						point_cashedout: 0
					};
				}
				
				socket.emit('message', {
					type: 'crash',
					command: 'bet_confirmed'
				});
				
				io.sockets.in('crash').emit('message', {
					type: 'crash',
					command: 'bet',
					bet: {
						id: row3.insertId,
						user: {
							userid: user.userid,
							name: user.name,
							avatar: user.avatar,
							level: calculateLevel(user.xp).level
						},
						amount: amount
					}
				});
				
				crashGame_totalBets.push({
					id: row3.insertId,
					user: {
						userid: user.userid,
						name: user.name,
						avatar: user.avatar,
						level: calculateLevel(user.xp).level
					},
					amount: amount,
					auto_cashout: auto
				});
			
				user_updateBalance(user.userid);
				
				logger.debug('[CRASH] Bet registed. ' + user.name + ' did bet $' + getFormatAmountString(amount));
				
				cooldown(false, false);
			});
		});
	});
}

function crashGame_cashout(user, socket, cooldown) {
	cooldown(true, true);
	
	if(crashGame.status != 'counting') {
		socket.emit('message', {
			type: 'error',
			error: 'Error: The game is ended!'
		});
		
		return cooldown(false, true);
	}
	
	if(crashGame_settings.point <= 1.00) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: You can\'t cashout at least 1.00x!'
		});
		
		return cooldown(false, true);
	}
	
	if(crashGame_userBets[user.userid] === undefined) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: You are not in this game!'
		});
		
		return cooldown(false, true);
	}
	
	if(crashGame_userBets[user.userid]['cashedout'] == true) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: You have already cashed out!'
		});
		
		return cooldown(false, true);
	}
	
	var winning = getFormatAmount(crashGame_userBets[user.userid]['amount'] * crashGame_settings.point);
	
	pool.query('UPDATE `crash_bets` SET `cashedout` = 1, `point_cashedout` = ' + roundedToFixed(crashGame_settings.point, 2).toFixed(2) + ' WHERE `id` = ' + pool.escape(crashGame_userBets[user.userid]['id']), function(err1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
	
		//FINISH BET
		user_finishBet(user.userid, crashGame_userBets[user.userid]['amount'], winning, winning, [], 'crash', function(err2){
			if(err2) {
				socket.emit('message', {
					type: 'error',
					error: err2.message
				});
				
				return cooldown(false, true);
			}
		
			io.sockets.in('crash').emit('message', {
				type: 'crash',
				command: 'bet_win',
				bet: {
					id: crashGame_userBets[user.userid]['id'],
					cashout: roundedToFixed(crashGame_settings.point, 2),
					profit: getFormatAmount(winning - crashGame_userBets[user.userid]['amount'])
				}
			});
			
			socket.emit('message', {
				type: 'crash',
				command: 'cashed_out',
				amount: winning
			});
			
			crashGame_userBets[user.userid]['cashedout'] = true;
			crashGame_userBets[user.userid]['point_cashedout'] = parseInt(crashGame_settings.point * 100);
			
			if(winning >= config.config_games.winning_to_chat){
				var send_message = user.name + ' won ' + getFormatAmountString(winning) + ' to crash on x' + roundedToFixed(crashGame_settings.point, 2).toFixed(2) + '!';
				otherMessages(send_message, io.sockets, true);
			}
			
			user_updateLevel(user.userid);
			user_updateBalance(user.userid);
			
			logger.debug('[CRASH] Win registed. ' + user.name + ' did win $' + getFormatAmountString(winning) + ' with multiplier x' + roundedToFixed(crashGame_settings.point, 2).toFixed(2));
			
			cooldown(false, false);
		});
	});
}

function crashGame_start(){
	logger.debug('[CRASH] New Round. Public Seed: ' + crashGame.public_seed + ', Nonce: ' + crashGame.nonce);
	
	crashGame_settings.progress_time = new Date().getTime();
	
	io.sockets.in('crash').emit('message', {
		type: 'crash',
		command: 'started',
		difference: new Date().getTime() - crashGame_settings.progress_time
	});

	function calcCrash1(ms) {
		var gamePayout = Math.floor(100 * calcCrash2(ms)) / 100;
		return gamePayout;
	}

	function calcCrash2(ms) {
		var r = 0.00006;
		return Math.pow(Math.E, r * ms);
	}
	
	crashGame_settings.point = calcCrash1(new Date().getTime() - crashGame_settings.progress_time);

	crashGame.status = 'counting';

	crashGame_settings.timeout = setInterval(function(){
		crashGame_settings.point = calcCrash1(new Date().getTime() - crashGame_settings.progress_time);
		crashGame_checkPoint();
	}, 10);
}

function crashGame_checkPoint(){
	if(crashGame.status != 'counting') return;
	
	var point = parseInt(crashGame_settings.point * 100);
	
	if(crashGame_totalBets.length > 0){
		crashGame_totalBets.forEach(function(bet){
			if(crashGame_userBets[bet.user.userid]['cashedout'] == false) {
				var winning = getFormatAmount(crashGame_userBets[bet.user.userid]['amount'] * point / 100);
				
				io.sockets.in(bet.user.userid).emit('message', {
					type: 'crash',
					command: 'cashout',
					amount: winning
				});
			}
		});
	}
	
	if(!crashGame_checking_bets) crashGame_checkBets(point);
	
	if(point >= crashGame.roll){
		crashGame_settings.end_time = new Date().getTime() - crashGame_settings.progress_time;
		
		crashGame.status = 'ended';
		
		clearInterval(crashGame_settings.timeout);
		
		var losers = [];
		for(var bet of crashGame_totalBets) {
			if(crashGame_userBets[bet.user.userid]['cashedout'] == false) {
				losers.push({
					id: bet.id,
					user: bet.user,
					amount: bet.amount,
					winning: 0
				});
			}
		}
		
		pool.query('UPDATE `crash_rolls` SET `ended` = 1 WHERE `id` = ' + parseInt(crashGame.id), function(err1){
			if(err1){
				logger.error(err1);
				writeError(err1);
				return;
			}
			
			io.sockets.in('crash').emit('message', {
				type: 'crash',
				command: 'crashed',
				number: crashGame.roll,
				time: crashGame_settings.end_time,
				history: true
			});
			
			var bets = [];
			
			if(crashGame_totalBets.length > 0){
				crashGame_totalBets.forEach(function(bet){
					if(crashGame_userBets[bet.user.userid]['cashedout'] == false) bets.push(bet.id);
				});
			}
			
			io.sockets.in('crash').emit('message', {
				type: 'crash',
				command: 'bets_lose',
				ids: bets
			});
			
			crashGame_lastGames.push(roundedToFixed(crashGame.roll / 100, 2));
			while(crashGame_lastGames.length > 50) crashGame_lastGames.shift();
			
			crashGame_losers(0, losers, function(err2){
				if(err2) {
					logger.error(err2);
					writeError(err2);
					return;
				}
			
				setTimeout(function() {
					crashGame_userBets = {};
					crashGame_totalBets = [];
					
					crashGame_checkSeed(false);
				}, 5000);
				
				logger.debug('[CRASH] Creshed at ' + roundedToFixed(crashGame.roll / 100, 2).toFixed(2) + 'x');
			});
		});
	}
}


function crashGame_losers(index, losers, callback) {
	if(index >= losers.length) return callback(null);
	
	//FINISH BET
	user_finishBet(losers[index].user.userid, losers[index].amount, losers[index].winning, losers[index].winning, [], 'crash', function(err1){
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return callback(new Error('[CRASH] Bet #' + losers[index].id + ' unfinished'));
		}
		
		crashGame_losers(index + 1, losers, callback);
	});
}

var crashGame_checking_bets = false;

async function crashGame_checkBets(point){
	crashGame_checking_bets = true;
	
	for(var i = 0; i < crashGame_totalBets.length; i++) await crashGame_checkBet(crashGame_totalBets[i], point);

	crashGame_checking_bets = false;
}

function crashGame_checkBet(bet, point){
	return new Promise(function(resolve, reject) {
		if(crashGame_userBets[bet.user.userid]['cashedout'] == false) {
			var profit = getFormatAmount(crashGame_userBets[bet.user.userid]['amount'] * crashGame_settings.point - crashGame_userBets[bet.user.userid]['amount']);
			
			if(profit >= config.config_games.games.crash.max_profit){
				var winning = getFormatAmount(crashGame_userBets[bet.user.userid]['amount'] + config.config_games.games.crash.max_profit);
				
				pool.query('UPDATE `crash_bets` SET `cashedout` = 1, `point_cashedout` = ' + roundedToFixed(parseFloat(winning / crashGame_userBets[bet.user.userid]['amount']), 2) + ' WHERE `id` = ' + pool.escape(crashGame_userBets[bet.user.userid]['id']), function(err1){
					if(err1){
						logger.error(err1);
						writeError(err1);
						
						return resolve();
					}
				
					//FINISH BET
					user_finishBet(bet.user.userid, crashGame_userBets[bet.user.userid]['amount'], winning, winning, [], 'crash', function(err2){
						if(err2){
							logger.error(err2);
							writeError(err2);
							
							return resolve();
						}
						
						io.sockets.in('crash').emit('message', {
							type: 'crash',
							command: 'bet_win',
							bet: {
								id: bet.id,
								cashout: roundedToFixed(parseFloat(winning / crashGame_userBets[bet.user.userid]['amount']), 2),
								profit: config.config_games.games.crash.max_profit
							}
						});
						
						io.sockets.in(bet.user.userid).emit('message', {
							type: 'crash',
							command: 'cashed_out',
							amount: winning
						});
				
						crashGame_userBets[bet.user.userid]['cashedout'] = true;
						crashGame_userBets[bet.user.userid]['point_cashedout'] = parseInt(winning / crashGame_userBets[bet.user.userid]['amount'] * 100);
					
						if(winning >= config.config_games.winning_to_chat){
							var send_message = bet.user.name + ' won ' + getFormatAmountString(winning) + ' to crash on x' + roundedToFixed(parseFloat(winning / crashGame_userBets[bet.user.userid]['amount']), 2).toFixed(2) + '!';
							otherMessages(send_message, io.sockets, true);
						}
						
						user_updateLevel(bet.user.userid);
						user_updateBalance(bet.user.userid);
						
						logger.debug('[CRASH] Win registed. ' + bet.user.name + ' did win $' + getFormatAmountString(winning) + ' with multiplier x' + roundedToFixed(parseFloat(winning / crashGame_userBets[bet.user.userid]['amount']), 2).toFixed(2));
					
						resolve();
					});
				});
			} else if(crashGame_userBets[bet.user.userid]['infinity_cashout'] == false){
				if(crashGame_userBets[bet.user.userid]['auto_cashout'] <= point && crashGame_userBets[bet.user.userid]['auto_cashout'] <= crashGame.roll){
					var winning = getFormatAmount(crashGame_userBets[bet.user.userid]['amount'] * crashGame_userBets[bet.user.userid]['auto_cashout'] / 100);
					
					pool.query('UPDATE `crash_bets` SET `cashedout` = 1, `point_cashedout` = ' + roundedToFixed(parseFloat(crashGame_userBets[bet.user.userid]['auto_cashout'] / 100), 2) + ' WHERE `id` = ' + pool.escape(crashGame_userBets[bet.user.userid]['id']), function(err1){
						if(err1){
							logger.error(err1);
							writeError(err1);
							
							return resolve();
						}
					
						//FINISH BET
						user_finishBet(bet.user.userid, crashGame_userBets[bet.user.userid]['amount'], winning, winning, [], 'crash', function(err2){
							if(err2){
								logger.error(err2);
								writeError(err2);
								
								return resolve();
							}
						
							io.sockets.in('crash').emit('message', {
								type: 'crash',
								command: 'bet_win',
								bet: {
									id: bet.id,
									cashout: roundedToFixed(parseFloat(crashGame_userBets[bet.user.userid]['auto_cashout'] / 100), 2),
									profit: getFormatAmount(winning - crashGame_userBets[bet.user.userid]['amount'])
								}
							});
							
							io.sockets.in(bet.user.userid).emit('message', {
								type: 'crash',
								command: 'cashed_out',
								amount: winning
							});
						
							crashGame_userBets[bet.user.userid]['cashedout'] = true;
							crashGame_userBets[bet.user.userid]['point_cashedout'] = parseInt(crashGame_userBets[bet.user.userid]['auto_cashout']);
							
							if(winning >= config.config_games.winning_to_chat){
								var send_message = bet.user.name + ' won ' + getFormatAmountString(winning) + ' to crash on x' + roundedToFixed(parseFloat(crashGame_userBets[bet.user.userid]['auto_cashout'] / 100), 2).toFixed(2) + '!';
								otherMessages(send_message, io.sockets, true);
							}
							
							user_updateLevel(bet.user.userid);
							user_updateBalance(bet.user.userid);
							
							logger.debug('[CRASH] Win registed. ' + bet.user.name + ' did win $' + getFormatAmountString(winning) + ' with multiplier x' + roundedToFixed(parseFloat(crashGame_userBets[bet.user.userid]['auto_cashout'] / 100), 2).toFixed(2));
							
							resolve();
						});
					});
				} else resolve();
			} else resolve();
		} else resolve();
	});
}

/* END CRASH */