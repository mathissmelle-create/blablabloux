function upgraderGame_bet(user, socket, myitems, siteitems, amount, game, cooldown){
	cooldown(true, true);
	
	/* CHECK DATA GAME */
	
	var allowed_games = ['under', 'over'];
	if(!allowed_games.includes(game)) {
		socket.emit('message', {
			type: 'error',
			error: 'Invalid type game [over or under]!'
		});
		
		return cooldown(false, true);
	}
	
	if(myitems.length < config.config_games.games.upgrader.interval_myitems.min) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: You have to sellect minimum ' + config.config_games.games.upgrader.interval_myitems.min + ' items from your inventory!'
		});
		
		return cooldown(false, true);
	}
	
	if(myitems.length > config.config_games.games.upgrader.interval_myitems.max) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: You have to sellect maximum ' + config.config_games.games.upgrader.interval_myitems.max + ' items from your inventory!'
		});
		
		return cooldown(false, true);
	}
	
	if(siteitems.length < config.config_games.games.upgrader.interval_siteitems.min) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: You have to sellect minimum ' + config.config_games.games.upgrader.interval_siteitems.min + ' items from site inventory!'
		});
		
		return cooldown(false, true);
	}
	
	if(siteitems.length > config.config_games.games.upgrader.interval_siteitems.max) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: You have to sellect maximum ' + config.config_games.games.upgrader.interval_siteitems.max + ' items from site inventory!'
		});
		
		return cooldown(false, true);
	}
	
	/* END CHECK DATA GAME */
	
	//VERIFY FORMAT AMOUNT
	site_verifyFormatAmount(amount, function(err1, amount){
		if(err1) {
			socket.emit('message', {
				type: 'error',
				error: err1.message
			});
			
			return cooldown(false, true);
		}
		
		var myitemsin_query = myitems.map(a => '"' + a + '"').join(',') || 'null';
		
		pool.query('SELECT users_items.itemid, items_list.price FROM `users_items` INNER JOIN `items_list` ON users_items.itemid = items_list.itemid WHERE users_items.id IN (' + myitemsin_query + ') AND users_items.status = 0 AND users_items.userid = ' + pool.escape(user.userid), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			if(row2.length != myitems.length){
				socket.emit('message', {
					type: 'error',
					error: 'Error: Invalid your items in upgrader!'
				});
				
				return cooldown(false, true);
			}
			
			var myitems_amount = row2.reduce(function(acc, val) { return getFormatAmount(acc + itemsSystem_items[val.itemid].price) }, 0);
			
			var siteitemsin_query = siteitems.map(a => '"' + a + '"').join(',') || 'null';
			
			pool.query('SELECT `itemid` FROM `items_list` WHERE `itemid` IN (' + siteitemsin_query + ')', function(err3, row3){
				if(err3){
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				if(row3.length != siteitems.length){
					socket.emit('message', {
						type: 'error',
						error: 'Error: Invalid site items in upgrader!'
					});
					
					return cooldown(false, true);
				}
				
				var siteitems_amount = row3.reduce(function(acc, val) { return getFormatAmount(acc + itemsSystem_items[val.itemid].price) }, 0);
				
				var chance = getFormatAmount(myitems_amount + amount) / siteitems_amount * 100;
				var multiplier = roundedToFixed(siteitems_amount / getFormatAmount(myitems_amount + amount), 2);
				
				if(chance > 80){
					socket.emit('message', {
						type: 'error',
						error: 'Error: Upgrade above 80% is not possible'
					});
					
					return cooldown(false, true);
				}
				
				if(chance < 1){
					socket.emit('message', {
						type: 'error',
						error: 'Error: Upgrade below 1% is not possible'
					});
					
					return cooldown(false, true);
				}
				
				//SEEDS
				fair_getUserSeeds(user.userid, function(err4, fair){
					if(err4) {
						socket.emit('message', {
							type: 'error',
							error: err4.message
						});
						
						return cooldown(false, true);
					}
					
					//REGISTER BET
					user_registerBet(user.userid, amount, myitems, 'upgrader', true, function(err5){
						if(err5) {
							socket.emit('message', {
								type: 'error',
								error: err5.message
							});
							
							return cooldown(false, true);
						}
						
						var seed = fair_getCombinedSeed(fair.server_seed, fair.client_seed, fair.nonce);
						var salt = fair_generateSaltHash(seed);
						
						var roll = (fair_getRoll(salt, 10000) / 100) % 100;
						var win = false;
					
						if(game == 'under' && roll < chance) win = true;
						if(game == 'over' && roll >= roundedToFixed(100 - chance, 2)) win = true;
						
						var winning = [];
						if(win) winning = siteitems.slice();
						
						//FINISH BET
						user_finishBet(user.userid, getFormatAmount(myitems_amount + amount), siteitems_amount, 0, winning, 'upgrader', function(err6, items){
							if(err6) {
								logger.error(err6);
								writeError(err6);
								
								return cooldown(false, true);
							}
							
							var insert_items = items.slice().map(a => a.id)
							
							pool.query('INSERT INTO `upgrader_bets` SET `userid` = ' + pool.escape(user.userid) + ', `avatar` = ' + pool.escape(user.avatar) + ', `name` = ' + pool.escape(user.name) + ', `xp` = ' + parseInt(user.xp) + ', `items` = ' + pool.escape(JSON.stringify(myitems)) + ', `amount` = ' + amount + ', `game` = ' + pool.escape(game) + ', `chance` = ' + chance + ', `multiplier` = ' + multiplier + ', `roll` = ' + roll + ', `winning` = ' + pool.escape(JSON.stringify(insert_items)) + ', `server_seedid` = ' + pool.escape(fair.server_seedid) + ', `client_seedid` = ' + pool.escape(fair.client_seedid) + ', `nonce` = ' + pool.escape(fair.nonce) + ', `time` = ' + pool.escape(time()), function(err7, row7) {
								if(err7) {
									logger.debug(err7);
									writeError(err7);
									
									return cooldown(false, true);
								}
								
								pool.query('UPDATE `users_seeds_server` SET `nonce` = `nonce` + 1 WHERE `userid` = ' + pool.escape(user.userid) + ' AND `id` = ' + pool.escape(fair.server_seedid), function(err8){
									if(err8) {
										logger.debug(err8);
										writeError(err8);
										
										return cooldown(false, true);
									}
									
									socket.emit('message', {
										type: 'upgrader',
										command: 'roll',
										roll: roll
									});
									
									setTimeout(function(){
										socket.emit('message', {
											type: 'upgrader',
											command: 'finish',
											win: win,
											items: insert_items,
										});
										
										if(win){
											if(siteitems_amount >= config.config_games.winning_to_chat){
												var send_message = user.name + ' won ' + getFormatAmountString(siteitems_amount) + ' to upgrader!';
												otherMessages(send_message, io.sockets, true);
											}
											
											logger.debug('[UPGRADER] Win registed. ' + user.name + ' did win $' + getFormatAmountString(siteitems_amount) + ' with chance ' + roundedToFixed(chance, 2).toFixed(2) + '%');
										}
									}, 6000);
									
									if(amount > 0) user_updateBalance(user.userid);
									
									logger.debug('[UPGRADER] Bet registed. ' + user.name + ' did bet $' + getFormatAmountString(myitems_amount + amount));
									
									cooldown(false, false);
								});
							});
						});
					});
				});
			});
		});
	});
}

function upgraderGame_getChance(user, socket, myitems, siteitems, amount, cooldown){
	cooldown(true, true);
	
	if(isNaN(Number(amount))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid amount!'
		});
		
		return cooldown(false, true);
	}
	
	amount = getFormatAmount(amount);
	
	if(myitems.length <= 0 || siteitems.length <= 0){
		socket.emit('message', {
			type: 'upgrader',
			command: 'chance',
			chance: 0
		});
		
		return cooldown(false, false);
	}
	
	var myitemsin_query = myitems.map(a => '"' + a + '"').join(',') || 'null';
	
	pool.query('SELECT users_items.itemid, items_list.price FROM `users_items` INNER JOIN `items_list` ON users_items.itemid = items_list.itemid WHERE users_items.id IN (' + myitemsin_query + ') AND users_items.status = 0 AND users_items.userid = ' + pool.escape(user.userid), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length != myitems.length){
			socket.emit('message', {
				type: 'upgrader',
				command: 'chance',
				chance: 0
			});
			
			return cooldown(false, false);
		}
		
		var myitems_amount = row1.reduce(function(acc, val) { return getFormatAmount(acc + itemsSystem_items[val.itemid].price) }, 0);
		
		var siteitemsin_query = siteitems.map(a => '"' + a + '"').join(',') || 'null';
		
		pool.query('SELECT `itemid` FROM `items_list` WHERE `itemid` IN (' + siteitemsin_query + ')', function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			if(row2.length != siteitems.length){
				socket.emit('message', {
					type: 'upgrader',
					command: 'chance',
					chance: 0
				});
				
				return cooldown(false, false);
			}
			
			var siteitems_amount = row2.reduce(function(acc, val) { return getFormatAmount(acc + itemsSystem_items[val.itemid].price) }, 0);
			
			var chance = getFormatAmount(myitems_amount + amount) / siteitems_amount * 100;
			
			if(chance > 80){
				socket.emit('message', {
					type: 'error',
					error: 'Error: Upgrade above 80% is not possible'
				});
			}
			
			if(chance < 1){
				socket.emit('message', {
					type: 'error',
					error: 'Error: Upgrade below 1% is not possible'
				});
			}
			
			socket.emit('message', {
				type: 'upgrader',
				command: 'chance',
				chance: chance
			});
			
			cooldown(false, false);
		});
	});
}

function upgraderGame_myItems(user, socket, page, order, cooldown){
	cooldown(true, true);
	
	var order_allowed = [ 0, 1, 2, 3, 4 ];
	if(!order_allowed.includes(order)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid order!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(page))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid page!'
		});
		
		return cooldown(false, true);
	}
	
	page = parseInt(page);
	
	pool.query('SELECT users_items.itemid FROM `users_items` INNER JOIN `items_list` ON users_items.itemid = items_list.itemid WHERE users_items.status = 0 AND users_items.userid = ' + pool.escape(user.userid), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		var pages = parseInt(row1.length / 100) + (row1.length % 100 > 0 ? 1 : 0);
		
		if(pages <= 0){
			socket.emit('message', {
				type: 'pagination',
				command: 'upgrader_myitems',
				list: [],
				pages: 1,
				page: 1
			});
			
			return cooldown(false, false);
		}
		
		if(page <= 0 || page > pages) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid page!'
			});
			
			return cooldown(false, true);
		}
		
		var order_query = { 
			0: 'ORDER BY users_items.time DESC',
			1: 'ORDER BY items_list.name ASC',
			2: 'ORDER BY items_list.name DESC',
			3: 'ORDER BY items_list.price ASC',
			4: 'ORDER BY items_list.price DESC'
		}[order];
		
		pool.query('SELECT users_items.id, users_items.itemid, items_list.price FROM `users_items` INNER JOIN `items_list` ON users_items.itemid = items_list.itemid WHERE users_items.status = 0 AND `userid` = ' + pool.escape(user.userid) + ' ' + order_query + ' LIMIT 100 OFFSET ' + pool.escape(page * 100 - 100), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			var list = [];
			
			row2.forEach(function(item){
				list.push({
					id: item.id,
					name: itemsSystem_items[item.itemid].name,
					image: itemsSystem_items[item.itemid].image,
					price: getFormatAmount(itemsSystem_items[item.itemid].price),
					color: getColorByQuality(itemsSystem_items[item.itemid].quality)
				});
			});
			
			socket.emit('message', {
				type: 'pagination',
				command: 'upgrader_myitems',
				list: list,
				pages: pages,
				page: page
			});
			
			cooldown(false, false);
		});
	});
}

function upgraderGame_siteItems(user, socket, page, order, search, items, amount, multiplier, cooldown){
	cooldown(true, true);

	if(isNaN(Number(amount))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid amount!'
		});
		
		return cooldown(false, true);
	}
	
	amount = getFormatAmount(amount);
	
	var multiplier_allowed = [ 0, 1, 2, 3 ];
	if(!multiplier_allowed.includes(multiplier)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid multiplier!'
		});
		
		return cooldown(false, true);
	}
	
	var order_allowed = [ 0, 1, 2, 3 ];
	if(!order_allowed.includes(order)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid order!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(page))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid page!'
		});
		
		return cooldown(false, true);
	}
	
	page = parseInt(page);
	search = search.trim();
	
	if(items.length <= 0){
		socket.emit('message', {
			type: 'pagination',
			command: 'upgrader_siteitems',
			list: [],
			pages: 1,
			page: 1
		});
		
		return cooldown(false, false);
	}
	
	var itemsin_query = items.map(a => '"' + a + '"').join(',') || 'null';
	
	pool.query('SELECT users_items.itemid, items_list.price FROM `users_items` INNER JOIN `items_list` ON users_items.itemid = items_list.itemid WHERE users_items.id IN (' + itemsin_query + ') AND users_items.status = 0 AND users_items.userid = ' + pool.escape(user.userid), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0){
			socket.emit('message', {
				type: 'pagination',
				command: 'upgrader_siteitems',
				list: [],
				pages: 1,
				page: 1
			});
			
			return cooldown(false, false);
		}
		
		var items_amount = row1.reduce(function(acc, val) { return getFormatAmount(acc + itemsSystem_items[val.itemid].price) }, 0);
		
		var total_amount = getFormatAmount(items_amount + amount);
		var multiplier_amount = getFormatAmount(total_amount * [1.50, 2.00, 5.00, 10.00][multiplier]);
		
		var items_prices = Object.values(itemsSystem_items).filter(a => a.price >= multiplier_amount).map(a => a.id);
		var items_query = items_prices.map(a => '"' + a + '"').join(',') || 'null';
		
		pool.query('SELECT COUNT(*) AS `count` FROM `items_list` WHERE `name` LIKE ' + pool.escape('%' + search + '%') + ' AND `itemid` IN (' + items_query + ')', function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			var pages = parseInt(row2[0].count / 100) + (row2[0].count % 100 > 0 ? 1 : 0);
			
			if(pages <= 0){
				socket.emit('message', {
					type: 'pagination',
					command: 'upgrader_siteitems',
					list: [],
					pages: 1,
					page: 1
				});
				
				return cooldown(false, false);
			}
			
			if(page <= 0 || page > pages) {
				socket.emit('message', {
					type: 'error',
					error: 'Error: Invalid page!'
				});
				
				return cooldown(false, true);
			}
			
			var order_query = { 
				0: 'ORDER BY `name` ASC',
				1: 'ORDER BY `name` DESC',
				2: 'ORDER BY `price` ASC',
				3: 'ORDER BY `price` DESC'
			}[order];
			
			pool.query('SELECT `itemid` FROM `items_list` WHERE `name` LIKE ' + pool.escape('%' + search + '%') + ' AND `itemid` IN (' + items_query + ') ' + order_query + ' LIMIT 100 OFFSET ' + pool.escape(page * 100 - 100), function(err3, row3){
				if(err3){
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				var list = [];
				
				row3.forEach(function(item){
					list.push({
						id: item.itemid,
						name: itemsSystem_items[item.itemid].name,
						image: itemsSystem_items[item.itemid].image,
						price: getFormatAmount(itemsSystem_items[item.itemid].price),
						color: getColorByQuality(itemsSystem_items[item.itemid].quality)
					});
				});
				
				socket.emit('message', {
					type: 'pagination',
					command: 'upgrader_siteitems',
					list: list,
					pages: pages,
					page: page
				});
				
				cooldown(false, false);
			});
		});
	});
}