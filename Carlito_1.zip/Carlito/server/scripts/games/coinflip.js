/* COINFLIP */

var coinflipGame_games = {};

var coinflipGame_secure = {};

coinflipGame_loadHistory();
function coinflipGame_loadHistory(){
	logger.debug('[COINFLIP] Loading History');
	
	pool.query('SELECT * FROM `coinflip_games` WHERE `ended` = 0 AND `canceled` = 0', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		if(row1.length == 0) return;
		
		row1.reverse();
		
		row1.forEach(function(coinflip){
			var amount = getFormatAmount(coinflip.amount);
			
			coinflipGame_games[coinflip.id] = {
				id: coinflip.id,
				status: 0,
				players: [],
				amount: amount,
				game: {
					server_seed: coinflip.server_seed,
					public_seed: null,
					block: null,
					roll: null
				},
				time: null,
				timeout: null,
			}
			
			/*coinflipGame_games[coinflip.id] = {
				status: 0,
				player1: {},
				player2: {},
				creator: parseInt(coinflip.creator),
				amount: amount,
				game: {
					server_seed: coinflip.server_seed,
					public_seed: null,
					block: null,
					roll: null
				},
				time: null,
				timeout: null,
			}*/
			
			coinflipGame_secure[coinflip.id] = {};
			
			pool.query('SELECT * FROM `coinflip_bets` WHERE `gameid` = ' + pool.escape(coinflip.id), function(err2, row2) {
				if(err2) {
					logger.error(err2);
					writeError(err2);
					return;
				}
				
				if(row2.length > 1) {
					coinflipGame_games[coinflip.id].status = 1;
					coinflipGame_games[coinflip.id].time = time();
				}
				
				row2.forEach(function(bet){
					coinflipGame_games[coinflip.id]['players'].push({
						user: {
							userid: bet.userid,
							name: bet.name,
							avatar: bet.avatar,
							level: calculateLevel(bet.xp).level
						},
						position: parseInt(bet.position),
						creator: parseInt(bet.creator),
						bot:  parseInt(bet.bot)
					});
				});
				
				if(row2.length > 1) {
					coinflipGame_continue(coinflip.id);
				} else {
					if(config.config_games.games.coinflip.cancel){
						var creator = coinflipGame_games[coinflip.id]['player' + coinflipGame_games[coinflip.id]['creator']]['userid'];
						
						if(coinflip.time + config.config_games.games.coinflip.timer_cancel > time()){
							coinflipGame_games[coinflip.id].timeout = setTimeout(function(){
								pool.query('UPDATE `coinflip_games` SET `canceled` = 1 WHERE `id` = ' + pool.escape(coinflip.id), function(err3){
									if(err3) {
										logger.error(err3);
										writeError(err3);
										return;
									}
									
									//REFUND BET
									user_refundBet(creator, amount, 'coinflip', function(err4){
										if(err4) {
											logger.error(err4);
											writeError(err4);
											return;
										}
										
										user_updateBalance(creator);
										
										delete coinflipGame_games[coinflip.id];
									
										logger.debug('[COINFLIP] Bet #' + coinflip.id + ' was canceled');
										
										io.sockets.in('coinflip').emit('message', {
											type: 'coinflip',
											command: 'remove',
											coinflip: {
												id: coinflip.id
											}
										});
									});
								});
							}, (time() - coinflip.time + config.config_games.games.coinflip.timer_cancel) * 1000);
						} else {
							pool.query('UPDATE `coinflip_games` SET `canceled` = 1 WHERE `id` = ' + coinflip.id, function(err3){
								if(err3) {
									logger.error(err3);
									writeError(err3);
									return;
								}
								
								//REFUND BET
								user_refundBet(creator, amount, 'coinflip', function(err4){
									if(err4) {
										logger.error(err4);
										writeError(err4);
										return;
									}
									
									user_updateBalance(creator);
									
									delete coinflipGame_games[coinflip.id];
								
									logger.debug('[COINFLIP] Bet #' + coinflip.id + ' was canceled');
									
									io.sockets.in('coinflip').emit('message', {
										type: 'coinflip',
										command: 'remove',
										coinflip: {
											id: coinflip.id
										}
									});
								});
							});
						}
					}
				}
			});
		});
	});
}

function coinflipGame_create(user, socket, amount, position, cooldown) {
	cooldown(true, true);
	
	/* CHECK DATA GAME */
	
	if(isNaN(Number(position))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid position!'
		});
		
		return cooldown(false, true);
	}
	
	position = parseInt(position);
	
	var allowed_coins = [0, 1];
	if(!allowed_coins.includes(position)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid position!'
		});
		
		return cooldown(false, true);
	}
	
	/* END CHECK DATA GAME */
	
	//VERIFY FORMAT AMOUNT
	site_verifyFormatAmount(amount, function(err1, amount){
		if(err1) {
			socket.emit('message', {
				type: 'error',
				error: err1.message
			});
			
			return cooldown(false, true);
		}
			
		//REGISTER BET
		user_registerBet(user.userid, amount, [], 'coinflip', true, function(err2){
			if(err2) {
				socket.emit('message', {
					type: 'error',
					error: err2.message
				});
				
				return cooldown(false, true);
			}
			
			var server_seed = fair_generateServerSeed();
			
			pool.query('INSERT INTO `coinflip_games` SET `amount` = ' + amount + ', `server_seed` = ' + pool.escape(server_seed) + ', `time` = ' + pool.escape(time()), function(err3, row3){
				if(err3) {
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				pool.query('INSERT INTO `coinflip_bets` SET `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + parseInt(user.xp) + ', `bot` = ' + parseInt(user.bot) + ', `gameid` = ' + pool.escape(row3.insertId) + ', `position` = ' + position + ', `creator` = 1, `time` = ' + pool.escape(time()), function(err4){
					if(err4) {
						logger.error(err4);
						writeError(err4);
						
						return cooldown(false, true);
					}
				
					coinflipGame_games[row3.insertId] = {
						id: row3.insertId,
						status: 0,
						players: [],
						amount: amount,
						game: {
							server_seed: server_seed,
							public_seed: null,
							block: null,
							roll: null
						},
						time: null,
						timeout: null
					}
					
					coinflipGame_secure[row3.insertId] = {};
					
					coinflipGame_games[row3.insertId]['players'].push({
						user: {
							userid: user.userid,
							name: user.name,
							avatar: user.avatar,
							level: calculateLevel(user.xp).level
						},
						position: position,
						creator: 1,
						bot: user.bot
					});
					
					socket.emit('message', {
						type: 'coinflip',
						command: 'bet_confirmed'
					});
					
					io.sockets.in('coinflip').emit('message', {
						type: 'coinflip',
						command: 'add',
						coinflip: {
							id: row3.insertId,
							players: coinflipGame_games[row3.insertId]['players'],
							amount: amount,
							data: {
								game: {
									server_seed_hashed: sha256(coinflipGame_games[row3.insertId].game.server_seed),
									nonce: row3.insertId
								}
							}
						}
					});
					
					if(config.config_games.games.coinflip.cancel){
						coinflipGame_games[row3.insertId].timeout = setTimeout(function(){
							pool.query('UPDATE `coinflip_games` SET `canceled` = 1 WHERE `id` = ' + pool.escape(row3.insertId), function(err5){
								if(err5) {
									logger.error(err5);
									writeError(err5);
									return;
								}
								
								//REFUND BET
								user_refundBet(user.userid, coinflipGame_games[row3.insertId].amount, 'coinflip', function(err6){
									if(err6) {
										logger.error(err6);
										writeError(err6);
										return;
									}
									
									user_updateBalance(user.userid);
									
									delete coinflipGame_games[row3.insertId];
								
									logger.debug('[COINFLIP] Bet #' + row3.insertId + ' was canceled');
									
									io.sockets.in('coinflip').emit('message', {
										type: 'coinflip',
										command: 'remove',
										coinflip: {
											id: row3.insertId
										}
									});
								});
							});
						}, config.config_games.games.coinflip.timer_cancel * 1000);
					}
					
					user_updateBalance(user.userid);
					
					logger.debug('[COINFLIP] Bet registed. ' + user.name + ' did bet $' + getFormatAmountString(amount));
					
					cooldown(false, false);
				});
			});
		});
	});
}

function coinflipGame_join(user, socket, id, cooldown) {
	cooldown(true, true);
	
	/* CHECK DATA GAME */
	
	if(isNaN(Number(id))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid game. Please join in a valid game!'
		});
		
		return cooldown(false, true);
	}
	
	id = parseInt(id);
	
	/* END CHECK DATA GAME */
	
	if(coinflipGame_games[id] === undefined) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid game. Please join in a valid game!'
		});
		
		return cooldown(false, true);
	}
	
	if(coinflipGame_games[id]['status'] != 0) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: This game are already ended!'
		});
		
		return cooldown(false, true);
	}
	
	if(coinflipGame_games[id].players.filter(a => a.user.userid == user.userid).length > 0) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: You cannot join your game!'
		});
		
		return cooldown(false, true);
	}
	
	if(Object.keys(coinflipGame_secure[id]).length > 0){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Another user are trying to join in this game. Please try again later!'
		});
		
		return cooldown(false, true);
	}
	
	coinflipGame_secure[id][user.userid] = true;
	
	coinflipGame_joinConfirm(user, id, function(err1){
		if(err1){
			socket.emit('message', {
				type: 'error',
				error: err1.message
			});
			
			return cooldown(false, true);
		}
		
		socket.emit('message', {
			type: 'coinflip',
			command: 'bet_confirmed',
		});
		
		user_updateBalance(user.userid);
		
		cooldown(false, false);
	})
}

function coinflipGame_joinConfirm(user, id, callback){
	var amount = getFormatAmount(coinflipGame_games[id]['amount']);
	var position = [ 1, 0 ][coinflipGame_games[id].players[0].position];
	
	//REGISTER BET
	user_registerBet(user.userid, amount, [], 'coinflip', false, function(err1){
		if(err1) return callback(err1);
		
		var playerToJoin = parseInt([2, 1][coinflipGame_games[id]['creator'] - 1]);
		
		pool.query('INSERT INTO `coinflip_bets` SET `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + parseInt(user.xp) + ', `bot` = ' + parseInt(user.bot) + ', `gameid` = ' + pool.escape(coinflipGame_games[id].id) + ', `position` = ' + position + ', `creator` = 0, `time` = ' + pool.escape(time()), function(err2){
			if(err2) {
				logger.error(err2);
				writeError(err2);
				
				return callback(new Error('Error: Error (1)'));
			}
			
			if(coinflipGame_games[id].timeout != null) clearTimeout(coinflipGame_games[id].timeout);
			
			coinflipGame_games[id].time = time();
			coinflipGame_games[id].status = 1;
			
			coinflipGame_games[id]['players'].push({
				user: {
					userid: user.userid,
					name: user.name,
					avatar: user.avatar,
					level: calculateLevel(user.xp).level
				},
				position: position,
				bot: user.bot,
				creator: 0
			});
			
			io.sockets.in('coinflip').emit('message', {
				type: 'coinflip',
				command: 'edit',
				status: coinflipGame_games[id].status,
				coinflip: {
					id: id,
					players: coinflipGame_games[id]['players'],
					amount: coinflipGame_games[id]['amount'],
					data: {
						game: {
							server_seed_hashed: sha256(coinflipGame_games[id].game.server_seed),
							nonce: id
						},
						time: config.config_games.games.coinflip.timer_wait_start - time() + coinflipGame_games[id].time
					}
				}
			});
			
			if(coinflipGame_games[id].status == 1) coinflipGame_continue(id);
			
			logger.debug('[COINFLIP] Join registed. ' + user.name + ' did bet $' + getFormatAmountString(amount));
			
			callback(null);
		});
	});
}

function coinflipGame_continue(id){
	delete coinflipGame_secure[id];
	
	setTimeout(function(){
		fair_generateEosSeed(function(data){
			coinflipGame_games[id].status = 2;
			
			coinflipGame_games[id].game.block = data.block;
			
			io.sockets.in('coinflip').emit('message', {
				type: 'coinflip',
				command: 'edit',
				status: coinflipGame_games[id].status,
				coinflip: {
					id: id,
					players: coinflipGame_games[id]['players'],
					amount: coinflipGame_games[id]['amount'],
					data: {
						game: {
							server_seed_hashed: sha256(coinflipGame_games[id].game.server_seed),
							block: coinflipGame_games[id].game.block,
							nonce: id
						}
					}
				}
			});
		}, function(data){
			pool.query('UPDATE `coinflip_rolls` SET `removed` = 1 WHERE `gameid` = ' + pool.escape(id), function(err1) {
				if(err1) {
					logger.error(err1);
					writeError(err1);
					return;
				}
				
				var seed = fair_getCombinedSeed(coinflipGame_games[id].game.server_seed, data.hash, id);
				var salt = fair_generateSaltHash(seed);
				
				var roll = fair_getRoll(salt, Math.pow(10, 8)) / Math.pow(10, 8);
				
				pool.query('INSERT INTO `coinflip_rolls` SET `gameid` = ' + pool.escape(id) + ', `blockid` = ' + pool.escape(data.block) + ', `public_seed` = ' + pool.escape(data.hash) + ', `roll` = ' + roll + ', `time` = ' + pool.escape(time()), function(err2) {
					if(err2) {
						logger.error(err2);
						writeError(err2);
						return;
					}
		
					coinflipGame_games[id].status = 3;
					
					coinflipGame_games[id].game.public_seed = data.hash;
					coinflipGame_games[id].game.block = data.block;
					coinflipGame_games[id].game.roll = roll;
					
					io.sockets.in('coinflip').emit('message', {
						type: 'coinflip',
						command: 'edit',
						status: coinflipGame_games[id].status,
						coinflip: {
							id: id,
							players: coinflipGame_games[id]['players'],
							amount: coinflipGame_games[id]['amount'],
							data: {
								game: {
									server_seed_hashed: sha256(coinflipGame_games[id].game.server_seed),
									block: coinflipGame_games[id].game.block,
									nonce: id
								},
								winner: coinflipGame_getWinner(id)
							}
						}
					});
					
					setTimeout(function(){
						var winner = coinflipGame_games[id]['players'].slice().filter(a => a.position == coinflipGame_getWinner(id))[0];
						var opponent = coinflipGame_games[id]['players'].slice().filter(a => a.position != winner.position)[0];
						
						pool.query('UPDATE `coinflip_games` SET `ended` = 1 WHERE `id` = ' + pool.escape(id), function(err3){
							if(err3) {
								logger.error(err3);
								writeError(err3);
								return;
							}
							
							var amount = getFormatAmount(coinflipGame_games[id]['amount']);
							var winning = getFormatAmount(amount * 2);
							
							pool.query('INSERT INTO `coinflip_winnings` SET `gameid` = ' + pool.escape(coinflipGame_games[id].id) + ', `position` = ' + pool.escape(winner.position) + ', `time` = ' + pool.escape(time()), function(err4){
								if(err4) {
									logger.error(err4);
									writeError(err4);
									return;
								}
								
								//FINISH BET
								user_finishBet(winner.user.userid, amount, winning, winning, [], 'coinflip', function(err5){
									if(err5) {
										logger.error(err5);
										writeError(err5);
										return;
									}
									
									//FINISH BET
									user_finishBet(opponent.user.userid, amount, 0, 0, [], 'coinflip', function(err6){
										if(err6) {
											logger.error(err6);
											writeError(err6);
											return;
										}
								
										coinflipGame_games[id].status = 4;
									
										io.sockets.in('coinflip').emit('message', {
											type: 'coinflip',
											command: 'edit',
											status: coinflipGame_games[id].status,
											coinflip: {
												id: id,
												players: coinflipGame_games[id]['players'],
												amount: coinflipGame_games[id]['amount'],
												data: {
													game: {
														server_seed_hashed: sha256(coinflipGame_games[id].game.server_seed),
														server_seed: coinflipGame_games[id].game.server_seed,
														public_seed: coinflipGame_games[id].game.public_seed,
														block: coinflipGame_games[id].game.block,
														nonce: id
													},
													winner: coinflipGame_getWinner(id)
												}
											}
										});
										
										if(winning >= config.config_games.winning_to_chat){
											var send_message = winner.user.name + ' won ' + getFormatAmountString(winning) + ' to coinflip!';
											otherMessages(send_message, io.sockets, true);
										}
										
										io.sockets.in(winner.user.userid).emit('message', {
											type: 'success',
											success: 'The game of ' + getFormatAmountString(winning) + ' on coinflip ended as win!'
										});
										
										io.sockets.in(opponent.user.userid).emit('message', {
											type: 'error',
											error: 'The game of ' + getFormatAmountString(winning) + ' on coinflip ended as lose!'
										});
										
										setTimeout(function(){
											delete coinflipGame_games[id];
											
											io.sockets.in('coinflip').emit('message', {
												type: 'coinflip',
												command: 'remove',
												coinflip: {
													id: id
												}
											});
										}, config.config_games.games.coinflip.timer_delete * 1000);
										
										user_updateLevel(winner.user.userid);
										user_updateLevel(opponent.user.userid);
										
										user_updateBalance(winner.user.userid);
										
										logger.debug('[COINFLIP] Win registed. ' + winner.user.name + ' did win $' + getFormatAmountString(winning));
									});
								});
							});
						});
					}, 4000);
				});
			});
		});
	}, config.config_games.games.coinflip.timer_wait_start * 1000 + 1000);
}

function coinflipGame_getWinner(id){
	var separator = 0.5;
	
	return coinflipGame_games[id]['game']['roll'] < separator ? 0 : 1;
}

/* END COINFLIP */