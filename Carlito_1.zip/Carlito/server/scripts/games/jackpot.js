/* JACKPOT */

var jackpotGame_lastGames = [];

jackpotGame_loadHistory();
function jackpotGame_loadHistory(){
	logger.debug('[JACKPOT] Loading History');
	
	pool.query('SELECT jackpot_games.id, jackpot_games.server_seed, jackpot_rolls.public_seed, jackpot_rolls.blockid, jackpot_rolls.betid, jackpot_rolls.chance, jackpot_rolls.amount FROM `jackpot_games` INNER JOIN `jackpot_rolls` ON jackpot_games.id = jackpot_rolls.gameid WHERE jackpot_games.ended = 1 AND jackpot_rolls.removed = 0 ORDER BY jackpot_rolls.id DESC LIMIT 5', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		if(row1.length == 0) return;
		
		row1.reverse();
		
		row1.forEach(function(history){
			pool.query('SELECT * FROM `jackpot_bets` WHERE `gameid` = ' + parseInt(history.id), function(err2, row2){
				if(err2) {
					logger.error(err2);
					writeError(err2);
					return;
				}
				
				var bets = [];
				
				row2.forEach(function(item){
					bets.push({
						id: item.id,
						user: {
							userid: item.userid,
							name: item.name,
							avatar: item.avatar,
							level: calculateLevel(item.xp).level
						},
						amount: getFormatAmount(item.amount),
						color: item.color,
						tickets: {
							min: parseInt(item.ticket_min),
							max: parseInt(item.ticket_max)
						}
					});
				});
				
				jackpotGame_lastGames.push({
					id: history.id,
					bets: bets,
					winner: bets.findIndex(a => a.id == history.betid),
					chance: roundedToFixed(history.chance, 2),
					amount: getFormatAmount(history.amount),
					game: {
						server_seed_hashed: sha256(history.server_seed),
						server_seed: history.server_seed,
						public_seed: history.public_seed,
						block: history.blockid,
						nonce: history.id
					}
				});
			});
		});
	});
};

var jackpotGame_settings = {
	last_ticket: 0,
	start_time: 0,
	avatars_rolling: []
}

var jackpotGame_totalBets = [];
var jackpotGame_usersBets = {};

var jackpotGame_totalAmounts = 0;

var jackpotGame = {
	status: 'wait',
	id: null,
	server_seed: null,
	public_seed: null,
	block: null,
	roll: null
}

var jackpotGame_colors = [];
var jackpotGame_avatars = [];

function jackpotGame_getColor(userid) {
	if(jackpotGame_usersBets[userid] !== undefined) return jackpotGame_usersBets[userid].color;
	
	var filter = config.config_games.games.jackpot.colors.filter(a => !jackpotGame_colors.includes(a));
	var index = getRandomInt(0, filter.length - 1);
	var color = filter[index];
	
	return color;
}

jackpotGame_checkGames();

function jackpotGame_checkGames(){
	pool.query('SELECT * FROM `jackpot_games` WHERE `ended` = 0 ORDER BY `id` DESC LIMIT 1', function(err1, row1){
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		if(row1.length > 0){
			jackpotGame = {
				status: 'wait',
				id: row1[0].id,
				server_seed: row1[0].server_seed,
				public_seed: null,
				block: null,
				roll: null
			}
			
			io.sockets.in('jackpot').emit('message', {
				type: 'jackpot',
				command: 'fair',
				fair: {
					server_seed_hashed: sha256(jackpotGame.server_seed),
					nonce: jackpotGame.id
				}
			});
			
			pool.query('SELECT * FROM `jackpot_bets` WHERE `gameid` = ' + parseInt(jackpotGame.id), function(err2, row2){
				if(err2) {
					logger.error(err2);
					writeError(err2);
					return;
				}
				
				row2.forEach(function(bet){
					var amount = getFormatAmount(bet.amount);
					
					var user_color = bet.color;
					
					if(!jackpotGame_colors.includes(user_color)) jackpotGame_colors.push(user_color);
					
					var min_ticket = parseInt(jackpotGame_settings.last_ticket + 1);
					var max_ticket = parseInt(parseInt(amount * 100) + jackpotGame_settings.last_ticket);
					
					if(jackpotGame_usersBets[bet.userid] === undefined){
						jackpotGame_usersBets[bet.userid] = {
							total: 1,
							amount: amount,
							color: user_color
						};
					}else{
						jackpotGame_usersBets[bet.userid].total++;
						jackpotGame_usersBets[bet.userid].amount += amount;
					}
					
					jackpotGame_totalAmounts += amount;
					
					jackpotGame_totalBets.push({
						id: bet.id,
						user: {
							userid: bet.userid,
							name: bet.name,
							avatar: bet.avatar,
							level: calculateLevel(bet.xp).level
						},
						amount: amount,
						color: user_color,
						tickets: {
							min: min_ticket,
							max: max_ticket
						}
					});
					
					if(jackpotGame_totalBets.length > 0){
						jackpotGame_totalBets.forEach(function(item){
							var chance = roundedToFixed(parseFloat(jackpotGame_usersBets[item.user.userid].amount / jackpotGame_totalAmounts * 100), 2);
							
							io.sockets.in(item.user.userid).emit('message', {
								type: 'jackpot',
								command: 'chance',
								chance: chance
							});
						});
					}
					
					jackpotGame_settings.last_ticket += parseInt(amount * 100);
					jackpotGame_checkRound();
					
					jackpotGame_avatars = jackpotGame_generateAvatars(25);
					
					logger.debug('[JACKPOT] Bet registed. ' + bet.name + ' did bet $' + getFormatAmountString(amount));
				});
			});
		} else jackpotGame_generateGame();
	});
}

function jackpotGame_generateGame(){
	var server_seed = fair_generateServerSeed();

	pool.query('INSERT INTO `jackpot_games` SET `server_seed` = ' + pool.escape(server_seed) + ', `time` = ' + pool.escape(time()), function(err1, row1){
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		jackpotGame.id = row1.insertId;
		jackpotGame.server_seed = server_seed;
		
		jackpotGame.status = 'wait';
		
		io.sockets.in('jackpot').emit('message', {
			type: 'jackpot',
			command: 'fair',
			fair: {
				server_seed_hashed: sha256(jackpotGame.server_seed),
				nonce: jackpotGame.id
			}
		});
	});
}

function jackpotGame_bet(user, socket, amount, cooldown){
	cooldown(true, true);
	
	if(jackpotGame.status != 'started' && jackpotGame.status != 'wait') {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Wait for preparing a new round!'
		});
		
		return cooldown(false, true);
	}
	
	if(jackpotGame_usersBets[user.userid] !== undefined && jackpotGame_usersBets[user.userid].total >= config.config_games.games.jackpot.total_bets) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: You have entered too many times in jackpot'
		});
		
		return cooldown(false, true);
	}
	
	//VERIFY FORMAT AMOUNT
	site_verifyFormatAmount(amount, function(err1, amount){
		if(err1) {
			socket.emit('message', {
				type: 'error',
				error: err1.message
			});
			
			return cooldown(false, true);
		}
			
		//REGISTER BET
		user_registerBet(user.userid, amount, [], 'jackpot', true, function(err2){
			if(err2) {
				socket.emit('message', {
					type: 'error',
					error: err2.message
				});
				
				return cooldown(false, true);
			}
			
			var user_color = jackpotGame_getColor(user.userid);
			
			if(!jackpotGame_colors.includes(user_color)) jackpotGame_colors.push(user_color);
		
			var min_ticket = parseInt(jackpotGame_settings.last_ticket + 1);
			var max_ticket = parseInt(parseInt(amount * 100) + jackpotGame_settings.last_ticket);
			
			pool.query('INSERT INTO `jackpot_bets` SET `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + parseInt(user.xp) + ', `amount` = ' + amount + ', `color` = ' + pool.escape(user_color) + ', `ticket_min` = ' + pool.escape(min_ticket) + ', `ticket_max` = ' + pool.escape(max_ticket) + ', `gameid` = ' + parseInt(jackpotGame.id) + ', `time` = ' + pool.escape(time()), function(err3, row3) {
				if(err3) {
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				if(jackpotGame_usersBets[user.userid] === undefined){
					jackpotGame_usersBets[user.userid] = {
						total: 1,
						amount: amount,
						color: user_color
					};
				} else {
					jackpotGame_usersBets[user.userid].total++;
					jackpotGame_usersBets[user.userid].amount += amount;
				}
				
				jackpotGame_totalAmounts += amount;
				
				jackpotGame_totalBets.push({
					id: row3.insertId,
					user: {
						userid: user.userid,
						name: user.name,
						avatar: user.avatar,
						level: calculateLevel(user.xp).level
					},
					amount: amount,
					color: user_color,
					tickets: {
						min: min_ticket,
						max: max_ticket
					}
				});
				
				if(jackpotGame_totalBets.length > 0){
					jackpotGame_totalBets.forEach(function(item){
						var chance = roundedToFixed(parseFloat(jackpotGame_usersBets[item.user.userid].amount / jackpotGame_totalAmounts * 100), 2);
						
						io.sockets.in(item.user.userid).emit('message', {
							type: 'jackpot',
							command: 'chance',
							chance: chance
						});
					});
				}
				
				socket.emit('message', {
					type: 'jackpot',
					command: 'bet_confirmed',
				});
				
				io.sockets.in('jackpot').emit('message', {
					type: 'jackpot',
					command: 'bet',
					bet: {
						id: row3.insertId,
						user: {
							user: user.userid,
							name: user.name,
							avatar: user.avatar,
							level: calculateLevel(user.xp).level
						},
						amount: amount,
						color: user_color,
						tickets: {
							min: min_ticket,
							max: max_ticket
						}
					},
					total: jackpotGame_totalAmounts
				});
				
				jackpotGame_settings.last_ticket += parseInt(amount * 100);
				jackpotGame_checkRound();
				
				jackpotGame_avatars = jackpotGame_generateAvatars(25);
				
				io.sockets.in('jackpot').emit('message', {
					type: 'jackpot',
					command: 'avatars',
					avatars: jackpotGame_avatars
				});
				
				user_updateBalance(user.userid);
				
				logger.debug('[JACKPOT] Bet registed. ' + user.name + ' did bet $' + getFormatAmountString(amount));
				
				cooldown(false, false);
			});
		});
	});
}

function jackpotGame_checkRound(){
	if(jackpotGame_totalBets.length >= config.config_games.games.jackpot.bets_start && Object.keys(jackpotGame_usersBets).length >= config.config_games.games.jackpot.users_start){
		if(jackpotGame.status == 'wait'){	
			jackpotGame.status = 'started';
		
			var timer = config.config_games.games.jackpot.timer;
			
			var timerID = setInterval(function(){
				if(timer >= 0){
					io.sockets.in('jackpot').emit('message', {
						type: 'jackpot',
						command: 'timer',
						time: timer,
						total: config.config_games.games.jackpot.timer
					});
					
					timer--;
				} else {
					clearInterval(timerID);

					jackpotGame_pickingWinner();
				}
			}, 1000);
		}
	}
}

function jackpotGame_pickingWinner(){
	jackpotGame.status = 'picking';
	
	io.sockets.in('jackpot').emit('message', {
		type: 'jackpot',
		command: 'picking'
	});
	
	fair_generateEosSeed(function(data){
		jackpotGame.status = 'eos';
		
		jackpotGame.block = data.block;
		
		io.sockets.in('jackpot').emit('message', {
			type: 'jackpot',
			command: 'fair',
			fair: {
				server_seed_hashed: sha256(jackpotGame.server_seed),
				block: jackpotGame.block,
				nonce: jackpotGame.id
			}
		});
	}, function(data){
		pool.query('UPDATE `jackpot_rolls` SET `removed` = 1 WHERE `gameid` = ' + pool.escape(jackpotGame.id), function(err1) {
			if(err1) {
				logger.error(err1);
				writeError(err1);
				return;
			}
			
			var seed = fair_getCombinedSeed(jackpotGame.server_seed, data.hash, jackpotGame.id);
			var salt = fair_generateSaltHash(seed);
			
			var roll = fair_getRoll(salt, Math.pow(10, 8)) / Math.pow(10, 8);
			
			var winner_bet = null;
			var ticket_winner = Math.floor(roll * jackpotGame_settings.last_ticket) + 1;
			
			for(var bet of jackpotGame_totalBets) {
				if(ticket_winner >= bet.tickets.min && ticket_winner <= bet.tickets.max) {
					winner_bet = bet;
					break;
				}
			}
			
			var chance = roundedToFixed(parseFloat(jackpotGame_usersBets[winner_bet.user.userid].amount / jackpotGame_totalAmounts * 100), 2);
			var winning = getFormatAmount(jackpotGame_totalAmounts);
			
			var losers = [];
			for(var bet of jackpotGame_totalBets) {
				if(bet.user.userid != winner_bet.user.userid) {
					losers.push({
						id: bet.id,
						user: bet.user,
						amount: bet.amount,
						winning: 0
					});
				}
			}
			
			pool.query('INSERT INTO `jackpot_rolls` SET `gameid` = ' + pool.escape(jackpotGame.id) + ', `betid` = ' + pool.escape(winner_bet.id) + ', `chance` = ' + chance + ', `amount` = ' + winning + ', `tickets` = ' + parseInt(jackpotGame_settings.last_ticket) + ', `blockid` = ' + pool.escape(data.block) + ', `public_seed` = ' + pool.escape(data.hash) + ', `roll` = ' + roll + ', `time` = ' + pool.escape(time()), function(err2) {
				if(err2) {
					logger.error(err2);
					writeError(err2);
					return;
				}
			
				jackpotGame.status = 'rolling';
				
				jackpotGame.public_seed = data.hash;
				jackpotGame.block = data.block;
				jackpotGame.roll = roll;
				
				io.sockets.in('jackpot').emit('message', {
					type: 'jackpot',
					command: 'fair',
					fair: {
						server_seed_hashed: sha256(jackpotGame.server_seed),
						server_seed: jackpotGame.server_seed,
						public_seed: jackpotGame.public_seed,
						block: jackpotGame.block,
						nonce: jackpotGame.id
					}
				});
				
				var avatars = jackpotGame_generateAvatars(150);
				avatars[99] = winner_bet.user.avatar;
				
				jackpotGame_settings.avatars_rolling = avatars;
				
				jackpotGame_settings.start_time = new Date().getTime();
				
				io.sockets.in('jackpot').emit('message', {
					type: 'jackpot',
					command: 'roll',
					avatars: jackpotGame_settings.avatars_rolling,
					cooldown: 0
				});
				
				setTimeout(function(){
					pool.query('UPDATE `jackpot_games` SET `ended` = 1 WHERE `id` = ' + parseInt(jackpotGame.id), function(err3) {
						if(err3) {
							logger.error(err3);
							writeError(err3);
							return;
						}
						
						//FINISH BET
						user_finishBet(winner_bet.user.userid, jackpotGame_usersBets[winner_bet.user.userid].amount, winning, winning, [], 'jackpot', function(err4){
							if(err4) {
								logger.error(err4);
								writeError(err4);
								return;
							}
							
							jackpotGame_losers(0, losers, function(err5){
								if(err5) {
									logger.error(err5);
									writeError(err5);
									return;
								}
							
								if(winning >= config.config_games.winning_to_chat){
									var send_message = winner_bet.user.name + ' won ' + getFormatAmountString(winning) + ' to jackpot with chance ' + chance.toFixed(2) + '%!';
									otherMessages(send_message, io.sockets, true);
								}
								
								var history = {
									id: jackpotGame.id,
									bets: jackpotGame_totalBets,
									winner: jackpotGame_totalBets.findIndex(a => a.id == winner_bet.id),
									chance: chance,
									amount: winning,
									game: {
										server_seed_hashed: sha256(jackpotGame.server_seed),
										server_seed: jackpotGame.server_seed,
										public_seed: jackpotGame.public_seed,
										block: jackpotGame.block,
										nonce: jackpotGame.id
									}
								};
								
								jackpotGame_lastGames.push(history);
								while(jackpotGame_lastGames.length > 10) jackpotGame_lastGames.shift();
								
								user_updateLevel(winner_bet.user.userid);
								user_updateBalance(winner_bet.user.userid);
								
								logger.debug('[JACKPOT] Win registed. ' + winner_bet.user.name + ' did win $' + getFormatAmountString(winning) + ' with chance ' + chance.toFixed(2) + '%');
								
								setTimeout(function(){
									jackpotGame_generateGame();
									
									jackpotGame_usersBets = {};
									jackpotGame_totalBets = [];
									
									jackpotGame_totalAmounts = 0;
									
									jackpotGame_colors = [];
									jackpotGame_avatars = [];
									
									jackpotGame_settings.last_ticket = 0;
									
									io.sockets.in('jackpot').emit('message', {
										type: 'jackpot',
										command: 'reset'
									});
									
									io.sockets.in('jackpot').emit('message', {
										type: 'jackpot',
										command: 'history',
										history: history
									});
								}, 5000);
							});
						});
					});
				}, 7000);
			});
		});
	});
}

function jackpotGame_losers(index, losers, callback) {
	if(index >= losers.length) return callback(null);
	
	//FINISH BET
	user_finishBet(losers[index].user.userid, losers[index].amount, losers[index].winning, losers[index].winning, [], 'jackpot', function(err1){
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return callback(new Error('[JACKPOT] Bet #' + losers[index].id + ' unfinished'));
		}
		
		jackpotGame_losers(index + 1, losers, callback);
	});
}

function jackpotGame_generateAvatars(amount){
	var avatars = [];
	
	for(var i = 0; i < amount; i++){
		var ticket = getRandomInt(1, jackpotGame_settings.last_ticket);
		
		for(var bet of jackpotGame_totalBets) {
			if(ticket >= bet.tickets.min && ticket <= bet.tickets.max){
				avatars.push(bet.user.avatar);
				break;
			}
		}
	}
	
	return avatars;
}

/* END JACKPOT */