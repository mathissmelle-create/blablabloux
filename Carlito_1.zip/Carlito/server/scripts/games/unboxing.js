/* CASES */

var casesGame_lastWinnings = [];

var casesGame_cases = {};

var unboxingGame_cooldown = {};

var casesGame_loadedHistory = false;

function unboxingGame_loadHistory(){
	if(casesGame_loadedHistory) return;
	casesGame_loadedHistory = true;
	
	logger.debug('[UNBOXING] Loading History');
	
	pool.query('SELECT * FROM `unboxing_bets` ORDER BY `id` DESC LIMIT 20', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		if(row1.length == 0) return;
		
		row1.reverse();
		
		casesGame_lastWinnings = [];
		
		row1.forEach(function(history){
			if(casesGame_cases[history.caseid] !== undefined){
				if(itemsSystem_items[history.itemid] !== undefined){
					if(casesGame_cases[history.caseid].items.filter(a => a.id == history.itemid).length > 0){
						casesGame_lastWinnings.push({
							user:{
								userid: history.userid,
								name: history.name,
								avatar: history.avatar,
								level: calculateLevel(history.xp).level,
							},
							unboxing: {
								id: history.caseid,
								name: casesGame_cases[history.caseid].name,
								image: casesGame_cases[history.caseid].image,
								price: casesGame_cases[history.caseid].price
							},
							winning: {
								name: itemsSystem_items[history.itemid].name,
								image: itemsSystem_items[history.itemid].image,
								price: getFormatAmount(itemsSystem_items[history.itemid].price),
								chance: roundedToFixed(casesGame_cases[history.caseid].items.filter(a => a.id == history.itemid)[0].chance, 5),
								color: getColorByQuality(itemsSystem_items[history.itemid].quality)
							}
						});
					}
				}
			}
		});
	});
}

function casesGame_getCases(){
	var list_cases = [];
	
	Object.keys(casesGame_cases).forEach(function(id){
		list_cases.push({
			id: id,
			name: casesGame_cases[id].name,
			image: casesGame_cases[id].image,
			price: getFormatAmount(casesGame_cases[id].price)
		});
	});
	
	list_cases.sort(function(a, b){ return a.price - b.price });
	
	return list_cases;
}

function casesGame_getItems(items){
	var newitems = [];
	
	items.forEach(function(item){
		newitems.push({
			id: item.id,
			name: itemsSystem_items[item.id].name,
			image: itemsSystem_items[item.id].image,
			price: getFormatAmount(itemsSystem_items[item.id].price),
			chance: roundedToFixed(item.chance, 5),
			quality: itemsSystem_items[item.id].quality
		});
	});
	
	return newitems;
}

function casesGame_spinner(user, socket, id, amount, cooldown){
	cooldown(true, true);
	
	if(casesGame_cases[id] === undefined) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid case id!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(amount))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid amount cases!'
		});
		
		return cooldown(false, true);
	}
	
	if(amount < config.config_games.games.unboxing.cases_length.min || amount > config.config_games.games.unboxing.cases_length.max){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid amount cases [' + config.config_games.games.unboxing.cases_length.min + '-' + config.config_games.games.unboxing.cases_length.max + ']!'
		});
		
		return cooldown(false, true);
	}
	
	amount = parseInt(amount);
	
	var items = casesGame_getItems(casesGame_cases[id].items);
	var spinner = [];
	
	for(var i = 0; i < amount; i++) spinner.push(casesGame_generateSpinner(items));
	
	socket.emit('message', {
		type: 'unboxing',
		command: 'spinner',
		spinner: spinner
	});
	
	cooldown(false, false);
}
	
function casesGame_show(user, socket, id, cooldown){
	cooldown(true, true);
	
	if(casesGame_cases[id] === undefined) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid case id!'
		});
		
		return cooldown(false, true);
	}
	
	var items = casesGame_getItems(casesGame_cases[id].items);
	
	var tickets = casesGame_generateTickets(items);
	var newitems = [];
	
	items.forEach(function(item, index){
		newitems.push({
			name: item.name,
			image: item.image,
			price: getFormatAmount(item.price),
			chance: roundedToFixed(item.chance, 5),
			color: getColorByQuality(item.quality),
			tickets: tickets[index]
		});
	})
	
	socket.emit('message', {
		type: 'unboxing',
		command: 'show',
		items: newitems,
		unboxing: {
			id: id,
			name: casesGame_cases[id].name,
			price: getFormatAmount(casesGame_cases[id].price)
		}
	});
	
	cooldown(false, false);
}

function casesGame_demo(user, socket, id, amount, cooldown){
	if(unboxingGame_cooldown[user.userid]){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Wait for ending last unboxing game!'
		});
		return;
	}
	
	cooldown(true, true);
	
	if(casesGame_cases[id] === undefined) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid case id!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(amount))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid amount cases!'
		});
		
		return cooldown(false, true);
	}
	
	if(amount < config.config_games.games.unboxing.cases_length.min || amount > config.config_games.games.unboxing.cases_length.max){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid amount cases [' + config.config_games.games.unboxing.cases_length.min + '-' + config.config_games.games.unboxing.cases_length.max + ']!'
		});
		
		return cooldown(false, true);
	}
	
	amount = parseInt(amount);
	
	//SEEDS
	fair_getUserSeeds(user.userid, function(err1, fair){
		if(err1) {
			socket.emit('message', {
				type: 'error',
				error: err1.message
			});
			
			return cooldown(false, true);
		}
		
		casesGame_open_winnings(0, [], function(err2, data){
			if(err2) {
				logger.debug(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'unboxing',
				command: 'roll',
				spinner: data.map(a => a.spinner)
			});
			
			setTimeout(function(){
				socket.emit('message', {
					type: 'unboxing',
					command: 'finish'
				});
			});
			
			cooldown(false, false);
		});
		
		function casesGame_open_winnings(index, data, callback){
			if(index >= amount) return callback(null, data);
			
			var seed = fair_getCombinedSeed(fair.server_seed, fair.client_seed, fair.nonce + index);
			var salt = fair_generateSaltHash(seed);
			
			var items = casesGame_getItems(casesGame_cases[id].items);
			
			var tickets = casesGame_generateTickets(items);
			var total = tickets[tickets.length - 1].max;
			
			var spinner = casesGame_generateSpinner(items);
			
			var roll = fair_getRoll(salt, total) + 1;
			
			var winning_item = null;
			var i = 0;
			
			for(i = 0; i < tickets.length; i++){
				if(roll >= tickets[i].min && roll <= tickets[i].max) {
					winning_item = {
						name: items[i].name,
						image: items[i].image,
						price: getFormatAmount(items[i].price),
						chance: roundedToFixed(items[i].chance, 5),
						color: getColorByQuality(items[i].quality)
					};
					
					break;
				}
			}
			
			spinner[99] = winning_item;
		
			pool.query('UPDATE `users_seeds_server` SET `nonce` = `nonce` + 1 WHERE `userid` = ' + pool.escape(user.userid) + ' AND `id` = ' + pool.escape(fair.server_seedid), function(err1){
				if(err1) return callback(err1);
				
				data.push({
					winning: winning_item,
					spinner: spinner
				});
				
				casesGame_open_winnings(index + 1, data, callback);
			});
		}
	});
}

function casesGame_open(user, socket, id, amount, cooldown){
	if(unboxingGame_cooldown[user.userid]){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Wait for ending last unboxing game!'
		});
		return;
	}
	
	cooldown(true, true);
	
	if(casesGame_cases[id] === undefined) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid case id!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(amount))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid amount cases!'
		});
		
		return cooldown(false, true);
	}
	
	if(amount < config.config_games.games.unboxing.cases_length.min || amount > config.config_games.games.unboxing.cases_length.max){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid amount cases [' + config.config_games.games.unboxing.cases_length.min + '-' + config.config_games.games.unboxing.cases_length.max + ']!'
		});
		
		return cooldown(false, true);
	}
	
	amount = parseInt(amount);
	
	//SEEDS
	fair_getUserSeeds(user.userid, function(err1, fair){
		if(err1) {
			socket.emit('message', {
				type: 'error',
				error: err1.message
			});
			
			return cooldown(false, true);
		}
		
		var amount_bet = getFormatAmount(getFormatAmount(casesGame_cases[id].price) * amount);
		
		//REGISTER BET
		user_registerBet(user.userid, amount_bet, [], 'unboxing', false, function(err2){
			if(err2) {
				socket.emit('message', {
					type: 'error',
					error: err2.message
				});
				
				return cooldown(false, true);
			}
			
			user_updateBalance(user.userid);
		
			casesGame_open_winnings(0, [], function(err3, data){
				if(err3) {
					logger.debug(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				socket.emit('message', {
					type: 'unboxing',
					command: 'roll',
					spinner: data.map(a => a.spinner)
				});
				
				setTimeout(function(){
					socket.emit('message', {
						type: 'unboxing',
						command: 'finish'
					});
					
					data.forEach(function(item){
						var winning = getFormatAmount(item.winning.price);
						
						var history = {
							user:{
								userid: user.userid,
								name: user.name,
								avatar: user.avatar,
								level: calculateLevel(user.xp).level
							},
							unboxing: {
								id: id,
								name: casesGame_cases[id].name,
								image: casesGame_cases[id].image,
								price: getFormatAmount(casesGame_cases[id].price)
							},
							winning: item.winning
						};
						
						casesGame_lastWinnings.push(history);
						if(casesGame_lastWinnings.length > 20) casesGame_lastWinnings.shift();
						
						io.sockets.in('unboxing').emit('message', {
							type: 'unboxing',
							command: 'history',
							history: history
						});
						
						if(winning >= config.config_games.winning_to_chat){
							var send_message = user.name + ' won ' + getFormatAmountString(winning) + ' to unboxing with chance '  + roundedToFixed(item.winning.chance, 2).toFixed(2) + '%!';
							otherMessages(send_message, io.sockets, true);
						}
						
						logger.debug('[UNBOXING] Win registed. ' + user.name + ' did win $' + getFormatAmountString(winning) + ' with chance ' + roundedToFixed(item.winning.chance, 2).toFixed(2) + '%');
					});
					
					user_updateLevel(user.userid);
				
					unboxingGame_cooldown[user.userid] = false;
				}, 5000);
				
				logger.debug('[UNBOXING] Bet registed. ' + user.name + ' did open a case for $' + getFormatAmountString(amount_bet));
				
				cooldown(false, false);
			});
		});
		
		function casesGame_open_winnings(index, data, callback){
			if(index >= amount) return callback(null, data);
			
			var seed = fair_getCombinedSeed(fair.server_seed, fair.client_seed, fair.nonce + index);
			var salt = fair_generateSaltHash(seed);
			
			var items = casesGame_getItems(casesGame_cases[id].items);
			
			var tickets = casesGame_generateTickets(items);
			var total = tickets[tickets.length - 1].max;
			
			var spinner = casesGame_generateSpinner(items);
			
			var roll = fair_getRoll(salt, total) + 1;
			
			var winning_item = null;
			
			for(var i = 0; i < tickets.length; i++){
				if(roll >= tickets[i].min && roll <= tickets[i].max) {
					winning_item = {
						id: items[i].id,
						name: items[i].name,
						image: items[i].image,
						price: getFormatAmount(items[i].price),
						chance: roundedToFixed(items[i].chance, 5),
						color: getColorByQuality(items[i].quality)
					};
					
					break;
				}
			}
			
			spinner[99] = winning_item;
			
			pool.query('INSERT INTO `unboxing_bets` SET `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + parseInt(user.xp) + ', `caseid` = ' + pool.escape(id) + ', `itemid` = ' + pool.escape(winning_item.id) + ', `roll` = ' + roll + ', `tickets` = ' + total + ', `server_seedid` = ' + pool.escape(fair.server_seedid) + ', `client_seedid` = ' + pool.escape(fair.client_seedid) + ', `nonce` = ' + pool.escape(fair.nonce + index) + ', `time` = ' + pool.escape(time()), function(err1) {
				if(err1) return callback(err1);
			
				pool.query('UPDATE `users_seeds_server` SET `nonce` = `nonce` + 1 WHERE `userid` = ' + pool.escape(user.userid) + ' AND `id` = ' + pool.escape(fair.server_seedid), function(err2){
					if(err2) return callback(err2);
					
					var winning = getFormatAmount(winning_item.price);
					
					//FINISH BET
					user_finishBet(user.userid, amount_bet, winning, 0, [ winning_item.id ], 'unboxing', function(err3){
						if(err3) return callback(err3);
						
						data.push({
							winning: winning_item,
							spinner: spinner
						});
						
						casesGame_open_winnings(index + 1, data, callback);
					});
				});
			});
		}
	});
}

function casesGame_generateTickets(items){
	var decimals = 0; 
	items.forEach(function(item){
		if(countDecimals(item.chance) > decimals) decimals = countDecimals(item.chance);
	});

	var tickets = [];
	var total = 0;

	items.forEach(function(item){
		tickets.push({
			min: total + 1,
			max: total + item.chance * Math.pow(10, decimals)
		});
		
		total += item.chance * Math.pow(10, decimals);
	});
	
	return tickets;
}

function casesGame_generateSpinner(items){
	var tickets = casesGame_generateTickets(items);
	var total = tickets[tickets.length - 1].max;
	
	var spinner = [];
	
	for(var i = 0; i < 150; i++){
		var ticket = getRandomInt(1, total);
		
		for(var j = 0; j < tickets.length; j++){
			if(ticket >= tickets[j].min && ticket <= tickets[j].max) {
				spinner.push({
					name: items[j].name,
					image: items[j].image,
					price: getFormatAmount(items[j].price),
					chance: roundedToFixed(items[j].chance, 5),
					color: getColorByQuality(items[j].quality)
				});
			}
		}
	}
	
	return spinner;
}

/* END CASES */