/* PLINKO */

var plinkoGame_lastGames = [];

var plinkoGame_cooldown = {};

plinkoGame_loadHistory();
function plinkoGame_loadHistory(){
	logger.debug('[PLINKO] Loading History');
	
	pool.query('SELECT * FROM `plinko_bets` ORDER BY `id` DESC LIMIT 10', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		if(row1.length == 0) return;
		
		row1.reverse();
		
		row1.forEach(function(item){
			plinkoGame_lastGames.push({
				id: item.id,
				user: {
					userid: item.userid,
					name: item.name,
					avatar: item.avatar,
					level: calculateLevel(item.xp).level,
				},
				amount: getFormatAmount(item.amount),
				game: item.game,
				roll: item.roll,
				multiplier: roundedToFixed(item.multiplier, 2)
			});
		});
	});
}

function plinkoGame_bet(user, socket, amount, game, cooldown){
	if(plinkoGame_cooldown[user.userid]){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Wait for ending last plinko game!'
		});
		return;
	}
	
	cooldown(true, true);
	
	/* CHECK DATA GAME */
	
	var allowed_games = ['low', 'medium', 'high'];
	if(!allowed_games.includes(game)) {
		socket.emit('message', {
			type: 'error',
			error: 'Invalid game type!'
		});
		
		return cooldown(false, true);
	}
	
	/* END CHECK DATA GAME */
	
	//VERIFY FORMAT AMOUNT
	site_verifyFormatAmount(amount, function(err1, amount){
		if(err1) {
			socket.emit('message', {
				type: 'error',
				error: err1.message
			});
			
			return cooldown(false, true);
		}
		
		//SEEDS
		fair_getUserSeeds(user.userid, function(err2, fair){
			if(err2) {
				socket.emit('message', {
					type: 'error',
					error: err2.message
				});
				
				return cooldown(false, true);
			}
			
			//REGISTER BET
			user_registerBet(user.userid, amount, [], 'plinko', true, function(err3){
				if(err3) {
					socket.emit('message', {
						type: 'error',
						error: err3.message
					});
					
					return cooldown(false, true);
				}
				
				var seed = fair_getCombinedSeed(fair.server_seed, fair.client_seed, fair.nonce);
				
				var salt = fair_generateSaltHash(seed);
				var array = fair_getRollPlinko(salt);
				
				var roll = array.join('');
				
				var result = 0;
				array.forEach(function(item){ result += item; });
				
				var multiplier = roundedToFixed(config.config_games.games.plinko.results[game][result], 2);
				var winning = getFormatAmount(multiplier * amount);
				
				pool.query('INSERT INTO `plinko_bets` SET `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + parseInt(user.xp) + ', `amount` = ' + amount + ', `game` = ' + pool.escape(game) + ', `multiplier` = ' + multiplier + ', `roll` = ' + pool.escape(roll) + ', `server_seedid` = ' + pool.escape(fair.server_seedid) + ', `client_seedid` = ' + pool.escape(fair.client_seedid) + ', `nonce` = ' + pool.escape(fair.nonce) + ', `time` = ' + pool.escape(time()), function(err4, row4) {
					if(err4) {
						logger.error(err4);
						writeError(err4);
						
						return cooldown(false, true);
					}
					
					pool.query('UPDATE `users_seeds_server` SET `nonce` = `nonce` + 1 WHERE `userid` = ' + pool.escape(user.userid) + ' AND `id` = ' + pool.escape(fair.server_seedid), function(err5){
						if(err5) {
							logger.debug(err5);
							writeError(err5);
							
							return cooldown(false, true);
						}
					
						//FINISH BET
						user_finishBet(user.userid, amount, winning, winning, [], 'plinko', function(err6){
							if(err6) {
								socket.emit('message', {
									type: 'error',
									error: err6.message
								});
								
								return cooldown(false, true);
							}
							
							socket.emit('message', {
								type: 'plinko',
								command: 'bet',
								id: row4.insertId,
								plinko: array,
								game: game
							});
							
							setTimeout(function(){
								var history = {
									id: row4.insertId,
									user: {
										userid: user.userid,
										avatar: user.avatar,
										name: user.name,
										level: calculateLevel(user.xp).level
									},
									amount: getFormatAmount(amount),
									game: game,
									roll: roll,
									multiplier: multiplier
								}
								
								plinkoGame_lastGames.push(history);
								if(plinkoGame_lastGames.length > 10) plinkoGame_lastGames.shift();
								
								io.sockets.in('plinko').emit('message', {
									type: 'plinko',
									command: 'history',
									history: history
								});
								
								user_updateLevel(user.userid);
								user_updateBalance(user.userid);
								
								if(winning >= config.config_games.winning_to_chat){
									var send_message = user.name + ' won ' + getFormatAmountString(winning) + ' to plinko with multiplier x'  + roundedToFixed(multiplier, 2).toFixed(2) + '!';
									otherMessages(send_message, io.sockets, true);
								}
								
								logger.debug('[PLINKO] Win registed. ' + user.name + ' did win $' + getFormatAmountString(winning) + ' with multiplier x' + roundedToFixed(multiplier, 2).toFixed(2));
							}, 4000);
							
							setTimeout(function(){
								plinkoGame_cooldown[user.userid] = false;
							}, 100);
							
							user_updateBalance(user.userid);
							
							logger.debug('[PLINKO] Bet registed. ' + user.name + ' did bet $' + getFormatAmountString(amount));
							
							cooldown(false, false);
						});
					});
				});
			});
		});
	});
}

/* END PLINKO */