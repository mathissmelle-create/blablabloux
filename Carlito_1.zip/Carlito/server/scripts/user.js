function user_updateBalance(userid) {
	pool.query('SELECT `balance` FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return;
		}
		
		if(row1.length == 0) return;
		
		io.sockets.in(userid).emit('message', {
			type: 'balance',
			balance: row1[0].balance
		});
	});
}

function user_updateLevel(userid) {
	pool.query('SELECT `xp` FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return;
		}
		
		if(row1.length == 0) return;
		
		io.sockets.in(userid).emit('message', {
			type: 'level',
			level: calculateLevel(row1[0].xp)
		});
	});
}

function user_getBalance(userid, callback){
	pool.query('SELECT `balance` FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err1, row1) {
		if(err1) return callback(err1);
		
		if(row1.length <= 0) return callback(new Error('Unable to get the user balance (1)'));
		
		var balance = getFormatAmount(row1[0].balance);
		
		callback(null, balance);
	});
}

function user_registerBet(userid, amountremove, itemsid, game, check, callback){
	var games_allowed = [ 'roulette', 'crash', 'jackpot', 'coinflip', 'dice', 'unboxing', 'casebattle', 'upgrader', 'minesweeper', 'tower', 'plinko' ];
	if(!games_allowed.includes(game)) return callback(new Error('Unable to register your bet (1)'));
	
	if(check) if(amountremove < config.config_site.interval_amount[game].min || amountremove > config.config_site.interval_amount[game].max) return callback(new Error('Invalid bet amount [' + getFormatAmountString(config.config_site.interval_amount[game].min) + '-' + getFormatAmountString(config.config_site.interval_amount[game].max)  + ']'));
	
	user_getBalance(userid, function(err1, balance){
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return callback(new Error('Unable to register your bet (2)'));
		}
		
		if(balance < amountremove) {
			io.sockets.in(userid).emit('message', {
				type: 'modal',
				modal: 'insufficient_balance',
				data: {
					amount: getFormatAmount(amountremove - balance)
				}
			});
			
			return callback(new Error('You don\'t have enough money'));
		}
		
		user_editBalance(userid, -amountremove, game + '_bet', function(err2){
			if(err2) {
				logger.error(err2);
				writeError(err2);
				
				return callback(new Error('Unable to register your bet (3)'));
			}
			
			user_removeItems(userid, itemsid, game + '_bet', function(err3){
				if(err3) {
					logger.error(err3);
					writeError(err3);
					
					return callback(new Error('Unable to register your bet (4)'));
				}
			
				return callback(null);
			});
		});
	});
}

function user_finishBet(userid, amount, winning, amountadd, itemsid, game, callback){
	var games_allowed = [ 'roulette', 'crash', 'jackpot', 'coinflip', 'dice', 'unboxing', 'casebattle', 'upgrader', 'minesweeper', 'tower', 'plinko' ];
	if(!games_allowed.includes(game)) return callback(new Error('Unable to finish your bet (1)'));
	
	amountadd = getFormatAmount(amountadd - getFeeFromCommission(amountadd, config.config_games.commissions[game]));
	
	user_editBalance(userid, amountadd, game + '_win', function(err1){
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return callback(new Error('Unable to finish your bet (2)'));
		}
		
		var available = getFormatAmount(winning - amount);
		if(available > amount || winning < amount) available = amount;
		
		user_addItems(userid, itemsid, game + '_win', function(err2, items){
			if(err2) {
				logger.error(err2);
				writeError(err2);
				
				return callback(new Error('Unable to finish your bet (3)'));
			}
			
			pool.query('UPDATE `users` SET `available` = `available` + ' + getAvailableAmount(available) + ' WHERE `deposit_count` > 0 AND `userid` = ' + pool.escape(userid), function(err3){
				if(err3) {
					logger.error(err3);
					writeError(err3);
					
					return callback(new Error('Unable to finish your bet (4)'));
				}
				
				pool.query('UPDATE `users` SET `xp` = `xp` + ' + getXpByAmount(amount) + ' WHERE `userid` = ' + pool.escape(userid), function(err4){
					if(err4) {
						logger.error(err4);
						writeError(err4);
						
						return callback(new Error('Unable to finish your bet (5)'));
					}
					
					user_registerAffiliates(userid, amount, 'bet', function(err5){
						if(err5) return callback(err5);
						
						callback(null, items);
					});
				});
			});
		});
	});
}

function user_refundBet(userid, amount, game, callback){
	user_editBalance(userid, amount, game + '_refund', function(err1){
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return callback(new Error('Unable to refund your bet (1)'));
		}
	
		callback(null);
	});
}

function user_editBalance(userid, amount, service, callback){
	pool.query('UPDATE `users` SET `balance` = `balance` + ' + amount + ' WHERE `userid` = ' + pool.escape(userid), function(err1, row1) {
		if(err1) return callback(err1);
		
		pool.query('INSERT INTO `users_transactions` SET `userid` = ' + pool.escape(userid) + ', `service` = ' + pool.escape(service) + ', `amount` = ' + amount + ', `time` = ' + pool.escape(time()), function(err2, row2){
			if(err2) return callback(err2);
			
			callback(null);
		});
	});
}

function user_addItems(userid, itemsid, service, callback){
	user_addItems_item(0, [], function(err1, items){
		if(err1) return callback(err1);
		
		callback(null, items);
	});
	
	function user_addItems_item(index, items, callback){
		if(index >= itemsid.length) return callback(null, items);
		
		itemsSyatem_addUserItem(userid, itemsid[index], function(err1, data){
			if(err1) return callback(err1);
			
			var amount = getFormatAmount(data.price);
			
			pool.query('INSERT INTO `users_items_transactions` SET `userid` = ' + pool.escape(userid) + ', `service` = ' + pool.escape(service) + ', `amount` = ' + amount + ', `itemid` = ' + pool.escape(data.id) + ', `time` = ' + pool.escape(time()), function(err2){
				if(err2) return callback(err2);
				
				items.push(data);
				
				user_addItems_item(index + 1, items, callback);
			});
		});
	}
}

function user_removeItems(userid, itemsid, service, callback){
	user_removeItems_item(0, function(err1){
		if(err1) return callback(err1);
		
		callback(null);
	});
	
	function user_removeItems_item(index, callback){
		if(index >= itemsid.length) return callback(null);
		
		pool.query('SELECT users_items.itemid, items_list.price FROM `users_items` INNER JOIN `items_list` ON users_items.itemid = items_list.itemid WHERE users_items.id = ' + pool.escape(itemsid[index]) + ' AND users_items.status = 0 AND users_items.userid = ' + pool.escape(userid), function(err1, row1){
			if(err1) return callback(err1);
			
			if(row1.length <= 0) return callback(new Error('Unable to remove user item (1)'));
		
			pool.query('UPDATE `users_items` SET `status` = 1 WHERE `id` = ' + pool.escape(itemsid[index]) + ' AND `status` = 0 AND `userid` = ' + pool.escape(userid), function(err2, row2){
				if(err2) return callback(err2);
				
				if(row2.affectedRows <= 0) return callback(new Error('Unable to remove user item (2)'));
				
				var amount = getFormatAmount(itemsSystem_items[row1[0].itemid].price);
				
				pool.query('INSERT INTO `users_items_transactions` SET `userid` = ' + pool.escape(userid) + ', `service` = ' + pool.escape(service) + ', `amount` = ' + -amount + ', `itemid` = ' + pool.escape(itemsid[index]) + ', `time` = ' + pool.escape(time()), function(err3){
					if(err3) return callback(err3);
					
					user_removeItems_item(index + 1, callback);
				});
			});
		});
	}
}

function user_registerAffiliates(userid, amount, type, callback){
	var types_allowed = ['bet', 'deposit'];
	if(!types_allowed.includes(type)) return callback(new Error('Unable to register the affiliates (1)'));
	
	pool.query('SELECT COALESCE(SUM(referral_deposited.amount), 0) AS `amount`, referral_uses.referral FROM `referral_uses` LEFT JOIN `referral_deposited` ON referral_uses.referral = referral_deposited.referral WHERE referral_uses.userid = ' + pool.escape(userid) + ' GROUP BY referral_uses.referral', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return callback(new Error('Unable to register the affiliates (2)'));
		}
		
		if(row1.length <= 0) return callback(null);
		
		var commission_deposit = getFeeFromCommission(amount, getAffiliateCommission(getFormatAmount(row1[0].amount), type));
		
		pool.query('INSERT INTO `referral_wagered` SET `userid` = ' + pool.escape(userid) + ', `referral` = ' + pool.escape(row1[0].referral) + ', `amount` = ' + amount + ', `commission` = ' + commission_deposit + ', `time` = ' + pool.escape(time()), function(err2, row2){
			if(err2) {
				logger.error(err2);
				writeError(err2);
				
				return callback(new Error('Unable to register the affiliates (3)'));
			}
			
			pool.query('UPDATE `referral_codes` SET `available` = `available` + ' + commission_deposit + ' WHERE `userid` = ' + pool.escape(row1[0].referral), function(err3, row3){
				if(err3) {
					logger.error(err3);
					writeError(err3);
					
					return callback(new Error('Unable to register the affiliates (4)'));
				}
				
				if(type != 'deposit') return callback(null);
				
				pool.query('INSERT INTO `referral_deposited` SET `userid` = ' + pool.escape(userid) + ', `referral` = ' + pool.escape(row1[0].referral) + ', `amount` = ' + amount + ', `commission` = ' + commission_deposit + ', `time` = ' + pool.escape(time()), function(err4, row4){
					if(err4) {
						logger.error(err4);
						writeError(err4);
						
						return callback(new Error('Unable to register the affiliates (5)'));
					}
					
					callback(null);
				});
			});
		});
	});
}

function user_registerDepositBonus(userid, amount, callback){
	pool.query('SELECT * FROM `deposit_uses` WHERE `userid` = ' + pool.escape(userid) + ' AND `removed` = 0', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return callback(new Error('Unable to register the deposit bonus (1)'));
		}
		
		if(row1.length <= 0) return callback(null);
		
		var bonus_deposit = getFeeFromCommission(amount, config.config_offers.deposit_bonus);
		
		user_editBalance(userid, bonus_deposit, 'deposit_bonus', function(err2){
			if(err2) return callback(err2);
			
			pool.query('UPDATE `deposit_uses` SET `uses` = `uses` + 1, `amount` = `amount` + ' + bonus_deposit + ' WHERE `id` = ' + pool.escape(row1[0].bonus) + ' AND `removed` = 0', function(err3) {
				if(err3) {
					logger.error(err3);
					writeError(err3);
					
					return callback(new Error('Unable to register the deposit bonus (2)'));
				}
				
				pool.query('INSERT INTO `deposit_bonuses` WHERE `userid` = ' + pool.escape(userid) + ', `bonus` = ' + pool.escape(row1[0].bonus) + ', `amount` = ' + bonus_deposit + ', `time` = ' + pool.escape(time()), function(err4) {
					if(err4) {
						logger.error(err4);
						writeError(err4);
						
						return callback(new Error('Unable to register the deposit bonus (3)'));
					}
					
					callback(null);
				});
			});
		});
	});
}

function user_saveProfileSettings(user, socket, data, cooldown){
	cooldown(true, true);
	
	var allowed_settings = [ 'anonymous', 'private', 'security' ];
	
	if(!allowed_settings.includes(data.setting)) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid setting!'
		});
		
		return cooldown(false, true);
	}
	
	pool.query('INSERT INTO `users_changes` SET `userid` = ' + pool.escape(user.userid) + ', `change` = ' + pool.escape(data.setting) + ', `value` = ' + pool.escape(data.value) + ', `time` = ' + pool.escape(time()), function(err1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
	
		pool.query('UPDATE `users` SET `' + data.setting + '` = ' + pool.escape(data.value) + ' WHERE `userid` = ' + pool.escape(user.userid), function(err2){
			if(err2) {
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			cooldown(false, false);
		});
	});
}

function user_applyDepositBonus(user, socket, code, recaptcha, cooldown){
	cooldown(true, true);
	
	site_verifyRecaptcha(recaptcha, function(verified){
		if(!verified){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid recaptcha!'
			});
			
			return cooldown(false, true);
		}
	
		code = code.trim().toLowerCase();
		
		pool.query('SELECT * FROM `deposit_codes` WHERE `code` = ' + pool.escape(code) + ' AND `removed` = 0', function(err1, row1){
			if(err1){
				logger.error(err1);
				writeError(err1);
				
				return cooldown(false, true);
			}
			
			if(row1.length <= 0){
				socket.emit('message', {
					type: 'error',
					error: 'Error: Unknown deposit bonus code!'
				});
				
				return cooldown(false, true);
			}
		
			pool.query('UPDATE `deposit_uses` SET `removed` = 1 WHERE `userid` = ' + pool.escape(user.userid) + ' AND `removed` = 0', function(err2, row2){
				if(err2){
					logger.error(err2);
					writeError(err2);
					
					return cooldown(false, true);
				}
				
				pool.query('INSERT INTO `deposit_uses` SET `userid` = '  + pool.escape(user.userid) + ', `bonus` = ' + pool.escape(row1[0].id) + ', `time` = ' + pool.escape(time()), function(err3, row3){
					if(err3){
						logger.error(err3);
						writeError(err3);
						
						return cooldown(false, true);
					}
					
					socket.emit('message', {
						type: 'success',
						success: 'Deposit bonus code applied successfully!'
					});
					
					cooldown(false, false);
				});
			});
		});
	});
}

function user_exclusionAccount(user, socket, exclusion, recaptcha, cooldown) {
	cooldown(true, true);
	
	site_verifyRecaptcha(recaptcha, function(verified){
		if(!verified){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid recaptcha!'
			});
			
			return cooldown(false, true);
		}
	
		var allowed_exclusions = ['24hours', '7days', '30days'];
		
		if(!allowed_exclusions.includes(exclusion)) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid exclusion!'
			});
			
			return cooldown(false, true);
		}
		
		if(user.exclusion > time()) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: You have already a exclusion. Please wait to end the currently exclusion!'
			});
			
			return cooldown(false, true);
		}
		
		var time_exclusion = getTimeString(exclusion);
		
		pool.query('INSERT INTO `users_changes` SET `userid` = ' + pool.escape(user.userid) + ', `change` = ' + pool.escape("exclusion") + ', `value` = ' + pool.escape(time_exclusion) + ', `time` = ' + pool.escape(time()), function(err1) {
			if(err1) {
				logger.error(err1);
				writeError(err1);
				
				return cooldown(false, true);
			}
		
			pool.query('UPDATE `users` SET `exclusion` = ' + pool.escape(time_exclusion) + ' WHERE `userid` = ' + pool.escape(user.userid), function(err2){
				if(err2) {
					logger.error(err2);
					writeError(err2);
					
					return cooldown(false, true);
				}
				
				socket.emit('message', {
					type: 'success',
					success: 'Exclusion successfully setted. The exclusion will expire ' + makeDate(new Date(time_exclusion * 1000)) + '.'
				});
				
				cooldown(false, false);
			});
		});
	});
}

function user_removeSessionAccount(user, socket, session, cooldown) {
	cooldown(true, true);
	
	pool.query('SELECT * FROM `users_sessions` WHERE `userid` = ' + pool.escape(user.userid) + ' AND `id` = ' + pool.escape(session) + ' AND `removed` = 0 AND `expire` > ' + pool.escape(time()), function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid session or session expired!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('UPDATE `users_sessions` SET `removed` = 1 WHERE `userid` = ' + pool.escape(user.userid) + ' AND `id` = ' + pool.escape(session) + ' AND `removed` = 0 AND `expire` > ' + pool.escape(time()), function(err2){
			if(err2) {
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'success',
				success: 'Session successfully removed. The device connected with that session is disconnected!'
			});
			
			socket.emit('message', {
				type: 'profile',
				command: 'remove_session',
				session: session
			});
			
			cooldown(false, false);
		});
	});
}

function user_unsetRestriction(user, socket, data, callback) {
	pool.query('SELECT * FROM `users_restrictions` WHERE `removed` = 0 AND `restriction` = ' + pool.escape(data.restriction) + ' AND (`expire` = -1 OR `expire` > ' + pool.escape(time()) + ') AND `userid` = ' + pool.escape(data.userid), function(err1, row1) {
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return;
		}
		
		if(row1.length <= 0) return callback(new Error('Error: This user don\'t have this restriction!'));
		
		pool.query('UPDATE `users_restrictions` SET `removed` = 1 WHERE `removed` = 0 AND `restriction` = ' + pool.escape(data.restriction) + ' AND (`expire` = -1 OR `expire` > ' + pool.escape(time()) + ') AND `userid` = '+ pool.escape(data.userid), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return;
			}
			
			if(row2.affectedRows <= 0) return callback(new Error('The user was unsuccessfully unrestricted!'));
			
			callback(null);
		});
	});
}

function user_setRestriction(user, socket, data, chat, callback) {
	var time_restriction = getTimeString(data.time);
	if(time_restriction == 0) return callback(new Error('Invalid restriction time!'));
		
	pool.query('SELECT `name` FROM `users` WHERE `userid` = ' + pool.escape(data.userid), function(err1, row1) {
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return;
		}
		
		if(row1.length == 0) return callback(new Error('Unknown user!'));
		
		pool.query('SELECT * FROM `users_restrictions` WHERE `removed` = 0 AND `restriction` = ' + pool.escape(data.restriction) + ' AND (`expire` = -1 OR `expire` > ' + pool.escape(time()) + ') AND `userid` = ' + pool.escape(data.userid), function(err2, row2) {
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return;
			}
			
			if(row2.length > 0) return callback(new Error('This user have already this restriction!'));
			
			pool.query('INSERT INTO `users_restrictions` SET `userid` = ' + pool.escape(data.userid) + ', `restriction` = ' + pool.escape(data.restriction) + ', `reason` = ' + pool.escape(data.reason) + ', `byuserid` = '+ pool.escape(user.userid) + ', `expire` = ' + pool.escape(time_restriction) + ', `time` = '+ pool.escape(time()), function(err3){
				if(err3){
					logger.error(err3);
					writeError(err3);
					
					return;
				}
				
				if(chat){
					if(data.restriction == 'play') var text_message = 'User ' + row1[0].name + ' was play banned by ' + user.name + ' for ' + data.reason + '. The restriction expires ' + ((time_restriction == -1) ? 'never' : makeDate(new Date(time_restriction * 1000))) + '.';
					else if(data.restriction == 'trade') var text_message = 'User ' + row1[0].name + ' was trade banned by ' + user.name + ' for ' + data.reason + '. The restriction expires ' + ((time_restriction == -1) ? 'never' : makeDate(new Date(time_restriction * 1000))) + '.';
					else if(data.restriction == 'site') var text_message = 'User ' + row1[0].name + ' was site banned by ' + user.name + ' for ' + data.reason + '. The restriction expires ' + ((time_restriction == -1) ? 'never' : makeDate(new Date(time_restriction * 1000))) + '.';
					else if(data.restriction == 'mute') var text_message = 'User ' + row1[0].name + ' was muted by ' + user.name + ' for ' + data.reason + '. The restriction expires ' + ((time_restriction == -1) ? 'never' : makeDate(new Date(time_restriction * 1000))) + '.';
					
					otherMessages(text_message, io.sockets, true);
				}
				
				callback(null);
			});
		});
	});
}

function user_sendCoins(user, socket, userid, amount, recaptcha, cooldown){
	cooldown(true, true);
	
	if(user.exclusion > time()) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Your exclusion expires ' + makeDate(new Date(user.exclusion * 1000)) + '.'
		});
		
		return cooldown(false, true);
	}
	
	if(!user.verified) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: Your account is not verified. Please verify your account and try again.'
		});
		
		return cooldown(false, true);
	}
	
	site_verifyRecaptcha(recaptcha, function(verified){
		if(!verified){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid recaptcha!'
			});
			
			return cooldown(false, true);
		}
		
		if(user.userid == userid){
			socket.emit('message', {
				type: 'error',
				error: 'Error: You can\'t send coins to yourself!'
			});
			
			return cooldown(false, true);
		}
		
		if(calculateLevel(user.xp).level < config.config_site.level_send_coins){
			socket.emit('message', {
				type: 'error',
				error: 'Error: You need to have level ' + config.config_site.level_send_coins + ' to send coins!'
			});
			
			return cooldown(false, true);
		}
		
		site_verifyFormatAmount(amount, function(err1, amount){
			if(err1){
				socket.emit('message', {
					type: 'error',
					error: err1.message
				});
				
				return cooldown(false, true);
			}
			
			if(amount < config.config_site.interval_amount.send_coins.min || amount > config.config_site.interval_amount.send_coins.max) {
				socket.emit('message', {
					type: 'error',
					error: 'Error: Invalid send amount [' + getFormatAmountString(config.config_site.interval_amount.send_coins.min) + '-' + getFormatAmountString(config.config_site.interval_amount.send_coins.max)  + ']!'
				});
				
				return cooldown(false, true);
			}
			
			//CHECK BALANCE
			user_getBalance(user.userid, function(err2, balance){
				if(err2) {
					logger.error(err2);
					writeError(err2);
					
					return cooldown(false, true);
				}
			
				if(getFormatAmount(balance) < amount) {
					socket.emit('message', {
						type: 'error',
						error: 'Error: You don\'t have enough money!'
					});
					
					socket.emit('message', {
						type: 'modal',
						modal: 'insufficient_balance',
						data: {
							amount: getFormatAmount(amount - balance)
						}
					});
					
					return cooldown(false, true);
				}
			
				pool.query('SELECT `name`, `exclusion`, `verified`, `initialized`, `xp` FROM `users` WHERE `userid` = ' + pool.escape(userid), function(err3, row3) {
					if(err3){
						logger.error(err3);
						writeError(err3);
						
						return cooldown(false, true);
					}
					
					if(row3.length == 0) {
						socket.emit('message', {
							type: 'error',
							error: 'Error: Unknown user!'
						});
						
						return cooldown(false, true);
					}
					
					if(!row3[0].initialized) {
						socket.emit('message', {
							type: 'error',
							error: 'Error: The recipient can\'t receive coins. The recipient profile is not initialized.'
						});
						
						return cooldown(false, true);
					}
					
					if(row3[0].exclusion > time()) {
						socket.emit('message', {
							type: 'error',
							error: 'Error: The recipient can\'t receive coins. The recipient is excluded.'
						});
						
						return cooldown(false, true);
					}
					
					if(!row3[0].verified) {
						socket.emit('message', {
							type: 'error',
							error: 'Error: The recipient can\'t receive coins. The recipient profile is not verified.'
						});
						
						return cooldown(false, true);
					}
					
					if(calculateLevel(row3[0].xp).level < config.config_site.level_receive_coins){
						socket.emit('message', {
							type: 'error',
							error: 'Error: The recipient can\'t receive coins. The recipient need to have level ' + config.config_site.level_send_coins + ' to receive coins.'
						});
						
						return cooldown(false, true);
					}
					
					pool.query('INSERT INTO `users_transfers` SET `from_userid` = ' + pool.escape(user.userid) + ', `to_userid` = ' + pool.escape(userid) + ', `amount` = ' + amount + ', `time` = ' + pool.escape(time()), function(err4){
						if(err4) {
							logger.error(err4);
							writeError(err4);
							
							return cooldown(false, true);
						}
						
						//EDIT BALANCE
						user_editBalance(user.userid, -amount, 'sent_coins', function(err5){
							if(err5) {
								logger.error(err5);
								writeError(err5);
								
								return cooldown(false, true);
							}
							
							socket.emit('message', {
								type: 'info',
								info: 'You sent ' + getFormatAmountString(amount) + ' coins to ' + row3[0].name + '.'
							});
							
							user_updateBalance(user.userid);
							
							//EDIT BALANCE
							user_editBalance(userid, amount, 'received_coins', function(err6){
								if(err6) {
									logger.error(err6);
									writeError(err6);
									
									return cooldown(false, true);
								}
								
								io.sockets.in(userid).emit('message', {
									type: 'info',
									info: 'You received ' + getFormatAmountString(amount) + ' coins from ' + user.name + '!'
								});
								
								user_updateBalance(userid);
								
								cooldown(false, false);
							});
						});
					});
				});
			});
		});
	});
}

function user_userTransactions(user, socket, page, userid, cooldown){
	cooldown(true, true);
	
	if(!config.config_site.profile_allowed.includes(config.config_site.ranks_name[user.rank]) && user.userid != userid){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(page))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid page!'
		});
		
		return cooldown(false, true);
	}
	
	page = parseInt(page);
	
	pool.query('SELECT COUNT(*) AS `count` FROM `users_transactions` WHERE `userid` = ' + pool.escape(userid), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		var pages = parseInt(row1[0].count / 10) + (row1[0].count % 10 > 0 ? 1 : 0);
		
		if(pages <= 0){
			socket.emit('message', {
				type: 'pagination',
				command: 'user_transactions',
				list: [],
				pages: 1,
				page: 1
			});
			
			return cooldown(false, false);
		}
		
		if(page <= 0 || page > pages) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid page!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('SELECT `id`, `service`, `amount`, `time` FROM `users_transactions` WHERE `userid` = ' + pool.escape(userid) + ' ORDER BY `id` DESC LIMIT 10 OFFSET ' + pool.escape(page * 10 - 10), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			row2.reverse();
			
			var id = 0;
			if(row2.length > 0) if(row2[0].id > 0) id = row2[0].id;
			
			pool.query('SELECT COALESCE(SUM(amount), 0) AS `balance` FROM `users_transactions` WHERE `userid` = ' + pool.escape(userid) + ' AND `id` < ' + id, function(err3, row3){
				if(err3){
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				var balance = getFormatAmount(row3[0].balance);
				
				var list = [];
			
				row2.forEach(function(item){
					list.push({
						id: item.id,
						service: item.service,
						balance: getFormatAmount(balance),
						amount: getFormatAmount(item.amount),
						time: makeDate(new Date(item.time * 1000))
					});
					
					balance += getFormatAmount(item.amount);
				});
				
				list.reverse();
				
				socket.emit('message', {
					type: 'pagination',
					command: 'user_transactions',
					list: list,
					pages: pages,
					page: page
				});
				
				cooldown(false, false);
			});
		});
	});
}

function user_userTransfers(user, socket, page, userid, cooldown){
	cooldown(true, true);
	
	if(!config.config_site.profile_allowed.includes(config.config_site.ranks_name[user.rank]) && user.userid != userid){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(page))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid page!'
		});
		
		return cooldown(false, true);
	}
	
	page = parseInt(page);
	
	pool.query('SELECT COUNT(*) AS `count` FROM `users_transfers`  WHERE `to_userid` = ' + pool.escape(userid) + ' OR `from_userid` = ' + pool.escape(userid), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		var pages = parseInt(row1[0].count / 10) + (row1[0].count % 10 > 0 ? 1 : 0);
		
		if(pages <= 0){
			socket.emit('message', {
				type: 'pagination',
				command: 'user_transfers',
				list: [],
				pages: 1,
				page: 1
			});
			
			return cooldown(false, false);
		}
		
		if(page <= 0 || page > pages) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid page!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('SELECT `id`, `from_userid`, `to_userid`, `amount`, `time` FROM `users_transfers` WHERE `to_userid` = ' + pool.escape(userid) + ' OR `from_userid` = ' + pool.escape(userid) + ' ORDER BY `id` DESC LIMIT 10 OFFSET ' + pool.escape(page * 10 - 10), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			var list = [];
			
			row2.forEach(function(item){
				list.push({
					id: item.id,
					received: item.to_userid == userid,
					from: (item.from_userid == userid) ? (config.config_site.profile_allowed.includes(config.config_site.ranks_name[user.rank]) && user.userid != userid ? 'HIM' : 'YOU') : item.from_userid,
					to: (item.to_userid == userid) ? (config.config_site.profile_allowed.includes(config.config_site.ranks_name[user.rank]) && user.userid != userid ? 'HIM' : 'YOU') : item.to_userid,
					amount: getFormatAmount(item.amount),
					time: makeDate(new Date(item.time * 1000))
				});
			});
			
			socket.emit('message', {
				type: 'pagination',
				command: 'user_transfers',
				list: list,
				pages: pages,
				page: page
			});
			
			cooldown(false, false);
		});
	});
}

function user_cryptoTransactions(user, socket, page, userid, cooldown){
	cooldown(true, true);
	
	if(!config.config_site.profile_allowed.includes(config.config_site.ranks_name[user.rank]) && user.userid != userid){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(page))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid page!'
		});
		
		return cooldown(false, true);
	}
	
	page = parseInt(page);
	
	pool.query('SELECT COUNT(*) AS `count` FROM `crypto_transactions` WHERE `userid` = ' + pool.escape(userid), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		var pages = parseInt(row1[0].count / 10) + (row1[0].count % 10 > 0 ? 1 : 0);
		
		if(pages <= 0){
			socket.emit('message', {
				type: 'pagination',
				command: 'crypto_transactions',
				list: [],
				pages: 1,
				page: 1
			});
			
			return cooldown(false, false);
		}
		
		if(page <= 0 || page > pages) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid page!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('SELECT `id`, `status`, `txnid`, `amount`, `type`, `currency`, `time` FROM `crypto_transactions` WHERE `userid` = ' + pool.escape(userid) + ' ORDER BY `id` DESC LIMIT 10 OFFSET ' + pool.escape(page * 10 - 10), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			var list = [];
			
			row2.forEach(function(item){
				if(item.status == 100){
					var status = 'success';
				} else if(item.status < 0){
					var status = 'danger';
				} else {
					var status = 'warning';
				}
				
				list.push({
					id: item.id,
					status: status,
					txnid: item.txnid,
					amount: getFormatAmount(item.amount),
					type: item.type,
					currency: item.currency,
					time: makeDate(new Date(item.time * 1000))
				});
			});
			
			socket.emit('message', {
				type: 'pagination',
				command: 'crypto_transactions',
				list: list,
				pages: pages,
				page: page
			});
			
			cooldown(false, false);
		});
	});
}

function user_inventoryItems(user, socket, page, userid, cooldown){
	cooldown(true, true);
	
	if(isNaN(Number(page))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid page!'
		});
		
		return cooldown(false, true);
	}
	
	page = parseInt(page);
	
	pool.query('SELECT users_items.itemid, items_list.price FROM `users_items` INNER JOIN `items_list` ON users_items.itemid = items_list.itemid WHERE users_items.status = 0 AND users_items.userid = ' + pool.escape(userid), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		var pages = parseInt(row1.length / 100) + (row1.length % 100 > 0 ? 1 : 0);
		
		if(pages <= 0){
			socket.emit('message', {
				type: 'pagination',
				command: 'inventory_items',
				list: [],
				pages: 1,
				page: 1
			});
			
			return cooldown(false, false);
		}
		
		if(page <= 0 || page > pages) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid page!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('SELECT users_items.id, users_items.itemid, items_list.price FROM `users_items` INNER JOIN `items_list` ON users_items.itemid = items_list.itemid WHERE users_items.status = 0 AND users_items.userid = ' + pool.escape(userid) + ' ORDER BY users_items.id DESC LIMIT 100 OFFSET ' + pool.escape(page * 100 - 100), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			var list = [];
			
			row2.forEach(function(item){
				list.push({
					item: {
						id: item.id,
						name: itemsSystem_items[item.itemid].name,
						image: itemsSystem_items[item.itemid].image,
						price: getFormatAmount(itemsSystem_items[item.itemid].price),
						color: getColorByQuality(itemsSystem_items[item.itemid].quality)
					}
				});
			});
			
			var value = row1.reduce(function(acc, val) { return getFormatAmount(acc + itemsSystem_items[val.itemid].price) }, 0);
			
			socket.emit('message', {
				type: 'pagination',
				command: 'inventory_items',
				list: list,
				pages: pages,
				page: page,
				inventory: {
					value: value,
					count: list.length
				}
			});
			
			cooldown(false, false);
		});
	});
}

function user_inventorySellItem(user, socket, id, cooldown){
	cooldown(true, true);
	
	if(isNaN(Number(id))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid item!'
		});
		
		return cooldown(false, true);
	}
	
	id = parseInt(id);
	
	pool.query('SELECT users_items.itemid, items_list.price FROM `users_items` INNER JOIN `items_list` ON users_items.itemid = items_list.itemid WHERE users_items.id = ' + pool.escape(id) + ' AND users_items.status = 0 AND users_items.userid = ' + pool.escape(user.userid), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid item. Item not found!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('UPDATE `users_items` SET `status` = 1 WHERE `id` = ' + pool.escape(id) + ' AND `status` = 0 AND `userid` = ' + pool.escape(user.userid), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			if(row2.affectedRows <= 0){
				socket.emit('message', {
					type: 'error',
					error: 'Error: Invalid item. Item not found!'
				});
				
				return cooldown(false, true);
			}
			
			var amount = getFormatAmount(itemsSystem_items[row1[0].itemid].price);
			
			pool.query('INSERT INTO `users_items_transactions` SET `userid` = ' + pool.escape(user.userid) + ', `service` = ' + pool.escape("sell_item") + ', `amount` = ' + -amount + ', `itemid` = ' + pool.escape(id) + ', `time` = ' + pool.escape(time()), function(err3){
				if(err3) {
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				user_editBalance(user.userid, amount, 'sell_item', function(err4){
					if(err4) {
						logger.error(err4);
						writeError(err4);
						
						return cooldown(false, true);
					}
					
					pool.query('SELECT users_items.itemid, items_list.price FROM `users_items` INNER JOIN `items_list` ON users_items.itemid = items_list.itemid WHERE users_items.status = 0 AND users_items.userid = ' + pool.escape(user.userid), function(err5, row5){
						if(err5){
							logger.error(err5);
							writeError(err5);
							
							return cooldown(false, true);
						}
						
						var value = row5.reduce(function(acc, val) { return getFormatAmount(acc + itemsSystem_items[val.itemid].price) }, 0);
						
						socket.emit('message', {
							type: 'inventory',
							command: 'sell_item',
							id: id,
							inventory: {
								value: value,
								count: row5.length
							}
						});
						
						socket.emit('message', {
							type: 'success',
							success: 'Item successfully sold!'
						});
						
						user_updateBalance(user.userid);
						
						cooldown(false, false);
					});
				});
			});
		});
	});
}

function user_inventorySellAll(user, socket, cooldown){
	cooldown(true, true);
	
	pool.query('SELECT users_items.id, users_items.itemid, items_list.price FROM `users_items` INNER JOIN `items_list` ON users_items.itemid = items_list.itemid WHERE users_items.status = 0 AND users_items.userid = ' + pool.escape(user.userid), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		if(row1.length <= 0){
			socket.emit('message', {
				type: 'error',
				error: 'Error: No available items in inventory!'
			});
			
			return cooldown(false, true);
		}
		
		user_inventorySellAll_sell(user, 0, row1, [], function(err2, items_success){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			var amount_sold = items_success.reduce(function(acc, val) { return getFormatAmount(acc + itemsSystem_items[val.itemid].price) }, 0);
			
			user_editBalance(user.userid, amount_sold, 'sell_items', function(err3){
				if(err3) {
					logger.error(err3);
					writeError(err3);
					
					return cooldown(false, true);
				}
				
				pool.query('SELECT users_items.itemid, items_list.price FROM `users_items` INNER JOIN `items_list` ON users_items.itemid = items_list.itemid WHERE users_items.status = 0 AND users_items.userid = ' + pool.escape(user.userid), function(err4, row4){
					if(err4){
						logger.error(err4);
						writeError(err4);
						
						return cooldown(false, true);
					}
					
					var value = row4.reduce(function(acc, val) { return getFormatAmount(acc + itemsSystem_items[val.itemid].price) }, 0);
					
					socket.emit('message', {
						type: 'inventory',
						command: 'sell_items',
						ids: items_success.slice().map(a => a.id),
						inventory: {
							value: value,
							count: row4.length
						}
					});
					
					socket.emit('message', {
						type: 'success',
						success: 'All items successfully sold!'
					});
					
					user_updateBalance(user.userid);
					
					cooldown(false, false);
				});
			});
		});
	});
}

function user_inventorySellAll_sell(user, index, items, items_success, callback){
	if(index >= items.length) return callback(null, items_success);
	
	pool.query('UPDATE `users_items` SET `status` = 1 WHERE `id` = ' + pool.escape(items[index].id) + ' AND `status` = 0 AND `userid` = ' + pool.escape(user.userid), function(err1, row1){
		if(err1) return callback(err1);
		
		if(row1.affectedRows <= 0) return callback(new Error('Invalid item. Item not found!'));
		
		var amount = getFormatAmount(items[index].price);
		
		pool.query('INSERT INTO `users_items_transactions` SET `userid` = ' + pool.escape(user.userid) + ', `service` = ' + pool.escape("sell_item") + ', `amount` = ' + -amount + ', `itemid` = ' + pool.escape(items[index].id) + ', `time` = ' + pool.escape(time()), function(err2){
			if(err2) return callback(err2);
			
			items_success.push(items[index]);
			
			user_inventorySellAll_sell(user, index + 1, items, items_success, callback);
		});
	});
}

function user_steamTransactions(user, socket, page, userid, cooldown){
	cooldown(true, true);
	
	if(!config.config_site.profile_allowed.includes(config.config_site.ranks_name[user.rank]) && user.userid != userid){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(page))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid page!'
		});
		
		return cooldown(false, true);
	}
	
	page = parseInt(page);
	
	pool.query('SELECT COUNT(*) AS `count` FROM `steam_transactions` WHERE `userid` = ' + pool.escape(userid), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		var pages = parseInt(row1[0].count / 10) + (row1[0].count % 10 > 0 ? 1 : 0);
		
		if(pages <= 0){
			socket.emit('message', {
				type: 'pagination',
				command: 'steam_transactions',
				list: [],
				pages: 1,
				page: 1
			});
			
			return cooldown(false, false);
		}
		
		if(page <= 0 || page > pages) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid page!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('SELECT `id`, `status`, `tradeofferid`, `code`, `amount`, `type`, `game`, `refill`, `time` FROM `steam_transactions` WHERE `userid` = ' + pool.escape(userid) + ' ORDER BY `id` DESC LIMIT 10 OFFSET ' + pool.escape(page * 10 - 10), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			var list = [];
			
			row2.forEach(function(item){
				if(item.status == 2){
					var status = 'success';
				} else if(item.status == 0 || item.status == 1){
					var status = 'warning';
				} else if(item.status == -1){
					var status = 'danger';
				}
				
				list.push({
					id: item.id,
					status: status,
					tradeofferid: item.tradeofferid,
					code: item.code,
					amount: getFormatAmount(item.amount),
					type: item.type,
					game: item.game,
					refill: parseInt(item.refill),
					time: makeDate(new Date(item.time * 1000))
				});
			});
			
			socket.emit('message', {
				type: 'pagination',
				command: 'steam_transactions',
				list: list,
				pages: pages,
				page: page
			});
			
			cooldown(false, false);
		});
	});
}

function user_p2pTransactions(user, socket, page, userid, cooldown){
	cooldown(true, true);
	
	if(!config.config_site.profile_allowed.includes(config.config_site.ranks_name[user.rank]) && user.userid != userid){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	if(isNaN(Number(page))){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid page!'
		});
		
		return cooldown(false, true);
	}
	
	page = parseInt(page);
	
	pool.query('SELECT COUNT(*) AS `count` FROM `p2p_transactions` LEFT JOIN `p2p_buyers` ON p2p_transactions.id = p2p_buyers.offerid WHERE p2p_buyers.userid = ' + pool.escape(userid) + ' OR p2p_transactions.userid = ' + pool.escape(userid), function(err1, row1){
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return cooldown(false, true);
		}
		
		var pages = parseInt(row1[0].count / 10) + (row1[0].count % 10 > 0 ? 1 : 0);
		
		if(pages <= 0){
			socket.emit('message', {
				type: 'pagination',
				command: 'p2p_transactions',
				list: [],
				pages: 1,
				page: 1
			});
			
			return cooldown(false, false);
		}
		
		if(page <= 0 || page > pages) {
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid page!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('SELECT p2p_transactions.*, COALESCE(p2p_buyers.canceled, -1) AS `canceled`, IF(COALESCE(p2p_buyers.userid, 0) = ' + pool.escape(userid) + ', 1, 0) AS `type` FROM `p2p_transactions` LEFT JOIN `p2p_buyers` ON p2p_transactions.id = p2p_buyers.offerid WHERE p2p_buyers.userid = ' + pool.escape(userid) + ' OR p2p_transactions.userid = ' + pool.escape(userid) + ' ORDER BY p2p_transactions.id DESC LIMIT 10 OFFSET ' + pool.escape(page * 10 - 10), function(err2, row2){
			if(err2){
				logger.error(err2);
				writeError(err2);
				
				return cooldown(false, true);
			}
			
			var list = [];
			
			row2.forEach(function(item){
				if(parseInt(item.canceled) == 1 && parseInt(item.type) == 1) item.status = -1;
				
				if(item.status == 4){
					var status = 'success';
				} else if(item.status == 0 || item.status == 1 || item.status == 2 || item.status == 3){
					var status = 'warning';
				} else if(item.status == -1){
					var status = 'danger';
				}
				
				var type = 'deposit';
				if(parseInt(item.type) == 1) type = 'withdraw';
				
				list.push({
					id: item.id,
					status: status,
					tradeofferid: item.tradeofferid,
					amount: getFormatAmount(item.amount),
					type: type,
					game: item.game,
					time: makeDate(new Date(item.time * 1000))
				});
			});
			
			socket.emit('message', {
				type: 'pagination',
				command: 'p2p_transactions',
				list: list,
				pages: pages,
				page: page
			});
			
			cooldown(false, false);
		});
	});
}

function user_saveTradelink(user, socket, tradelink, recaptcha, cooldown){
	cooldown(true, true);
	
	site_verifyRecaptcha(recaptcha, function(verified){
		if(!verified){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid recaptcha!'
			});
			
			return cooldown(false, true);
		}
		
		var reg1 = /^(http|https):\/\/steamcommunity.com\/tradeoffer\/new\/\?partner=(\d+)&token=([a-zA-Z0-9_-]+)$/;
		
		if(!reg1.test(tradelink)){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid tradelink!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('INSERT INTO `users_changes` SET `userid` = ' + pool.escape(user.userid) + ', `change` = ' + pool.escape('tradelink') + ', `value` = ' + pool.escape(tradelink) + ', `time` = ' + pool.escape(time()), function(err1) {
			if(err1) {
				logger.error(err1);
				writeError(err1);
				
				return cooldown(false, true);
			}
		
			pool.query('UPDATE `users` SET `tradelink` = ' + pool.escape(tradelink) + ' WHERE `userid` = ' + pool.escape(user.userid), function(err2) {
				if(err2) {
					logger.error(err2);
					writeError(err2);
					
					return cooldown(false, true);
				}
				
				socket.emit('message', {
					type: 'success',
					success: 'Tradelink saved!'
				});
				
				cooldown(false, false);
			});
		});
	});
}

function user_saveApikey(user, socket, apikey, recaptcha, cooldown){
	cooldown(true, true);
	
	site_verifyRecaptcha(recaptcha, function(verified){
		if(!verified){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid recaptcha!'
			});
			
			return cooldown(false, true);
		}
		
		socket.emit('message', {
			type: 'info',
			info: 'Processing your Apikey verify!'
		});
		
		offers_verifyApikey(user, apikey, function(err1){
			if(err1) {
				socket.emit('message', {
					type: 'error',
					error: err1.message
				});
				
				return cooldown(false, true);
			}
		
			pool.query('INSERT INTO `users_changes` SET `userid` = ' + pool.escape(user.userid) + ', `change` = ' + pool.escape('apikey') + ', `value` = ' + pool.escape(apikey) + ', `time` = ' + pool.escape(time()), function(err2) {
				if(err2) {
					logger.error(err2);
					writeError(err2);
					
					return cooldown(false, true);
				}
			
				pool.query('UPDATE `users` SET `apikey` = ' + pool.escape(apikey) + ' WHERE `userid` = ' + pool.escape(user.userid), function(err3) {
					if(err3) {
						logger.error(err3);
						writeError(err3);
						
						return cooldown(false, true);
					}
					
					socket.emit('message', {
						type: 'success',
						success: 'Apikey saved!'
					});
					
					cooldown(false, false);
				});
			});
		});
	});
}