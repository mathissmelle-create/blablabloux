function site_verifyFormatAmount(amount, callback){
	if(isNaN(Number(amount))) return callback(new Error('Invalid amount. This field must to be a number'));
	
	amount = getFormatAmount(amount);
	
	return callback(null, amount);
}

function site_verifyRecaptcha(recaptcha, callback){
	request('https://www.google.com/recaptcha/api/siteverify?secret=' + config.config_site.recaptcha.private_key + '&response=' + recaptcha, function(err, response) {
		var verifiedRecaptcha = false;
		
		if(err) {
			logger.error(err);
			writeError(err);
		}else{
			var res = JSON.parse(response.body);
			
			if(res.success !== undefined){
				verifiedRecaptcha = res.success;
			}
		}
		
		callback(verifiedRecaptcha);
	});
}

function site_getAlerts(){
	if(new Date().getDay() == 0 || new Date().getDay() == 6) return config.settings.server.alerts.concat(config.config_chat.message_double_xp);
	
	return config.settings.server.alerts
}

function site_getNotifies(){
	if(new Date().getDay() == 0 || new Date().getDay() == 6) return config.settings.server.notifies.concat(config.config_chat.message_double_xp);
	
	return config.settings.server.notifies
}