var TradeOfferManager = require('steam-tradeoffer-manager');
var SteamTotp = require('steam-totp');
var SteamCommunity = require('steamcommunity');
var protos = require('./protos');
var EventEmitter = require('events').EventEmitter;

var SteamClient = require('steam-client');
var SteamUser = require('steam-user');

class Bot extends EventEmitter {
	constructor(props){
		super();
		
		this._bot_props = {
			username: props.username,
			password: props.password,
			identity_secret: props.identity_secret,
			shared_secret: props.shared_secret,
		};
		
		this.name = props.botname;
		this.steamid = props.steamid;
		this.can_trade = props.can_trade;
		this.can_info = props.can_info;
		this.can_apikey = props.can_apikey;
		this.active = props.active;
		
		this.connected = false;
		
		this.queueRequestInspect = [];
		
		this.client = new SteamClient.CMClient(SteamClient.EConnectionProtocol.WebSocket);
		this.user = new SteamUser();
		
		this.community = new SteamCommunity();
		this.manager = null;
		
		this.cookies = null;
		
		this.gameCoordinator = {
			connected: false,
			appid: null,
			interval: null
		};
		
		if((this.can_trade || this.can_apikey) && this.active){
			this.manager = new TradeOfferManager({
				steam: this.client,
				community: this.community,
				domain: 'localhost',
				language: 'en',
				//cancelTime: 150000
			});
		}
		
		this.client.connect();
		
		//EVENTS
		if(this.can_info && this.active){
			this.user.on('receivedFromGC', (appid, type, buffer) => {
				switch(type){
					case 4004:						
						if(!this.gameCoordinator.connected){
							this.emit('message', '[BOT] ' + this.name + ' - Counter Strike Global Offensive Are Ready');
							
							this.gameCoordinator.connected = true;
							this.gameCoordinator.appid = appid;
							
							if(this.gameCoordinator.interval) clearInterval(this.gameCoordinator.interval);
						}
						
						break;
						
					case 9157:
						var itemDataResponse = protos.CMsgGCCStrike15_v2_Client2GCEconPreviewDataBlockResponse.decode(buffer);
						
						var buf = new Buffer.alloc(4);
						buf.writeUInt32LE(Number(itemDataResponse.iteminfo.paintwear), 0);
						
						var wear = buf.readFloatLE(0);
						var paintindex = itemDataResponse.iteminfo.paintindex;
						
						this.confirmInspect({ wear, paintindex });
						
						break;
				}
			});
		}
		
		this.client.on('connected', () => {
			this.emit('message', '[BOT] ' + this.name + ' - Client Connected Successfuly');
			
			this.user.logOn({
				accountName: this._bot_props.username,
				password: this._bot_props.password,
				twoFactorCode: SteamTotp.generateAuthCode(this._bot_props.shared_secret)
			});
		});
		
		this.user.on('loggedOn', (response) => {
			if(response.eresult !== SteamUser.EResult.OK) {
				this.emit('message', '[BOT] ' + this.name + ' - User Login Failed');
				
				//this.client.connect();  
				return;
			}
			
			this.emit('message', '[BOT] ' + this.name + ' - User Login Successfuly');
			
			if(this.can_info && this.active){
				this.user.setPersona(SteamUser.EPersonaState.Busy)
				this.user.gamesPlayed([{game_id: '730'}]);
			}
		});
		
		if(this.can_info && this.active){
			this.user.on('appLaunched', (appid) => {
				if(!this.gameCoordinator.connected){
					this.user.sendToGC(appid, 4006, {}, Buffer.alloc(0));
					
					this.gameCoordinator.interval = setInterval(() => {
						this.user.sendToGC(appid, 4006, {}, Buffer.alloc(0));
					}, 2500);
				}
			});
		}
		
		this.client.on('loggedOff', (eresult) => {
			this.emit('message', '[BOT] ' + this.name + ' - Client Logout. Client Reconnecting');
			
			this.client.connect();
		});
		
		this.client.on('error', (err1) => {
			if(err1.message == 'Disconnected') {
				this.emit('message', '[BOT] ' + this.name + ' - Client Disconnected. Client Reconnecting');
				
				//this.client.connect();  
			} else this.emit('message', '[BOT] ' + this.name + ' - Client Error. Error: ' + err1.message);
		});
		
		this.community.on('confKeyNeeded', (deepDataAndEvents, updateFunc) => {
			this.emit('message', '[BOT] ' + this.name + ' - Need Confirmation Key');
			
			updateFunc(null, time, SteamTotp.getConfirmationKey(this._bot_props.identity_secret, time(), deepDataAndEvents));
		});
		
		this.community.on('sessionExpired', (err1) => {
			this.emit('message', '[BOT] ' + this.name + ' - Session Expired. Session Are Setting. Error: ' + err1.message);
			this.connected = false;
			
			this.community.stopConfirmationChecker();
			
			this.user.webLogOn();
		});
		
		if(this.manager != null){
			this.manager.on('sentOfferChanged', (offer) => {
				this.emit('sentOfferChanged', {
					bot: this.steamid,
					offer: offer
				});
			});
			
			this.manager.on('newOffer', (offer) => {
				this.emit('newOffer', {
					bot: this.steamid,
					offer: offer
				});
			});
		}
		
		this.community.on('confirmationAccepted', (offer) => {
			this.emit('confirmationAccepted', {
				bot: this.steamid,
				offer: offer
			});
		});
		
		this.user.on('webSession', (sessionid, cookies) => {
			this.emit('message', '[BOT] ' + this.name + ' - Session Cookies Have Been Set');
			
			this.cookies = cookies;
			
			if(this.manager != null){
				this.manager.setCookies(cookies, (err1) => {
					if(err1) {
						this.emit('error', err1);
						
						return;
						//process.exit(1);
					}
				});
			}
			
			this.community.setCookies(cookies);
			this.community.startConfirmationChecker(5000, this._bot_props.identity_secret);
			
			setTimeout(() => {
				this.connected = true;
				
				this.emit('ready', this.steamid);
			}, 1000);
		});
	}
	
	addQueueRequestInspect(request) {
		var firstRequest = false;
		if(this.queueRequestInspect.length <= 0) firstRequest = true;
		
		this.queueRequestInspect.push(request);
		
		if(firstRequest) this.requestInspect(this.queueRequestInspect[0].inspect);
	}
	
	requestInspect(inspect){
		if(!this.gameCoordinator.connected) return this.confirmInspect(null);
		
		var payload = new protos.CMsgGCCStrike15_v2_Client2GCEconPreviewDataBlockRequest({
			param_s: inspect.s.toString(),
			param_a: inspect.a.toString(),
			param_d: inspect.d.toString(),
			param_m: '0',
		});
		
		this.user.sendToGC(this.gameCoordinator.appid, 9156, {}, payload.toBuffer());
		
		setTimeout(() => {
			if(this.queueRequestInspect.length > 0) if(inspect.a == this.queueRequestInspect[0].inspect.a) this.requestInspect(inspect);
		}, 5000);
	}
	
	confirmInspect(inspect){
		this.queueRequestInspect[0].callback(this.queueRequestInspect[0].index, inspect);
		
		this.queueRequestInspect.shift();
		
		if(this.queueRequestInspect.length > 0){
			setTimeout(() => {
				this.requestInspect(this.queueRequestInspect[0].inspect);
			}, 500);
		}
	}
};

module.exports = Bot;