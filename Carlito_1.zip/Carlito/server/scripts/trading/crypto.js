var coinpayments = require('coinpayments');

var client = new coinpayments({
	key: config.config_offers.coinpayments.apikey.public_key,
	secret: config.config_offers.coinpayments.apikey.private_key
});

/*client.balances({all: 1}, function(err1, result1){
	if(err1) return logger.error(err1);
	
	Object.keys(result1).forEach(function(prop){
		if(parseFloat(result1[prop]['balancef']) > 0) {
			logger.debug(prop);
			logger.debug(result1[prop]);
		}
	});
});*/

var cryptoSystem_currencyAmount = {};

var cryptoSystem_transactionsChecking = false;

crypto_initializing();
function crypto_initializing(){
	site_pricesUpdate_crypto = true;
	
	cryptoSystem_updateCurrencies(0, function(){
		crypto_startCheckingTransactions();
		
		logger.debug('[CRYPTO] Prices loaded');
		
		site_pricesUpdate_crypto = false;
		
		setInterval(function(){
			site_pricesUpdate_crypto = true;
			
			cryptoSystem_updateCurrencies(0, function(){
				logger.debug('[CRYPTO] Prices loaded');
				
				site_pricesUpdate_crypto = false;
			});
		}, config.config_offers.coinpayments.prices.cooldown_load * 1000);
	});
}

function crypto_startCheckingTransactions(){
	cryptoSystem_checkTransactions();
	
	setInterval(function(){
		if(!cryptoSystem_transactionsChecking) {
			cryptoSystem_checkTransactions();
		} else logger.error('[CRYPTO] Transactions are still checking');
	}, config.config_offers.coinpayments.cooldown_check * 1000);
}

function cryptoSystem_updateCurrencies(item, callback){
	var games = Object.keys(config.settings.trades.crypto.enable.deposit).concat(Object.keys(config.settings.trades.crypto.enable.withdraw));
	var check = games.filter((item, pos) => games.indexOf(item) === pos);
	
	if(check[item] === undefined) return callback();
	
	request('https://min-api.cryptocompare.com/data/price?fsym=' + check[item] + '&tsyms=USD', function(err1, response1, body1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		if(response1 && response1.statusCode == 200){
			var body1 = JSON.parse(body1);
			var data1 = body1['USD'];
			
			cryptoSystem_currencyAmount[check[item]] = parseFloat(data1);
			
			cryptoSystem_updateCurrencies(item + 1, callback);
		}
	});
}

function cryptoSystem_checkTransactions() {
	logger.debug('[CRYPTO] Checking transactions');
	
	cryptoSystem_transactionsChecking = true;
	
  	pool.query('SELECT * FROM `crypto_transactions` WHERE `inspected` = 0', async function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			cryptoSystem_transactionsChecking = false;
			return;
		}
		
		for(var i = 0; i < row1.length; i++) await cryptoSystem_checkTransactionsByOne(row1[i]);
		
		cryptoSystem_transactionsChecking = false;
	});
}

function cryptoSystem_checkTransactionsByOne(transaction){
  	return new Promise(function(resolve, reject) {
		var type = transaction.type;
		var status = parseInt(transaction.status);
		
		var txnid = transaction.txnid;
		var currency = transaction.currency;
		var value = parseFloat(transaction.value);
		
		var user = {
			userid: transaction.userid,
			name: transaction.name,
			avatar: transaction.avatar,
			level: calculateLevel(transaction.xp).level
		}
		
		var amount = getFormatAmount(transaction.amount);
		
		if(type == 'deposit'){
			if(status == 100){
				if(Object.keys(config.settings.trades.crypto.enable.deposit).includes(currency)){
					if(config.settings.trades.crypto.enable.deposit[currency]){
						if(cryptoSystem_currencyAmount[currency] > 0){
							var exchange = cryptoSystem_currencyAmount[currency];
							var amount_calculated = getFormatAmount(exchange * value);
							
							pool.query('UPDATE `crypto_transactions` SET `inspected` = 1, `amount` = ' + amount_calculated + ', `exchange` = ' + exchange + ' WHERE `id` = ' + pool.escape(transaction.id), function(err1, row1) {
								if(err1) {
									logger.error(err1);
									writeError(err1);
									
									resolve();
									return;
								}
								
								if(row1.affectedRows > 0){
									//EDIT BALANCE
									user_editBalance(user.userid, amount_calculated, currency + '_deposit', function(err2){
										if(err2) {
											logger.error(err2);
											writeError(err2);
											
											resolve();
											return;
										}
										
										user_updateBalance(user.userid);
										
										pool.query('UPDATE `users` SET `deposit_count` = `deposit_count` + 1, `deposit_total` = `deposit_total` + ' + amount_calculated + ' WHERE `userid` = ' + pool.escape(user.userid), function(err3) {
											if(err3) {
												logger.error(err3);
												writeError(err3);
												
												resolve();
												return;
											}
											
											//REGISTER AFFILIATES
											user_registerAffiliates(user.userid, amount_calculated, 'deposit', function(err4){
												if(err4) {
													logger.error(err4);
													writeError(err4);
													
													resolve();
													return;
												}
												
												//REGISTER DEPOSIT BONUS
												user_registerDepositBonus(user.userid, amount_calculated, function(err5){
													if(err5) {
														logger.error(err5);
														writeError(err5);
														
														resolve();
														return;
													}
													
													pool.query('INSERT INTO `users_trades` SET `type` = ' + pool.escape(type) + ', `method` = ' + pool.escape("crypto") + ', `game` = ' + pool.escape(currency) + ', `userid` = ' + pool.escape(user.userid) + ', `amount` = ' + amount_calculated + ', `value` = ' + parseFloat(value) + ', `tradeid` = ' + parseInt(transaction.id) + ', `time` = ' + pool.escape(time()), function(err6){
														if(err6) {
															logger.error(err6);
															writeError(err6);
															
															resolve();
															return;
														}
														
														io.sockets.in(user.userid).emit('message', {
															type: 'success',
															success: 'Your crypto deposit order has been finished! You received the money.'
														});
														
														logger.debug('[CRYPTO] Deposit order #' + transaction.id + ' has been finished');
														
														resolve();
													});
												});
											});
										});
									});
								} else resolve();
							});
						} else resolve();
					} else resolve();
				} else resolve();
			} else resolve();
		} else if(type == 'withdraw'){
			if(status == 2){
				pool.query('UPDATE `crypto_transactions` SET `inspected` = 1 WHERE `id` = ' + pool.escape(transaction.id), function(err1, row1) {
					if(err1) {
						logger.error(err1);
						writeError(err1);
						
						resolve();
						return;
					}
					
					if(row1.affectedRows > 0){
						pool.query('INSERT INTO `users_trades` SET `type` = ' + pool.escape(type) + ', `method` = ' + pool.escape("crypto") + ', `game` = ' + pool.escape(currency) + ', `userid` = ' + pool.escape(user.userid) + ', `amount` = ' + amount + ', `value` = ' + parseFloat(value) + ', `tradeid` = '+ parseInt(transaction.id) + ', `time` = ' + pool.escape(time()), function(err2){
							if(err2) {
								logger.error(err2);
								writeError(err2);
								
								resolve();
								return;
							}
						
							pool.query('UPDATE `users` SET `withdraw_count` = `withdraw_count` + 1, `withdraw_total` = `withdraw_total` + ' + amount + ' WHERE `userid` = ' + pool.escape(user.userid), function(err3) {
								if(err3) {
									logger.error(err3);
									writeError(err3);
									
									resolve();
									return;
								}
								
								io.sockets.in(user.userid).emit('message', {
									type: 'success',
									success: 'Your crypto withdraw order has been finished!'
								});
								
								logger.debug('[CRYPTO] Withdraw order #' + transaction.id + ' has been finished');
								
								resolve();
							});
						});
					} else resolve();
				});
			} else if(status < 0){
				pool.query('UPDATE `crypto_transactions` SET `inspected` = 1 WHERE `id` = ' + pool.escape(transaction.id), function(err1, row1) {
					if(err1) {
						logger.error(err1);
						writeError(err1);
						
						resolve();
						return;
					}
					
					if(row1.affectedRows > 0){
						//EDIT BALANCE
						user_editBalance(user.userid, amount, currency + '_withdraw_refund', function(err2){
							if(err2) {
								logger.error(err2);
								writeError(err2);
								
								resolve();
								return;
							}
							
							user_updateBalance(user.userid);
							
							pool.query('UPDATE `users` SET `available` = `available` + ' + amount + ' WHERE `userid` = ' + pool.escape(user.userid), function(err3) {
								if(err3) {
									logger.error(err3);
									writeError(err3);
									
									resolve();
									return;
								}
								
								logger.debug('[CRYPTO] Withdraw order #' + transaction.id + ' has been refunded');
								
								resolve();
							});
						});
					} else resolve();
				});
			} else resolve();
		} else resolve();
	});
}

function cryptoSystem_withdraw(user, socket, currency, amount, address, recaptcha, cooldown){
	cooldown(true, true);
	
	site_verifyRecaptcha(recaptcha, function(verified){
		if(!verified){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid recaptcha!'
			});
			
			return cooldown(false, true);
		}
	
		if(config.settings.trades.manually.enable.crypto && getFormatAmount(amount) >= getFormatAmount(config.settings.trades.manually.amount)) {
			return cryptoSystem_withdrawManually(user, currency, amount, address, function(err1, transactionid){
				if(err1){
					socket.emit('message', {
						type: 'error',
						error: err1.message
					});
					
					return cooldown(false, true);
				}
				
				socket.emit('message', {
					type: 'info',
					info: 'Your crypto withdraw order was listed. Admin confirmations required!'
				});
				
				cooldown(false, false);
			});
		}
		
		cryptoSystem_withdrawAutomatically(user, currency, amount, address, function(err1, listingid){
			if(err1){
				socket.emit('message', {
					type: 'error',
					error: err1.message
				});
				
				return cooldown(false, true);
			}
			
			socket.emit('message', {
				type: 'info',
				info: 'Your crypto withdraw order was prepared!'
			});
			
			cooldown(false, false);
		});
	});
}

function cryptoSystem_withdrawManually(user, currency, amount, address, callback){
	if((user.restrictions.trade >= time() || user.restrictions.trade == -1) && !config.config_site.bantrade_excluded.includes(config.config_site.ranks_name[user.rank])) return callback(new Error('Error: You are restricted to use our trade. The restriction expires ' + ((user.restrictions.trade == -1) ? 'never' : makeDate(new Date(user.restrictions.trade * 1000))) + '.'));
	
	if(!user.verified > time()) return callback(new Error('Error: Your account is not verified. Please verify your account and try again.'));
	
	if(!Object.keys(config.settings.trades.crypto.enable.withdraw).includes(currency)) return callback(new Error('Error: Invalid currency!'));
	if(!config.settings.trades.crypto.enable.withdraw[currency]) return callback(new Error('Error: Invalid currency!'));
	
	if(cryptoSystem_currencyAmount[currency] === undefined) return callback(new Error('Error: The prices are not loaded. Please try again later!'));
	if(cryptoSystem_currencyAmount[currency] <= 0) return callback(new Error('Error: The prices are not loaded. Please try again later!'));

	site_verifyFormatAmount(amount, function(err1, amount){
		if(err1) return callback(err1);
		
		if(amount < config.config_site.interval_amount.withdraw_crypto.min || amount > config.config_site.interval_amount.withdraw_crypto.max) return callback(new Error('Error: Invalid withdraw amount [' + getFormatAmountString(config.config_site.interval_amount.withdraw_crypto.min) + '-' + getFormatAmountString(config.config_site.interval_amount.withdraw_crypto.max)  + ']!'));
		
		if(user.deposit.count <= 0) return callback(new Error('Error: You need to deposit minimum 1 time to withdraw!'));
		
		//CHECK BALANCE
		user_getBalance(user.userid, function(err2, balance){
			if(err2) return callback(err2);
		
			if(balance < amount){
				io.sockets.in(user.userid).emit('message', {
					type: 'modal',
					modal: 'insufficient_balance',
					data: {
						amount: getFormatAmount(amount - balance)
					}
				});
				
				return callback(new Error('You don\'t have enough money to withdraw!'));
			}
		
			if(user.available < amount) return callback(new Error('Error: You need to have withdraw available ' + getFormatAmountString(amount) + ' coins. Need ' + getFormatAmountString(amount - user.available) + '!'));
				
			pool.query('SELECT * FROM `crypto_listings` WHERE `address` = ' + pool.escape(address) + ' AND `type` = ' + pool.escape('withdraw') + ' AND `confirmed` = 0 AND `canceled` = 0', function(err3, row3) {
				if(err3){
					logger.error(err3);
					writeError(err3);
					return callback(new Error('Error in crypto manually withdraw (1)'));
				}
				
				if(row3.length > 0) return callback(new Error('This address is already in a withdraw transaction. Please try again later!'));
				
				//EDIT BALANCE
				user_editBalance(user.userid, -amount, currency + '_withdraw', function(err4){
					if(err4) {
						logger.error(err4);
						writeError(err4);
						return callback(new Error('Error in crypto manually withdraw (2)'));
					}
					
					user_updateBalance(user.userid);
					
					pool.query('UPDATE `users` SET `available` = `available` - ' + amount + ' WHERE `userid` = ' + pool.escape(user.userid), function(err5) {
						if(err5) {
							logger.error(err5);
							writeError(err5);
							return callback(new Error('Error in crypto manually withdraw (3)'));
						}
						
						pool.query('INSERT INTO `crypto_listings` SET `type` = ' + pool.escape('withdraw') + ', `userid` = ' + pool.escape(user.userid) + ', `address` = ' + pool.escape(address) + ', `currency` = ' + pool.escape(currency) + ', `amount` = ' + amount + ', `time` = ' + pool.escape(time()), function(err6, row6) {
							if(err6) {
								logger.error(err6);
								writeError(err6);
								return callback(new Error('Error in crypto manually withdraw (4)'));
							}
							
							logger.debug('[CRYPTO] Withdraw listing #' + row6.insertId + ' has been listed. Admin confirmations required');
							
							callback(null, row6.insertId);
						});
					});
				});
			});
		});
	});
}

function cryptoSystem_listingConfirm(user, id, callback){
	pool.query('SELECT * FROM `crypto_listings` WHERE `id` = ' + pool.escape(id), function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return callback(new Error('Error in confirming crypto withdraw listing (1)'));
		}
		
		if(row1.length <= 0) return callback(new Error('Error: Unknown crypto withdraw listing!'));
		if(parseInt(row1[0].confirmed)) return callback(new Error('Error: Crypto withdraw listing already confirmed!'));
		if(parseInt(row1[0].canceled)) return callback(new Error('Error: Crypto withdraw listing is canceled!'));
		
		pool.query('SELECT * FROM `users` WHERE `userid` = ' + pool.escape(row1[0].userid), function(err2, row2) {
			if(err2) {
				logger.error(err2);
				writeError(err2);
				return callback(new Error('Error in confirming crypto withdraw listing (2)'));
			}
			
			if(row2.length <= 0) return callback(new Error('Error: Unknown user listing!'));
			
			var currency = row1[0].currency;
			var amount = getFormatAmount(row1[0].amount);
			var address = row1[0].address;
			
			if(cryptoSystem_currencyAmount[currency] === undefined) return callback(new Error('Error: The prices are not loaded. Please try again later!'));
			if(cryptoSystem_currencyAmount[currency] <= 0) return callback(new Error('Error: The prices are not loaded. Please try again later!'));
			
			var exchange = cryptoSystem_currencyAmount[currency];
			var value = parseFloat(amount / exchange);
			
			var options_withdraw = {
				amount: value,
				currency: currency,
				address: address
			}
			
			client.balances({all: 1}, function(err3, result3){
				if(err3) {
					logger.error(err3);
					writeError(err3);
					return callback(new Error('Error in confirming crypto withdraw listing (3)'));
				}
				
				var new_result3 = lowercaseKeysObject(result3);
				
				if(new_result3[currency] === undefined) return callback(new Error('Error: The bank don\'t have that currency!'));
				if(new_result3[currency]['status'] == 'unavailable') return callback(new Error('Error: The bank for that currency is unavailable!'));
				if(new_result3[currency]['coin_status'] == 'offline') return callback(new Error('Error: The bank for that currency is offline!'));
				if(parseFloat(new_result3[currency]['balancef']) < value) return callback(new Error('Error: The bank don\'t have enough money!'));
				
				pool.query('SELECT * FROM `crypto_transactions` WHERE `address` = ' + pool.escape(address) + ' AND `type` = ' + pool.escape('withdraw') + ' AND `inspected` = 0', function(err4, row4) {
					if(err4){
						logger.error(err4);
						writeError(err4);
						return callback(new Error('Error in confirming crypto withdraw listing (4)'));
					}
					
					if(row4.length > 0) return callback(new Error('This address is already in a withdraw transaction. Please try again later!'));
				
					client.createWithdrawal(options_withdraw, function(err5, result5){
						if(err5) {
							logger.error(err5);
							writeError(err5);
							return callback(new Error('Error in confirming crypto withdraw listing (5)'));
						}
						
						client.getWithdrawalInfo({id: result5.id}, function(err6, result6){
							if(err6) {
								logger.error(err6);
								writeError(err6);
								return callback(new Error('Error in confirming crypto withdraw listing (6)'));
							}
							
							pool.query('INSERT INTO `crypto_transactions` SET `type` = ' + pool.escape('withdraw') + ', `userid` = ' + pool.escape(row2[0].userid) + ', `name` = ' + pool.escape(row2[0].name) + ', `avatar` = ' + pool.escape(row2[0].avatar) + ', `xp` = ' + pool.escape(row2[0].xp) + ', `address` = ' + pool.escape(address) + ', `status` = ' + pool.escape(result6.status) + ', `currency` = ' + pool.escape(currency) + ', `amount` = ' + amount + ', `value` = ' + parseFloat(result6.amountf) + ', `exchange` = ' + exchange + ', `time` = ' + pool.escape(time()), function(err7, row7) {
								if(err7) {
									logger.error(err7);
									writeError(err7);
									return callback(new Error('Error in confirming crypto withdraw listing (7)'));
								}
								
								io.sockets.in(row2[0].userid).emit('message', {
									type: 'info',
									info: 'Your crypto withdraw order was confirmed. Admin confirmations required!'
								});
								
								logger.debug('[CRYPTO] Withdraw listing #' + row7.insertId + ' has been listed. Admin confirmations required');
								
								pool.query('UPDATE `crypto_listings` SET `confirmed` = 1 WHERE `id` = ' + pool.escape(row1[0].id) + ' AND `confirmed` = 0 AND `canceled` = 0', function(err8) {
									if(err8) {
										logger.error(err8);
										writeError(err8);
										return callback(new Error('Error in confirming crypto withdraw listing (8)'));
									}
									
									pool.query('INSERT INTO `crypto_confirmations` SET `userid` = ' + pool.escape(user.userid) + ', `listingid` = ' + pool.escape(row1[0].id) + ', `transactionid` = ' + pool.escape(row7.insertId), function(err9) {
										if(err9) {
											logger.error(err9);
											writeError(err9);
											return callback(new Error('Error in confirming crypto withdraw listing (9)'));
										}
										
										callback(null, row7.insertId);
									});
								});
							});
						});
					});
				});
			});
		});
	});
}

function cryptoSystem_listingCancel(user, id, callback){
	pool.query('SELECT * FROM `crypto_listings` WHERE `id` = ' + pool.escape(id), function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return callback(new Error('Error in canceling crypto withdraw listing (1)'));
		}
		
		if(row1.length <= 0) return callback(new Error('Error: Unknown crypto withdraw listing!'));
		if(parseInt(row1[0].confirmed)) return callback(new Error('Error: Crypto withdraw listing id confirmed!'));
		if(parseInt(row1[0].canceled)) return callback(new Error('Error: Crypto withdraw listing already canceled!'));
		
		var currency = row1[0].currency;
		var amount = getFormatAmount(row1[0].amount);
		
		//EDIT BALANCE
		user_editBalance(row1[0].userid, amount, currency + '_withdraw_refund', function(err2){
			if(err2) {
				logger.error(err2);
				writeError(err2);
				return callback(new Error('Error in canceling crypto withdraw listing (2)'));
			}
			
			user_updateBalance(row1[0].userid);
			
			pool.query('UPDATE `users` SET `available` = `available` + ' + amount + ' WHERE `userid` = ' + pool.escape(row1[0].userid), function(err3) {
				if(err3) {
					logger.error(err3);
					writeError(err3);
					return callback(new Error('Error in canceling crypto withdraw listing (3)'));
				}
				
				pool.query('UPDATE `crypto_listings` SET `canceled` = 1 WHERE `id` = ' + pool.escape(row1[0].id) + ' AND `confirmed` = 0 AND `canceled` = 0', function(err4) {
					if(err4) {
						logger.error(err4);
						writeError(err4);
						return callback(new Error('Error in canceling crypto withdraw listing (4)'));
					}
					
					io.sockets.in(row1[0].userid).emit('message', {
						type: 'info',
						info: 'Your crypto withdraw order was canceled!'
					});
				
					logger.debug('[CRYPTO] Withdraw listing #' + row1[0].id + ' has been canceled');
					
					callback(null);
				});
			});
		});
	});
}

function cryptoSystem_withdrawAutomatically(user, currency, amount, address, callback){
	if((user.restrictions.trade >= time() || user.restrictions.trade == -1) && !config.config_site.bantrade_excluded.includes(config.config_site.ranks_name[user.rank])) return callback(new Error('Error: You are restricted to use our trade. The restriction expires ' + ((user.restrictions.trade == -1) ? 'never' : makeDate(new Date(user.restrictions.trade * 1000))) + '.'));
	
	if(!user.verified > time()) return callback(new Error('Error: Your account is not verified. Please verify your account and try again.'));
	
	if(!Object.keys(config.settings.trades.crypto.enable.withdraw).includes(currency)) return callback(new Error('Error: Invalid currency!'));
	if(!config.settings.trades.crypto.enable.withdraw[currency]) return callback(new Error('Error: Invalid currency!'));
	
	if(cryptoSystem_currencyAmount[currency] === undefined) return callback(new Error('Error: The prices are not loaded. Please try again later!'));
	if(cryptoSystem_currencyAmount[currency] <= 0) return callback(new Error('Error: The prices are not loaded. Please try again later!'));

	site_verifyFormatAmount(amount, function(err1, amount){
		if(err1) return callback(err1);
		
		if(amount < config.config_site.interval_amount.withdraw_crypto.min || amount > config.config_site.interval_amount.withdraw_crypto.max) return callback(new Error('Error: Invalid withdraw amount [' + getFormatAmountString(config.config_site.interval_amount.withdraw_crypto.min) + '-' + getFormatAmountString(config.config_site.interval_amount.withdraw_crypto.max)  + ']!'));
		
		if(user.deposit.count <= 0) return callback(new Error('Error: You need to deposit minimum 1 time to withdraw!'));
		
		//CHECK BALANCE
		user_getBalance(user.userid, function(err2, balance){
			if(err2) return callback(err2);
			
			if(balance < amount){
				io.sockets.in(user.userid).emit('message', {
					type: 'modal',
					modal: 'insufficient_balance',
					data: {
						amount: getFormatAmount(amount - balance)
					}
				});
				
				return callback(new Error('You don\'t have enough money to withdraw!'));
			}
		
			if(user.available < amount) return callback(new Error('Error: You need to have withdraw available ' + getFormatAmountString(amount) + ' coins. Need ' + getFormatAmountString(amount - user.available) + '!'));
			
			var exchange = cryptoSystem_currencyAmount[currency];
			var value = parseFloat(amount / exchange);
			
			var options_withdraw = {
				amount: value,
				currency: currency,
				address: address
			}
			
			client.balances({all: 1}, function(err3, result3){
				if(err3) {
					logger.error(err3);
					writeError(err3);
					return callback(new Error('Error in crypto automatically withdraw (1)'));
				}
				
				var new_result3 = lowercaseKeysObject(result3);
				
				if(new_result3[currency] === undefined) return callback(new Error('Error: The bank don\'t have that currency!'));
				if(new_result3[currency]['status'] == 'unavailable') return callback(new Error('Error: The bank for that currency is unavailable!'));
				if(new_result3[currency]['coin_status'] == 'offline') return callback(new Error('Error: The bank for that currency is offline!'));
				if(parseFloat(new_result3[currency]['balancef']) < value) return callback(new Error('Error: The bank don\'t have enough money!'));
				
				pool.query('SELECT * FROM `crypto_transactions` WHERE `address` = ' + pool.escape(address) + ' AND `type` = ' + pool.escape('withdraw') + ' AND `inspected` = 0', function(err4, row4) {
					if(err4){
						logger.error(err4);
						writeError(err4);
						return callback(new Error('Error in crypto automatically withdraw (2)'));
					}
					
					if(row4.length > 0) return callback(new Error('This address is already in a withdraw transaction. Please try again later!'));
				
					client.createWithdrawal(options_withdraw, function(err5, result5){
						if(err5) {
							logger.error(err5);
							writeError(err5);
							return callback(new Error('Error in crypto automatically withdraw (3)'));
						}
						
						//EDIT BALANCE
						user_editBalance(user.userid, -amount, currency + '_withdraw', function(err6){
							if(err6) {
								logger.error(err6);
								writeError(err6);
								return callback(new Error('Error in crypto automatically withdraw (4)'));
							}
							
							user_updateBalance(user.userid);
							
							pool.query('UPDATE `users` SET `available` = `available` - ' + amount + ' WHERE `userid` = ' + pool.escape(user.userid), function(err7) {
								if(err7) {
									logger.error(err7);
									writeError(err7);
									return callback(new Error('Error in crypto automatically withdraw (5)'));
								}
							
								client.getWithdrawalInfo({id: result5.id}, function(err8, result8){
									if(err8) {
										logger.error(err8);
										writeError(err8);
										return callback(new Error('Error in crypto automatically withdraw (6)'));
									}
									
									pool.query('INSERT INTO `crypto_transactions` SET `type` = ' + pool.escape('withdraw') + ', `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + pool.escape(user.xp) + ', `address` = ' + pool.escape(address) + ', `status` = ' + pool.escape(result8.status) + ', `currency` = ' + pool.escape(currency) + ', `amount` = ' + amount + ', `value` = ' + parseFloat(result8.amountf) + ', `exchange` = ' + exchange + ', `time` = ' + pool.escape(time()), function(err9, row9) {
										if(err9) {
											logger.error(err9);
											writeError(err9);
											return callback(new Error('Error in crypto automatically withdraw (7)'));
										}
										
										logger.debug('[CRYPTO] Withdraw order #' + row9.insertId + ' has been prepared');
										
										callback(null, row9.insertId);
									});
								});
							});
						});
					});
				});
			});
		});
	});
}

function cryptoSystem_generateAddress(user, socket, currency, recaptcha, cooldown){
	cooldown(true, true);
	
	site_verifyRecaptcha(recaptcha, function(verified){
		if(!verified){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid recaptcha!'
			});
			
			return cooldown(false, true);
		}
	
		if(!Object.keys(config.settings.trades.crypto.enable.deposit).includes(currency)){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid currency!'
			});
			
			return cooldown(false, true);
		}
		
		if(!config.settings.trades.crypto.enable.deposit[currency]){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid currency!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('SELECT * FROM `crypto_addresses` WHERE `userid` = ' + pool.escape(user.userid) + ' AND `currency` = ' + pool.escape(currency), function(err1, row1) {
			if(err1) {
				logger.error(err1);
				writeError(err1);
				
				return cooldown(false, true);
			}
		
			if(row1.length > 0){
				socket.emit('message', {
					type: 'error',
					error: 'Error: You have already a address created!'
				});
				
				return cooldown(false, true);
			}
			
			client.getCallbackAddress({currency: currency}, function(err2, result2){
				if(err2) {
					logger.error(err2);
					writeError(err2);
					
					return cooldown(false, true);
				}
				
				pool.query('INSERT INTO `crypto_addresses` SET `address` = ' + pool.escape(result2.address) + ', `currency` = ' + pool.escape(currency) + ', `userid` = ' + pool.escape(user.userid) + ', `time` = ' + pool.escape(time()), function(err3, row3) {
					if(err3) {
						logger.error(err3);
						writeError(err3);
						
						return cooldown(false, true);
					}
					
					socket.emit('message', {
						type: 'success',
						success: currency.toUpperCase() + ' Address successfully created!'
					});
					
					socket.emit('message', {
						type: 'offers',
						command: 'refresh',
						currency: currency,
						address: result2.address
					});
					
					logger.debug('[CRYPTO] Address created. ' + user.name + ' a created ' + currency.toUpperCase() + ' address');
					
					cooldown(false, false);
				});
			});
		});
	});
}