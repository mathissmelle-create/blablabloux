var axios = require('axios');

var totalRequestProxy = {};

var proxyList = [
	//{ host: '123.456.7.89', port: 80, auth: { username: 'username', password: 'password' } }
];

var totalRequestProxy = proxyList.slice().reduce((obj, a) => ({ ...obj, [a.host + ':' + a.port]: {
	total: 0
} }), {});

async function requestProxy(options, callback) {
	var items = proxyList.slice().map(a => ({ ...a, ['total']: totalRequestProxy[a.host + ':' + a.port].total })).sort(function(a, b){ return a.total - b.total });
	
	if(items.length <= 0) return callback(new Error('Error: No active proxies!'));
	
	var item = items[0];
	totalRequestProxy[item.host + ':' + item.port].total++;
	
	var proxy = {
		protocol: 'http',
		host: item.host,
		port: item.port
	};
	
	if(item.auth !== undefined) proxy.auth = item.auth;
	
	axios.get(options.url, { 
		headers: options.headers,
		proxy: proxy,
		params: options.params,
		responseType: 'text'
	}).then(function(response) {
		callback(null, response.status, response.data);
	}).catch(function(error) {
		callback(error);
	});
}

module.exports = requestProxy;