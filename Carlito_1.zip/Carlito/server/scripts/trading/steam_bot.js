/* -------------- BOT -------------- */

var requestProxy = require('./scripts/trading/proxy.js');

// green {"iteminfo":{"accountid":null,"itemid":{"low":-1012148469,"high":6,"unsigned":true},"defindex":520,"paintindex":418,"rarity":6,"quality":3,"paintwear":1032163755,"paintseed":669,"killeaterscoretype":null,"killeatervalue":null,"customname":null,"stickers":[],"inventory":24,"origin":8,"questid":null,"dropreason":null}}
// blue  {"iteminfo":{"accountid":null,"itemid":{"low":719820473,"high":8,"unsigned":true},"defindex":509,"paintindex":421,"rarity":6,"quality":3,"paintwear":1024474664,"paintseed":630,"killeaterscoretype":null,"killeatervalue":null,"customname":null,"stickers":[],"inventory":51,"origin":8,"questid":null,"dropreason":null}}
// blue  {"iteminfo":{"accountid":null,"itemid":{"low":1968167761,"high":4,"unsigned":true},"defindex":516,"paintindex":420,"rarity":6,"quality":3,"paintwear":1022893020,"paintseed":84,"killeaterscoretype":null,"killeatervalue":null,"customname":null,"stickers":[],"inventory":37,"origin":8,"questid":null,"dropreason":null}}

// Falchion Knife | Emerald | Finish Catalog #568 | steam://rungame/730/76561202255233023/+csgo_econ_action_preview%20S76561198036030455A34899583066D14422791081966331008
// Butterfly Knife | Ruby | Finish Catalog #415 | steam://rungame/730/76561202255233023/+csgo_econ_action_preview%20S76561198036030455A35493082651D7531888274119073879
// M9 Bayonet | Phase 3 | Finish Catalog #571 | steam://rungame/730/76561202255233023/+csgo_econ_action_preview%20S76561198036030455A35466122419D9271823303905868622

// {"iteminfo":{"accountid":null,"itemid":{"low":539844698,"high":8,"unsigned":true},"defindex":512,"paintindex":568,"rarity":6,"quality":3,"paintwear":1024218539,"paintseed":191,"killeaterscoretype":null,"killeatervalue":null,"customname":null,"stickers":[],"inventory":258,"origin":8,"questid":null,"dropreason":null}}
// {"iteminfo":{"accountid":null,"itemid":{"low":1133344283,"high":8,"unsigned":true},"defindex":515,"paintindex":415,"rarity":6,"quality":3,"paintwear":1031248803,"paintseed":408,"killeaterscoretype":null,"killeatervalue":null,"customname":null,"stickers":[],"inventory":75,"origin":8,"questid":null,"dropreason":null}}
// {"iteminfo":{"accountid":null,"itemid":{"low":1106384051,"high":8,"unsigned":true},"defindex":508,"paintindex":571,"rarity":6,"quality":3,"paintwear":1018669670,"paintseed":54,"killeaterscoretype":null,"killeatervalue":null,"customname":null,"stickers":[],"inventory":263,"origin":8,"questid":null,"dropreason":null}}

// {"iteminfo":{"accountid":null,"itemid":{"low":-204125691,"high":6,"unsigned":true},"defindex":39,"paintindex":1022,"rarity":1,"quality":12,"paintwear":1032362474,"paintseed":661,"killeaterscoretype":null,"killeatervalue":null,"customname":null,"stickers":[{"slot":0,"sticker_id":4965,"wear":0,"scale":1,"rotation":0},{"slot":1,"sticker_id":1689,"wear":0,"scale":1,"rotation":0},{"slot":2,"sticker_id":4981,"wear":0,"scale":1,"rotation":0},{"slot":3,"sticker_id":5053,"wear":0,"scale":1,"rotation":0}],"inventory":12,"origin":8,"questid":null,"dropreason":null}}

function getUserInventory(steamid, appid, contextid, callback){
	var bot = offers_steamBots[getBotBySteamid(steamid)];
	
	var count = 5000;
	
	var headers = {};
	
	if(bot !== undefined){
		if(bot.connected && bot.active) headers['Cookie'] = bot.cookies.join('; ') + ';';
	}
	
	var options = {
		headers: headers,
		url: 'https://steamcommunity.com/inventory/' + steamid + '/' + appid + '/' + contextid,
		params: {
			'l': 'english',
			'count': count
		}
	}
	
	requestProxy(options, function(err1, response1, body1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return callback(err1);
		}
		
		if(response1 != 200) return callback(new Error('Error. (1)'));
		
		var body = JSON.parse(body1);
		
		if(!body.assets || !body.descriptions) return callback(new Error('Error. (2)'));
		
		var descriptions = body.descriptions.slice().reduce((obj, a) => ({ ...obj, [a.classid + '_' + a.instanceid]: a }), {});
		var assets = body.assets.slice().map(a => ({ ...descriptions[a.classid + '_' + a.instanceid], ['assetid']: a.assetid }));
		
		var items = [];
		
		assets.forEach(function(item){
			//INSPECT
			var inspect = null;
			if(item.actions !== undefined){
				var actions = item.actions[0];
				if(actions !== undefined){
					inspect = actions.link;
					inspect = inspect.replace("%owner_steamid%", steamid);
					inspect = inspect.replace("%assetid%", item.assetid);
				}
			}
			
			//QUALITY
			var color = null;
			item.tags.forEach(function(tag){
				if(tag.category !== undefined){
					if(tag.category == 'Rarity'){
						color = tag.color;						
						if(color.indexOf('#') < 0) color = '#' + color;
					}
				}
			});
			
			//STICKERS
			var stickers = [];
			if(item.descriptions !== undefined){
				if(Array.isArray(item.descriptions)){
					item.descriptions.forEach(function(description){
						if(description.value !== undefined){
							var value = description.value;
							
							if(value.indexOf('sticker_info') != -1){
								var dates = value.split('<center>')[1];
								dates = dates.split('</center>')[0];
								
								if(dates.indexOf('Sticker') != -1) dates = dates.split('<br>Sticker: ');
								else if(dates.indexOf('Patch') != -1) dates = dates.split('<br>Patch: ');
								
								if(dates.length == 2) {
									var images = dates[0].split('">');
									delete images[images.length - 1]; 
									
									var names = dates[1].split(', ');
									
									images.forEach(function(image, index){
										stickers.push({
											image: image.split('src="')[1],
											name: names[index]
										});
									});
								}
							}
						}
					});
				}
			}
			
			//TRADELOCKED
			var tradelocked = null;
			if(item.owner_descriptions !== undefined) {
				if(Array.isArray(item.owner_descriptions)){
					item.owner_descriptions.forEach(function(description){
						if(description.value !== undefined){
							var value = description.value;
							var exp = /Tradable After (.*)/i.exec(value);
							
							if(exp) if(exp.length > 1) tradelocked = parseInt(new Date(exp[1]).getTime() / 1000);
						}
					});
				}
			}
			
			if(!tradelocked && item.marketable && !item.tradable) tradelocked = parseInt(new Date() / 1000) + 7 * 24 * 60 * 60;
			
			items.push({
				assetid: item.assetid,
				classid: item.classid,
				instanceid: item.instanceid,
				
				game: Object.keys(config.config_offers.steam.games).find(a => config.config_offers.steam.games[a].game.appid == appid) || null,
				name: item.market_name || item.market_hash_name || item.name,
				image: 'https://steamcommunity-a.akamaihd.net/economy/image/' + (item.icon_url_large || item.icon_url),
				price: 0,
				offset: 0,
				color: color,
				stickers: stickers,
				wear: null,
				
				inspect: inspect,
				tradable: item.tradable,
				marketable: item.marketable,
				tradelocked: tradelocked
			});
		});
		
		callback(null, items);
	});
}
function getUserInventoryAssetids(steamid, appid, contextid, callback){
	var bot = offers_steamBots[getBotBySteamid(steamid)];
	
	var count = 5000;
	
	var headers = {};
	
	if(bot !== undefined){
		if(bot.connected && bot.active) headers['Cookie'] = bot.cookies.join('; ') + ';';
	}
	
	var options = {
		headers: headers,
		url: 'https://steamcommunity.com/inventory/' + steamid + '/' + appid + '/' + contextid,
		params: {
			'l': 'english',
			'count': count
		}
	}
	
	requestProxy(options, function(err1, response1, body1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return callback(err1);
		}
		
		if(response1 != 200) return callback(new Error('Error. (1)'));
		
		var body = JSON.parse(body1);
		
		if(!body.assets || !body.descriptions) return callback(new Error('Error. (2)'));
		
		var items = [];
		
		callback(null, body.assets.map(a => a.assetid));
	});
}

var offers_steamUsersInspect = {};

function requestItemsInspect(user, items, callback){
	if(!haveActiveBots('info')) return callback(new Error('No active bots'), items);
	
	if(offers_steamUsersInspect[user] !== undefined) return [];
	
	offers_steamUsersInspect[user] = {
		pos_array: [],
		
		user: user,
		items: items,
		
		callback: callback,
		
		new_items: [],
		
		start: function(){
			for(var i = 0; i < this.items.length; i++) this.pos_array.push(0);
		},
		
		registerInspect: function(index, inspect){
			this.pos_array[index] = 1;
			
			var new_item = this.items[index].item;
			new_item.wear = inspect.wear;
			new_item.paintindex = inspect.paintindex;
			
			this.new_items.push(new_item);
			
			var copy_pos_array = [...this.pos_array];
			copy_pos_array.sort(function(a, b){ return a - b});
			
			if(copy_pos_array[0] == 1) {
				this.callback(null, this.new_items);
				
				delete offers_steamUsersInspect[this.user];
			}
		}
	}
	
	offers_steamUsersInspect[user].start();
	
	items.forEach(function(item, i){
		addQueueRequestInspect({
			index: i,
			inspect: item.inspect,
			callback: function(index, wear){
				if(offers_steamUsersInspect[user] !== undefined){
					offers_steamUsersInspect[user].registerInspect(index, wear);
				}
			}
		})
	})
}

//BOT STEAM
var BotManager = require('./scripts/trading/steam_bot_manager');

var offers_steamBots = [];

instantiateSteamBots();

function instantiateSteamBots(){
	config.config_offers.steam.bots.forEach(function(bot){
		var new_steam_bots = new BotManager(bot);
		
		new_steam_bots.on('error', steamBotError);
		new_steam_bots.on('message', steamBotMessage);
		new_steam_bots.on('ready', steamBotReady);
		
		new_steam_bots.on('sentOfferChanged', steamBotSentOfferChanged);
		new_steam_bots.on('newOffer', steamBotNewOffer);
		new_steam_bots.on('confirmationAccepted', steamBotConfirmationAccepted);
		
		offers_steamBots.push(new_steam_bots);
	});
}

function haveActiveBots(type){
	return (offers_steamBots.filter(a => a.connected && a['can_' + type] && a.active).length > 0);
}

function getFreeBot(type){
	var filter = offers_steamBots.filter(a => a.connected && a['can_' + type] && a.active);
	
	return filter[getRandomInt(0, filter.length - 1)];
}

function haveBotByIndex(index){
	return offers_steamBots[index] !== undefined;
}

function getBotByIndex(index){
	return offers_steamBots[index];
}

function getBotBySteamid(steamid){
	return offers_steamBots.findIndex(a => a.steamid == steamid);
}

function addQueueRequestInspect(request){
	var free_bot = getFreeBot('info');
	
	free_bot.addQueueRequestInspect(request);
}

function steamBotError(error){
	logger.error(error);
	writeError(error);
}

function steamBotMessage(message){
	logger.warn(message);
}

function steamBotReady(bot){
	setTimeout(function(){
		offers_steamLoadOffers(bot);
	}, 1000);
}

function steamBotSentOfferChanged(response){
	var steam_bot = offers_steamBots[getBotBySteamid(response.bot)];
	
	if(steam_bot == undefined) {
		logger.error(new Error('[BOT] ' + response.bot + ' Was Not Found'));
		writeError(new Error('[BOT] ' + response.bot + ' Was Not Found'));
		return;
	}
	
	steam_bot.manager.getOffer(response.offer.id, function(err1, offer){
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		offers_steamStateChanged(offer.state, offer.id, offer.itemsToGive, offer.itemsToReceive, response.bot);
	});
}

function steamBotNewOffer(response){
	//offers_steamDeclineOffer(response.offer.id, response.bot);
}

function steamBotConfirmationAccepted(response){
	var steam_bot = offers_steamBots[getBotBySteamid(response.bot)];
	
	if(steam_bot == undefined) {
		logger.error(new Error('[BOT] ' + response.bot + ' Was Not Found'));
		writeError(new Error('[BOT] ' + response.bot + ' Was Not Found'));
		return;
	}
	
	if(offers_steamActiveOffers[response.offer.creator] !== undefined){
		if(offers_steamActiveOffers[response.offer.creator].type == 'withdraw'){
			pool.query('UPDATE `steam_transactions` SET `status` = 1 WHERE `tradeofferid` = ' + pool.escape(response.offer.creator), function(err1) {
				if(err1) {
					logger.error(err1);
					writeError(err1);
					return;
				}
			
				offers_steamActiveOffers[response.offer.creator].status = 1;
				offers_steamActiveOffers[response.offer.creator].time = time();
				
				offers_steamActiveOffers[response.offer.creator].timeout = setTimeout(function(){
					offers_steamDeclineOffer(offers_steamActiveOffers[response.offer.creator].tradeofferid, steam_bot.steamid, function(err2){
						if(err2) {
							logger.error(err2);
							writeError(err2);
							return;
						}
					});
				}, config.config_offers.steam.time_cancel_trade * 1000)
				
				//EDIT PENDING FROM BUYER
				io.sockets.in(offers_steamActiveOffers[response.offer.creator].user.userid).emit('message', {
					type: 'offers',
					command: 'edit_pending',
					offer: {
						id: offers_steamActiveOffers[response.offer.creator].id,
						type: offers_steamActiveOffers[response.offer.creator].type,
						method: 'steam',
						status: offers_steamActiveOffers[response.offer.creator].status,
						game: offers_steamActiveOffers[response.offer.creator].game,
						items: offers_steamActiveOffers[response.offer.creator].items,
						data: {
							tradeofferid: offers_steamActiveOffers[response.offer.creator].tradeofferid,
							code: offers_steamActiveOffers[response.offer.creator].code,
							time: offers_steamActiveOffers[response.offer.creator].time + config.config_offers.steam.time_cancel_trade
						}
					}
				});
				
				logger.warn('[BOT] ' + steam_bot.name + ' - ' + offers_steamActiveOffers[response.offer.creator].type.toUpperCase() + ' | ' + offers_steamActiveOffers[response.offer.creator].user.userid + ' | Offer #' + response.offer.creator + ' Was Confirmed');
			});
		}
	} else {
		logger.warn('[BOT] ' + steam_bot.name + ' - Unknown Offer #' + response.offer.creator + ' Was Confirmed');
	}
}
/* -------------- END BOT -------------- */