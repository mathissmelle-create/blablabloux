var offers_steamActiveOffers = {};

var offers_inventoryDeposit = {};
var offers_inventoryWithdraw = {};

var offers_steamSiteInventory = {};

var offers_itemExteriors = ['Battle-Scarred', 'Well-Worn', 'Field-Tested', 'Minimal Wear', 'Factory New'];

/* OFFERS */

function offers_verifyApikey(user, apikey, callback){
	var reg1 = /^(([a-f\d]{2}){16})$/i;
	
	if(!reg1.test(apikey)) return callback(new Error('Invalid apikey!'));
	
	if(user.binds.steam === undefined) return callback(new Error('Please bind your Steam Account.'));
	
	if(!user.tradelink) return callback(new Error('Firstly, you must set your valid Steam Trade Link from settings.'));
	
	var offer_code = generateHexCode(24);
	var offer_message = offer_code;
	
	pool.query('SELECT * FROM `steam_verifications` WHERE `userid` = ' + pool.escape(user.userid) + ' ORDER BY `id` DESC LIMIT 1', function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return callback(new Error('We can\'t verify your Apikey (1). Please try again later.'));
		}
		
		if(row1.length > 0){
			offers_confirmApikey(apikey, row1[0].tradeofferid, callback);
		} else {
			if(!haveActiveBots('apikey')) return callback(new Error('We can\'t verify your Apikey (2). Please try again later.'));
	
			var steam_bot = getFreeBot('apikey');
			
			getUserInventory(steam_bot.steamid, config.config_offers.steam.games[config.config_offers.steam.game_apikey].game.appid, config.config_offers.steam.games[config.config_offers.steam.game_apikey].game.contextid, function(err2, items){
				if(err2) return callback(new Error('We can\'t verify your Apikey (3). Please try again later.'));
				
				var filtered_items = items.filter(a => a.marketable == true).filter(a => a.tradable == true);
				
				if(filtered_items.length <= 0) return callback(new Error('We can\'t verify your Apikey (4). Please try again later.'));
				
				var item = {
					id: filtered_items[getRandomInt(0, filtered_items.length - 1)].assetid,
					game: config.config_offers.steam.game_apikey
				};
				
				offers_steamSendOffer(user.binds.steam, user.tradelink, offer_message, [item], [], steam_bot.steamid, function(err3, offer){
					if(err3) return callback(new Error('We can\'t verify your Apikey (5). Please try again later.'));
					
					pool.query('INSERT INTO `steam_verifications` SET `userid` = ' + pool.escape(user.userid) + ', `botsteamid` = ' + pool.escape(steam_bot.steamid) + ', `tradeofferid` = ' + pool.escape(offer.id) + ', `code` = ' + pool.escape(offer_code) + ', `item` = ' + pool.escape(JSON.stringify({item})) + ', `time` = ' + pool.escape(time()), function(err4) {
						if(err4) {
							logger.error(err4);
							writeError(err4);
							return callback(new Error('We can\'t verify your Apikey (6). Please try again later.'));
						}
					
						offers_steamDeclineOffer(offer.id, steam_bot.steamid, function(err4){
							if(err4) return callback(new Error('We can\'t verify your Apikey (7). Please try again later.'));
							
							offers_confirmApikey(apikey, offer.id, callback);
						});
					});
				});
			});
		}
	});
}

function offers_confirmApikey(apikey, offerid, callback){
	var options = 'https://api.steampowered.com/IEconService/GetTradeOffer/v1?key=' + apikey + '&tradeofferid=' + offerid;
	
	request(options, function(err1, response1, body1) {
		if(err1) return callback(new Error('We can\'t confirm your Apikey (1). Please try again later.'));
		
		if(!response1) return callback(new Error('Invalid Apikey (1)!'));
		if(response1.statusCode != 200) return callback(new Error('Invalid Apikey (2)!'));
		if(!isJsonString(body1)) return callback(new Error('Invalid Apikey (3)!'));
	
		var body = JSON.parse(body1);
		
		var user_offer = body.response.offer;
		
		if(user_offer === undefined) return callback(new Error('Invalid Apikey (4)!'));
		
		callback(null);
	});
}

function offers_steamLoadOffers(bot){
	var steam_bot = offers_steamBots[getBotBySteamid(bot)];
	
	if(steam_bot == undefined) {
		logger.error(new Error('[BOT] ' + bot + ' Was Not Found'));
		writeError(new Error('[BOT] ' + bot + ' Was Not Found'));
		return;
	}
	
	logger.warn('[BOT] ' + steam_bot.name + ' - Steam Offers Are Loading');
	
	pool.query('SELECT * FROM `steam_transactions` WHERE (`status` = 0 OR `status` = 1) AND `botsteamid` = ' + pool.escape(bot), function(err1, row1){
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		logger.warn('[BOT] ' + steam_bot.name + ' - ' + row1.length + ' Offers Loaded');
	
		row1.forEach(function(transaction){
			steam_bot.manager.getOffer(transaction.tradeofferid, function(err2, offer){
				if(err2) {
					logger.error(err2);
					writeError(err2);
					return;
				}
				
				var total_items = [];
				var total_price = 0;
				
				total_items = getItemsFromSql(transaction.items);
				total_price = getFormatAmount(transaction.amount);
				
				offers_steamActiveOffers[offer.id] = {
					id: transaction.id,
					status: transaction.status,
					type: transaction.type,
					refill: transaction.refill == 1,
					user: {
						userid: transaction.userid,
						name: transaction.name,
						avatar: transaction.avatar,
						level: calculateLevel(transaction.xp).level
					},
					game: transaction.game,
					items: total_items,
					amount: total_price,
					time_created: transaction.time,
					tradeofferid: transaction.tradeofferid,
					code: transaction.code,
					time: null,
					timeout: null
				};
				
				if(transaction.status == 1){
					offers_steamActiveOffers[offer.id].time = time();
					offers_steamActiveOffers[offer.id].timeout = setTimeout(function(){
						offers_steamDeclineOffer(offer.id, steam_bot.steamid, function(err3){
							if(err3){
								logger.error(err3);
								writeError(err3);
							}
						});
					}, config.config_offers.steam.time_cancel_trade * 1000);
				}
				
				offers_steamStateChanged(offer.state, offer.id, offer.itemsToGive, offer.itemsToReceive, transaction.botsteamid);
			});
		});
	});
}

//MAKE OFFER
function offers_steamSendOffer(steamid, tradelink, message, items_send, items_receive, bot, callback){
	var steam_bot = offers_steamBots[getBotBySteamid(bot)];
	
	if(steam_bot == undefined) {
		logger.error(new Error('[BOT] ' + bot + ' Was Not Found'));
		writeError(new Error('[BOT] ' + bot + ' Was Not Found'));
		return;
	}
	
	var create = steam_bot.manager.createOffer(steamid, tradelink.split('token=')[1]);
	
	items_receive.forEach(function(item){
		create.addTheirItem({
			'appid': config.config_offers.steam.games[item.game].game.appid,
			'contextid': config.config_offers.steam.games[item.game].game.contextid,
			'assetid': item.id
		});
	});
	
	items_send.forEach(function(item){
		create.addMyItem({
			'appid': config.config_offers.steam.games[item.game].game.appid,
			'contextid': config.config_offers.steam.games[item.game].game.contextid,
			'assetid': item.id
		});
	});
	
	create.setMessage(message);
	
	create.send(function(err1, status) {
		if(err1){
			logger.error(err1);
			writeError(err1);
			
			return callback(err1);
		}
		
		callback(null, create);
	});
}

//DECLINE OFFERS
function offers_steamDeclineOffer(offerid, bot, callback){
	var steam_bot = offers_steamBots[getBotBySteamid(bot)];
	
	if(steam_bot == undefined) return callback(new Error('[BOT] ' + bot + ' Was Not Found'));
	
	steam_bot.manager.getOffer(offerid, function(err1, offer){
		if(err1) return callback(err1);
		
		if(offer.state == 2 || offer.state == 9){
			offer.decline(function(err2) {
				if(err2) return callback(err2);
				
				steam_bot.community.checkConfirmations();
				
				if(offers_steamActiveOffers[offer.id] === undefined) logger.warn('[BOT] ' + steam_bot.name + ' - Unknown Offer #' + offer.id + ' Was Declined');
				
				callback(null);
			});
		}
	});
}

//ACCEPT OFFERS
function offers_steamAcceptOffer(offerid, bot, callback){
	var steam_bot = offers_steamBots[getBotBySteamid(bot)];
	
	if(steam_bot == undefined) return callback(new Error('[BOT] ' + bot + ' Was Not Found'));
	
	steam_bot.manager.getOffer(offerid, function(err1, offer){
		if(err1) return callback(err1);
		
		if(offer.state == 2){
			offer.accept(function(err2) {
				if(err2) return callback(err2);
				
				steam_bot.community.checkConfirmations();
				
				if(offers_steamActiveOffers[offer.id] === undefined) logger.warn('[BOT] ' + steam_bot.name + ' - Unknown Offer #' + offer.id + ' Was Accepted');
			});
		}
	});
}

//OFFERS CHANGED
function offers_steamStateChanged(state, id, sender, recipient, bot){
	if(offers_steamActiveOffers[id] !== undefined){
		var steam_bot = offers_steamBots[getBotBySteamid(bot)];
		
		if(steam_bot == undefined) {
			logger.error(new Error('[BOT] ' + bot + ' Was Not Found'));
			writeError(new Error('[BOT] ' + bot + ' Was Not Found'));
			return;
		}
		
		var amount = getFormatAmount(offers_steamActiveOffers[id].amount);
		
		if(offers_steamActiveOffers[id].status == 0){
			if(state == 2){
				if(offers_steamActiveOffers[id].type == 'withdraw'){
					pool.query('UPDATE `steam_transactions` SET `status` = 1 WHERE `id` = ' + pool.escape(offers_steamActiveOffers[id].id), function(err1) {
						if(err1) {
							logger.error(err1);
							writeError(err1);
							return;
						}
					
						offers_steamActiveOffers[id].status = 1;
						offers_steamActiveOffers[id].time = time();
						
						offers_steamActiveOffers[id].timeout = setTimeout(function(){
							offers_steamDeclineOffer(offers_steamActiveOffers[id].tradeofferid, steam_bot.steamid, function(err2){
								if(err2) {
									logger.error(err2);
									writeError(err2);
									return;
								}
							});
						}, config.config_offers.steam.time_cancel_trade * 1000)
						
						//EDIT PENDING FROM BUYER
						io.sockets.in(offers_steamActiveOffers[id].user.userid).emit('message', {
							type: 'offers',
							command: 'edit_pending',
							offer: {
								id: offers_steamActiveOffers[id].id,
								type: offers_steamActiveOffers[id].type,
								method: 'steam',
								status: offers_steamActiveOffers[id].status,
								game: offers_steamActiveOffers[id].game,
								items: offers_steamActiveOffers[id].items,
								data: {
									tradeofferid: offers_steamActiveOffers[id].tradeofferid,
									code: offers_steamActiveOffers[id].code,
									time: offers_steamActiveOffers[id].time + config.config_offers.steam.time_cancel_trade
								}
							}
						});
						
						logger.warn('[BOT] ' + steam_bot.name + ' - ' + offers_steamActiveOffers[id].type.toUpperCase() + ' | ' + offers_steamActiveOffers[id].user.userid + ' | Offer #' + id + ' Was Confirmed');
					});
				}
			}
		} else if(offers_steamActiveOffers[id].status == 1){
			if(state == 3){
				if(offers_steamActiveOffers[id].type == 'deposit'){
					steam_bot.manager.getOffer(id, function(err1, offer){
						if(err1) {
							logger.error(err1);
							writeError(err1);
							return;
						}
					
						offer.getReceivedItems(function(err2, items) {
							if(err2) {
								logger.error(err2);
								writeError(err2);
								return;
							}
							
							offers_assignItemsChanges(items, recipient, offers_steamActiveOffers[id].items, function(assign_items){
								if(assign_items.length != offers_steamActiveOffers[id].items.length) {
									logger.error(new Error('Unassigned items'));
									writeError(new Error('Unassigned items'));
									return;
								}
								
								pool.query('UPDATE `steam_transactions` SET `status` = 2 WHERE `id` = ' + pool.escape(offers_steamActiveOffers[id].id), function(err3) {
									if(err3) {
										logger.error(err3);
										writeError(err3);
										return;
									}
									
									assign_items.forEach(function(item){
										if(item.wear != null){
											pool.query('INSERT INTO `steam_items` SET `itemid` = ' + pool.escape(item.id) + ', `wear` = ' + pool.escape(item.wear) + ', `time` = ' + pool.escape(time()), function(err4) {
												if(err4) {
													logger.error(err4);
													writeError(err4);
													return;
												}
											});
										}
									});
									
									if(offers_steamActiveOffers[id].refill) {
										//EDIT BALANCE
										user_editBalance(offers_steamActiveOffers[id].user.userid, 0, 'steam_refill', function(err5){
											if(err5) {
												logger.error(err5);
												writeError(err5);
												return;
											}
											
											if(offers_steamActiveOffers[id].timeout != null) clearTimeout(offers_steamActiveOffers[id].timeout);
											
											offers_steamActiveOffers[id].status = 2;
											
											//EDIT PENDING FROM SELLER
											io.sockets.in(offers_steamActiveOffers[id].user.userid).emit('message', {
												type: 'offers',
												command: 'edit_pending',
												offer: {
													id: offers_steamActiveOffers[id].id,
													type: offers_steamActiveOffers[id].type,
													method: 'steam',
													status: offers_steamActiveOffers[id].status,
													items: offers_steamActiveOffers[id].items,
													data: {
														tradeofferid: offers_steamActiveOffers[id].tradeofferid,
														amount: amount,
														refill: offers_steamActiveOffers[id].refill
													}
												}
											});
											
											//ADD ITEMS TO WITHDRAW
											io.sockets.in('withdraw').emit('message', {
												type: 'offers',
												command: 'add_items',
												offer: {
													items: offers_assignItemsType(assign_items, { type: 'withdraw', method: 'steam', game: offers_steamActiveOffers[id].game, tradelocked: true, offset: true, bot: getBotBySteamid(bot) }),
													paths: ['withdraw', 'steam', offers_steamActiveOffers[id].game],
													more: true
												}
											});
											
											//ADD ITEMS
											assign_items.forEach(function(item){
												pool.query('INSERT INTO `steam_inventory` SET `itemid` = ' + pool.escape(item.id) + ', `game` = ' + pool.escape(offers_steamActiveOffers[id].game) + ', `time` = ' + pool.escape(time()), function(err7, row7) {
													if(err7) {
														logger.error(err7);
														writeError(err7);
														return;
													}
													
													if(row7.affectedRows > 0) offers_steamSiteInventory[item.id] = false;
												});
											});
											
											setTimeout(function(){
												if(offers_steamActiveOffers[id] !== undefined){
													//REMOVE PENDING FROM SELLER
													io.sockets.in(offers_steamActiveOffers[id].user.userid).emit('message', {
														type: 'offers',
														command: 'remove_pending',
														offer: {
															id: offers_steamActiveOffers[id].id,
															method: 'steam'
														}
													});
													
													delete offers_steamActiveOffers[id];
												}
											}, config.config_offers.steam.time_remove_pending * 1000);
											
											logger.warn('[BOT] ' + steam_bot.name + ' - ' + offers_steamActiveOffers[id].type.toUpperCase() + ' (REFILL) | ' + offers_steamActiveOffers[id].user.userid + ' | Offer #' + id + ' Was Accepted');
										});
									} else {
										pool.query('INSERT INTO `users_trades` SET `type` = ' + pool.escape(offers_steamActiveOffers[id].type) + ', `method` = ' + pool.escape("steam") + ', `game` = ' + pool.escape(offers_steamActiveOffers[id].game) + ', `userid` = ' + pool.escape(offers_steamActiveOffers[id].user.userid) + ', `amount` = ' + amount + ', `value` = ' + amount + ', `tradeid` = ' + pool.escape(offers_steamActiveOffers[id].id) + ', `time` = ' + pool.escape(time()), function(err4){
											if(err4) {
												logger.error(err4);
												writeError(err4);
												return;
											}
											
											//EDIT BALANCE
											user_editBalance(offers_steamActiveOffers[id].user.userid, amount, 'steam_deposit', function(err5){
												if(err5) {
													logger.error(err5);
													writeError(err5);
													return;
												}
												
												user_updateBalance(offers_steamActiveOffers[id].user.userid);
												
												pool.query('UPDATE `users` SET `deposit_count` = `deposit_count` + 1, `deposit_total` = `deposit_total` + ' + amount + ' WHERE `userid` = ' + pool.escape(offers_steamActiveOffers[id].user.userid), function(err6) {
													if(err6) {
														logger.error(err6);
														writeError(err6);
														return;
													}
													
													//REGISTER AFFILIATES
													user_registerAffiliates(offers_steamActiveOffers[id].user.userid, amount, 'deposit', function(err7){
														if(err7) {
															logger.error(err7);
															writeError(err7);
															return;
														}
														
														if(offers_steamActiveOffers[id].timeout != null) clearTimeout(offers_steamActiveOffers[id].timeout);
													
														offers_steamActiveOffers[id].status = 2;
														
														//EDIT PENDING FROM SELLER
														io.sockets.in(offers_steamActiveOffers[id].user.userid).emit('message', {
															type: 'offers',
															command: 'edit_pending',
															offer: {
																id: offers_steamActiveOffers[id].id,
																type: offers_steamActiveOffers[id].type,
																method: 'steam',
																status: offers_steamActiveOffers[id].status,
																items: offers_steamActiveOffers[id].items,
																data: {
																	tradeofferid: offers_steamActiveOffers[id].tradeofferid,
																	amount: amount,
																	refill: offers_steamActiveOffers[id].refill
																}
															}
														});
														
														//ADD ITEMS TO WITHDRAW
														io.sockets.in('withdraw').emit('message', {
															type: 'offers',
															command: 'add_items',
															offer: {
																items: offers_assignItemsType(assign_items, { type: 'withdraw', method: 'steam', game: offers_steamActiveOffers[id].game, tradelocked: true, offset: true, bot: getBotBySteamid(bot) }),
																paths: ['withdraw', 'steam', offers_steamActiveOffers[id].game],
																more: true
															}
														});
														
														//ADD ITEMS
														assign_items.forEach(function(item){
															pool.query('INSERT INTO `steam_inventory` SET `itemid` = ' + pool.escape(item.id) + ', `game` = ' + pool.escape(offers_steamActiveOffers[id].game) + ', `time` = ' + pool.escape(time()), function(err8, row8) {
																if(err8) {
																	logger.error(err8);
																	writeError(err8);
																	return;
																}
																
																if(row8.affectedRows > 0) offers_steamSiteInventory[item.id] = false;
															});
														});
														
														setTimeout(function(){
															if(offers_steamActiveOffers[id] !== undefined){
																//REMOVE PENDING FROM SELLER
																io.sockets.in(offers_steamActiveOffers[id].user.userid).emit('message', {
																	type: 'offers',
																	command: 'remove_pending',
																	offer: {
																		id: offers_steamActiveOffers[id].id,
																		method: 'steam'
																	}
																});
																
																delete offers_steamActiveOffers[id];
															}
														}, config.config_offers.steam.time_remove_pending * 1000);
														
														logger.warn('[BOT] ' + steam_bot.name + ' - ' + offers_steamActiveOffers[id].type.toUpperCase() + ' | ' + offers_steamActiveOffers[id].user.userid + ' | Offer #' + id + ' Was Accepted');
													});
												});
											});
										});
									}
								});
							});
						});
					});
				} else if(offers_steamActiveOffers[id].type == 'withdraw'){
					pool.query('UPDATE `steam_transactions` SET `status` = 2 WHERE `id` = ' + pool.escape(offers_steamActiveOffers[id].id), function(err1) {
						if(err1) {
							logger.error(err1);
							writeError(err1);
							return;
						}
						
						pool.query('INSERT INTO `users_trades` SET `type` = ' + pool.escape(offers_steamActiveOffers[id].type) + ', `method` = ' + pool.escape("steam") + ', `game` = ' + pool.escape(offers_steamActiveOffers[id].game) + ', `userid` = ' + pool.escape(offers_steamActiveOffers[id].user.userid) + ', `amount` = ' + amount + ', `value` = ' + amount + ', `tradeid` = ' + pool.escape(offers_steamActiveOffers[id].id) + ', `time` = ' + pool.escape(time()), function(err2){
							if(err2) {
								logger.error(err2);
								writeError(err2);
								return;
							}
							
							pool.query('UPDATE `users` SET `withdraw_count` = `withdraw_count` + 1, `withdraw_total` = `withdraw_total` + ' + amount + ' WHERE `userid` = ' + pool.escape(offers_steamActiveOffers[id].user.userid), function(err3) {
								if(err3) {
									logger.error(err3);
									writeError(err3);
									return;
								}
								
								if(offers_steamActiveOffers[id].timeout != null) clearTimeout(offers_steamActiveOffers[id].timeout);
								
								offers_steamActiveOffers[id].status = 2;
								
								//EDIT PENDING FROM BUYER
								io.sockets.in(offers_steamActiveOffers[id].user.userid).emit('message', {
									type: 'offers',
									command: 'edit_pending',
									offer: {
										id: offers_steamActiveOffers[id].id,
										type: offers_steamActiveOffers[id].type,
										method: 'steam',
										status: offers_steamActiveOffers[id].status,
										items: offers_steamActiveOffers[id].items,
										data: {
											tradeofferid: offers_steamActiveOffers[id].tradeofferid
										}
									}
								});
								
								//ADD ITEMS TO DEPOSIT
								io.sockets.in(offers_steamActiveOffers[id].user.userid).emit('message', {
									type: 'offers',
									command: 'add_items',
									offer: {
										items: offers_assignItemsType(offers_steamActiveOffers[id].items, { type: 'deposit', method: 'steam', game: offers_steamActiveOffers[id].game, tradelocked: false, offset: false }),
										paths: ['deposit', 'steam', offers_steamActiveOffers[id].game],
										more: true
									}
								});
							
								//EDIT ITEMS
								offers_steamActiveOffers[id].items.forEach(function(item){
									pool.query('UPDATE `steam_inventory` SET `status` = 2 WHERE `itemid` = ' + pool.escape(item.id) + ' AND `status` = 1', function(err4, row4) {
										if(err4) {
											logger.error(err4);
											writeError(err4);
											return;
										}
										
										if(row4.affectedRows > 0) if(offers_steamSiteInventory[item.id] !== undefined) delete offers_steamSiteInventory[item.id];
									});
								});
								
								setTimeout(function(){
									if(offers_steamActiveOffers[id] !== undefined){
										//REMOVE PENDING FROM BUYER
										io.sockets.in(offers_steamActiveOffers[id].user.userid).emit('message', {
											type: 'offers',
											command: 'remove_pending',
											offer: {
												id: offers_steamActiveOffers[id].id,
												method: 'steam'
											}
										});
										
										delete offers_steamActiveOffers[id];
									}
								}, config.config_offers.steam.time_remove_pending * 1000);
								
								logger.warn('[BOT] ' + steam_bot.name + ' - ' + offers_steamActiveOffers[id].type.toUpperCase() + ' | ' + offers_steamActiveOffers[id].user.userid + ' | Offer #' + id + ' Was Accepted');
							});
						});
					});
				}
			} else if(state != 2 && state != 9){
				if(offers_steamActiveOffers[id].type == 'deposit'){
					pool.query('UPDATE `steam_transactions` SET `status` = -1 WHERE `id` = ' + pool.escape(offers_steamActiveOffers[id].id), function(err1) {
						if(err1) {
							logger.error(err1);
							writeError(err1);
							return;
						}
						
						if(offers_steamActiveOffers[id].timeout != null) clearTimeout(offers_steamActiveOffers[id].timeout);
						
						offers_steamActiveOffers[id].status = -1;
						
						//EDIT PENDING FROM SELLER
						io.sockets.in(offers_steamActiveOffers[id].user.userid).emit('message', {
							type: 'offers',
							command: 'edit_pending',
							offer: {
								id: offers_steamActiveOffers[id].id,
								type: offers_steamActiveOffers[id].type,
								method: 'steam',
								status: offers_steamActiveOffers[id].status,
								items: offers_steamActiveOffers[id].items,
								data: {
									tradeofferid: offers_steamActiveOffers[id].tradeofferid
								}
							}
						});
						
						//ADD ITEMS TO DEPOSIT
						io.sockets.in(offers_steamActiveOffers[id].user.userid).emit('message', {
							type: 'offers',
							command: 'add_items',
							offer: {
								items: offers_assignItemsType(offers_steamActiveOffers[id].items, { type: 'deposit', method: 'steam', game: offers_steamActiveOffers[id].game, tradelocked: false, offset: false }),
								paths: ['deposit', 'steam', offers_steamActiveOffers[id].game],
								more: true
							}
						});
						
						setTimeout(function(){
							if(offers_steamActiveOffers[id] !== undefined){
								//REMOVE PENDING FROM SELLER
								io.sockets.in(offers_steamActiveOffers[id].user.userid).emit('message', {
									type: 'offers',
									command: 'remove_pending',
									offer: {
										id: offers_steamActiveOffers[id].id,
										method: 'steam'
									}
								});
								
								delete offers_steamActiveOffers[id];
							}
						}, config.config_offers.steam.time_remove_pending * 1000);
						
						if(offers_steamActiveOffers[id].refill) logger.warn('[BOT] ' + steam_bot.name + ' - ' + offers_steamActiveOffers[id].type.toUpperCase() + ' (REFILL) | ' + offers_steamActiveOffers[id].user.userid + ' | Offer #' + id + ' Was Declined');
						else logger.warn('[BOT] ' + steam_bot.name + ' - ' + offers_steamActiveOffers[id].type.toUpperCase() + ' | ' + offers_steamActiveOffers[id].user.userid + ' | Offer #' + id + ' Was Declined');
					});
				} else if(offers_steamActiveOffers[id].type == 'withdraw'){
					pool.query('UPDATE `steam_transactions` SET `status` = -1 WHERE `id` = ' + pool.escape(offers_steamActiveOffers[id].id), function(err1) {
						if(err1) {
							logger.error(err1);
							writeError(err1);
							return;
						}
						
						//EDIT BALANCE
						user_editBalance(offers_steamActiveOffers[id].user.userid, amount, 'steam_withdraw_refund', function(err2){
							if(err2) {
								logger.error(err2);
								writeError(err2);
								return;
							}
							
							user_updateBalance(offers_steamActiveOffers[id].user.userid);
							
							pool.query('UPDATE `users` SET `available` = `available` + ' + amount + ' WHERE `userid` = ' + pool.escape(offers_steamActiveOffers[id].user.userid), function(err3) {
								if(err3) {
									logger.error(err3);
									writeError(err3);
									return;
								}
							
								if(offers_steamActiveOffers[id].timeout != null) clearTimeout(offers_steamActiveOffers[id].timeout);
								
								offers_steamActiveOffers[id].status = -1;
								
								//EDIT PENDING FROM BUYER
								io.sockets.in(offers_steamActiveOffers[id].user.userid).emit('message', {
									type: 'offers',
									command: 'edit_pending',
									offer: {
										id: offers_steamActiveOffers[id].id,
										type: offers_steamActiveOffers[id].type,
										method: 'steam',
										status: offers_steamActiveOffers[id].status,
										items: offers_steamActiveOffers[id].items,
										data: {
											tradeofferid: offers_steamActiveOffers[id].tradeofferid,
											amount: amount
										}
									}
								});
								
								//ADD ITEMS TO WITHDRAW
								io.sockets.in('withdraw').emit('message', {
									type: 'offers',
									command: 'add_items',
									offer: {
										items: offers_assignItemsType(offers_steamActiveOffers[id].items, { type: 'withdraw', method: 'steam', game: offers_steamActiveOffers[id].game, tradelocked: false, offset: true, bot: getBotBySteamid(bot) }),
										paths: ['withdraw', 'steam', offers_steamActiveOffers[id].game],
										more: true
									}
								});
								
								//EDIT ITEMS
								if(state != 8){
									offers_steamActiveOffers[id].items.forEach(function(item){
										pool.query('UPDATE `steam_inventory` SET `status` = 0 WHERE `itemid` = ' + pool.escape(item.id) + ' AND `status` = 1', function(err4, row4) {
											if(err4) {
												logger.error(err4);
												writeError(err4);
												return;
											}
											
											if(row4.affectedRows > 0) if(offers_steamSiteInventory[item.id] !== undefined) offers_steamSiteInventory[item.id] = false;
										});
									});
								}
								
								setTimeout(function(){
									if(offers_steamActiveOffers[id] !== undefined){
										//REMOVE PENDING FROM BUYER
										io.sockets.in(offers_steamActiveOffers[id].user.userid).emit('message', {
											type: 'offers',
											command: 'remove_pending',
											offer: {
												id: offers_steamActiveOffers[id].id,
												method: 'steam'
											}
										});
										
										delete offers_steamActiveOffers[id];
									}
								}, config.config_offers.steam.time_remove_pending * 1000);
								
								logger.warn('[BOT] ' + steam_bot.name + ' - ' + offers_steamActiveOffers[id].type.toUpperCase() + ' | ' + offers_steamActiveOffers[id].user.userid + ' | Offer #' + id + ' Was Declined');
							});
						});
					});
				}
				
				offers_steamDeclineOffer(id, bot, function(err1){
					if(err1){
						logger.error(err1);
						writeError(err1);
					}
				});
			}
		}
	}
}

function offers_assignItemsType(items, data){
	for(var i = 0; i < items.length; i++){
		if(items[i].accepted === undefined) items[i].accepted = true;
		if(items[i].inspect === undefined) items[i].inspect = null;
		
		if(!data.offset) items[i].offset = 0;
		
		if(items[i].bot === undefined) if(data.type == 'withdraw' && data.method == 'steam') items[i].bot = data.bot;
		
		if(items[i].tradelocked === undefined) {
			if(data.tradelocked) {
				items[i].tradelocked = {
					tradelocked: true,
					time: 7 * 24 * 60 * 60
				}
			} else {
				items[i].tradelocked = {
					tradelocked: false,
					time: 0
				}
			}
		}
	}
	
	return items;
}

function offers_assignItemsChanges(new_items, old_items, info_items, callback){
	var new_info_items = [];
	
	info_items.forEach(function(item){
		var old_index = old_items.findIndex(old_item => old_item.assetid === item.id);
		
		if(old_index != -1) {
			var icon = item.image.split('https://steamcommunity-a.akamaihd.net/economy/image/')[1];
			
			var new_index = new_items.findIndex(new_item => (new_item.icon_url_large === icon || new_item.icon_url === icon));
			
			if(new_index != -1){
				new_info_items.push(Object.assign(generateItem(item, {
					'id': new_items[new_index].assetid
				}), {}));
				
				new_items.splice(new_index, 1);
			}
		}
	});
	
	callback(new_info_items);
}

/* END OFFERS */

/* DEPOSIT */

function steamSystem_deposit(user, socket, game, items, refill, recaptcha, cooldown){
	cooldown(true, true);
	
	if(refill && !config.config_site.refillshop_allowed.includes(config.config_site.ranks_name[user.rank])) {
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	site_verifyRecaptcha(recaptcha, function(verified){
		if(!verified){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid recaptcha!'
			});
			
			return cooldown(false, true);
		}
		
		socket.emit('message', {
			type: 'info',
			info: 'Preparing deposit request. Please wait...'
		});
		
		steamSystem_depositAutomatically(user, game, items, refill, function(err1, offer){
			if(err1){
				socket.emit('message', {
					type: 'error',
					error: err1.message
				});
				
				return cooldown(false, true);
			}
			
			//REMOVE ITEMS FROM DEPOSIT
			io.sockets.in(offers_steamActiveOffers[offer.id].user.userid).emit('message', {
				type: 'offers',
				command: 'remove_items',
				offer: {
					items: offers_steamActiveOffers[offer.id].items,
					paths: [offers_steamActiveOffers[offer.id].type, 'steam', game],
					all: false
				}
			});
			
			//ADD PENDING TO SELLER
			io.sockets.in(offers_steamActiveOffers[offer.id].user.userid).emit('message', {
				type: 'offers',
				command: 'add_pending',
				offer: {
					id: offers_steamActiveOffers[offer.id].id,
					type: offers_steamActiveOffers[offer.id].type,
					method: 'steam',
					status: offers_steamActiveOffers[offer.id].status,
					items: offers_steamActiveOffers[offer.id].items,
					data: {
						tradeofferid: offers_steamActiveOffers[offer.id].tradeofferid,
						code: offers_steamActiveOffers[offer.id].code,
						time: offers_steamActiveOffers[offer.id].time + config.config_offers.steam.time_cancel_trade
					}
				}
			});
			
			cooldown(false, false);
		});
	});
}

function steamSystem_depositAutomatically(user, game, items, refill, callback){
	if(user.binds.steam === undefined) return callback(new Error('Please bind your Steam Account!'));
	
	if((user.restrictions.trade >= time() || user.restrictions.trade == -1) && !config.config_site.bantrade_excluded.includes(config.config_site.ranks_name[user.rank])) return callback(new Error('Error: You are restricted to use our trade. The restriction expires ' + ((user.restrictions.trade == -1) ? 'never' : makeDate(new Date(user.restrictions.trade * 1000))) + '.'));
	
	if(user.exclusion > time()) return callback(new Error('Error: Your exclusion expires ' + makeDate(new Date(user.exclusion * 1000)) + '.'));
	
	if(!user.tradelink) return callback(new Error('Error: Firstly, you must set your valid Steam Trade Link from settings.'));
	
	if(config.config_offers.steam.games[game] === undefined) return callback(new Error('Invalid deposit game!'));
	
	if(items.length < config.config_site.interval_items.deposit.min || items.length > config.config_site.interval_items.deposit.max) return callback(new Error('Error: Invalid items amount [' + config.config_site.interval_items.deposit.min + '-' + config.config_site.interval_items.deposit.max + ']!'));
	
	steamSystem_depositByGames(user.binds.steam, game, 0, items, config.config_offers.steam.deposit_offset, [], 0, function(err1, total_items, total_price){
		if(err1) return callback(new Error('Error: ' + err1.message));
		
		if(total_items.length != items.length) return callback(new Error('Error: Invalids items in your offer. Please refresh your inventory!'));
		
		if(total_price < config.config_site.interval_amount.deposit_steam.min || total_price > config.config_site.interval_amount.deposit_steam.max) return callback(new Error('Error: Invalid deposit amount [' + getFormatAmountString(config.config_site.interval_amount.deposit_steam.min) + '-' + getFormatAmountString(config.config_site.interval_amount.deposit_steam.max)  + ']!'));
		
		var offer_code = generateHexCode(24);
		var offer_message = offer_code;
		
		if(!haveActiveBots('trade')) return callback(new Error('Error: There are no active bots. Please try again later.'));
		
		var steam_bot = getFreeBot('trade');
		
		offers_steamSendOffer(user.binds.steam, user.tradelink, offer_message, [], items, steam_bot.steamid, function(err2, offer){
			if(err2) return callback(new Error('Error: There was an error sending your trade offer. Please try again later.'));
			
			if(refill) logger.warn('[BOT] ' + steam_bot.name + ' - DEPOSIT (REFILL) | ' + user.userid + ' | Offer #' + offer.id + ' Was Sent');
			else logger.warn('[BOT] ' + steam_bot.name + ' - DEPOSIT | ' + user.userid + ' | Offer #' + offer.id + ' Was Sent');
			
			pool.query('INSERT INTO `steam_transactions` SET `status` = 1, `refill` = ' + (refill ? 1 : 0) + ', `type` = ' + pool.escape('deposit') + ', `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + pool.escape(user.xp) + ', `steamid` = ' + pool.escape(user.binds.steam) + ', `items` = ' + pool.escape(getSqlItems(total_items)) + ', `amount` = ' + total_price + ', `code` = ' + pool.escape(offer_code) + ', `game` = ' + pool.escape(game) + ', `tradeofferid` = ' + pool.escape(offer.id) + ', `botsteamid` = ' + pool.escape(steam_bot.steamid) + ', `time` = ' + pool.escape(time()), function(err3, row3) {
				if(err3) {
					logger.error(err3);
					writeError(err3);
					return callback(new Error('Error in steam automatically deposit (1)'));
				}
				
				offers_steamActiveOffers[offer.id] = {
					id: row3.insertId,
					status: 1,
					type: 'deposit',
					refill: refill,
					user: {
						userid: user.userid,
						name: user.name,
						avatar: user.avatar,
						level: calculateLevel(user.xp).level
					},
					game: game,
					items: total_items,
					amount: total_price,
					time_created: time(),
					tradeofferid: offer.id,
					code: offer_code,
					time: time(),
					timeout: setTimeout(function(){
						offers_steamDeclineOffer(offer.id, steam_bot.steamid, function(err4){
							if(err4){
								logger.error(err4);
								writeError(err4);
							}
						});
					}, config.config_offers.steam.time_cancel_trade * 1000)
				};
				
				logger.debug('[STEAM] Deposit order #' + row3.insertId + ' has been prepared');
				
				callback(null, offer);
			});
		});
	});
}

function steamSystem_depositByGames(steamid, game, gameid, itemsid, offset, total_items, total_price, callback){
	if(gameid >= Object.keys(config.config_offers.steam.games).length) return callback(null, total_items, total_price);
	
	if(game != Object.keys(config.config_offers.steam.games)[gameid]) return steamSystem_depositByGames(steamid, game, gameid + 1, itemsid, offset, total_items, total_price, callback);
	
	getUserInventory(steamid, config.config_offers.steam.games[Object.keys(config.config_offers.steam.games)[gameid]].game.appid, config.config_offers.steam.games[Object.keys(config.config_offers.steam.games)[gameid]].game.contextid, function(err1, items){
		if(err1) return callback(new Error('We can\'t load your inventory.'));
		
		steamSystem_depositByItems(Object.keys(config.config_offers.steam.games)[gameid], items, 0, itemsid, offset, [], 0, function(err2, new_total_items, new_total_price){
			if(err2) return callback(err2);
			
			return steamSystem_depositByGames(steamid, game, gameid + 1, itemsid, offset, total_items.concat(new_total_items), getFormatAmount(total_price + new_total_price), callback);
		});
	});
}

function steamSystem_depositByItems(game, items, itemid, itemsid, offset, total_items, total_price, callback){
	if(items === undefined) return callback(null, total_items, total_price);
	
	if(items[itemid] === undefined) return callback(null, total_items, total_price);
	
	if(itemsid.filter(a => a.id == items[itemid].assetid.toString()).length <= 0) return steamSystem_depositByItems(game, items, itemid + 1, itemsid, offset, total_items, total_price, callback);
	
	var price = getFormatAmount(pricesSystem_getPrice(items[itemid].name, config.config_offers.steam.games[game].game.appid));
	if(price > 0) price = getFormatAmount(price + getFeeFromCommission(price, offset));
	
	/* -- ACCEPTING --*/
	
	var accepted = true;
	
	if(accepted) if(!items[itemid].marketable || !items[itemid].tradable) accepted = false;
	if(accepted) if(total_items.filter(a => a.id == itemid).length > 0) accepted = false;
	if(accepted) if(p2pStstem_items[items[itemid].assetid] !== undefined) if(p2pStstem_items[items[itemid].assetid] == true) accepted = false;
	if(accepted) if(price == null) accepted = false;
	if(accepted) if(price <= 0) accepted = false;
	if(accepted) if(price < config.config_site.interval_amount.deposit_item.min || price > config.config_site.interval_amount.deposit_item.max) accepted = false;
	if(accepted) if(config.config_offers.steam.blacklist_items[game].filter(a => items[itemid].name.toLowerCase().indexOf(a.toLowerCase()) >= 0).length > 0) accepted = false;
	
	if(!accepted) return steamSystem_depositByItems(game, items, itemid + 1, itemsid, offset, total_items, total_price, callback);
	
	if(items[itemid].inspect && offers_itemExteriors.includes(getInfosByItemName(items[itemid].name).exterior)){
		pool.query('SELECT `wear` FROM `steam_items` WHERE `itemid` = ' + pool.escape(items[itemid].assetid), function(err1, row1) {
			if(err1) {
				logger.error(err1);
				writeError(err1);
				
				total_items.push(Object.assign(generateItem(items[itemid], {
					'price': price,
					'offset': offset,
					'wear': row1[0].wear
				}), {}));
				total_price += price;
				
				return steamSystem_depositByItems(game, items, itemid + 1, itemsid, offset, total_items, total_price, callback);
			}
			
			if(row1.length > 0){
				total_items.push(Object.assign(generateItem(items[itemid], {
					'price': price,
					'offset': offset,
					'wear': row1[0].wear
				}), {}));
				total_price += price;
				
				steamSystem_depositByItems(game, items, itemid + 1, itemsid, offset, total_items, total_price, callback);
			} else {
				total_items.push(Object.assign(generateItem(items[itemid], {
					'price': price,
					'offset': offset
				}), {}));
				total_price += price;
				
				steamSystem_depositByItems(game, items, itemid + 1, itemsid, offset, total_items, total_price, callback);
			}
		});
	} else {
		total_items.push(Object.assign(generateItem(items[itemid], {
			'price': price,
			'offset': offset
		}), {}));
		total_price += price;
		
		steamSystem_depositByItems(game, items, itemid + 1, itemsid, offset, total_items, total_price, callback);
	}
}

function steamSystem_depositInventory(user, socket, method, game, offset, cooldown){
	cooldown(true, true);
	
	if(user.binds.steam === undefined) {
		socket.emit('message', {
			type: 'error',
			error: 'Please bind your Steam Account!'
		});
		
		return cooldown(false, true);
	}
	
	if(!user.tradelink){
		socket.emit('message', {
			type: 'offers',
			command: 'error',
			error: 'Firstly, you must set your valid Steam Trade Link from settings.'
		});
		
		return cooldown(false, true);
	}
	
	if(config.config_offers.steam.games[game] === undefined){
		socket.emit('message', {
			type: 'offers',
			command: 'error',
			error: 'Invalid deposit game!'
		});
		
		return cooldown(false, true);
	}
	
	if(offers_inventoryDeposit[user.userid] !== undefined){
		if(offers_inventoryDeposit[user.userid][method + '_' + game] !== undefined){
			if(offers_inventoryDeposit[user.userid][method + '_' + game]['time'] - time() > 0){
				if(offers_inventoryDeposit[user.userid][method + '_' + game]['error']['have']){			
					socket.emit('message', {
						type: 'offers',
						command: 'error',
						error: offers_inventoryDeposit[user.userid][method + '_' + game]['error']['error']
					});
				} else {
					if(offers_inventoryDeposit[user.userid][method + '_' + game]['items'].length > 0){
						socket.emit('message', {
							type: 'offers',
							command: 'add_items',
							offer: {
								items: offers_inventoryDeposit[user.userid][method + '_' + game]['items'],
								paths: ['deposit', method, game],
								more: false
							}
						});
					} else {
						socket.emit('message', {
							type: 'offers',
							command: 'error',
							error: 'Your Inventory is currently empty.'
						});	
					}
				}
				
				socket.emit('message', {
					type: 'offers',
					command: 'wait',
					time: offers_inventoryDeposit[user.userid][method + '_' + game]['time'] - time()
				});
				
				return cooldown(false, false);
			}
		}
	} else {
		offers_inventoryDeposit[user.userid] = {};
	}
	
	steamSystem_depositInventoryByGames(user.userid, user.binds.steam, game, 0, offset, [], function(err1, total_items){
		if(err1){
			socket.emit('message', {
				type: 'offers',
				command: 'error',
				error: err1.message
			});
			
			offers_inventoryDeposit[user.userid][method + '_' + game] = {
				time: time() + config.config_offers.steam.cooldown_inventory,
				items: [],
				error: {
					have: true,
					error: err1.message
				}
			}
			
			socket.emit('message', {
				type: 'offers',
				command: 'wait',
				time: config.config_offers.steam.cooldown_inventory
			});
			
			return cooldown(false, false);
		}
		
		if(total_items.length > 0){			
			socket.emit('message', {
				type: 'offers',
				command: 'add_items',
				offer: {
					items: total_items,
					paths: ['deposit', method, game],
					more: false
				}
			});
		} else {
			socket.emit('message', {
				type: 'offers',
				command: 'error',
				error: 'Your Inventory is currently empty.'
			});	
		}
		
		offers_inventoryDeposit[user.userid][method + '_' + game] = {
			time: time() + config.config_offers.steam.cooldown_inventory,
			items: total_items,
			error: {
				have: false,
				error: ''
			}
		}
		
		socket.emit('message', {
			type: 'offers',
			command: 'wait',
			time: config.config_offers.steam.cooldown_inventory
		});
		
		cooldown(false, false);
	});
}

function steamSystem_depositInventoryByGames(userid, steamid, game, gameid, offset, total_items, callback){
	if(gameid >= Object.keys(config.config_offers.steam.games).length) return callback(null, total_items);
	
	if(game != Object.keys(config.config_offers.steam.games)[gameid]) return steamSystem_depositInventoryByGames(userid, steamid, game, gameid + 1, offset, total_items, callback);
	
	getUserInventory(steamid, config.config_offers.steam.games[Object.keys(config.config_offers.steam.games)[gameid]].game.appid, config.config_offers.steam.games[Object.keys(config.config_offers.steam.games)[gameid]].game.contextid, function(err1, items){
		if(err1) return callback(new Error('We can\'t load your inventory.'));
		
		steamSystem_depositInventoryByItems(userid, steamid, Object.keys(config.config_offers.steam.games)[gameid], items, 0, offset, [], [], function(err2, new_total_items){
			if(err2) return callback(err2);
			
			return steamSystem_depositInventoryByGames(userid, steamid, game, gameid + 1, offset, total_items.concat(new_total_items), callback);
		});
	});
}

function steamSystem_depositInventoryByItems(userid, steamid, game, items, itemid, offset, total_items, inspect_items, callback){
	if(items[itemid] === undefined) {
		if(inspect_items.length > 0) {
			requestItemsInspect(userid, inspect_items, function(err1, new_items){
				if(err1) logger.error(new Error('[BOT] Error Loading Info (1): ' + err1.message));
				else {
					new_items.forEach(function(item){
						if(item.wear != null) pool.query('INSERT INTO `steam_items` SET `itemid` = ' + pool.escape(item.id) + ', `wear` = ' + parseFloat(item.wear) + ', `paintindex` = ' + parseInt(item.paintindex) + ', `time` = ' + pool.escape(time()), function(err2){
							if(err2) logger.error(new Error('[BOT] Error Loading Info (2): ' + err2.message));
						});
					});
				} 
				
				callback(null, total_items.concat(new_items));
			});
		} else callback(null, total_items);
	} else {
		var price = getFormatAmount(pricesSystem_getPrice(items[itemid].name, config.config_offers.steam.games[game].game.appid));
		if(price > 0) price = getFormatAmount(parseFloat(price + getFeeFromCommission(price, offset)));
		
		var tradelocked = {
			tradelocked: false,
			time: null
		};
		
		if(items[itemid].tradelocked) {
			tradelocked = {
				tradelocked: true,
				time: items[itemid].tradelocked - time()
			}
		}
		
		/* -- ACCEPTING --*/
		
		var accepted = true;
		var view = true;
		
		if(accepted) if(!tradelocked.tradelocked && (!items[itemid].marketable || !items[itemid].tradable)) accepted = false;
		if(accepted) if(total_items.filter(a => a.id == itemid).length > 0) accepted = false;
		if(accepted) if(p2pStstem_items[items[itemid].assetid] !== undefined) if(p2pStstem_items[items[itemid].assetid] == true) accepted = false;
		if(accepted) if(price == null) accepted = false;
		if(accepted) if(price <= 0) accepted = false;
		if(accepted) if(price < config.config_site.interval_amount.deposit_item.min || price > config.config_site.interval_amount.deposit_item.max) accepted = false;
		if(accepted) if(config.config_offers.steam.blacklist_items[game].filter(a => items[itemid].name.toLowerCase().indexOf(a.toLowerCase()) >= 0).length > 0) accepted = false;
		
		if(view) if(!items[itemid].marketable) view = false;
		if(view) if(total_items.filter(a => a.id == itemid).length > 0) view = false;
		if(view) if(price == null) view = false;
		if(view) if(price <= 0) view = false;
		
		if(!view) return steamSystem_depositInventoryByItems(userid, steamid, game, items, itemid + 1, offset, total_items, inspect_items, callback);
		
		if(items[itemid].inspect && offers_itemExteriors.includes(getInfosByItemName(items[itemid].name).exterior)){
			pool.query('SELECT `wear` FROM `steam_items` WHERE `itemid` = ' + pool.escape(items[itemid].assetid), function(err1, row1) {
				if(err1) {
					logger.error(err1);
					writeError(err1);
					
					total_items.push(Object.assign(generateItem(items[itemid], {
						'price': price,
						'offset': offset
					}), {
						'inspect': items[itemid].inspect,
						'accepted': accepted,
						'tradelocked': tradelocked
					}));
					
					return steamSystem_depositInventoryByItems(userid, steamid, game, items, itemid + 1, offset, total_items, inspect_items, callback);
				}
				
				if(row1.length > 0){
					total_items.push(Object.assign(generateItem(items[itemid], {
						'price': price,
						'offset': offset,
						'wear': row1[0].wear
					}), {
						'inspect': items[itemid].inspect,
						'accepted': accepted,
						'tradelocked': tradelocked
					}));
					
					steamSystem_depositInventoryByItems(userid, steamid, game, items, itemid + 1, offset, total_items, inspect_items, callback);
				} else {
					inspect_items.push({
						item: Object.assign(generateItem(items[itemid], {
							'price': price,
							'offset': offset
						}), {
							'inspect': items[itemid].inspect,
							'accepted': accepted,
							'tradelocked': tradelocked
						}),
						inspect: {
							s: steamid,
							a: items[itemid].assetid,
							d: items[itemid].inspect.split('A' + items[itemid].assetid + 'D')[1]
						}
					});
					
					steamSystem_depositInventoryByItems(userid, steamid, game, items, itemid + 1, offset, total_items, inspect_items, callback)
				}
			});
		} else {
			total_items.push(Object.assign(generateItem(items[itemid], {
				'price': price,
				'offset': offset
			}), {
				'inspect': items[itemid].inspect,
				'accepted': accepted,
				'tradelocked': tradelocked
			}));
			
			steamSystem_depositInventoryByItems(userid, steamid, game, items, itemid + 1, offset, total_items, inspect_items, callback);
		}
	}
}

/* END DEPOSIT */

/* WITHDRAW */

offers_steamLoadBotItems();
function offers_steamLoadBotItems(){
	pool.query('SELECT `itemid`, `status` FROM `steam_inventory` WHERE `status` != 2', function(err1, items) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return;
		}
		
		items.forEach(function(item){
			if(offers_steamSiteInventory[item.itemid] === undefined) offers_steamSiteInventory[item.itemid] = parseInt(item.status) == 1 ? true : false;
		});
		
		logger.debug('[BOT] Items withdraw loaded!');
	});
}

function steamSystem_withdraw(user, socket, game, items, bot, recaptcha, cooldown){
	cooldown(true, true);
	
	site_verifyRecaptcha(recaptcha, function(verified){
		if(!verified){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid recaptcha!'
			});
			
			return cooldown(false, true);
		}
		
		if(config.settings.trades.manually.enable.steam) {
			socket.emit('message', {
				type: 'info',
				info: 'Preparing withdraw request. Please wait...'
			});
			
			return steamSystem_confirmWithdraw(user, game, items, bot, function(err1, listingid){
				if(err1){
					socket.emit('message', {
						type: 'error',
						error: err1.message
					});
					
					return cooldown(false, true);
				}
				
				socket.emit('message', {
					type: 'info',
					info: 'Your steam withdraw order was listed. Admin confirmations required!'
				});
				
				cooldown(false, false);
			});
		}
		
		socket.emit('message', {
			type: 'info',
			info: 'Preparing withdraw request. Please wait...'
		});
		
		steamSystem_confirmWithdraw(user, game, items, bot, function(err1, offerid){
			if(err1){
				socket.emit('message', {
					type: 'error',
					error: err1.message
				});
				
				return cooldown(false, true);
			}
			
			cooldown(false, false);
		});
	});
}

function steamSystem_confirmWithdraw(user, game, items, bot, callback){
	if(user.binds.steam === undefined) return callback(new Error('Please bind your Steam Account!'));
	
	if((user.restrictions.trade >= time() || user.restrictions.trade == -1) && !config.config_site.bantrade_excluded.includes(config.config_site.ranks_name[user.rank])) return callback(new Error('Error: You are restricted to use our trade. The restriction expires ' + ((user.restrictions.trade == -1) ? 'never' : makeDate(new Date(user.restrictions.trade * 1000))) + '.'));
	
	if(!user.verified > time()) return callback(new Error('Error: Your account is not verified. Please verify your account and try again.'));
	
	if(!user.tradelink) return callback(new Error('Error: Firstly, you must set your valid Steam Trade Link from settings.'));
	
	if(config.config_offers.steam.games[game] === undefined) return callback(new Error('Invalid withdraw game!'));
	
	if(items.length < config.config_site.interval_items.withdraw.min || items.length > config.config_site.interval_items.withdraw.max) return callback(new Error('Error: Invalid items amount [' + config.config_site.interval_items.withdraw.min + '-' + config.config_site.interval_items.withdraw.max + ']!'));
	
	steamSystem_withdrawByGames(game, 0, items, config.config_offers.steam.withdraw_offset, [], 0, function(err1, total_items, total_price){
		if(err1) return callback(new Error('Error: ' + err1.message));
		
		if(total_items.length != items.length) return callback(new Error('Error: Invalids items in your offer. Please refresh your inventory!'));
		
		if(total_price < config.config_site.interval_amount.withdraw_steam.min || total_price > config.config_site.interval_amount.withdraw_steam.max) return callback(new Error('Error: Invalid withdraw amount [' + getFormatAmountString(config.config_site.interval_amount.withdraw_steam.min) + '-' + getFormatAmountString(config.config_site.interval_amount.withdraw_steam.max)  + ']!'));
		
		if(user.deposit.count <= 0) return callback(new Error('Error: You need to deposit minimum 1 time to withdraw!'));
		
		//CHECK BALANCE
		user_getBalance(user.userid, function(err2, balance){
			if(err2) return callback(new Error('Error: ' + err2.message));
			
			if(balance < total_price) {
				io.sockets.in(user.userid).emit('message', {
					type: 'modal',
					modal: 'insufficient_balance',
					data: {
						amount: getFormatAmount(total_price - balance)
					}
				});
				
				return callback(new Error('Error: You don\'t have enough money!'));
			}
			
			if(user.available < total_price) return callback(new Error('Error: You need to have withdraw available ' + getFormatAmountString(total_price) + ' coins. Need ' + getFormatAmountString(total_price - user.available) + '!'));
			
			if(!haveBotByIndex(bot)) return callback(new Error('Error: This bot is not active anymore. Please try again later.'));
			
			if(config.settings.trades.manually.enable.steam && getFormatAmount(total_price) >= getFormatAmount(config.settings.trades.manually.amount)) {
				return steamSystem_withdrawManually(user, game, items, bot, total_items, total_price, function(err1, listingid){
					if(err1) return callback(err1);
					
					callback(null, listingid);
				});
			}
			
			steamSystem_withdrawAutomatically(user, game, items, bot, total_items, total_price, function(err1, offerid){
				if(err1) return callback(err1);
				
				callback(null, offerid);
			});
		});
	});
}

function steamSystem_withdrawManually(user, game, items, bot, total_items, total_price, callback){
	//EDIT ITEMS
	total_items.forEach(function(item){
		pool.query('UPDATE `steam_inventory` SET `status` = 1 WHERE `itemid` = ' + pool.escape(item.id) + ' AND `status` = 0', function(err1, row1) {
			if(err1) {
				logger.error(err1);
				writeError(err1);
				return;
			}
			
			if(row1.affectedRows > 0) if(offers_steamSiteInventory[item.id] !== undefined) offers_steamSiteInventory[item.id] = true;
		});
	});
	
	//EDIT BALANCE
	user_editBalance(user.userid, -total_price, 'steam_withdraw', function(err1){
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return callback(new Error('Error in steam manually withdraw (1)'));
		}
		
		user_updateBalance(user.userid);
		
		pool.query('UPDATE `users` SET `available` = `available` - ' + total_price + ' WHERE `userid` = ' + pool.escape(user.userid), function(err2) {
			if(err2) {
				logger.error(err2);
				writeError(err2);
				return callback(new Error('Error in steam manually withdraw (2)'));
			}
			
			pool.query('INSERT INTO `steam_listings` SET `type` = ' + pool.escape('withdraw') + ', `userid` = ' + pool.escape(user.userid) + ', `steamid` = ' + pool.escape(user.binds.steam) + ', `tradelink` = ' + pool.escape(user.tradelink) + ', `items` = ' + pool.escape(getSqlItems(total_items)) + ', `amount` = ' + total_price + ', `game` = ' + pool.escape(game) + ', `bot` = ' + pool.escape(bot) + ', `time` = ' + pool.escape(time()), function(err3, row3) {
				if(err3) {
					logger.error(err3);
					writeError(err3);
					return callback(new Error('Error in steam manually withdraw (3)'));
				}
				
				//REMOVE ITEMS FROM WITHDRAW
				io.sockets.in('withdraw').emit('message', {
					type: 'offers',
					command: 'remove_items',
					offer: {
						items: total_items,
						paths: ['withdraw', 'steam', game],
						all: false
					}
				});
				
				logger.debug('[STEAM] Withdraw listing #' + row3.insertId + ' has been listed. Admin confirmations required');
				
				callback(null, row3.insertId);
			});
		});
	});
}

function steamSystem_withdrawAutomatically(user, game, items, bot, total_items, total_price, callback){
	var steam_bot = getBotByIndex(bot);
	
	var offer_code = generateHexCode(24);
	var offer_message = offer_code;
	
	offers_steamSendOffer(user.binds.steam, user.tradelink, offer_message, items, [], steam_bot.steamid, function(err1, offer){
		if(err1) return callback(new Error('Error: There was an error sending your trade offer. Please try again later.'));
		
		logger.warn('[BOT] ' + steam_bot.name + ' - WITHDRAW | ' + user.userid + ' | Offer #' + offer.id + ' Was Sent');
		
		//EDIT ITEMS
		total_items.forEach(function(item){
			pool.query('UPDATE `steam_inventory` SET `status` = 1 WHERE `itemid` = ' + pool.escape(item.id) + ' AND `status` = 0', function(err2, row2) {
				if(err2) {
					logger.error(err2);
					writeError(err2);
					return;
				}
				
				if(row2.affectedRows > 0) if(offers_steamSiteInventory[item.id] !== undefined) offers_steamSiteInventory[item.id] = true;
			});
		});
		
		//EDIT BALANCE
		user_editBalance(user.userid, -total_price, 'steam_withdraw', function(err3){
			if(err3) {
				logger.error(err3);
				writeError(err3);
				return callback(new Error('Error in steam automatically withdraw (1)'));
			}
			
			user_updateBalance(user.userid);
			
			pool.query('UPDATE `users` SET `available` = `available` - ' + total_price + ' WHERE `userid` = ' + pool.escape(user.userid), function(err4) {
				if(err4) {
					logger.error(err4);
					writeError(err4);
					return callback(new Error('Error in steam automatically withdraw (2)'));
				}
				
				pool.query('INSERT INTO `steam_transactions` SET `type` = ' + pool.escape('withdraw') + ', `userid` = ' + pool.escape(user.userid) + ', `name` = ' + pool.escape(user.name) + ', `avatar` = ' + pool.escape(user.avatar) + ', `xp` = ' + pool.escape(user.xp) + ', `steamid` = ' + pool.escape(user.binds.steam) + ', `items` = ' + pool.escape(getSqlItems(total_items)) + ', `amount` = ' + total_price + ', `code` = ' + pool.escape(offer_code) + ', `game` = ' + pool.escape(game) + ', `tradeofferid` = ' + pool.escape(offer.id) + ', `botsteamid` = ' + pool.escape(steam_bot.steamid) + ', `time` = ' + pool.escape(time()), function(err5, row5) {
					if(err5) {
						logger.error(err5);
						writeError(err5);
						return callback(new Error('Error in steam automatically withdraw (3)'));
					}
					
					offers_steamActiveOffers[offer.id] = {
						id: row5.insertId,
						status: 0,
						type: 'withdraw',
						refill: false,
						user: {
							userid: user.userid,
							name: user.name,
							avatar: user.avatar,
							level: calculateLevel(user.xp).level
						},
						game: game,
						items: total_items,
						amount: total_price,
						time_created: time(),
						tradeofferid: offer.id,
						code: offer_code,
						time: null,
						timeout: null
					};
					
					//REMOVE ITEMS FROM WITHDRAW
					io.sockets.in('withdraw').emit('message', {
						type: 'offers',
						command: 'remove_items',
						offer: {
							items: offers_steamActiveOffers[offer.id].items,
							paths: [offers_steamActiveOffers[offer.id].type, 'steam', game],
							all: false
						}
					});
					
					//ADD PENDING TO BUYER
					io.sockets.in(offers_steamActiveOffers[offer.id].user.userid).emit('message', {
						type: 'offers',
						command: 'add_pending',
						offer: {
							id: offers_steamActiveOffers[offer.id].id,
							type: offers_steamActiveOffers[offer.id].type,
							method: 'steam',
							status: offers_steamActiveOffers[offer.id].status,
							items: offers_steamActiveOffers[offer.id].items,
							data: {
								tradeofferid: offers_steamActiveOffers[offer.id].tradeofferid,
								code: offers_steamActiveOffers[offer.id].code
							}
						}
					});
					
					steam_bot.community.checkConfirmations();
					
					logger.debug('[STEAM] Withdraw order #' + row5.insertId + ' has been prepared');
					
					callback(null, offer.id);
				});
			});
		});
	});
}

function steamSystem_listingConfirm(user, id, callback){
	pool.query('SELECT * FROM `steam_listings` WHERE `id` = ' + pool.escape(id), function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return callback(new Error('Error in confirming steam withdraw listing (1)'));
		}
		
		if(row1.length <= 0) return callback(new Error('Error: Unknown steam withdraw listing!'));
		if(parseInt(row1[0].confirmed)) return callback(new Error('Error: Steam withdraw listing already confirmed!'));
		if(parseInt(row1[0].canceled)) return callback(new Error('Error: Steam withdraw listing is canceled!'));
		
		pool.query('SELECT * FROM `users` WHERE `userid` = ' + pool.escape(row1[0].userid), function(err2, row2) {
			if(err2) {
				logger.error(err2);
				writeError(err2);
				return callback(new Error('Error in confirming steam withdraw listing (2)'));
			}
			
			if(row2.length <= 0) return callback(new Error('Error: Unknown user listing!'));
			
			var game = row1[0].game;
			var bot = parseInt(row1[0].bot);
			var steamid = row1[0].steamid;
			var tradelink = row1[0].tradelink;
			
			var total_items = getItemsFromSql(row1[0].items);
			var total_price = getFormatAmount(row1[0].amount);
			
			var items = [];
			total_items.forEach(function(item){ items.push({ 'id': item.id, 'game': item.game }) });
			
			if(config.config_offers.steam.games[game] === undefined) return callback(new Error('Invalid withdraw game!'));
			
			var offer_code = generateHexCode(24);
			var offer_message = offer_code;
			
			if(!haveActiveBots('trade')) return callback(new Error('Error: There are no active bots. Please try again later.'));
			
			var steam_bot = getBotByIndex(bot);
			
			offers_steamSendOffer(steamid, tradelink, offer_message, items, [], steam_bot.steamid, function(err3, offer){
				if(err3) return callback(new Error('Error: There was an error sending your trade offer. Please try again later.'));
				
				logger.warn('[BOT] ' + steam_bot.name + ' - WITHDRAW | ' + row2[0].userid + ' | Offer #' + offer.id + ' Was Sent');
				
				pool.query('INSERT INTO `steam_transactions` SET `type` = ' + pool.escape('withdraw') + ', `userid` = ' + pool.escape(row2[0].userid) + ', `name` = ' + pool.escape(row2[0].name) + ', `avatar` = ' + pool.escape(row2[0].avatar) + ', `xp` = ' + pool.escape(row2[0].xp) + ', `steamid` = ' + pool.escape(steamid) + ', `items` = ' + pool.escape(getSqlItems(total_items)) + ', `amount` = ' + total_price + ', `code` = ' + pool.escape(offer_code) + ', `game` = ' + pool.escape(game) + ', `tradeofferid` = ' + pool.escape(offer.id) + ', `botsteamid` = ' + pool.escape(steam_bot.steamid) + ', `time` = ' + pool.escape(time()), function(err4, row4) {
					if(err4) {
						logger.error(err4);
						writeError(err4);
						return callback(new Error('Error in confirming steam withdraw listing (3)'));
					}
					
					offers_steamActiveOffers[offer.id] = {
						id: row4.insertId,
						status: 0,
						type: 'withdraw',
						refill: false,
						user: {
							userid: row2[0].userid,
							name: row2[0].name,
							avatar: row2[0].avatar,
							level: calculateLevel(row2[0].xp).level
						},
						game: game,
						items: total_items,
						amount: total_price,
						time_created: time(),
						tradeofferid: offer.id,
						code: offer_code,
						time: null,
						timeout: null
					};
					
					//REMOVE ITEMS FROM WITHDRAW
					io.sockets.in('withdraw').emit('message', {
						type: 'offers',
						command: 'remove_items',
						offer: {
							items: offers_steamActiveOffers[offer.id].items,
							paths: [offers_steamActiveOffers[offer.id].type, 'steam', game],
							all: false
						}
					});
					
					//ADD PENDING TO BUYER
					io.sockets.in(offers_steamActiveOffers[offer.id].user.userid).emit('message', {
						type: 'offers',
						command: 'add_pending',
						offer: {
							id: offers_steamActiveOffers[offer.id].id,
							type: offers_steamActiveOffers[offer.id].type,
							method: 'steam',
							status: offers_steamActiveOffers[offer.id].status,
							items: offers_steamActiveOffers[offer.id].items,
							data: {
								tradeofferid: offers_steamActiveOffers[offer.id].tradeofferid,
								code: offers_steamActiveOffers[offer.id].code
							}
						}
					});
					
					steam_bot.community.checkConfirmations();
					
					logger.debug('[STEAM] Withdraw order #' + row4.insertId + ' has been prepared');
					
					pool.query('UPDATE `steam_listings` SET `confirmed` = 1 WHERE `id` = ' + pool.escape(row1[0].id) + ' AND `confirmed` = 0 AND `canceled` = 0', function(err5) {
						if(err5) {
							logger.error(err5);
							writeError(err5);
							return callback(new Error('Error in confirming steam withdraw listing (4)'));
						}
						
						pool.query('INSERT INTO `steam_confirmations` SET `userid` = ' + pool.escape(user.userid) + ', `listingid` = ' + pool.escape(row1[0].id) + ', `transactionid` = ' + pool.escape(row4.insertId), function(err6) {
							if(err6) {
								logger.error(err6);
								writeError(err6);
								return callback(new Error('Error in confirming steam withdraw listing (5)'));
							}
							
							callback(null, row4.insertId);
						});
					});
				});
			});
		});
	});
}

function steamSystem_listingCancel(user, id, callback){
	pool.query('SELECT * FROM `steam_listings` WHERE `id` = ' + pool.escape(id), function(err1, row1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			return callback(new Error('Error in canceling steam withdraw listing (1)'));
		}
		
		if(row1.length <= 0) return callback(new Error('Error: Unknown steam withdraw listing!'));
		if(parseInt(row1[0].confirmed)) return callback(new Error('Error: Steam withdraw listing id confirmed!'));
		if(parseInt(row1[0].canceled)) return callback(new Error('Error: Steam withdraw listing already canceled!'));
		
		var amount = getFormatAmount(row1[0].amount);
		
		var game = row1[0].game;
		var bot = parseInt(row1[0].bot);
		
		var total_items = getItemsFromSql(row1[0].items);
		
		//EDIT BALANCE
		user_editBalance(row1[0].userid, amount, 'steam_withdraw_refund', function(err2){
			if(err2) {
				logger.error(err2);
				writeError(err2);
				return callback(new Error('Error in canceling steam withdraw listing (2)'));
			}
			
			user_updateBalance(row1[0].userid);
			
			pool.query('UPDATE `users` SET `available` = `available` + ' + amount + ' WHERE `userid` = ' + pool.escape(row1[0].userid), function(err3) {
				if(err3) {
					logger.error(err3);
					writeError(err3);
					return callback(new Error('Error in canceling steam withdraw listing (3)'));
				}
				
				pool.query('UPDATE `steam_listings` SET `canceled` = 1 WHERE `id` = ' + pool.escape(row1[0].id) + ' AND `confirmed` = 0 AND `canceled` = 0', function(err4) {
					if(err4) {
						logger.error(err4);
						writeError(err4);
						return callback(new Error('Error in canceling steam withdraw listing (4)'));
					}
					
					io.sockets.in(row1[0].userid).emit('message', {
						type: 'info',
						info: 'Your steam withdraw order was canceled!'
					});
					
					//ADD ITEMS TO WITHDRAW
					io.sockets.in('withdraw').emit('message', {
						type: 'offers',
						command: 'add_items',
						offer: {
							items: offers_assignItemsType(total_items, { type: 'withdraw', method: 'steam', game: game, tradelocked: false, offset: true, bot: bot }),
							paths: ['withdraw', 'steam', game],
							more: true
						}
					});
					
					//EDIT ITEMS
					total_items.forEach(function(item){
						pool.query('UPDATE `steam_inventory` SET `status` = 0 WHERE `itemid` = ' + pool.escape(item.id) + ' AND `status` = 1', function(err5, row5) {
							if(err5) {
								logger.error(err5);
								writeError(err5);
								return;
							}
							
							if(row5.affectedRows > 0) if(offers_steamSiteInventory[item.id] !== undefined) offers_steamSiteInventory[item.id] = false;
						});
					});
				
					logger.debug('[STEAM] Withdraw listing #' + row1[0].id + ' has been canceled');
					
					callback(null);
				});
			});
		});
	});
}

function steamSystem_withdrawByGames(game, gameid, itemsid, offset, total_items, total_price, callback) {
	if(gameid >= Object.keys(config.config_offers.steam.games).length) return callback(null, total_items, total_price);
	
	if(game != Object.keys(config.config_offers.steam.games)[gameid]) return steamSystem_withdrawByGames(game, gameid + 1, itemsid, offset, total_items, total_price, callback);
	
	steamSystem_withdrawByBots(Object.keys(config.config_offers.steam.games)[gameid], 0, itemsid, offset, [], 0, function(err1, new_total_items, new_total_price){
		if(err1) return callback(err1);
		
		return steamSystem_withdrawByGames(game, gameid + 1, itemsid, offset, total_items.concat(new_total_items), getFormatAmount(total_price + new_total_price), callback);
	});
}

function steamSystem_withdrawByBots(game, bot, itemsid, offset, total_items, total_price, callback) {
	if(getBotByIndex(bot) === undefined) return callback(new Error('Error: Invalid bot. Please try again later.'));
	
	if(!getBotByIndex(bot).connected || !getBotByIndex(bot).can_trade || !getBotByIndex(bot).active) return callback(new Error('Error: The bot is no longer active. Please try again later.'));
	
	getUserInventory(getBotByIndex(bot).steamid, config.config_offers.steam.games[game].game.appid, config.config_offers.steam.games[game].game.contextid, function(err1, items){
		if(err1) return callback(new Error('We can\'t load shop inventory.'));
		
		steamSystem_withdrawByItems(game, bot, items, 0, itemsid, offset, [], 0, function(err2, new_total_items, new_total_price){
			if(err2) return callback(err2);
			
			return callback(null, total_items.concat(new_total_items), getFormatAmount(total_price + new_total_price));
		});
	});
}

function steamSystem_withdrawByItems(game, bot, items, itemid, itemsid, offset, total_items, total_price, callback){
	if(items[itemid] === undefined) return callback(null, total_items, total_price);
	
	if(itemsid.filter(a => a.id == items[itemid].assetid.toString()).length <= 0) return steamSystem_withdrawByItems(game, bot, items, itemid + 1, itemsid, offset, total_items, total_price, callback);
	
	var price = getFormatAmount(pricesSystem_getPrice(items[itemid].name, config.config_offers.steam.games[game].game.appid));
	if(price > 0) price = getFormatAmount(parseFloat(price + getFeeFromCommission(price, offset)));
	
	/* -- ACCEPTING --*/
	
	var accepted = true;
	
	if(accepted) if(!items[itemid].marketable || !items[itemid].tradable) accepted = false;
	if(accepted) if(total_items.filter(a => a.id == itemid).length > 0) accepted = false;
	if(accepted) if(offers_steamSiteInventory[items[itemid].assetid] === undefined || offers_steamSiteInventory[items[itemid].assetid] == true) accepted = false;
	if(accepted) if(price == null) accepted = false;
	if(accepted) if(price <= 0) accepted = false;
	if(accepted) if(price < config.config_site.interval_amount.withdraw_item.min || price > config.config_site.interval_amount.withdraw_item.max) accepted = false;
	if(accepted) if(config.config_offers.steam.blacklist_items[game].filter(a => items[itemid].name.toLowerCase().indexOf(a.toLowerCase()) >= 0).length > 0) accepted = false;
	
	if(!accepted) return steamSystem_withdrawByItems(game, bot, items, itemid + 1, itemsid, offset, total_items, total_price, callback);
	
	if(items[itemid].inspect && offers_itemExteriors.includes(getInfosByItemName(items[itemid].name).exterior)){
		pool.query('SELECT * FROM `steam_items` WHERE `itemid` = ' + parseInt(items[itemid].assetid), function(err1, row1) {
			if(err1) {
				logger.error(err1);
				writeError(err1);
				
				total_items.push(Object.assign(generateItem(items[itemid], {
					'price': price,
					'offset': offset
				}), {}));
				total_price += price;
				
				return steamSystem_withdrawByItems(game, bot, items, itemid + 1, itemsid, offset, total_items, total_price, callback);
			}
			
			if(row1.length > 0){
				total_items.push(Object.assign(generateItem(items[itemid], {
					'price': price,
					'offset': offset,
					'wear': row1[0].wear
				}), {}));
				total_price += price;
				
				steamSystem_withdrawByItems(game, bot, items, itemid + 1, itemsid, offset, total_items, total_price, callback);
			} else {
				total_items.push(Object.assign(generateItem(items[itemid], {
					'price': price,
					'offset': offset
				}), {}));
				total_price += price;
				
				steamSystem_withdrawByItems(game, bot, items, itemid + 1, itemsid, offset, total_items, total_price, callback);
			}
		});
	} else {
		total_items.push(Object.assign(generateItem(items[itemid], {
			'price': price,
			'offset': offset
		}), {}));
		total_price += price;
		
		steamSystem_withdrawByItems(game, bot, items, itemid + 1, itemsid, offset, total_items, total_price, callback);
	}
}

function steamSystem_withdrawInventory(user, socket, method, game, offset, cooldown){
	cooldown(true, true);
	
	if(config.config_offers.steam.games[game] === undefined){
		socket.emit('message', {
			type: 'offers',
			command: 'error',
			error: 'Invalid withdraw game!'
		});
		
		return cooldown(false, true);
	}
	
	if(offers_inventoryWithdraw[user.userid] !== undefined){
		if(offers_inventoryWithdraw[user.userid][method + '_' + game] !== undefined){
			if(offers_inventoryWithdraw[user.userid][method + '_' + game]['time'] - time() > 0){
				if(offers_inventoryWithdraw[user.userid][method + '_' + game]['error']['have']){			
					socket.emit('message', {
						type: 'offers',
						command: 'error',
						error: offers_inventoryWithdraw[user.userid][method + '_' + game]['error']['error']
					});
				} else {
					if(offers_inventoryWithdraw[user.userid][method + '_' + game]['items'].length > 0){
						socket.emit('message', {
							type: 'offers',
							command: 'add_items',
							offer: {
								items: offers_inventoryWithdraw[user.userid][method + '_' + game]['items'],
								paths: ['withdraw', method, game],
								more: false
							}
						});
					} else {
						socket.emit('message', {
							type: 'offers',
							command: 'error',
							error: 'The Marketplace is currently empty.'
						});	
					}
				}
				
				socket.emit('message', {
					type: 'offers',
					command: 'wait',
					time: offers_inventoryWithdraw[user.userid][method + '_' + game]['time'] - time()
				});
				
				return cooldown(false, false);
			}
		}
	} else {
		offers_inventoryWithdraw[user.userid] = {};
	}
	
	steamSystem_withdrawInventoryByGames(game, 0, offset, [], function(err1, total_items){
		if(err1){
			socket.emit('message', {
				type: 'offers',
				command: 'error',
				error: err1.message
			});
			
			offers_inventoryWithdraw[user.userid][method + '_' + game] = {
				time: time() + config.config_offers.steam.cooldown_inventory,
				items: [],
				error: {
					have: true,
					error: err1.message
				}
			};
			
			socket.emit('message', {
				type: 'offers',
				command: 'wait',
				time: config.config_offers.steam.cooldown_inventory
			});
			
			return cooldown(false, false);
		}
		
		if(total_items.length > 0){
			socket.emit('message', {
				type: 'offers',
				command: 'add_items',
				offer: {
					items: total_items,
					paths: ['withdraw', method, game],
					more: false
				}
			});
		} else {
			socket.emit('message', {
				type: 'offers',
				command: 'error',
				error: 'The Marketplace is currently empty.'
			});	
		}
		
		offers_inventoryWithdraw[user.userid][method + '_' + game] = {
			time: time() + config.config_offers.steam.cooldown_inventory,
			items: total_items,
			error: {
				have: false,
				error: ''
			}
		};
		
		socket.emit('message', {
			type: 'offers',
			command: 'wait',
			time: config.config_offers.steam.cooldown_inventory
		});
		
		cooldown(false, false);
	});
}

function steamSystem_withdrawInventoryByGames(game, gameid, offset, total_items, callback) {
	if(gameid >= Object.keys(config.config_offers.steam.games).length) return callback(null, total_items);
	
	if(game != Object.keys(config.config_offers.steam.games)[gameid]) return steamSystem_withdrawInventoryByGames(game, gameid + 1, offset, total_items, callback);
	
	steamSystem_withdrawInventoryByBots(Object.keys(config.config_offers.steam.games)[gameid], 0, offset, [], function(err1, new_total_items){
		if(err1) return callback(err1);
		
		 return steamSystem_withdrawInventoryByGames(game, gameid + 1, offset, total_items.concat(new_total_items), callback)
	});
}

function steamSystem_withdrawInventoryByBots(game, bot, offset, total_items, callback) {
	if(getBotByIndex(bot) === undefined) return callback(null, total_items);
	
	if(!getBotByIndex(bot).connected || !getBotByIndex(bot).can_trade || !getBotByIndex(bot).active) return steamSystem_withdrawInventoryByBots(game, bot + 1, offset, total_items, callback);
	
	getUserInventory(getBotByIndex(bot).steamid, config.config_offers.steam.games[game].game.appid, config.config_offers.steam.games[game].game.contextid, function(err1, items){
		if(err1) return callback(new Error('We can\'t load shop inventory.'));
		
		steamSystem_withdrawInventoryByItems(game, bot, items, 0, offset, [], function(err2, new_total_items){
			if(err2) return callback(err2);
			
			return steamSystem_withdrawInventoryByBots(game, bot + 1, offset, total_items.concat(new_total_items), callback);
		});
	});
}

function steamSystem_withdrawInventoryByItems(game, bot, items, itemid, offset, total_items, callback){
	if(items[itemid] === undefined) return callback(null, total_items);
	
	var price = getFormatAmount(pricesSystem_getPrice(items[itemid].name, config.config_offers.steam.games[game].game.appid));
	if(price > 0) price = getFormatAmount(parseFloat(price + getFeeFromCommission(price, offset)));
	
	var tradelocked = {
		tradelocked: false,
		time: null
	};
	
	if(items[itemid].tradelocked) {
		tradelocked = {
			tradelocked: true,
			time: items[itemid].tradelocked - time()
		}
	}
	
	/* -- ACCEPTING --*/
	
	var accepted = true;
	var view = true;
	
	if(accepted) if(!tradelocked.tradelocked && (!items[itemid].marketable || !items[itemid].tradable)) accepted = false;
	if(accepted) if(total_items.filter(a => a.id == itemid).length > 0) accepted = false;
	if(accepted) if(offers_steamSiteInventory[items[itemid].assetid] === undefined || offers_steamSiteInventory[items[itemid].assetid] == true) accepted = false;
	if(accepted) if(price == null) accepted = false;
	if(accepted) if(price <= 0) accepted = false;
	if(accepted) if(price < config.config_site.interval_amount.withdraw_item.min || price > config.config_site.interval_amount.withdraw_item.max) accepted = false;
	if(accepted) if(config.config_offers.steam.blacklist_items[game].filter(a => items[itemid].name.toLowerCase().indexOf(a.toLowerCase()) >= 0).length > 0) accepted = false;
	
	if(view) if(!items[itemid].marketable) view = false;
	if(view) if(total_items.filter(a => a.id == itemid).length > 0) view = false;
	if(view) if(offers_steamSiteInventory[items[itemid].assetid] === undefined || offers_steamSiteInventory[items[itemid].assetid] == true) view = false;
	if(view) if(price == null) view = false;
	if(view) if(price <= 0) view = false;
	
	if(!view) return steamSystem_withdrawInventoryByItems(game, bot, items, itemid + 1, offset, total_items, callback);
	
	if(items[itemid].inspect && offers_itemExteriors.includes(getInfosByItemName(items[itemid].name).exterior)){
		pool.query('SELECT * FROM `steam_items` WHERE `itemid` = ' + parseInt(items[itemid].assetid), function(err1, row1) {
			if(err1) {
				logger.error(err1);
				writeError(err1);
				
				total_items.push(Object.assign(generateItem(items[itemid], {
					'price': price,
					'offset': offset
				}), {
					'inspect': items[itemid].inspect,
					'accepted': accepted,
					'tradelocked': tradelocked,
					'bot': bot
				}));
				
				return steamSystem_withdrawInventoryByItems(game, bot, items, itemid + 1, offset, total_items, callback);
			}
			
			if(row1.length > 0){
				total_items.push(Object.assign(generateItem(items[itemid], {
					'price': price,
					'offset': offset,
					'wear': row1[0].wear
				}), {
					'inspect': items[itemid].inspect,
					'accepted': accepted,
					'tradelocked': tradelocked,
					'bot': bot
				}));
				
				steamSystem_withdrawInventoryByItems(game, bot, items, itemid + 1, offset, total_items, callback);
			} else {
				total_items.push(Object.assign(generateItem(items[itemid], {
					'price': price,
					'offset': offset
				}), {
					'inspect': items[itemid].inspect,
					'accepted': accepted,
					'tradelocked': tradelocked,
					'bot': bot
				}));
				
				steamSystem_withdrawInventoryByItems(game, bot, items, itemid + 1, offset, total_items, callback);
			}
		});
	} else {
		total_items.push(Object.assign(generateItem(items[itemid], {
			'price': price,
			'offset': offset
		}), {
			'inspect': items[itemid].inspect,
			'accepted': accepted,
			'tradelocked': tradelocked,
			'bot': bot
		}));
		
		steamSystem_withdrawInventoryByItems(game, bot, items, itemid + 1, offset, total_items, callback);
	}
}

/* END WITHDRAW */