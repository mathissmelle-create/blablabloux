var dashboard_graph = {
	queue: [],
	loading: false
};

var dashboard_stats = {
	queue: [],
	loading: false
};

function dashboard_getAllStats(user, socket, stats, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.dashboard.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	stats.forEach(function(item){
		dashboard_processStats(socket, item);
	});
	
	cooldown(false, false);
}

function dashboard_processStats(socket, stats){
	var stats_allowed = [
		'users_registed', 'users_initialized', 'users_verified', 'users_online',
		'tickets_count', 'tickets_opened',
		'total_bets', 'total_winnings', 'total_profit', 'count_games',
		'total_deposits', 'count_deposits', 'total_withdrawls', 'count_withdrawls', 'offers_profit',
		
		'steam_total_deposits', 'steam_count_deposits', 'steam_total_withdrawls', 'steam_count_withdrawls',
		'p2p_total', 'p2p_count',
		
		'crypto_total_deposits', 'crypto_count_deposits', 'crypto_total_withdrawls', 'crypto_count_withdrawls',
		
		'roulette_total_bets', 'roulette_total_winnings', 'roulette_total_profit', 'roulette_count_games',
		'crash_total_bets', 'crash_total_winnings', 'crash_total_profit', 'crash_count_games',
		'jackpot_total_bets', 'jackpot_total_winnings', 'jackpot_total_profit', 'jackpot_count_games',
		'coinflip_total_bets', 'coinflip_total_winnings', 'coinflip_total_profit', 'coinflip_count_games',
		'dice_total_bets', 'dice_total_winnings', 'dice_total_profit', 'dice_count_games',
		'unboxing_total_bets', 'unboxing_total_winnings', 'unboxing_total_profit', 'unboxing_count_games',
		'casebattle_total_bets', 'casebattle_total_winnings', 'casebattle_total_profit', 'casebattle_count_games',
		'upgrader_total_bets', 'upgrader_total_winnings', 'upgrader_total_profit', 'upgrader_count_games',
		'minesweeper_total_bets', 'minesweeper_total_winnings', 'minesweeper_total_profit', 'minesweeper_count_games',
		'tower_total_bets', 'tower_total_winnings', 'tower_total_profit', 'tower_count_games',
		'plinko_total_bets', 'plinko_total_winnings', 'plinko_total_profit', 'plinko_count_games',
	];
	if(!stats_allowed.includes(stats)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid stats!'
		});
		
		return;
	}
	
	if(dashboard_stats.loading) return dashboard_stats.queue.push({ socket, stats });
	
	dashboard_sendStats({ socket, stats });
}

function dashboard_sendStats(item){
	dashboard_stats.loading = true;
	
	dashboard_finishStats(item.stats, function(data){
		item.socket.emit('message', {
			type: 'dashboard',
			command: 'stats',
			data: data,
			stats: item.stats
		});
		
		if(dashboard_stats.queue.length > 0){
			var first = dashboard_stats.queue[0];
			
			dashboard_stats.queue.shift();
			dashboard_sendStats(first);
			
			return;
		} 
		
		dashboard_stats.loading = false;
	});
}

function dashboard_loadStats(stats, callback){
	if(stats == 'users_registed') var query = 'SELECT COUNT(*) AS `users` FROM `users`';
	else if(stats == 'users_initialized') var query = 'SELECT (SELECT COUNT(*) AS `users` FROM `users`) AS `users`, COUNT(*) AS `total` FROM `users` WHERE `initialized` = 1';
	else if(stats == 'users_verified') var query = 'SELECT (SELECT COUNT(*) AS `users` FROM `users`) AS `users`, COUNT(*) AS `total` FROM `users` WHERE `verified` = 1';
	else if(stats == 'tickets_count') var query = 'SELECT COUNT(*) AS `tickets` FROM `support_tickets`';
	else if(stats == 'tickets_opened') var query = 'SELECT (SELECT COUNT(*) AS `tickets` FROM `support_tickets`) AS `tickets`, COUNT(*) AS `total` FROM `support_tickets` WHERE `closed` = 0';
	else if(stats == 'total_bets') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` IN ("roulette_bet", "crash_bet", "coinflip_bet", "jackpot_bet", "dice_bet", "unboxing_bet", "casebattle_bet", "minesweeper_bet", "tower_bet", "plinko_bet")';
	else if(stats == 'total_winnings') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` IN ("roulette_win", "crash_win", "coinflip_win", "coinflip_refund", "jackpot_win", "dice_win", "unboxing_win", "casebattle_win", "casebattle_refund", "minesweeper_win", "tower_win", "plinko_win")';
	else if(stats == 'total_profit') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` IN ("roulette_bet", "roulette_win", "crash_bet", "crash_win", "coinflip_bet", "coinflip_win", "coinflip_refund", "jackpot_bet", "jackpot_win", "dice_bet", "dice_win", "unboxing_bet", "unboxing_win", "casebattle_bet", "casebattle_win", "casebattle_refund", "upgrader_bet", "upgrader_win", "minesweeper_bet", "minesweeper_win", "tower_bet", "tower_win", "plinko_bet", "plinko_win")';
	else if(stats == 'count_games') var query = 'SELECT COUNT(*) AS `total` FROM `users_transactions` WHERE `service` IN ("roulette_bet", "roulette_win", "crash_bet", "crash_win", "coinflip_bet", "coinflip_win", "coinflip_refund", "jackpot_bet", "jackpot_win", "dice_bet", "dice_win", "unboxing_bet", "unboxing_win", "casebattle_bet", "casebattle_win", "casebattle_refund", "upgrader_bet", "upgrader_win", "minesweeper_bet", "minesweeper_win", "tower_bet", "tower_win", "plinko_bet", "plinko_win")';
	
	else if(stats == 'steam_total_deposits') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_trades` WHERE `type` = ' + pool.escape("deposit") + ' AND `method` = ' + pool.escape("steam");
	else if(stats == 'steam_count_deposits') var query = 'SELECT COUNT(*) AS `count` FROM `users_trades` WHERE `type` = ' + pool.escape("deposit") + ' AND `method` = ' + pool.escape("steam");
	else if(stats == 'steam_total_withdrawls') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_trades` WHERE `type` = ' + pool.escape("withdraw") + ' AND `method` = ' + pool.escape("steam");
	else if(stats == 'steam_count_withdrawls') var query = 'SELECT COUNT(*) AS `count` FROM `users_trades` WHERE `type` = ' + pool.escape("withdraw") + ' AND `method` = ' + pool.escape("steam");
	else if(stats == 'p2p_total') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_trades` WHERE `method` = ' + pool.escape("p2p");
	else if(stats == 'p2p_count') var query = 'SELECT COUNT(*) AS `count` FROM `users_trades` WHERE `method` = ' + pool.escape("p2p");
	
	else if(stats == 'crypto_total_deposits') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_trades` WHERE `type` = ' + pool.escape("deposit") + ' AND `method` = ' + pool.escape("crypto");
	else if(stats == 'crypto_count_deposits') var query = 'SELECT COUNT(*) AS `count` FROM `users_trades` WHERE `type` = ' + pool.escape("deposit") + ' AND `method` = ' + pool.escape("crypto");
	else if(stats == 'crypto_total_withdrawls') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_trades` WHERE `type` = ' + pool.escape("withdraw") + ' AND `method` = ' + pool.escape("crypto");
	else if(stats == 'crypto_count_withdrawls') var query = 'SELECT COUNT(*) AS `count` FROM `users_trades` WHERE `type` = ' + pool.escape("withdraw") + ' AND `method` = ' + pool.escape("crypto");
	
	else if(stats == 'total_deposits') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_trades` WHERE `type` = ' + pool.escape("deposit");
	else if(stats == 'count_deposits') var query = 'SELECT COUNT(*) AS `count` FROM `users_trades` WHERE `type` = ' + pool.escape("deposit");
	else if(stats == 'total_withdrawls') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_trades` WHERE `type` = ' + pool.escape("withdraw");
	else if(stats == 'count_withdrawls') var query = 'SELECT COUNT(*) AS `count` FROM `users_trades` WHERE `type` = ' + pool.escape("withdraw");
	else if(stats == 'offers_profit') var query = 'SELECT ((SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_trades` WHERE `type` = ' + pool.escape("deposit") + ') - (SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_trades` WHERE `type` = ' + pool.escape("withdraw") + ')) AS `total`';
	
	else if(stats == 'roulette_total_bets') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("roulette_bet");
	else if(stats == 'roulette_total_winnings') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("roulette_win");
	else if(stats == 'roulette_total_profit') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` IN ("roulette_bet", "roulette_win")';
	else if(stats == 'roulette_count_games') var query = 'SELECT COUNT(*) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("roulette_bet");
	
	else if(stats == 'crash_total_bets') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("crash_bet");
	else if(stats == 'crash_total_winnings') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("crash_win");
	else if(stats == 'crash_total_profit') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` IN ("crash_bet", "crash_win")';
	else if(stats == 'crash_count_games') var query = 'SELECT COUNT(*) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("crash_win");
	
	else if(stats == 'jackpot_total_bets') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("jackpot_bet");
	else if(stats == 'jackpot_total_winnings') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("jackpot_win");
	else if(stats == 'jackpot_total_profit') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` IN ("jackpot_bet", "jackpot_win")';
	else if(stats == 'jackpot_count_games') var query = 'SELECT COUNT(*) AS `total` FROM `jackpot_games`';
	
	else if(stats == 'coinflip_total_bets') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("coinflip_bet");
	else if(stats == 'coinflip_total_winnings') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` IN ("coinflip_win", "coinflip_refund")';
	else if(stats == 'coinflip_total_profit') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` IN ("coinflip_bet", "coinflip_refund", "coinflip_win")';
	else if(stats == 'coinflip_count_games') var query = 'SELECT COUNT(*) AS `total` FROM `coinflip_games`';
	
	else if(stats == 'dice_total_bets') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("dice_bet");
	else if(stats == 'dice_total_winnings') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("dice_win");
	else if(stats == 'dice_total_profit') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` IN ("dice_bet", "dice_win")';
	else if(stats == 'dice_count_games') var query = 'SELECT COUNT(*) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("dice_win");
	
	else if(stats == 'unboxing_total_bets') var query = 'SELECT COALESCE(SUM(total), 0) AS `total` FROM (SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("unboxing_bet") + ' UNION ALL SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_items_transactions` WHERE `service` = ' + pool.escape("unboxing_bet") + ') AS `table`';
	else if(stats == 'unboxing_total_winnings') var query = 'SELECT COALESCE(SUM(total), 0) AS `total` FROM (SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("unboxing_win") + ' UNION ALL SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_items_transactions` WHERE `service` = ' + pool.escape("unboxing_win") + ') AS `table`';
	else if(stats == 'unboxing_total_profit') var query = 'SELECT COALESCE(SUM(total), 0) AS `total` FROM (SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` IN ("unboxing_bet", "unboxing_win") UNION ALL SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_items_transactions` WHERE `service` IN ("unboxing_bet", "unboxing_win")) AS `table`';
	else if(stats == 'unboxing_count_games') var query = 'SELECT COUNT(*) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("unboxing_win");
	
	else if(stats == 'casebattle_total_bets') var query = 'SELECT COALESCE(SUM(total), 0) AS `total` FROM (SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("casebattle_bet") + ' UNION ALL SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_items_transactions` WHERE `service` = ' + pool.escape("casebattle_bet") + ') AS `table`';
	else if(stats == 'casebattle_total_winnings') var query = 'SELECT COALESCE(SUM(total), 0) AS `total` FROM (SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` IN ("casebattle_win", "casebattle_refund") UNION ALL SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_items_transactions` WHERE `service` IN ("casebattle_win", "casebattle_refund")) AS `table`';
	else if(stats == 'casebattle_total_profit') var query = 'SELECT COALESCE(SUM(total), 0) AS `total` FROM (SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` IN ("casebattle_bet", "casebattle_refund", "casebattle_win") UNION ALL SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_items_transactions` WHERE `service` IN ("casebattle_bet", "casebattle_refund", "casebattle_win")) AS `table`';
	else if(stats == 'casebattle_count_games') var query = 'SELECT COUNT(*) AS `total` FROM `casebattle_games`';
	
	else if(stats == 'upgrader_total_bets') var query = 'SELECT COALESCE(SUM(total), 0) AS `total` FROM (SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("upgrader_bet") + ' UNION ALL SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_items_transactions` WHERE `service` = ' + pool.escape("upgrader_bet") + ') AS `table`';
	else if(stats == 'upgrader_total_winnings') var query = 'SELECT COALESCE(SUM(total), 0) AS `total` FROM (SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("upgrader_win") + ' UNION ALL SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_items_transactions` WHERE `service` = ' + pool.escape("upgrader_win") + ') AS `table`';
	else if(stats == 'upgrader_total_profit') var query = 'SELECT COALESCE(SUM(total), 0) AS `total` FROM (SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` IN ("upgrader_bet", "upgrader_win") UNION ALL SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_items_transactions` WHERE `service` IN ("upgrader_bet", "upgrader_win")) AS `table`';
	else if(stats == 'upgrader_count_games') var query = 'SELECT COUNT(*) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("upgrader_win");
	
	else if(stats == 'minesweeper_total_bets') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("minesweeper_bet");
	else if(stats == 'minesweeper_total_winnings') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("minesweeper_win");
	else if(stats == 'minesweeper_total_profit') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` IN ("minesweeper_bet", "minesweeper_win")';
	else if(stats == 'minesweeper_count_games') var query = 'SELECT COUNT(*) AS `total` FROM `users_transactions` WHERE `service` IN ("minesweeper_bet", "minesweeper_win")';
	
	else if(stats == 'tower_total_bets') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("tower_bet");
	else if(stats == 'tower_total_winnings') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("tower_win");
	else if(stats == 'tower_total_profit') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` IN ("tower_bet", "tower_win")';
	else if(stats == 'tower_count_games') var query = 'SELECT COUNT(*) AS `total` FROM `users_transactions` WHERE `service` IN ("tower_bet", "tower_win")';
	
	else if(stats == 'plinko_total_bets') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("plinko_bet");
	else if(stats == 'plinko_total_winnings') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` = ' + pool.escape("plinko_win");
	else if(stats == 'plinko_total_profit') var query = 'SELECT COALESCE(SUM(amount), 0) AS `total` FROM `users_transactions` WHERE `service` IN ("plinko_bet", "plinko_win")';
	else if(stats == 'plinko_count_games') var query = 'SELECT COUNT(*) AS `total` FROM `users_transactions` WHERE `service` IN ("plinko_bet", "plinko_win")';
	
	if(stats == 'users_online') return callback(null, { online: Object.keys(users_online).length });
	
	pool.query(query, function(err1, row1) {
		if(err1) return callback(err1);
		
		callback(null, row1);
	});
}

function dashboard_finishStats(stats, callback){
	var result = 0;
	
	dashboard_loadStats(stats, function(err1, data){
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return callback(result);
		}
		
		if(stats == 'users_registed') result = data[0].users;
		else if(stats == 'users_initialized') result = roundedToFixed(data[0].total / data[0].users * 100, 2).toFixed(2);
		else if(stats == 'users_verified') result = roundedToFixed(data[0].total / data[0].users * 100, 2).toFixed(2);
		else if(stats == 'users_online') result = data.online;
		else if(stats == 'tickets_count') result = data[0].tickets;
		else if(stats == 'tickets_opened') result = roundedToFixed(data[0].total / data[0].tickets * 100, 2).toFixed(2);
		else if(stats == 'total_bets') result = roundedToFixed(-data[0].total, 2).toFixed(2);
		else if(stats == 'total_winnings') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'total_profit') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'count_games') result = data[0].total;
		
		else if(stats == 'steam_total_deposits') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'steam_count_deposits') result = data[0].count;
		else if(stats == 'steam_total_withdrawls') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'steam_count_withdrawls') result = data[0].count;
		else if(stats == 'p2p_total') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'p2p_count') result = data[0].count;
		
		else if(stats == 'crypto_total_deposits') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'crypto_count_deposits') result = data[0].count;
		else if(stats == 'crypto_total_withdrawls') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'crypto_count_withdrawls') result = data[0].count;
		
		else if(stats == 'total_deposits') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'count_deposits') result = data[0].count;
		else if(stats == 'total_withdrawls') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'count_withdrawls') result = data[0].count;
		else if(stats == 'offers_profit') result = roundedToFixed(data[0].total, 2).toFixed(2);
		
		else if(stats == 'roulette_total_bets') result = roundedToFixed(-data[0].total, 2).toFixed(2);
		else if(stats == 'roulette_total_winnings') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'roulette_total_profit') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'roulette_count_games') result = data[0].total;
		else if(stats == 'crash_total_bets') result = roundedToFixed(-data[0].total, 2).toFixed(2);
		else if(stats == 'crash_total_winnings') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'crash_total_profit') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'crash_count_games') result = data[0].total;
		else if(stats == 'jackpot_total_bets') result = roundedToFixed(-data[0].total, 2).toFixed(2);
		else if(stats == 'jackpot_total_winnings') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'jackpot_total_profit') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'jackpot_count_games') result = data[0].total;
		else if(stats == 'coinflip_total_bets') result = roundedToFixed(-data[0].total, 2).toFixed(2);
		else if(stats == 'coinflip_total_winnings') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'coinflip_total_profit') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'coinflip_count_games') result = data[0].total;
		else if(stats == 'dice_total_bets') result = roundedToFixed(-data[0].total, 2).toFixed(2);
		else if(stats == 'dice_total_winnings') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'dice_total_profit') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'dice_count_games') result = data[0].total;
		else if(stats == 'unboxing_total_bets') result = roundedToFixed(-data[0].total, 2).toFixed(2);
		else if(stats == 'unboxing_total_winnings') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'unboxing_total_profit') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'unboxing_count_games') result = data[0].total;
		else if(stats == 'casebattle_total_bets') result = roundedToFixed(-data[0].total, 2).toFixed(2);
		else if(stats == 'casebattle_total_winnings') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'casebattle_total_profit') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'casebattle_count_games') result = data[0].total;
		else if(stats == 'upgrader_total_bets') result = roundedToFixed(-data[0].total, 2).toFixed(2);
		else if(stats == 'upgrader_total_winnings') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'upgrader_total_profit') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'upgrader_count_games') result = data[0].total;
		else if(stats == 'minesweeper_total_bets') result = roundedToFixed(-data[0].total, 2).toFixed(2);
		else if(stats == 'minesweeper_total_winnings') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'minesweeper_total_profit') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'minesweeper_count_games') result = data[0].total;
		else if(stats == 'tower_total_bets') result = roundedToFixed(-data[0].total, 2).toFixed(2);
		else if(stats == 'tower_total_winnings') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'tower_total_profit') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'tower_count_games') result = data[0].total;
		else if(stats == 'plinko_total_bets') result = roundedToFixed(-data[0].total, 2).toFixed(2);
		else if(stats == 'plinko_total_winnings') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'plinko_total_profit') result = roundedToFixed(data[0].total, 2).toFixed(2);
		else if(stats == 'plinko_count_games') result = data[0].total;
		
		return callback(result);
	});
}

function dashboard_getAllGraphs(user, socket, graphs, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.dashboard.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	graphs.forEach(function(item){
		dashboard_processGraph(socket, item);
	});
	
	cooldown(false, false);
}

function dashboard_getGraph(user, socket, graph, cooldown){
	cooldown(true, true);
	
	if(!config.settings.allowed.dashboard.includes(user.userid)){
		socket.emit('message', {
			type: 'error',
			error: 'Error: You don\'t have permission to use that!'
		});
		
		return cooldown(false, true);
	}
	
	dashboard_processGraph(socket, graph);
	
	cooldown(false, false);
}

function dashboard_processGraph(socket, graph){
	var graphs_allowed = [
		'unique_visitors', 'all_visitors', 'users', 'count_games', 'total_profit', 'roulette_games', 'roulette_profit', 'crash_games', 'crash_profit', 'jackpot_games', 'jackpot_profit', 'coinflip_games', 
		'coinflip_profit', 'dice_games', 'dice_profit',
		'unboxing_games', 'unboxing_profit', 'casebattle_games', 'casebattle_profit', 'upgrader_games', 'upgrader_profit',
		'minesweeper_games', 'minesweeper_profit', 'tower_games', 'tower_profit', 'plinko_games', 'plinko_profit',
		'deposit_count', 'deposit_total', 'withdraw_count', 'withdraw_total',
		
		'steam_deposit_count', 'steam_deposit_total', 'steam_withdraw_count', 'steam_withdraw_total',
		'p2p_count', 'p2p_total',
		
		'crypto_deposit_count', 'crypto_deposit_total', 'crypto_withdraw_count', 'crypto_withdraw_total',
		
		'join_referral'
	];
	if(!graphs_allowed.includes(graph.graph.split('.')[0])){
		socket.emit('message', {
			type: 'error',
			error: 'Error: Invalid graph!'
		});
		
		return;
	}
	
	if(dashboard_graph.loading) return dashboard_graph.queue.push({ socket, date: graph.date, graph: graph.graph });
	
	dashboard_sendGraph({ socket, date: graph.date, graph: graph.graph });
}

function dashboard_sendGraph(item){
	dashboard_graph.loading = true;
	
	dashboard_finishGraph(item.date, item.graph, function(data){
		item.socket.emit('message', {
			type: 'dashboard',
			command: 'graph',
			data: data,
			graph: item.graph
		});
		
		if(dashboard_graph.queue.length > 0){
			var first = dashboard_graph.queue[0]
			
			dashboard_graph.queue.shift();
			dashboard_sendGraph(first);
			
			return;
		} 
		
		dashboard_graph.loading = false;
	});
}

function dashboard_loadGraph(date, graph, callback){
	var time = dashboard_getDate(date);
	
	var graph_name = graph.split('.')[0];
	var graph_data = graph.split('.')[1];
	
	if(graph_name == 'unique_visitors') var query = 'SELECT * FROM `join_visitors` WHERE `time` > ' + pool.escape(time);
	else if(graph_name == 'all_visitors') var query = 'SELECT * FROM `join_visitors` WHERE `time` > ' + pool.escape(time);
	else if(graph_name == 'users') var query = 'SELECT * FROM `users` WHERE `time_create` > ' + pool.escape(time);
	else if(graph_name == 'count_games') var query = 'SELECT * FROM `users_transactions` WHERE `service` IN ("roulette_bet", "roulette_win", "crash_bet", "crash_win", "coinflip_bet", "coinflip_win", "coinflip_refund", "jackpot_bet", "jackpot_win", "dice_bet", "dice_win", "unboxing_bet", "unboxing_win", "casebattle_bet", "casebattle_win", "casebattle_refund", "upgrader_bet", "upgrader_win", "minesweeper_bet", "minesweeper_win", "tower_bet", "tower_win", "plinko_bet", "plinko_win") AND `time` > ' + pool.escape(time);
	else if(graph_name == 'total_profit') var query = 'SELECT `amount`, `time` FROM `users_transactions` WHERE `service` IN ("roulette_bet", "roulette_win", "crash_bet", "crash_win", "coinflip_bet", "coinflip_win", "coinflip_refund", "jackpot_bet", "jackpot_win", "dice_bet", "dice_win", "unboxing_bet", "unboxing_win", "casebattle_bet", "casebattle_win", "casebattle_refund", "upgrader_bet", "upgrader_win", "minesweeper_bet", "minesweeper_win", "tower_bet", "tower_win", "plinko_bet", "plinko_win") AND `time` > ' + pool.escape(time) + ' UNION ALL SELECT `amount`, `time` FROM `users_items_transactions` WHERE `service` IN ("unboxing_win", "casebattle_win", "upgrader_bet", "upgrader_win") AND `time` > ' + pool.escape(time);
	else if(graph_name == 'roulette_games') var query = 'SELECT * FROM `roulette_bets` WHERE `time` > ' + pool.escape(time);
	else if(graph_name == 'roulette_profit') var query = 'SELECT * FROM `users_transactions` WHERE `service` IN ("roulette_bet", "roulette_win") AND `time` > ' + pool.escape(time);
	else if(graph_name == 'crash_games') var query = 'SELECT * FROM `crash_bets` WHERE `time` > ' + pool.escape(time);
	else if(graph_name == 'crash_profit') var query = 'SELECT * FROM `users_transactions` WHERE `service` IN ("crash_bet", "crash_win") AND `time` > ' + pool.escape(time);
	else if(graph_name == 'jackpot_games') var query = 'SELECT * FROM `jackpot_bets` WHERE `time` > ' + pool.escape(time);
	else if(graph_name == 'jackpot_profit') var query = 'SELECT * FROM `users_transactions` WHERE `service` IN ("jackpot_bet", "jackpot_win") AND `time` > ' + pool.escape(time);
	
	else if(graph_name == 'coinflip_games') var query = 'SELECT coinflip_bets.* FROM `coinflip_games` INNER JOIN `coinflip_bets` ON coinflip_games.id = coinflip_bets.gameid WHERE coinflip_games.ended = 1 AND coinflip_games.canceled = 0 AND coinflip_bets.time > ' + pool.escape(time);
	else if(graph_name == 'coinflip_profit') var query = 'SELECT * FROM `users_transactions` WHERE `service` IN ("coinflip_bet", "coinflip_refund", "coinflip_win") AND `time` > ' + pool.escape(time);
	
	else if(graph_name == 'dice_games') var query = 'SELECT * FROM `dice_bets` WHERE `time` > ' + pool.escape(time);
	else if(graph_name == 'dice_profit') var query = 'SELECT * FROM `users_transactions` WHERE `service` IN ("dice_bet", "dice_win") AND `time` > ' + pool.escape(time);
	
	else if(graph_name == 'unboxing_games') var query = 'SELECT * FROM `unboxing_bets` WHERE `time` > ' + pool.escape(time);
	else if(graph_name == 'unboxing_profit') var query = 'SELECT `amount`, `time` FROM `users_transactions` WHERE `service` IN ("unboxing_bet", "unboxing_win") AND `time` > ' + pool.escape(time) + ' UNION ALL SELECT `amount`, `time` FROM `users_items_transactions` WHERE `service` IN ("unboxing_bet", "unboxing_win") AND `time` > ' + pool.escape(time);
	
	else if(graph_name == 'casebattle_games') var query = 'SELECT casebattle_bets.* FROM `casebattle_games` INNER JOIN `casebattle_bets` ON casebattle_games.id = casebattle_bets.gameid WHERE casebattle_games.ended = 1 AND casebattle_games.canceled = 0 AND casebattle_bets.time > ' + pool.escape(time);
	else if(graph_name == 'casebattle_profit') var query = 'SELECT `amount`, `time` FROM `users_transactions` WHERE `service` IN ("casebattle_bet", "casebattle_refund", "casebattle_win") AND `time` > ' + pool.escape(time) + ' UNION ALL SELECT `amount`, `time` FROM `users_items_transactions` WHERE `service` IN ("casebattle_bet", "casebattle_refund", "casebattle_win") AND `time` > ' + pool.escape(time);
	
	else if(graph_name == 'upgrader_games') var query = 'SELECT * FROM `upgrader_bets` WHERE `time` > ' + pool.escape(time);
	else if(graph_name == 'upgrader_profit') var query = 'SELECT `amount`, `time` FROM `users_transactions` WHERE `service` IN ("upgrader_bet", "upgrader_win") AND `time` > ' + pool.escape(time) + ' UNION ALL SELECT `amount`, `time` FROM `users_items_transactions` WHERE `service` IN ("upgrader_bet", "upgrader_win") AND `time` > ' + pool.escape(time);
	
	else if(graph_name == 'minesweeper_games') var query = 'SELECT * FROM `minesweeper_bets` WHERE `ended` = 1 AND `time` > ' + pool.escape(time);
	else if(graph_name == 'minesweeper_profit') var query = 'SELECT * FROM `users_transactions` WHERE `service` IN ("minesweeper_bet", "minesweeper_win") AND `time` > ' + pool.escape(time);
	else if(graph_name == 'tower_games') var query = 'SELECT * FROM `tower_bets` WHERE `ended` = 1 AND `time` > ' + pool.escape(time);
	else if(graph_name == 'tower_profit') var query = 'SELECT * FROM `users_transactions` WHERE `service` IN ("tower_bet", "tower_win") AND `time` > ' + pool.escape(time);
	else if(graph_name == 'plinko_games') var query = 'SELECT * FROM `plinko_bets` WHERE `time` > ' + pool.escape(time);
	else if(graph_name == 'plinko_profit') var query = 'SELECT * FROM `users_transactions` WHERE `service` IN ("plinko_bet", "plinko_win") AND `time` > ' + pool.escape(time);
	else if(graph_name == 'deposit_count') var query = 'SELECT * FROM `users_trades` WHERE `type` = ' + pool.escape("deposit") + ' AND `time` > ' + pool.escape(time);
	else if(graph_name == 'deposit_total') var query = 'SELECT * FROM `users_trades` WHERE `type` = ' + pool.escape("deposit") + ' AND `time` > ' + pool.escape(time);
	else if(graph_name == 'withdraw_count') var query = 'SELECT * FROM `users_trades` WHERE `type` = ' + pool.escape("withdraw") + ' AND `time` > ' + pool.escape(time);
	else if(graph_name == 'withdraw_total') var query = 'SELECT * FROM `users_trades` WHERE `type` = ' + pool.escape("withdraw") + ' AND `time` > ' + pool.escape(time);
	
	else if(graph_name == 'steam_deposit_count') var query = 'SELECT * FROM `users_trades` WHERE `type` = ' + pool.escape("deposit") + ' AND `method` = ' + pool.escape("steam") + ' AND `time` > ' + pool.escape(time);
	else if(graph_name == 'steam_deposit_total') var query = 'SELECT * FROM `users_trades` WHERE `type` = ' + pool.escape("deposit") + ' AND `method` = ' + pool.escape("steam") + ' AND `time` > ' + pool.escape(time);
	else if(graph_name == 'steam_withdraw_count') var query = 'SELECT * FROM `users_trades` WHERE `type` = ' + pool.escape("withdraw") + ' AND `method` = ' + pool.escape("steam") + ' AND `time` > ' + pool.escape(time);
	else if(graph_name == 'steam_withdraw_total') var query = 'SELECT * FROM `users_trades` WHERE `type` = ' + pool.escape("withdraw") + ' AND `method` = ' + pool.escape("steam") + ' AND `time` > ' + pool.escape(time);
	
	else if(graph_name == 'p2p_count') var query = 'SELECT * FROM `users_trades` WHERE `method` = ' + pool.escape("p2p") + ' AND `time` > ' + pool.escape(time);
	else if(graph_name == 'p2p_total') var query = 'SELECT * FROM `users_trades` WHERE `method` = ' + pool.escape("p2p") + ' AND `time` > ' + pool.escape(time);
	
	else if(graph_name == 'crypto_deposit_count') var query = 'SELECT * FROM `users_trades` WHERE `type` = ' + pool.escape("deposit") + ' AND `method` = ' + pool.escape("crypto") + ' AND `time` > ' + pool.escape(time);
	else if(graph_name == 'crypto_deposit_total') var query = 'SELECT * FROM `users_trades` WHERE `type` = ' + pool.escape("deposit") + ' AND `method` = ' + pool.escape("crypto") + ' AND `time` > ' + pool.escape(time);
	else if(graph_name == 'crypto_withdraw_count') var query = 'SELECT * FROM `users_trades` WHERE `type` = ' + pool.escape("withdraw") + ' AND `method` = ' + pool.escape("crypto") + ' AND `time` > ' + pool.escape(time);
	else if(graph_name == 'crypto_withdraw_total') var query = 'SELECT * FROM `users_trades` WHERE `type` = ' + pool.escape("withdraw") + ' AND `method` = ' + pool.escape("crypto") + ' AND `time` > ' + pool.escape(time);
	
	else if(graph_name == 'join_referral') var query = 'SELECT join_referrals.* FROM `join_referrals` INNER JOIN `link_referrals` ON join_referrals.referral = link_referrals.referral WHERE link_referrals.id = ' + pool.escape(graph_data) + ' AND link_referrals.removed = 0 AND join_referrals.time > ' + pool.escape(time);
	
	pool.query(query, function(err1, row1) {
		if(err1) return callback(err1);
		
		callback(null, row1);
	});
}

function dashboard_finishGraph(date, graph, callback){
	var result = {
		'labels': [],
		'data': []
	};
	
	var months = [ 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December' ];
	
	for(var i = 0; i < { 'day': 24, 'week': 7, 'month': 31, 'year': 12 }[date]; i++) result['data'].push(0);
	
	if(date == 'day') result['labels'] = [ '00', '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23' ];
	else if(date == 'week') result['labels'] = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
	else if(date == 'month') result['labels'] = [ '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31' ];
	else if(date == 'year') result['labels'] = months;
	
	if(date == 'month') for(var i = 0; i < result['labels'].length; i++) result['labels'][i] += ' ' + months[new Date(dashboard_getDate(date) * 1000).getMonth()]
	if(date == 'day') for(var i = 0; i < result['labels'].length; i++) result['labels'][i] += ':00';
	
	dashboard_loadGraph(date, graph, function(err1, data){
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return callback(result);
		}
		
		var temp = {};
		
		var graph_name = graph.split('.')[0];
		var graph_data = graph.split('.')[1];
		
		data.forEach(function(item){
			if(graph_name == 'unique_visitors') var time_row = item.time;
			else if(graph_name == 'all_visitors') var time_row = item.time;
			else if(graph_name == 'users') var time_row = item.time_create;
			else if(graph_name == 'count_games') var time_row = item.time;
			else if(graph_name == 'total_profit') var time_row = item.time;
			else if(graph_name == 'roulette_games') var time_row = item.time;
			else if(graph_name == 'roulette_profit') var time_row = item.time;
			else if(graph_name == 'crash_games') var time_row = item.time;
			else if(graph_name == 'crash_profit') var time_row = item.time;
			else if(graph_name == 'jackpot_games') var time_row = item.time;
			else if(graph_name == 'jackpot_profit') var time_row = item.time;
			else if(graph_name == 'coinflip_games') var time_row = item.time;
			else if(graph_name == 'coinflip_profit') var time_row = item.time;
			else if(graph_name == 'dice_games') var time_row = item.time;
			else if(graph_name == 'dice_profit') var time_row = item.time;
			else if(graph_name == 'unboxing_games') var time_row = item.time;
			else if(graph_name == 'unboxing_profit') var time_row = item.time;
			else if(graph_name == 'casebattle_games') var time_row = item.time;
			else if(graph_name == 'casebattle_profit') var time_row = item.time;
			else if(graph_name == 'upgrader_games') var time_row = item.time;
			else if(graph_name == 'upgrader_profit') var time_row = item.time;
			else if(graph_name == 'minesweeper_games') var time_row = item.time;
			else if(graph_name == 'minesweeper_profit') var time_row = item.time;
			else if(graph_name == 'tower_games') var time_row = item.time;
			else if(graph_name == 'tower_profit') var time_row = item.time;
			else if(graph_name == 'plinko_games') var time_row = item.time;
			else if(graph_name == 'plinko_profit') var time_row = item.time;
			else if(graph_name == 'deposit_count') var time_row = item.time;
			else if(graph_name == 'deposit_total') var time_row = item.time;
			else if(graph_name == 'withdraw_count') var time_row = item.time;
			else if(graph_name == 'withdraw_total') var time_row = item.time;
			
			else if(graph_name == 'steam_deposit_count') var time_row = item.time;
			else if(graph_name == 'steam_deposit_total') var time_row = item.time;
			else if(graph_name == 'steam_withdraw_count') var time_row = item.time;
			else if(graph_name == 'steam_withdraw_total') var time_row = item.time;
			
			else if(graph_name == 'p2p_count') var time_row = item.time;
			else if(graph_name == 'p2p_total') var time_row = item.time;
			
			else if(graph_name == 'crypto_deposit_count') var time_row = item.time;
			else if(graph_name == 'crypto_deposit_total') var time_row = item.time;
			else if(graph_name == 'crypto_withdraw_count') var time_row = item.time;
			else if(graph_name == 'crypto_withdraw_total') var time_row = item.time;
			
			else if(graph_name == 'join_referral') var time_row = item.time;
			
			if(date == 'day') var time = new Date(time_row * 1000).getHours();
			else if(date == 'week') var time = (new Date(time_row * 1000).getDay() + 6) % 7;
			else if(date == 'month') var time = new Date(time_row * 1000).getDate() - 1;
			else if(date == 'year') var time = new Date(time_row * 1000).getMonth();
			
			if(graph_name == 'unique_visitors') if(temp[time] === undefined) temp[time] = {};
			
			if(graph_name == 'unique_visitors') var add = (temp[time][item.ip] === undefined) ? 1 : 0;
			else if(graph_name == 'all_visitors') var add = 1;
			else if(graph_name == 'users') var add = 1;
			else if(graph_name == 'count_games') var add = 1;
			else if(graph_name == 'total_profit') var add = -getFormatAmount(item.amount);
			else if(graph_name == 'roulette_games') var add = 1;
			else if(graph_name == 'roulette_profit') var add = -getFormatAmount(item.amount);
			else if(graph_name == 'crash_games') var add = 1;
			else if(graph_name == 'crash_profit') var add = -getFormatAmount(item.amount);
			else if(graph_name == 'jackpot_games') var add = 1;
			else if(graph_name == 'jackpot_profit') var add = -getFormatAmount(item.amount);
			else if(graph_name == 'coinflip_games') var add = 1;
			else if(graph_name == 'coinflip_profit') var add = -getFormatAmount(item.amount);
			else if(graph_name == 'dice_games') var add = 1;
			else if(graph_name == 'dice_profit') var add = -getFormatAmount(item.amount);
			else if(graph_name == 'unboxing_games') var add = 1;
			else if(graph_name == 'unboxing_profit') var add = -getFormatAmount(item.amount);
			else if(graph_name == 'casebattle_games') var add = 1;
			else if(graph_name == 'casebattle_profit') var add = -getFormatAmount(item.amount);
			else if(graph_name == 'upgrader_games') var add = 1;
			else if(graph_name == 'upgrader_profit') var add = -getFormatAmount(item.amount);
			else if(graph_name == 'minesweeper_games') var add = 1;
			else if(graph_name == 'minesweeper_profit') var add = -getFormatAmount(item.amount);
			else if(graph_name == 'tower_games') var add = 1;
			else if(graph_name == 'tower_profit') var add = -getFormatAmount(item.amount);
			else if(graph_name == 'plinko_games') var add = 1;
			else if(graph_name == 'plinko_profit') var add = -getFormatAmount(item.amount);
			else if(graph_name == 'deposit_count') var add = 1;
			else if(graph_name == 'deposit_total') var add = getFormatAmount(item.amount);
			else if(graph_name == 'withdraw_count') var add = 1;
			else if(graph_name == 'withdraw_total') var add = getFormatAmount(item.amount);
			
			else if(graph_name == 'steam_deposit_count') var add = 1;
			else if(graph_name == 'steam_deposit_total') var add = getFormatAmount(item.amount);
			else if(graph_name == 'steam_withdraw_count') var add = 1;
			else if(graph_name == 'steam_withdraw_total') var add = getFormatAmount(item.amount);
			
			else if(graph_name == 'p2p_count') var add = 1;
			else if(graph_name == 'p2p_total') var add = getFormatAmount(item.amount);
			
			else if(graph_name == 'crypto_deposit_count') var add = 1;
			else if(graph_name == 'crypto_deposit_total') var add = getFormatAmount(item.amount);
			else if(graph_name == 'crypto_withdraw_count') var add = 1;
			else if(graph_name == 'crypto_withdraw_total') var add = getFormatAmount(item.amount);
			
			else if(graph_name == 'join_referral') var add = 1;
			
			if(graph_name == 'unique_visitors') if(temp[time][item.ip] === undefined) temp[time][item.ip] = true;
			
			result['data'][time] += add;
		});
		
		for(var i = 0; i < result['data'].length; i++) {
			if(graph_name == 'unique_visitors') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'all_visitors') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'users') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'count_games') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'total_profit') result['data'][i] = getFormatAmount(result['data'][i]);
			else if(graph_name == 'roulette_games') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'roulette_profit') result['data'][i] = getFormatAmount(result['data'][i]);
			else if(graph_name == 'crash_games') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'crash_profit') result['data'][i] = getFormatAmount(result['data'][i]);
			else if(graph_name == 'jackpot_games') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'jackpot_profit') result['data'][i] = getFormatAmount(result['data'][i]);
			else if(graph_name == 'coinflip_games') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'coinflip_profit') result['data'][i] = getFormatAmount(result['data'][i]);
			else if(graph_name == 'dice_games') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'dice_profit') result['data'][i] = getFormatAmount(result['data'][i]);
			else if(graph_name == 'unboxing_games') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'unboxing_profit') result['data'][i] = getFormatAmount(result['data'][i]);
			else if(graph_name == 'casebattle_games') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'casebattle_profit') result['data'][i] = getFormatAmount(result['data'][i]);
			else if(graph_name == 'upgrader_games') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'upgrader_profit') result['data'][i] = getFormatAmount(result['data'][i]);
			else if(graph_name == 'minesweeper_games') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'minesweeper_profit') result['data'][i] = getFormatAmount(result['data'][i]);
			else if(graph_name == 'tower_games') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'tower_profit') result['data'][i] = getFormatAmount(result['data'][i]);
			else if(graph_name == 'plinko_games') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'plinko_profit') result['data'][i] = getFormatAmount(result['data'][i]);
			else if(graph_name == 'deposit_count') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'deposit_total') result['data'][i] = getFormatAmount(result['data'][i]);
			else if(graph_name == 'withdraw_count') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'withdraw_total') result['data'][i] = getFormatAmount(result['data'][i]);
			
			else if(graph_name == 'steam_deposit_count') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'steam_deposit_total') result['data'][i] = getFormatAmount(result['data'][i]);
			else if(graph_name == 'steam_withdraw_count') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'steam_withdraw_total') result['data'][i] = getFormatAmount(result['data'][i]);
			
			else if(graph_name == 'p2p_count') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'p2p_total') result['data'][i] = getFormatAmount(result['data'][i]);
			
			else if(graph_name == 'crypto_deposit_count') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'crypto_deposit_total') result['data'][i] = getFormatAmount(result['data'][i]);
			else if(graph_name == 'crypto_withdraw_count') result['data'][i] = parseInt(result['data'][i]);
			else if(graph_name == 'crypto_withdraw_total') result['data'][i] = getFormatAmount(result['data'][i]);
			
			else if(graph_name == 'join_referral') result['data'][i] = parseInt(result['data'][i]);
		}
		
		return callback(result);
	});
}

function dashboard_getDate(type){
	var date = new Date();
	
	if(type == 'day'){
		var year = date.getFullYear();
		var month = date.getMonth();
		var day = date.getDate();
		
		var new_date = new Date(year + '-' + (month + 1) + '-' + day);
		
		return parseInt(new_date.getTime() / 1000);
	} else if(type == 'week'){
		var date = new Date();
		var year = date.getFullYear();
		var month = date.getMonth();
		var day = date.getDate();
		var week = (date.getDay() + 6) % 7;
		
		if(week >= day){
			var last_date = new Date(year, (month + 11) % 12, 0);
			
			month--;
			day += last_date.getDate();
			
			if(month < 0) {
				month = 11;
				year--;
			}
		}
		
		var new_date = new Date(year + '-' + (month + 1) + '-' + (day - week));
		
		return parseInt(new_date.getTime() / 1000);
	} else if(type == 'month'){
		var date = new Date();
		var year = date.getFullYear();
		var month = date.getMonth();
		
		var new_date = new Date(year + '-' + (month + 1) + '-01');
		
		return parseInt(new_date.getTime() / 1000);
	} else if(type == 'year'){
		var date = new Date();
		var year = date.getFullYear();
		
		var new_date = new Date(year + '-01-01');
		
		return parseInt(new_date.getTime() / 1000);
	}
}