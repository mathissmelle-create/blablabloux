var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
	host: config.config_site.mailer.host,
    port: config.config_site.mailer.port,
    secure: config.config_site.mailer.secure,
	auth: {
		user: config.config_site.mailer.email,
		pass: config.config_site.mailer.password
	}
});

function mailer_send(to, subject, message, callback){
	var options = {
		from: config.config_site.mailer.email,
		to: to,
		subject: subject,
		text: message
	};

	transporter.sendMail(options, function(err1, info){
		if(err1) return callback(err1);
		
		logger.warn('[MAILER] Email sent to ' + to);
		
		callback(null, info);
	});
}


