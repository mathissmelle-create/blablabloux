function affiliates_collectAvailable(user, socket, recaptcha, cooldown){
	cooldown(true, true);
	
	site_verifyRecaptcha(recaptcha, function(verified){
		if(!verified){
			socket.emit('message', {
				type: 'error',
				error: 'Error: Invalid recaptcha!'
			});
			
			return cooldown(false, true);
		}
		
		pool.query('SELECT * FROM `referral_codes` WHERE `userid` = ' + pool.escape(user.userid), function(err1, row1){
			if(err1) {
				logger.error(err1);
				writeError(err1);
				
				return cooldown(false, true);
			}
		
			if(row1.length == 0) {
				socket.emit('message', {
					type: 'error',
					error: 'Error: You don\'t have a code to collect the available coins!'
				});
				
				return cooldown(false, true);
			}
			
			var available = getFormatAmount(row1[0].available);
		
			if(available <= 0) {
				socket.emit('message', {
					type: 'error',
					error: 'Error: You don\'t have available coins to collect!'
				});
				
				return cooldown(false, true);
			}
			
			pool.query('UPDATE `referral_codes` SET `collected` = `collected` + ' + available + ', `available` = `available` - ' + available + ' WHERE `userid` = ' + pool.escape(user.userid), function(err2){
				if(err2) {
					logger.error(err2);
					writeError(err2);
					
					return cooldown(false, true);
				}
				
				//EDIT BALANCE
				user_editBalance(user.userid, available, 'affiliates_available', function(err3){
					if(err3) {
						logger.error(err3);
						writeError(err3);
						
						return cooldown(false, true);
					}
					
					socket.emit('message', {
						type: 'refresh'
					});	
					
					socket.emit('message', {
						type: 'success',
						success: 'You collected ' + getFormatAmountString(available) + ' coins!'
					});		
					
					user_updateBalance(user.userid);
					
					cooldown(false, false);
				});
			});
		});
	});
}