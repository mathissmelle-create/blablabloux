function pricesSystem_getPrice(name, game){
	var price = -1;
	
	if (name && game) {
		var prices = require('./prices/prices_' + game + '.json');
		
		if(prices[name] !== undefined){
			var list_price = prices[name];
			
			if(list_price != null && list_price > 0) price = roundedToFixed(list_price, 2);
		}
	}
	return price;
}

pricesSystem_initializing();
function pricesSystem_initializing(){
	site_pricesUpdate_steam = true;
	
	pricesSystem_loadPrices(0, [730, 570, 433850, 252490, 440], function(){
		logger.warn('[PRICES] All Prices Loaded Successfully');
		
		site_pricesUpdate_steam = false;
		
		setTimeout(function(){
			site_pricesUpdate_steam = true;
			
			pricesSystem_loadPrices(0, [730, 570, 433850, 252490, 440], function(){
				logger.warn('[PRICES] All Prices Loaded Successfully');
				
				site_pricesUpdate_steam = false;
			});
		}, config.config_offers.steam.prices.cooldown_load * 1000);
	});
}

function pricesSystem_loadPrices(gameid, games, callback){
	if(gameid >= games.length) return callback();
	
	logger.warn('[PRICES] Prices For #' + games[gameid] + ' Are Loading');
	
	var options = {
		headers: {
			'content-type': 'application/json',
			'x-apikey': config.config_offers.steam.prices.apikey.key,
		},
		uri: 'https://api.bitskins.com/market/skin/' + games[gameid],
		qs: {}
	}
	
	request(options, function(err1, response1, body1) {
		if(err1) {
			logger.error(err1);
			writeError(err1);
			
			return pricesSystem_loadPrices(gameid + 1, games, callback);
		}
		
		if (200 != response1.statusCode) return pricesSystem_loadPrices(gameid + 1, games, callback);
		
		if (!isJsonString(body1)) return pricesSystem_loadPrices(gameid + 1, games, callback);
		
		var body = JSON.parse(body1);
		
		var prices = {};
		
		body.forEach(function(item){
			prices[item.name] = item.suggested_price == null ? 0 : roundedToFixed(item.suggested_price / 1000, 2);
		});
		
		fs.writeFileSync('./prices/prices_' + games[gameid] + '.json', JSON.stringify(prices));
		
		logger.warn('[PRICES] Prices For #' + games[gameid] + ' Loaded Successfully');
		
		pricesSystem_loadPrices(gameid + 1, games, callback);
	});
}