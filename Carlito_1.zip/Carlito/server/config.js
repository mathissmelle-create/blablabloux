const config = {
	settings: require('./settings.json'),
	
	config_site: {
		name: 'VGOWitch.com',
		abbreviation: 'VGOWitch',
		
		url: 'https://vgowitch.com',
		root: '/',
		
		frontend: '/var/www/html',
		
		access_secrets: [ 'iKP2Cz' ],
		
		ranks_name: { '0': 'member', '1': 'admin', '2': 'moderator', '3': 'helper', '4': 'veteran', '5': 'pro', '6': 'youtuber', '7': 'streamer', '8': 'developer', '100': 'owner' },
		
		banip_excluded: ['owner'],
		ban_excluded: ['owner'],
		banplay_excluded: ['owner'],
		bantrade_excluded: ['owner'],
		mute_excluded: ['owner'],
		pause_excluded: ['owner', 'admin', 'moderator'],
		maintenance_excluded: ['owner', 'developer', 'admin', 'moderator', 'helper'],
		bonus_allowed: ['owner', 'admin'],
		playoffline_allowed: ['owner'],
		tradeoffline_allowed: ['owner'],
		profile_allowed: ['owner', 'admin'],
		refillshop_allowed: ['owner'],
		gamebots_allowed: ['owner'],
		
		flood: {
			time: 100 * 10e5, // IN NANO SECONDS
			count: 5
		},
		
		mailer: {
			host: 'smtp.gmail.com',
			port: 465,
			secure: true,
			email: '',
			password: ''
		},
		
		recaptcha: {
			private_key: ''
		},
	
		server_port: 2052,
		
		database: {
			database: '',
			host: 'localhost',
			user: 'root',
			password: ''
		},
		
		level: {
			start: 500,
			next: 0.235,
		},
		
		level_send_coins: 5,
		level_receive_coins: 5,
		
		rain: {
			start: 1.00,
			cooldown_start: 1 * 60,
			timeout_interval: { min: 10 * 60, max: 30 * 60 }
		},
		
		multiplier_wager_withdraw: 3 / 4,
		
		interval_amount: {
			roulette: { min: 0.01, max: 1000.00 },
			crash: { min: 0.01, max: 1000.00 },
			jackpot: { min: 0.01, max: 1000.00 },
			coinflip: { min: 0.01, max: 1000.00 },
			dice: { min: 0.01, max: 1000.00 },
			upgrader: { min: 0.00, max: 1000.00 },
			minesweeper: { min: 0.01, max: 1000.00 },
			tower: { min: 0.01, max: 1000.00 },
			plinko: { min: 0.01, max: 1000.00 },
			
			send_coins: { min: 0.01, max: 100.00 },
			tip_rain: { min: 0.01, max: 500.00 },
			
			withdraw_crypto: { min: 2.00, max: 500.00 },
			
			deposit_item: { min: 0.01, max: 2000.00 },
			withdraw_item: { min: 0.01, max: 2000.00 },
			
			deposit_p2p: { min: 0.01, max: 500.00 },
			deposit_steam: { min: 0.01, max: 500.00 },
			withdraw_steam: { min: 0.01, max: 500.00 }
		},
		
		rewards_amount: {
			steam: 0.50,
			google: 0.50,
			discord: 0.50,
			facebook: 0.50,
			
			refferal_code: 1.00,
			
			daily_start: 0.20,
			daily_step: 0.02
		},
		
		rewards_requirements: {
			code_length: { min: 6, max: 20 },
			bonus_uses: { min: 1, max: 500 },
			bonus_amount: { min: 0.01, max: 10.00 }
		},
		
		affiliates_requirements: [0.00, 200.00, 500.00, 750.00, 1000.00, 2000.00, 3500.00, 5000.00, 7500.00, 10000.00],
		affiliates_commission: {
			deposit: 1,
			bet: 2
		},
		
		daily_requirements: {
			amount: 5.00,
			time: 7 * 24 * 60 * 60
		},
		
		join_referral: { //move to admin
			code_length: 64,
			usage_length: { min: 4, max: 20 }
		},
		
		deposit_bonuses: { //move to admin
			code_length: { min: 6, max: 12 },
		},
		
		dailycases:{
			time: 24
		},
		
		items: {
			prices: {
				apikey: {
					key: ''
				},
				
				cooldown_load: 24 * 60 * 60
			}
		},
		
		
		
		
		interval_items: {
			deposit: { min: 1, max: 20 },
			withdraw: { min: 1, max: 20 },
			p2p: { min: 1, max: 20 }
		},
		
		admin: {
			casecreator_requirements: {
				name_length: { min: 4, max: 20 },
				items_length: { min: 2, max: 50 },
				
				unboxing: {
					offset: { min: -10, max: 10 }
				},
				dailycases: {
					level: { min: 0, max: 100 }
				}
			},
			gamebots_requirements: {
				name_length: { min: 4, max: 20 }
			}
		}
	},
	
	config_offers: {
		deposit_bonus: 5,
		
		steam: {
			time_cancel_trade: 5 * 60,
			time_remove_pending: 1 * 60,
		
			cooldown_inventory: 1 * 60,
			
			withdraw_offset: 10,
			deposit_offset: 0,
			
			game_apikey: 'csgo',
			
			bots: [
			
			/*
			
			{
				active: true,
				botname: '',
				steamid: '',
				username: '',
				password: '',
				identity_secret: '',
				shared_secret: '',
				can_trade: true,
				can_info: true,
				can_apikey: true
			}
			
			*/
			
			],
			
			prices: {
				apikey: {
					key: ''
				},
				
				cooldown_load: 1 * 60 * 60
			},
			
			games: {
				csgo: { game: { appid: 730, contextid: 2 } },
				dota2: { game: { appid: 570, contextid: 2 } },
				h1z1: { game: { appid: 433850, contextid: 1 } },
				rust: { game: { appid: 252490, contextid: 2 } },
				tf2: { game: { appid: 440, contextid: 2 } }
			},
			
			blacklist_items: {
				csgo: [],
				dota2: [],
				h1z1: [],
				rust: [],
				tf2: []
			}
		},
		
		p2p: {
			timer_confirm: 1 * 60,
			timer_send: 10 * 60,
			
			cooldown_tracking: 1,
			
			listing_validity: {
				enable: true,
				
				cooldown_checking: 1 * 60 * 60,
				cooldown_listing: 1 * 60,
				cooldown_fault: 10 * 60
			}
		},
		
		coinpayments: {
			apikey: {
				public_key: '',
				private_key: ''
			},
			
			prices: {
				cooldown_load: 1 * 60 * 60
			},
			
			cooldown_check: 1 * 60
		}
	},
	
	config_games: {
		winning_to_chat: 50000.00,
		
		eos_future: 10,
		
		commissions: {
			roulette: 5,
			crash: 5,
			jackpot: 5,
			coinflip: 5,
			dice: 5,
			unboxing: 0,
			casebattle: 0,
			upgrader: 0,
			minesweeper: 5,
			tower: 5,
			plinko: 5
		},
		
		games: {
			roulette: {
				timer: 20,
				cooldown_rolling: 10,
				total_bets: 3,
				normal_multiplier: 2,
				color_multiplier: 14,
			},
			
			crash: {
				timer: 5,
				max_profit: 5000.00,
				instant_chance: 5
			},
			
			jackpot: {
				timer: 30,
				total_bets: 3,
				bets_start: 2,
				users_start: 2,
				colors: [
					'#FF0000','#FF9D00','#FFF700','#1AFF00','#147AFF',
					'#C414FF','#14FFE4','#99FF14','#D55AED','#CC3798',
					'#965821','#A8A142','#A1ED8E','#37DBB5','#C45F41',
					'#F3408B','#05668D','#4CE0B3','#5D2E8C','#2CA58D',
					'#E9D758','#F68F71','#2B4570','#297373','#5B507A',
					'#1B2238','#C1A88D','#7880B5','#6987C9','#6C99B5',
					'#2B013B','#570C43','#8F065A','#F1EEFD','#AB90F0',
					'#23113A','#F9CC72','#791E94','#DE6449','#D8D4F2'
				]
			},
			
			coinflip: {
				cancel: false,
				timer_cancel: 1 * 60 * 60,
				timer_wait_start: 10,
				timer_delete: 1 * 60
			},
			
			dice: {},
			
			unboxing: {
				cases_length: { min: 1, max: 5 }
			},
			
			casebattle: {
				interval_cases: { min: 1, max: 20 },
				timer_countdown: 3,
				timer_wait_start: 1,
				timer_delete: 1 * 60,
			},
			
			upgrader: {
				interval_myitems: { min: 1, max: 15 },
				interval_siteitems: { min: 1, max: 15 },
			},
			
			minesweeper: {
				multipliers: {
					24: [24],
					23: [2.35294117647059, 24],
					22: [1.48251332071010, 4.54628193224559, 24],
					21: [1.27058823529412, 2.35294117647059, 6.68235294117647, 24],
					20: [1.18322730219403, 1.73866861693904, 3.42245182190568, 8.52672801826549, 24],
					19: [1.13708379723594, 1.48251332071010, 2.35294117647059, 4.54628193224559, 10.07315430783212, 24],
					18: [1.10897301030979, 1.34960492622279, 1.88096327625237, 3.05429764079371, 5.64522997664017, 11.36647242193310, 24],
					17: [1.09019607843137, 1.27058823529412, 1.63137254901961, 2.35294117647059, 3.79607843137255, 6.68235294117647, 12.45490196078431, 24],
					16: [1.07682445790281, 1.21908410361758, 1.48251332071010, 1.97031822187729, 2.87361066691832, 4.54628193224559, 7.64364998531782, 13.37919949528999, 24],
					15: [1.06684441533969, 1.18322730219403, 1.38586167761218, 1.73866861693904, 2.35294117647059, 3.42245182190568, 5.28457801157511, 8.52672801826549, 14.17163904749518, 24],
					14: [1.05912412107726, 1.15700449136128, 1.31904608643915, 1.58730701004609, 2.03141472880725, 2.76663797046067, 3.98380486991299, 5.99883265629076, 9.33472437475721, 14.85731499735958, 24],
					13: [1.05298127135399, 1.13708379723594, 1.27058823529412, 1.48251332071010, 1.81892342423787, 2.35294117647059, 3.20064151813450, 4.54628193224559, 6.68235294117647, 10.07315430783212, 15.45571596427649, 24],
					12: [1.04798127928913, 1.12148698494201, 1.23409525307447, 1.40660733141127, 1.67089003165735, 2.07576223726025, 2.69601283526430, 3.64621588452404, 5.10189498862801, 7.33194640319227, 10.74831014543421, 15.98206446297130, 24],
					11: [1.04383477902020, 1.10897301030979, 1.20576805001060, 1.34960492622279, 1.56334570284141, 1.88096327625237, 2.35294117647059, 3.05429764079371, 4.09650934142716, 5.64522997664017, 7.94661999603525, 11.36647242193310, 16.44835359650846, 24],
					10: [1.04034193122011, 1.09872756725392, 1.18322730219403, 1.30552116914473, 1.48251332071010, 1.73866861693904, 2.10939429717861, 2.64593416971851, 3.42245182190568, 4.54628193224559, 6.17276667904978, 8.52672801826549, 11.93354385063634, 16.86412360245150, 24],
					9: [1.03736043895914, 1.09019607843137, 1.16491695634966, 1.27058823529412, 1.42002999113069, 1.63137254901961, 1.93025606069274, 2.35294117647059, 2.95070819981686, 3.79607843137255, 4.99161247806509, 6.68235294117647, 9.07342103456155, 12.45490196078431, 17.23703814755448, 24],
					8: [1.03478631292767, 1.08298881409930, 1.14978178304750, 1.24233508614337, 1.37058382323122, 1.54829480722052, 1.79454435748952, 2.13576604028280, 2.60858817003326, 3.26376566213068, 4.17162830040779, 5.42963026158770, 7.17281129758209, 9.58829252735730, 12.93536288374635, 17.57331238735761, 24],
					7: [1.03254184315298, 1.07682445790281, 1.13708379723594, 1.21908410361758, 1.33066930055295, 1.48251332071010, 1.68914114492621, 1.97031822187729, 2.35294117647059, 2.87361066691832, 3.58213250291547, 4.54628193224559, 5.85828683435186, 7.64364998531782, 10.07315430783212, 13.37919949528999, 17.87803272650730, 24],
					6: [1.03056782089476, 1.07149520165624, 1.12629303961017, 1.19966208958491, 1.29789621149905, 1.42942228021006, 1.60552307302517, 1.84130514675421, 2.15699473226522, 2.57967281301977, 3.14559822883972, 3.90331808906822, 4.91783231750740, 6.27616957871519, 8.09485290859232, 10.52989547779339, 13.79018396035288, 18.15539758082668, 24],
					5: [1.02881836057952, 1.06684441533969, 1.11702009541123, 1.18322730219403, 1.27058823529412, 1.38586167761218, 1.53796589665289, 1.73866861693904, 2.00349744407025, 2.35294117647059, 2.81403494574284, 3.42245182190568, 4.22526270305027, 5.28457801157511, 6.68235294117647, 8.52672801826549, 10.96039552291682, 14.17163904749518, 18.40890028159455, 24],
					4: [1.02725736377704, 1.06275193578967, 1.10897301030979, 1.16916214934302, 1.24754051884601, 1.34960492622279, 1.48251332071010, 1.65558679244429, 1.88096327625237, 2.17444880551768, 2.55662601599136, 3.05429764079371, 3.70236623134739, 4.54628193224559, 5.64522997664017, 7.07628144658353, 8.93979839815632, 11.36647242193310, 14.52649026491702, 18.64146931448683, 24],
					3: [1.02585604962438, 1.05912412107726, 1.10192898084015, 1.15700449136128, 1.22786821748876, 1.31904608643915, 1.43636144989291, 1.58730701004609, 1.78152336380556, 2.03141472880725, 2.35294117647059, 2.76663797046067, 3.29892711370675, 3.98380486991299, 4.86501303825102, 5.99883265629076, 7.45767855949694, 9.33472437475721, 11.74985333720809, 14.85731499735958, 18.85557683738662, 24],
					2: [1.02459119524375, 1.05588697115258, 1.09571527473958, 1.14640242725625, 1.21090900169864, 1.29300274616223, 1.39747865328193, 1.53043902973700, 1.69964992432937, 1.91499473315235, 2.18905147635864, 2.53782746453943, 2.98169426565631, 3.54657758277160, 4.26547154184280, 5.18036583723156, 6.34469829707909, 7.82647611981492, 9.71224808930829, 12.11215978076630, 15.16638702561404, 19.05332340597023, 24],
					1: [1.02344385940228, 1.05298127135399, 1.09019607843137, 1.13708379723594, 1.19615862113936, 1.27058823529412, 1.36436367290325, 1.48251332071010, 1.63137254901961, 1.81892342423787, 2.05522271985156, 2.35294117647059, 2.72804292690711, 3.20064151813450, 3.79607843137255, 4.54628193224559, 5.49147911470037, 6.68235294117647, 8.18275994292256, 10.07315430783212, 12.45490196078431, 15.45571596427649, 19.23650469409561, 24],
				}
			},
			
			tower: {
				multipliers: [1.45, 2.1025, 3.048625, 4.42050625, 6.4097340625, 9.294114390625, 13.47646586640625, 19.54087550628906, 28.33426948411914, 41.08469075197275]
			},
			
			plinko: {
				results: {
					low: [7.1, 4, 1.9, 1.4, 1.3, 1.1, 1, 0.5, 1, 1.1, 1.3, 1.4, 1.9, 4, 7.1],
					medium: [58, 15, 7, 4, 1.9, 1, 0.5, 0.2, 0.5, 1, 1.9, 4, 7, 15, 58],
					high: [420, 56, 18, 5, 1.9, 0.3, 0.2, 0.2, 0.2, 0.3, 1.9, 5, 18, 56, 420]
				}
			}
		}
	},
	
	config_chat: {
		max_messages: 40,
		
		cooldown_massage: 1,
		
		channels: ['en', 'ro', 'fr', 'ru', 'de'],
	
		support: {
			active: false,
			message: 'If you find bugs contact us as soon as possible to solve them! With all due respect, the VGOWitch team.',
			cooldown: 24 * 60 * 60
		},
		
		greeting: {
			active: true,
			message: 'Please contact us if you need help. We don\'t resolve issues in the chat. Type /help for chat commands. With all due respect, the VGOWitch team.',
		},
		
		message_double_xp: 'Weekly Double XP! Get double XP betting on our games until Sunday at 23:59PM GTM.'
	}
}

module.exports = config;